import tkinter as tk
from tkinter import ttk, messagebox, filedialog
import requests
import os
import threading
import datetime
import sys
import subprocess

class LoadingSplash:
    """Splash screen with loading bar shown during startup checks"""
    def __init__(self, root):
        self.root = root
        self.splash = tk.Toplevel(root)
        self.splash.title("LM Studio Orchestrator")
        self.splash.geometry("400x150")
        self.splash.resizable(False, False)
        
        # Center on screen
        self.splash.update_idletasks()
        x = (self.splash.winfo_screenwidth() // 2) - 200
        y = (self.splash.winfo_screenheight() // 2) - 75
        self.splash.geometry(f"+{x}+{y}")
        
        # Remove window decorations for cleaner look
        self.splash.attributes('-topmost', True)
        
        # Content
        ttk.Label(self.splash, text="LM Studio Multi-Model Orchestrator", font=("Arial", 12, "bold")).pack(pady=15)
        ttk.Label(self.splash, text="Checking server...", font=("Arial", 9)).pack(pady=(0, 10))
        
        self.progress = ttk.Progressbar(self.splash, mode='indeterminate', length=300)
        self.progress.pack(pady=10)
        self.progress.start()
    
    def update_status(self, text):
        """Update status text on splash screen"""
        self.status_text.config(text=text)
        self.splash.update()
    
    def close(self):
        """Close splash screen"""
        self.progress.stop()
        self.splash.destroy()

class ChatWindow:
    """Separate window for direct chat interface - Facebook Messenger style"""
    def __init__(self, parent, parent_app):
        self.parent_app = parent_app
        self.window = tk.Toplevel(parent)
        self.window.title("Chat - LM Studio")
        self.window.geometry("600x700")
        self.window.resizable(True, True)
        self.window.configure(bg="#fff")
        
        # Store message labels for responsive updates
        self.message_labels = []
        
        # Header with title and resolution
        header_frame = tk.Frame(self.window, bg="#f0f2f5")
        header_frame.pack(fill=tk.X, side=tk.TOP)
        
        # Title on left
        ttk.Label(header_frame, text="LM Studio Chat", font=("Arial", 14, "bold"), background="#f0f2f5").pack(side=tk.LEFT, pady=10, padx=10, fill=tk.X, expand=True)
        
        # Resolution counter on right
        self.chat_resolution_label = ttk.Label(header_frame, text="600x700", font=("Courier", 9), background="#f0f2f5", foreground="blue")
        self.chat_resolution_label.pack(side=tk.RIGHT, pady=10, padx=10)
        
        # Bind window resize event to update resolution display
        self.window.bind("<Configure>", self.update_chat_resolution)
        
        # Messages frame with scrollbar
        messages_container = tk.Frame(self.window, bg="#fff")
        messages_container.pack(fill=tk.BOTH, expand=True, side=tk.TOP)
        
        self.canvas = tk.Canvas(messages_container, bg="#fff", highlightthickness=0)
        scrollbar = ttk.Scrollbar(messages_container, orient="vertical", command=self.canvas.yview)
        self.messages_frame = tk.Frame(self.canvas, bg="#fff")
        
        self.messages_frame.bind(
            "<Configure>",
            lambda e: self.canvas.configure(scrollregion=self.canvas.bbox("all"))
        )
        
        # Bind canvas resize to update message wraplengths
        self.canvas.bind("<Configure>", self.update_message_wraplengths)
        
        self.canvas.create_window((0, 0), window=self.messages_frame, anchor="nw")
        self.canvas.configure(yscrollcommand=scrollbar.set)
        
        self.canvas.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        
        # Bind mousewheel only to canvas (not globally)
        def _on_mousewheel(event):
            try:
                if self.canvas.winfo_exists():
                    self.canvas.yview_scroll(int(-1*(event.delta/120)), "units")
            except:
                pass  # Canvas was destroyed, ignore
        
        self.canvas.bind("<MouseWheel>", _on_mousewheel)
        self.messages_frame.bind("<MouseWheel>", _on_mousewheel)
        
        # Input frame
        input_frame = tk.Frame(self.window, bg="#f0f2f5")
        input_frame.pack(fill=tk.BOTH, side=tk.BOTTOM, padx=0, pady=0)
        
        # Input field with icon
        input_sub_frame = tk.Frame(input_frame, bg="#f0f2f5")
        input_sub_frame.pack(fill=tk.X, expand=True, padx=10, pady=10)
        
        self.chat_input = tk.Text(input_sub_frame, height=2, font=("Arial", 10), wrap=tk.WORD, 
                                   bg="white", fg="#000", relief=tk.SOLID, bd=1)
        self.chat_input.pack(side=tk.LEFT, fill=tk.BOTH, expand=True, padx=(0, 8))
        self.chat_input.bind('<Control-Return>', lambda e: self.send_chat())
        
        # Send button (blue like Messenger)
        send_btn = tk.Button(input_sub_frame, text="➤", font=("Arial", 12, "bold"), 
                            bg="#0084ff", fg="white", relief=tk.FLAT, bd=0, padx=12, pady=6,
                            command=self.send_chat, cursor="hand2")
        send_btn.pack(side=tk.LEFT)
        
        # Options frame
        options_frame = tk.Frame(input_frame, bg="#f0f2f5")
        options_frame.pack(fill=tk.X, padx=10, pady=(0, 10))
        
        ttk.Button(options_frame, text="📋 Copy", command=self.copy_chat_output).pack(side=tk.LEFT, padx=(0, 5))
        ttk.Button(options_frame, text="🗑️ Clear", command=self.clear_chat_output).pack(side=tk.LEFT)
    
    def update_chat_resolution(self, event=None):
        """Update chat window resolution display"""
        width = self.window.winfo_width()
        height = self.window.winfo_height()
        if width > 1 and height > 1:  # Skip initial configure events
            self.chat_resolution_label.config(text=f"{width}x{height}")
    
    def update_message_wraplengths(self, event=None):
        """Update wraplength for all messages based on canvas width"""
        canvas_width = self.canvas.winfo_width()
        if canvas_width > 1:
            # Calculate max bubble width (canvas width - padding)
            max_width = max(canvas_width - 100, 150)  # Min 150 to prevent too narrow text
            
            # Update all existing message labels
            for label in self.message_labels:
                label.config(wraplength=max_width)
    
    def add_message(self, text, is_user=True):
        """Add a message bubble to the chat"""
        msg_frame = tk.Frame(self.messages_frame, bg="#fff")
        msg_frame.pack(fill=tk.X, padx=10, pady=5, anchor=tk.E if is_user else tk.W)
        
        # Get current canvas width for initial wraplength
        canvas_width = self.canvas.winfo_width()
        if canvas_width < 2:
            canvas_width = 600  # Default width if not yet rendered
        max_width = max(canvas_width - 100, 150)
        
        if is_user:
            # User message (right, blue)
            bubble_frame = tk.Frame(msg_frame, bg="#0084ff", relief=tk.FLAT)
            bubble_frame.pack(side=tk.RIGHT, padx=(50, 0), fill=tk.X, expand=False)
            
            msg_label = tk.Label(bubble_frame, text=text, font=("Arial", 10), 
                                fg="white", bg="#0084ff", wraplength=max_width, justify=tk.LEFT, padx=12, pady=8)
            msg_label.pack(fill=tk.BOTH, expand=True)
        else:
            # Assistant message (left, gray)
            bubble_frame = tk.Frame(msg_frame, bg="#e4e6eb", relief=tk.FLAT)
            bubble_frame.pack(side=tk.LEFT, padx=(0, 50), fill=tk.X, expand=False)
            
            msg_label = tk.Label(bubble_frame, text=text, font=("Arial", 10), 
                                fg="#000", bg="#e4e6eb", wraplength=max_width, justify=tk.LEFT, padx=12, pady=8)
            msg_label.pack(fill=tk.BOTH, expand=True)
        
        # Store label for later updates
        self.message_labels.append(msg_label)
        
        # Auto-scroll to bottom
        self.messages_frame.update_idletasks()
        self.canvas.yview_moveto(1)
    
    def send_chat(self):
        """Send a chat message to the currently loaded model"""
        if not self.parent_app.current_model:
            messagebox.showwarning("No Model", "Please load a model first.")
            return
        
        # Get user input
        user_message = self.chat_input.get("1.0", tk.END).strip()
        if not user_message:
            messagebox.showwarning("Empty Message", "Please type a message.")
            return
        
        try:
            # Display user message
            self.add_message(user_message, is_user=True)
            
            # Clear input field
            self.chat_input.delete("1.0", tk.END)
            self.window.update()
            
            # Show typing indicator
            self.add_message("Thinking...", is_user=False)
            self.window.update()
            
            # Build prompt with uploaded documents if available
            chat_prompt = user_message
            if self.parent_app.uploaded_documents:
                # Read all uploaded files
                all_content = []
                for file_path in self.parent_app.uploaded_documents:
                    with open(file_path, 'r', encoding='utf-8') as f:
                        content = f.read()
                        all_content.append(f"=== {os.path.basename(file_path)} ===\n{content}")
                
                combined_content = "\n\n".join(all_content)
                chat_prompt = f"""Here are some documents:

{combined_content}

User's question: {user_message}"""
            
            # Send to LM Studio API
            response = requests.post(
                f"{self.parent_app.api_base}/v1/chat/completions",
                json={
                    "model": self.parent_app.current_model,
                    "messages": [
                        {"role": "user", "content": chat_prompt}
                    ],
                    "temperature": self.parent_app.temperature_var.get(),
                    "max_tokens": self.parent_app.max_tokens_var.get()
                },
                timeout=60
            )
            
            if response.status_code == 200:
                result = response.json()
                assistant_message = result['choices'][0]['message']['content']
                
                # Extract token usage and update parent app
                if 'usage' in result:
                    tokens_used = result['usage'].get('total_tokens', 0)
                    self.parent_app.reasoning_tokens = tokens_used
                    self.parent_app.session_tokens += tokens_used
                    
                    # Update token display in main window
                    self.parent_app.reasoning_tokens_label.config(text=str(self.parent_app.reasoning_tokens))
                    self.parent_app.session_tokens_label.config(text=str(self.parent_app.session_tokens))
                
                # Remove typing indicator and add real response
                self.messages_frame.winfo_children()[-1].destroy()
                self.add_message(assistant_message, is_user=False)
            else:
                self.messages_frame.winfo_children()[-1].destroy()
                self.add_message(f"API Error: {response.status_code}", is_user=False)
        
        except requests.exceptions.RequestException as e:
            if self.messages_frame.winfo_children():
                self.messages_frame.winfo_children()[-1].destroy()
            self.add_message(f"Failed to connect to LM Studio:\n{str(e)}", is_user=False)
        except KeyError:
            if self.messages_frame.winfo_children():
                self.messages_frame.winfo_children()[-1].destroy()
            self.add_message("Unexpected response format from LM Studio.", is_user=False)
    
    def copy_chat_output(self):
        """Copy last assistant message to clipboard"""
        # Find the last assistant message (gray bubble)
        for widget in reversed(self.messages_frame.winfo_children()):
            for child in widget.winfo_children():
                if isinstance(child, tk.Frame) and child.cget("bg") == "#e4e6eb":
                    # Found assistant message frame
                    for label in child.winfo_children():
                        if isinstance(label, tk.Label):
                            text = label.cget("text")
                            if text.strip():
                                self.parent_app.root.clipboard_clear()
                                self.parent_app.root.clipboard_append(text)
                                messagebox.showinfo("Success", "Message copied to clipboard!")
                                return
        messagebox.showwarning("Empty", "No message to copy.")
    
    def clear_chat_output(self):
        """Clear all chat messages"""
        for widget in self.messages_frame.winfo_children():
            widget.destroy()

class LMStudioOrchestrator:
    def __init__(self, root):
        self.root = root
        self.root.title("LM Studio Multi-Model Orchestrator")
        self.root.geometry("900x624")
        self.root.resizable(False, False)  # Start locked
        
        # Window lock state
        self.window_locked = True
        
        # API Config
        self.api_base = "http://localhost:1234"
        self.model_keys = {}
        self.current_model = None
        self.uploaded_documents = []
        self.loading_model = False
        
        # Document settings
        self.max_tokens_var = tk.IntVar(value=2000)
        self.temperature_var = tk.DoubleVar(value=0.7)
        
        # Token tracking
        self.session_tokens = 0
        self.reasoning_tokens = 0
        
        # Logging
        self.error_log = []
        # Set up log file
        self.log_file_path = os.path.join(os.path.expanduser("~"), "Downloads", "lm_studio_logs.txt")
        self._initialize_log_file()
        
        # ===== TOP TAB MENU BAR =====
        menu_bar = tk.Frame(self.root, bg="#f0f0f0", relief=tk.RIDGE, bd=1)
        menu_bar.pack(fill=tk.X, side=tk.TOP)
        menu_bar.grid_rowconfigure(0, weight=1)
        
        # File Menu (Exit button)
        file_menu_btn = tk.Button(
            menu_bar,
            text="File",
            font=("Arial", 10, "bold"),
            bg="#e8e8e8",
            activebackground="#d0d0d0",
            relief=tk.FLAT,
            bd=0,
            pady=8,
            command=self.show_file_menu,
            justify=tk.CENTER
        )
        file_menu_btn.grid(row=0, column=0, sticky="nsew", padx=3, pady=5)
        menu_bar.grid_columnconfigure(0, weight=0, minsize=50)
        
        self.tab_buttons = {}
        self.tab_frames = {}
        self.current_tab = "model_control"
        
        # Tab button specs
        tabs = [
            ("model_control", "Model Control")
        ]
        
        for idx, (tab_id, tab_label) in enumerate(tabs, start=1):
            btn = tk.Button(
                menu_bar,
                text=tab_label,
                font=("Arial", 10, "bold"),
                bg="#e8e8e8",
                activebackground="#d0d0d0",
                relief=tk.FLAT,
                bd=0,
                pady=8,
                command=lambda tid=tab_id: self.switch_tab(tid),
                justify=tk.CENTER
            )
            btn.grid(row=0, column=idx, sticky="nsew", padx=3, pady=5)
            menu_bar.grid_columnconfigure(idx, weight=1)
            self.tab_buttons[tab_id] = btn
        
        # Update tab appearance to highlight active tab
        self.update_tab_appearance()
        
        # ===== MAIN CONTAINER FRAME =====
        self.main_container = tk.Frame(self.root)
        self.main_container.pack(fill=tk.BOTH, expand=True)
        
        # ===== TAB 1: MODEL CONTROL =====
        self.model_control_frame = tk.Frame(self.main_container)
        self.tab_frames["model_control"] = self.model_control_frame
        
        # Scrollable container for model control
        canvas = tk.Canvas(self.model_control_frame, bg="white", highlightthickness=0)
        scrollbar = ttk.Scrollbar(self.model_control_frame, orient="vertical", command=canvas.yview)
        scrollable_frame = ttk.Frame(canvas)
        
        scrollable_frame.bind(
            "<Configure>",
            lambda e: canvas.configure(scrollregion=canvas.bbox("all"))
        )
        
        canvas.create_window((0, 0), window=scrollable_frame, anchor="nw")
        canvas.configure(yscrollcommand=scrollbar.set)
        
        canvas.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        
        # Bind mousewheel
        def _on_mousewheel(event):
            try:
                if canvas.winfo_exists():
                    canvas.yview_scroll(int(-1*(event.delta/120)), "units")
            except:
                pass
        canvas.bind("<MouseWheel>", _on_mousewheel)
        scrollable_frame.bind("<MouseWheel>", _on_mousewheel)
        
        # ===== CONTROL PANEL =====
        control_panel = ttk.LabelFrame(scrollable_frame, text="Model Control", padding=10)
        control_panel.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)
        
        # Connection status
        ttk.Label(control_panel, text="LM Studio Status:", font=("Arial", 10, "bold")).pack(anchor=tk.W, pady=(0, 5))
        
        status_row = ttk.Frame(control_panel)
        status_row.pack(fill=tk.X, pady=(0, 5))
        
        self.status_label = ttk.Label(status_row, text="❌ Disconnected", foreground="red", font=("Arial", 9))
        self.status_label.pack(side=tk.LEFT, padx=(0, 15))
        
        ttk.Label(status_row, text="Server:", font=("Arial", 9)).pack(side=tk.LEFT, padx=(0, 5))
        self.server_label = ttk.Label(status_row, text=self.api_base, foreground="blue", font=("Courier", 9))
        self.server_label.pack(side=tk.LEFT)
        
        # Window resolution display with lock button
        resolution_frame = ttk.Frame(status_row)
        resolution_frame.pack(side=tk.RIGHT)
        
        self.resolution_label = ttk.Label(resolution_frame, text="491x624", foreground="blue", font=("Courier", 9))
        self.resolution_label.pack(side=tk.LEFT, padx=(0, 5))
        
        self.lock_button = tk.Button(resolution_frame, text="🔒", font=("Arial", 8), command=self.toggle_window_lock, relief=tk.FLAT, bd=0, padx=3, pady=0)
        self.lock_button.pack(side=tk.LEFT)
        
        # Model load status
        model_status_row = ttk.Frame(control_panel)
        model_status_row.pack(anchor=tk.W, pady=(0, 10))
        
        self.model_status_label = ttk.Label(model_status_row, text="❌ No Model Loaded", foreground="red", font=("Arial", 9))
        self.model_status_label.pack(side=tk.LEFT, padx=(0, 15))
        
        ttk.Label(model_status_row, text="Model:", font=("Arial", 9)).pack(side=tk.LEFT, padx=(0, 5))
        self.model_name_label = ttk.Label(model_status_row, text="Waiting...", foreground="blue", font=("Courier", 9))
        self.model_name_label.pack(side=tk.LEFT)
        
        # Token tracking
        token_row = ttk.Frame(control_panel)
        token_row.pack(anchor=tk.W, pady=(0, 10))
        
        ttk.Label(token_row, text="Tokens used:", font=("Arial", 9)).pack(side=tk.LEFT, padx=(0, 10))
        self.session_tokens_label = ttk.Label(token_row, text="0", foreground="green", font=("Courier", 9, "bold"))
        self.session_tokens_label.pack(side=tk.LEFT, padx=(0, 20))
        
        ttk.Label(token_row, text="Reasoning:", font=("Arial", 9)).pack(side=tk.LEFT, padx=(0, 10))
        self.reasoning_tokens_label = ttk.Label(token_row, text="0", foreground="blue", font=("Courier", 9, "bold"))
        self.reasoning_tokens_label.pack(side=tk.LEFT)
        
        ttk.Button(control_panel, text="Refresh Script", command=self.refresh_script).pack(fill=tk.X, pady=3)
        ttk.Button(control_panel, text="Restart Script", command=self.restart_script).pack(fill=tk.X, pady=3)
        
        # Model selection
        ttk.Separator(control_panel, orient="horizontal").pack(fill=tk.X, pady=15)
        ttk.Label(control_panel, text="MODEL MANAGEMENT", font=("Arial", 11, "bold")).pack(anchor=tk.W, pady=(0, 8))
        
        ttk.Label(control_panel, text="Available Models:", font=("Arial", 9)).pack(anchor=tk.W, pady=(0, 3))
        ttk.Label(control_panel, text="(double-click to load)", font=("Arial", 8), foreground="gray").pack(anchor=tk.W, pady=(0, 5))
        
        self.models_listbox = tk.Listbox(control_panel, height=4, font=("Arial", 9), selectmode=tk.SINGLE)
        self.models_listbox.pack(fill=tk.X, pady=(0, 8))
        self.models_listbox.bind('<Double-Button-1>', self.on_model_select)
        self.models_listbox.bind('<Motion>', self.on_listbox_hover)
        
        # Max tokens and temperature
        tokens_row = ttk.Frame(control_panel)
        tokens_row.pack(fill=tk.X, pady=(0, 15))
        
        ttk.Label(tokens_row, text="Max Tokens:", font=("Arial", 9)).pack(side=tk.LEFT, padx=(0, 5))
        ttk.Spinbox(tokens_row, from_=100, to=32000, textvariable=self.max_tokens_var, width=10).pack(side=tk.LEFT, padx=(0, 20))
        
        ttk.Label(tokens_row, text="Temperature:", font=("Arial", 9)).pack(side=tk.LEFT, padx=(0, 5))
        ttk.Spinbox(tokens_row, from_=0.0, to=2.0, increment=0.1, textvariable=self.temperature_var, width=10).pack(side=tk.LEFT, padx=(0, 20))
        
        ttk.Button(tokens_row, text="💬 Open Chat", command=self.open_chat_window).pack(side=tk.LEFT)
        
        # ===== DISCUSSIONS SECTION (in Model Control tab) =====
        ttk.Separator(control_panel, orient="horizontal").pack(fill=tk.X, pady=15)
        ttk.Label(control_panel, text="MODEL DISCUSSIONS", font=("Arial", 11, "bold")).pack(anchor=tk.W, pady=(0, 8))
        
        # Model selection row
        ttk.Label(control_panel, text="Select Models for Discussion:", font=("Arial", 9)).pack(anchor=tk.W, pady=(0, 3))
        
        model_select_frame = ttk.Frame(control_panel)
        model_select_frame.pack(fill=tk.X, pady=(0, 10))
        
        # Left model dropdown
        ttk.Label(model_select_frame, text="Model 1:", font=("Arial", 9)).pack(side=tk.LEFT, padx=(0, 5))
        self.model1_var = tk.StringVar(value="Select Model")
        self.model1_dropdown = ttk.Combobox(model_select_frame, textvariable=self.model1_var, state="readonly", width=30)
        self.model1_dropdown.pack(side=tk.LEFT, padx=(0, 10))
        
        # Right model dropdown
        ttk.Label(model_select_frame, text="Model 2:", font=("Arial", 9)).pack(side=tk.LEFT, padx=(0, 5))
        self.model2_var = tk.StringVar(value="Select Model")
        self.model2_dropdown = ttk.Combobox(model_select_frame, textvariable=self.model2_var, state="readonly", width=30)
        self.model2_dropdown.pack(side=tk.LEFT)
        
        # Discussion prompt input
        ttk.Label(control_panel, text="Discussion Prompt:", font=("Arial", 9)).pack(anchor=tk.W, pady=(0, 3))
        
        self.discussion_input = tk.Text(control_panel, height=3, font=("Arial", 9), wrap=tk.WORD, 
                                        bg="white", fg="#000", relief=tk.SOLID, bd=1)
        self.discussion_input.pack(fill=tk.X, pady=(0, 8))
        
        # Start button
        button_row = ttk.Frame(control_panel)
        button_row.pack(fill=tk.X, pady=(0, 10))
        
        ttk.Button(button_row, text="Submit", command=self.start_discussion).pack(side=tk.LEFT, padx=(0, 5))
        ttk.Button(button_row, text="🗑️ Clear", command=self.clear_discussion).pack(side=tk.LEFT)
        
        # Outputs section
        ttk.Label(control_panel, text="Responses:", font=("Arial", 9)).pack(anchor=tk.W, pady=(0, 5))
        
        # Vertical output layout - Model 1 top, Model 2 bottom
        outputs_container = ttk.Frame(control_panel)
        outputs_container.pack(fill=tk.BOTH, expand=True, pady=(0, 0))
        
        # Model 1 output (top)
        model1_col = ttk.Frame(outputs_container)
        model1_col.pack(fill=tk.BOTH, expand=True, pady=(0, 3))
        
        model1_label_frame = ttk.LabelFrame(model1_col, text="Model 1 Response", padding=5)
        model1_label_frame.pack(fill=tk.BOTH, expand=True)
        
        self.model1_output = tk.Text(model1_label_frame, height=10, font=("Courier", 8), wrap=tk.WORD,
                                     bg="#f0f0f0", fg="#000", relief=tk.SOLID, bd=1, state=tk.DISABLED)
        self.model1_output.pack(fill=tk.BOTH, expand=True)
        
        model1_btn_frame = ttk.Frame(model1_col)
        model1_btn_frame.pack(fill=tk.X, pady=(2, 0))
        ttk.Button(model1_btn_frame, text="📋 Copy", command=lambda: self.copy_discussion_output(1)).pack(side=tk.LEFT, padx=(0, 3))
        
        # Model 2 output (bottom)
        model2_col = ttk.Frame(outputs_container)
        model2_col.pack(fill=tk.BOTH, expand=True, pady=(3, 0))
        
        model2_label_frame = ttk.LabelFrame(model2_col, text="Model 2 Response", padding=5)
        model2_label_frame.pack(fill=tk.BOTH, expand=True)
        
        self.model2_output = tk.Text(model2_label_frame, height=10, font=("Courier", 8), wrap=tk.WORD,
                                     bg="#f0f0f0", fg="#000", relief=tk.SOLID, bd=1, state=tk.DISABLED)
        self.model2_output.pack(fill=tk.BOTH, expand=True)
        
        model2_btn_frame = ttk.Frame(model2_col)
        model2_btn_frame.pack(fill=tk.X, pady=(2, 0))
        ttk.Button(model2_btn_frame, text="📋 Copy", command=lambda: self.copy_discussion_output(2)).pack(side=tk.LEFT, padx=(0, 3))
        
        # ===== DOCUMENT UPLOAD SECTION =====
        ttk.Separator(control_panel, orient="horizontal").pack(fill=tk.X, pady=15)
        ttk.Label(control_panel, text="DOCUMENT UPLOAD", font=("Arial", 11, "bold")).pack(anchor=tk.W, pady=(0, 8))
        
        doc_main_frame = ttk.Frame(control_panel)
        doc_main_frame.pack(fill=tk.BOTH, expand=True, pady=(0, 15))
        
        left_frame = ttk.Frame(doc_main_frame)
        left_frame.pack(side=tk.LEFT, fill=tk.BOTH, expand=False, padx=(0, 8))
        
        ttk.Label(left_frame, text="Uploaded Files (Max 2):", font=("Arial", 9)).pack(anchor=tk.W, pady=(0, 3))
        
        upload_button_frame = ttk.Frame(left_frame)
        upload_button_frame.pack(fill=tk.X, pady=(0, 8))
        
        ttk.Button(upload_button_frame, text="Add Files", command=self.browse_document).pack(side=tk.LEFT, padx=(0, 5))
        ttk.Button(upload_button_frame, text="Submit", command=self.submit_document).pack(side=tk.LEFT, padx=(0, 5))
        ttk.Button(upload_button_frame, text="View Output", command=self.open_last_output).pack(side=tk.LEFT)
        
        self.files_frame = ttk.Frame(left_frame)
        self.files_frame.pack(fill=tk.X)
        
        self.last_output_file = None
        
        # Initialize chat window reference
        self.chat_window = None
        
        # Initialize logs_listbox as None (no UI display, only file logging)
        self.logs_listbox = None
        
        # Store model display names for dropdown updates
        self.model_display_names = {}
        
        # Bind window resize event
        self.root.bind("<Configure>", self.update_resolution)
        
        # Bind window close (X button) to clean exit
        self.root.protocol("WM_DELETE_WINDOW", self.exit_app)
        
        # Run startup checks
        self.run_startup_checks()
    
    def switch_tab(self, tab_id):
        """Switch to a different tab"""
        # Hide all frames
        for frame in self.tab_frames.values():
            frame.pack_forget()
        
        # Show selected frame
        if tab_id in self.tab_frames:
            self.tab_frames[tab_id].pack(fill=tk.BOTH, expand=True)
            self.current_tab = tab_id
            self.update_tab_appearance()
    
    def update_tab_appearance(self):
        """Update tab button styling to highlight active tab"""
        for tab_id, btn in self.tab_buttons.items():
            if tab_id == self.current_tab:
                btn.config(bg="#4a9eff", fg="white")
            else:
                btn.config(bg="#e8e8e8", fg="black")
    
    def _initialize_log_file(self):
        """Create or append to log file with session separator"""
        try:
            with open(self.log_file_path, 'a', encoding='utf-8') as f:
                f.write(f"\n{'='*60}\nSession started: {datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n{'='*60}\n")
        except Exception as e:
            pass  # Silently fail
    
    def show_file_menu(self):
        """Show File menu with View Log and Exit options"""
        menu = tk.Menu(self.root, tearoff=0)
        menu.add_command(label="View Log File", command=self.open_log_file)
        menu.add_separator()
        menu.add_command(label="Exit", command=self.exit_app)
        
        # Get File button position for menu placement
        try:
            menu.post(self.root.winfo_x(), self.root.winfo_y() + 50)
        except:
            pass  # Fallback if positioning fails
    
    def exit_app(self):
        """Clean exit - save logs and close app"""
        self.add_log("Application closing", "SYSTEM")
        self.root.quit()
    
    def open_log_file(self):
        """Open the log file with default application"""
        if not os.path.exists(self.log_file_path):
            messagebox.showwarning("No Log File", f"Log file not found:\n{self.log_file_path}")
            return
        
        try:
            if os.name == 'nt':  # Windows
                os.startfile(self.log_file_path)
            else:  # macOS and Linux
                os.system(f'open "{self.log_file_path}"')
            self.add_log("Opened log file", "INFO")
        except Exception as e:
            messagebox.showerror("Error", f"Could not open log file:\n{str(e)}")
            self.add_log(f"Error opening log file: {str(e)}", "ERROR")
    
    def add_log(self, message, log_type="INFO"):
        """Add a message to the error logs and save to file"""
        timestamp = datetime.datetime.now().strftime("%H:%M:%S")
        log_entry = f"[{timestamp}] {log_type}: {message}"
        self.error_log.append(log_entry)
        
        # Write to log file
        try:
            with open(self.log_file_path, 'a', encoding='utf-8') as f:
                f.write(log_entry + "\n")
        except Exception as e:
            pass  # Silently fail if log write fails
        
        # Update listbox if it exists
        if self.logs_listbox and self.logs_listbox.winfo_exists():
            self.logs_listbox.insert(tk.END, log_entry)
            self.logs_listbox.see(tk.END)
        
        # Keep last 1000 entries in memory
        if len(self.error_log) > 1000:
            self.error_log.pop(0)
            if self.logs_listbox and self.logs_listbox.winfo_exists():
                self.logs_listbox.delete(0, 1)
    

    
    def clear_logs(self):
        """Clear all logs from memory and file"""
        if messagebox.askyesno("Clear Logs", "Clear all logs?"):
            if self.logs_listbox and self.logs_listbox.winfo_exists():
                self.logs_listbox.delete(0, tk.END)
            self.error_log.clear()
            # Clear log file
            try:
                with open(self.log_file_path, 'w', encoding='utf-8') as f:
                    f.write("")
            except:
                pass
            self.add_log("Logs cleared", "SYSTEM")
    
    def copy_log_entry(self):
        """Copy selected log entry to clipboard"""
        selection = self.logs_listbox.curselection()
        if selection:
            text = self.logs_listbox.get(selection[0])
            self.root.clipboard_clear()
            self.root.clipboard_append(text)
            messagebox.showinfo("Copied", "Log entry copied!")
        else:
            messagebox.showwarning("No Selection", "Select a log entry first.")

    
    def run_startup_checks(self):
        """Run startup checks in background with loading splash"""
        splash = LoadingSplash(self.root)
        self.add_log("Starting application...", "SYSTEM")
        
        def startup_thread():
            self.check_connection()
            self.refresh_models()
            splash.close()
            self.root.deiconify()
        
        thread = threading.Thread(target=startup_thread, daemon=True)
        thread.start()
    
    def update_resolution(self, event=None):
        """Update window resolution display"""
        width = self.root.winfo_width()
        height = self.root.winfo_height()
        if width > 1 and height > 1:
            self.resolution_label.config(text=f"{width}x{height}")
    
    def toggle_window_lock(self):
        """Toggle window resizing lock"""
        self.window_locked = not self.window_locked
        self.root.resizable(not self.window_locked, not self.window_locked)
        self.lock_button.config(text="🔒" if self.window_locked else "🔓")
    
    def refresh_models(self):
        """Fetch available models from LM Studio"""
        try:
            response = requests.get(f"{self.api_base}/api/v1/models", timeout=5)
            if response.status_code == 200:
                data = response.json()
                models = data.get("models", [])
                
                self.models_listbox.delete(0, tk.END)
                self.model_keys = {}
                
                llm_models = [m for m in models if m.get("type") == "llm"]
                
                if llm_models:
                    for idx, model in enumerate(llm_models):
                        display_name = model.get("display_name", "Unknown")
                        key = model.get("key", "unknown")
                        quantization = model.get("quantization", {}).get("name", "")
                        
                        display_text = f"{display_name} ({quantization})"
                        
                        self.models_listbox.insert(tk.END, display_text)
                        self.model_keys[idx] = key
                    self.add_log(f"Loaded {len(llm_models)} models", "INFO")
                else:
                    self.models_listbox.insert(tk.END, "No LLM models found")
                    self.add_log("No LLM models found", "WARNING")
                
                self.models_listbox.selection_clear(0, tk.END)
                self.update_discussion_models()  # Update discussion dropdowns
            else:
                self.models_listbox.delete(0, tk.END)
                self.models_listbox.insert(tk.END, "Failed to load models")
                self.add_log(f"Failed to load models: {response.status_code}", "ERROR")
        except Exception as e:
            self.models_listbox.delete(0, tk.END)
            self.models_listbox.insert(tk.END, f"Error: {str(e)}")
            self.add_log(f"Error fetching models: {str(e)}", "ERROR")
    
    def on_model_select(self, event):
        """Handle model selection from listbox"""
        if self.loading_model:
            return
        
        idx = self.models_listbox.nearest(event.y)
        if idx >= 0:
            model_key = self.model_keys.get(idx)
            if model_key:
                self.load_model(model_key)
    
    def on_listbox_hover(self, event):
        """Highlight listbox item on hover"""
        idx = self.models_listbox.nearest(event.y)
        if idx >= 0:
            self.models_listbox.selection_clear(0, tk.END)
            self.models_listbox.selection_set(idx)
            self.models_listbox.see(idx)
    
    def load_model(self, model_key):
        """Load a model by its key"""
        if not model_key:
            messagebox.showerror("Error", "Could not identify model")
            self.add_log("Failed to identify model", "ERROR")
            return
        
        self.loading_model = True
        
        try:
            response = requests.post(
                f"{self.api_base}/api/v1/models/load",
                json={"model": model_key},
                timeout=30
            )
            
            if response.status_code == 200:
                self.current_model = model_key
                self.check_connection()
                messagebox.showinfo("Success", f"Model loaded: {model_key}")
                self.add_log(f"Model loaded: {model_key}", "INFO")
            else:
                messagebox.showerror("Error", f"Failed to load model.\nStatus: {response.status_code}")
                self.add_log(f"Failed to load model: {response.status_code}", "ERROR")
        except Exception as e:
            messagebox.showerror("Error", f"Error loading model:\n{str(e)}")
            self.add_log(f"Error loading model: {str(e)}", "ERROR")
        finally:
            self.loading_model = False
    
    def refresh_script(self):
        """Refresh connection and model list"""
        self.check_connection()
        self.refresh_models()
        self.add_log("Script refreshed", "INFO")
    
    def restart_script(self):
        """Restart the application"""
        if messagebox.askyesno("Restart", "Restart? Token count will reset."):
            self.root.quit()
            subprocess.Popen([sys.executable, sys.argv[0]])
            sys.exit()
    
    def check_connection(self):
        """Check LM Studio API connection"""
        try:
            response = requests.get(f"{self.api_base}/api/v1/models", timeout=2)
            self.status_label.config(text="✅ Connected", foreground="green")
            self.add_log("Connected to LM Studio", "INFO")
            
            if response.status_code == 200:
                data = response.json()
                models = data.get("models", [])
                
                if self.current_model:
                    for model in models:
                        if model.get("key") == self.current_model:
                            display_name = model.get("display_name", "Unknown")
                            self.model_status_label.config(text="✅ Model Loaded", foreground="green")
                            self.model_name_label.config(text=display_name, foreground="blue")
                            return True
                    self.current_model = None
                
                self.model_status_label.config(text="❌ No Model Loaded", foreground="red")
                self.model_name_label.config(text="Waiting...", foreground="blue")
            return True
        except:
            self.status_label.config(text="❌ Disconnected", foreground="red")
            self.model_status_label.config(text="❌ No Model Loaded", foreground="red")
            self.model_name_label.config(text="Offline", foreground="blue")
            self.add_log("Lost connection to LM Studio", "ERROR")
            return False
    
    def browse_document(self):
        """Open file dialog for documents"""
        slots_available = 2 - len(self.uploaded_documents)
        
        if slots_available <= 0:
            messagebox.showwarning("File Limit", "Maximum 2 files. Remove one to add more.")
            return
        
        files = filedialog.askopenfilenames(
            title=f"Select Files (max {slots_available} remaining)",
            filetypes=[("Text/Markdown", "*.txt *.md"), ("Text", "*.txt"), ("Markdown", "*.md")]
        )
        
        if files:
            files_to_add = list(files)[:slots_available]
            
            for file_path in files_to_add:
                if file_path not in self.uploaded_documents:
                    self.uploaded_documents.append(file_path)
            
            self.update_files_display()
            file_count = len(files_to_add)
            filenames = ", ".join(os.path.basename(f) for f in files_to_add)
            messagebox.showinfo("Files Added", f"Added {file_count} file(s):\n{filenames}")
            self.add_log(f"Added {file_count} file(s)", "INFO")
    
    def update_files_display(self):
        """Update file chips display"""
        for widget in self.files_frame.winfo_children():
            widget.destroy()
        
        if len(self.uploaded_documents) == 0:
            ttk.Label(self.files_frame, text="No files", font=("Arial", 9), foreground="gray").pack(anchor=tk.W)
        else:
            for i, file_path in enumerate(self.uploaded_documents):
                self.create_file_chip(i, os.path.basename(file_path))
    
    def create_file_chip(self, index, filename):
        """Create a file chip with X button"""
        chip_frame = ttk.Frame(self.files_frame)
        chip_frame.pack(fill=tk.X, pady=2)
        
        ttk.Label(chip_frame, text=f"📎 {filename}", font=("Arial", 9), foreground="blue").pack(side=tk.LEFT, padx=(0, 8))
        
        remove_btn = tk.Button(chip_frame, text="✕", font=("Arial", 9, "bold"), 
                              fg="red", relief=tk.FLAT, bd=0, padx=4, 
                              command=lambda idx=index: self.remove_file_by_index(idx))
        remove_btn.pack(side=tk.LEFT)
    
    def remove_file_by_index(self, index):
        """Remove a file by index"""
        if 0 <= index < len(self.uploaded_documents):
            filename = os.path.basename(self.uploaded_documents[index])
            self.uploaded_documents.pop(index)
            self.update_files_display()
            self.add_log(f"Removed file: {filename}", "INFO")
    
    def submit_document(self):
        """Submit documents for analysis"""
        if not self.uploaded_documents:
            messagebox.showwarning("No Documents", "Add documents first.")
            return
        
        if not self.current_model:
            messagebox.showwarning("No Model", "Load a model first.")
            return
        
        try:
            messagebox.showinfo("Processing", "Analyzing documents...")
            self.add_log("Starting document analysis", "INFO")
            
            all_content = []
            for file_path in self.uploaded_documents:
                with open(file_path, 'r', encoding='utf-8') as f:
                    content = f.read()
                    all_content.append(f"=== {os.path.basename(file_path)} ===\n{content}")
            
            combined_content = "\n\n".join(all_content)
            prompt = f"""Examine thoroughly, fact check claims, verify information, and provide deep reasoning.

Documents:
{combined_content}

Provide a comprehensive analysis."""
            
            response = requests.post(
                f"{self.api_base}/v1/chat/completions",
                json={
                    "model": self.current_model,
                    "messages": [{"role": "user", "content": prompt}],
                    "temperature": self.temperature_var.get(),
                    "max_tokens": self.max_tokens_var.get()
                },
                timeout=120
            )
            
            if response.status_code == 200:
                result = response.json()
                analysis = result['choices'][0]['message']['content']
                
                if 'usage' in result:
                    tokens_used = result['usage'].get('total_tokens', 0)
                    self.reasoning_tokens = tokens_used
                    self.session_tokens += tokens_used
                    
                    self.reasoning_tokens_label.config(text=str(self.reasoning_tokens))
                    self.session_tokens_label.config(text=str(self.session_tokens))
                
                timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
                output_filename = f"analysis_{timestamp}.txt"
                output_path = os.path.join(os.path.expanduser("~"), "Downloads", output_filename)
                
                with open(output_path, 'w', encoding='utf-8') as f:
                    f.write(analysis)
                
                self.last_output_file = output_path
                messagebox.showinfo("Success", f"Saved:\n{output_filename}\n\nTokens: {self.reasoning_tokens}\nSession: {self.session_tokens}")
                self.add_log(f"Document analysis complete: {self.reasoning_tokens} tokens", "INFO")
            else:
                messagebox.showerror("API Error", f"Status: {response.status_code}")
                self.add_log(f"API error: {response.status_code}", "ERROR")
        
        except FileNotFoundError:
            messagebox.showerror("File Error", "Could not read a file.")
            self.add_log("File read error", "ERROR")
        except requests.exceptions.RequestException as e:
            messagebox.showerror("Connection Error", f"Failed to connect:\n{str(e)}")
            self.add_log(f"Connection error: {str(e)}", "ERROR")
        except KeyError:
            messagebox.showerror("Response Error", "Unexpected response format.")
            self.add_log("Unexpected response format", "ERROR")
        except Exception as e:
            messagebox.showerror("Error", f"An error occurred:\n{str(e)}")
            self.add_log(f"Error: {str(e)}", "ERROR")
    
    def open_last_output(self):
        """Open last output file"""
        if not self.last_output_file:
            messagebox.showwarning("No Output", "No analysis yet.")
            return
        
        if not os.path.exists(self.last_output_file):
            messagebox.showerror("File Not Found", f"File not found:\n{self.last_output_file}")
            self.last_output_file = None
            return
        
        try:
            if os.name == 'nt':
                os.startfile(self.last_output_file)
            else:
                os.system(f'open "{self.last_output_file}"')
        except Exception as e:
            messagebox.showerror("Error", f"Could not open:\n{str(e)}")
    
    def open_chat_window(self):
        """Open or focus chat window"""
        if self.chat_window is None or not self.chat_window.window.winfo_exists():
            self.chat_window = ChatWindow(self.root, self)
        else:
            self.chat_window.window.lift()
            self.chat_window.window.focus()
    
    def update_discussion_models(self):
        """Update discussion model dropdowns when models list changes"""
        try:
            response = requests.get(f"{self.api_base}/api/v1/models", timeout=5)
            if response.status_code == 200:
                data = response.json()
                models = data.get("models", [])
                llm_models = [m for m in models if m.get("type") == "llm"]
                
                model_options = []
                self.model_display_names = {}
                
                for model in llm_models:
                    display_name = model.get("display_name", "Unknown")
                    key = model.get("key", "unknown")
                    quantization = model.get("quantization", {}).get("name", "")
                    display_text = f"{display_name} ({quantization})" if quantization else display_name
                    
                    model_options.append(display_text)
                    self.model_display_names[display_text] = key
                
                self.model1_dropdown['values'] = model_options
                self.model2_dropdown['values'] = model_options
        except Exception as e:
            self.add_log(f"Error updating discussion models: {str(e)}", "ERROR")
    
    def start_discussion(self):
        """Start a chained discussion: Model 1 answers input, Model 2 answers Model 1"""
        model1_display = self.model1_var.get()
        model2_display = self.model2_var.get()
        prompt = self.discussion_input.get("1.0", tk.END).strip()
        
        if model1_display == "Select Model" or model2_display == "Select Model":
            messagebox.showwarning("Model Selection", "Please select both Model 1 and Model 2")
            self.add_log("Discussion error: models not selected", "WARNING")
            return
        
        if not prompt:
            messagebox.showwarning("Empty Prompt", "Please enter a discussion prompt")
            self.add_log("Discussion error: empty prompt", "WARNING")
            return
        
        model1_key = self.model_display_names.get(model1_display)
        model2_key = self.model_display_names.get(model2_display)
        
        if not model1_key or not model2_key:
            messagebox.showerror("Error", "Could not identify selected models")
            self.add_log("Discussion error: could not identify models", "ERROR")
            return
        
        # Clear previous outputs
        self.model1_output.config(state=tk.NORMAL)
        self.model2_output.config(state=tk.NORMAL)
        self.model1_output.delete("1.0", tk.END)
        self.model2_output.delete("1.0", tk.END)
        
        # Show loading message
        self.model1_output.insert(tk.END, "⏳ Model 1 thinking...")
        self.model2_output.insert(tk.END, "⏳ Waiting for Model 1...")
        self.model1_output.config(state=tk.DISABLED)
        self.model2_output.config(state=tk.DISABLED)
        self.root.update()
        
        # Run discussion in background thread
        def discussion_thread():
            try:
                # Step 1: Get response from Model 1 to user input
                self.add_log("Model 1: processing user input", "INFO")
                response1 = requests.post(
                    f"{self.api_base}/v1/chat/completions",
                    json={
                        "model": model1_key,
                        "messages": [{"role": "user", "content": prompt}],
                        "temperature": self.temperature_var.get(),
                        "max_tokens": self.max_tokens_var.get()
                    },
                    timeout=120
                )
                
                response_text1 = ""
                tokens1 = 0
                if response1.status_code == 200:
                    result1 = response1.json()
                    response_text1 = result1['choices'][0]['message']['content']
                    
                    if 'usage' in result1:
                        tokens1 = result1['usage'].get('total_tokens', 0)
                        self.session_tokens += tokens1
                else:
                    response_text1 = f"API Error: {response1.status_code}"
                
                # Update UI with Model 1 response
                self.model1_output.config(state=tk.NORMAL)
                self.model1_output.delete("1.0", tk.END)
                self.model1_output.insert(tk.END, response_text1)
                self.model1_output.config(state=tk.DISABLED)
                
                # Update Model 2 loading state
                self.model2_output.config(state=tk.NORMAL)
                self.model2_output.delete("1.0", tk.END)
                self.model2_output.insert(tk.END, "⏳ Model 2 processing Model 1's response...")
                self.model2_output.config(state=tk.DISABLED)
                self.root.update()
                
                # Step 2: Get response from Model 2 to Model 1's response
                self.add_log("Model 2: processing Model 1's response", "INFO")
                response2 = requests.post(
                    f"{self.api_base}/v1/chat/completions",
                    json={
                        "model": model2_key,
                        "messages": [{"role": "user", "content": response_text1}],
                        "temperature": self.temperature_var.get(),
                        "max_tokens": self.max_tokens_var.get()
                    },
                    timeout=120
                )
                
                response_text2 = ""
                tokens2 = 0
                if response2.status_code == 200:
                    result2 = response2.json()
                    response_text2 = result2['choices'][0]['message']['content']
                    
                    if 'usage' in result2:
                        tokens2 = result2['usage'].get('total_tokens', 0)
                        self.session_tokens += tokens2
                else:
                    response_text2 = f"API Error: {response2.status_code}"
                
                # Update UI with Model 2 response
                self.model2_output.config(state=tk.NORMAL)
                self.model2_output.delete("1.0", tk.END)
                self.model2_output.insert(tk.END, response_text2)
                self.model2_output.config(state=tk.DISABLED)
                
                # Update token display
                self.session_tokens_label.config(text=str(self.session_tokens))
                self.reasoning_tokens_label.config(text=str(tokens1 + tokens2))
                
                self.add_log(f"Discussion completed: Model 1 ({tokens1}t) → Model 2 ({tokens2}t)", "INFO")
                
            except requests.exceptions.RequestException as e:
                error_msg = f"Connection error: {str(e)}"
                self.model1_output.config(state=tk.NORMAL)
                self.model2_output.config(state=tk.NORMAL)
                self.model1_output.delete("1.0", tk.END)
                self.model2_output.delete("1.0", tk.END)
                self.model1_output.insert(tk.END, error_msg)
                self.model2_output.insert(tk.END, error_msg)
                self.model1_output.config(state=tk.DISABLED)
                self.model2_output.config(state=tk.DISABLED)
                self.session_tokens_label.config(text=str(self.session_tokens))
                self.add_log(f"Discussion error: {str(e)}", "ERROR")
            except Exception as e:
                error_msg = f"Error: {str(e)}"
                self.model1_output.config(state=tk.NORMAL)
                self.model2_output.config(state=tk.NORMAL)
                self.model1_output.delete("1.0", tk.END)
                self.model2_output.delete("1.0", tk.END)
                self.model1_output.insert(tk.END, error_msg)
                self.model2_output.insert(tk.END, error_msg)
                self.model1_output.config(state=tk.DISABLED)
                self.model2_output.config(state=tk.DISABLED)
                self.session_tokens_label.config(text=str(self.session_tokens))
                self.add_log(f"Discussion error: {str(e)}", "ERROR")
        
        thread = threading.Thread(target=discussion_thread, daemon=True)
        thread.start()
    
    def clear_discussion(self):
        """Clear discussion inputs and outputs"""
        self.discussion_input.delete("1.0", tk.END)
        self.model1_output.config(state=tk.NORMAL)
        self.model2_output.config(state=tk.NORMAL)
        self.model1_output.delete("1.0", tk.END)
        self.model2_output.delete("1.0", tk.END)
        self.model1_output.config(state=tk.DISABLED)
        self.model2_output.config(state=tk.DISABLED)
        self.add_log("Discussion cleared", "INFO")
    
    def copy_discussion_output(self, model_num):
        """Copy a model's discussion response to clipboard"""
        if model_num == 1:
            text = self.model1_output.get("1.0", tk.END).strip()
            if not text or text == "⏳ Generating response...":
                messagebox.showwarning("Empty", "No response to copy")
                return
        else:
            text = self.model2_output.get("1.0", tk.END).strip()
            if not text or text == "⏳ Generating response...":
                messagebox.showwarning("Empty", "No response to copy")
                return
        
        self.root.clipboard_clear()
        self.root.clipboard_append(text)
        messagebox.showinfo("Copied", f"Model {model_num} response copied to clipboard!")
        self.add_log(f"Copied Model {model_num} discussion response", "INFO")


if __name__ == "__main__":
    root = tk.Tk()
    root.withdraw()
    app = LMStudioOrchestrator(root)
    root.mainloop()
