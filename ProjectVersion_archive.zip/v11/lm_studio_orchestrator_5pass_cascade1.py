import tkinter as tk
from tkinter import ttk, messagebox, filedialog
import requests
import os
import threading
import datetime
import sys
import subprocess

class LoadingSplash:
    """Splash screen with loading bar shown during startup checks"""
    def __init__(self, root):
        self.root = root
        self.splash = tk.Toplevel(root)
        self.splash.title("LM Studio Orchestrator")
        self.splash.geometry("400x150")
        self.splash.resizable(False, False)
        
        # Center on screen
        self.splash.update_idletasks()
        x = (self.splash.winfo_screenwidth() // 2) - 200
        y = (self.splash.winfo_screenheight() // 2) - 75
        self.splash.geometry(f"+{x}+{y}")
        
        # Remove window decorations for cleaner look
        self.splash.attributes('-topmost', True)
        
        # Content
        ttk.Label(self.splash, text="LM Studio Multi-Model Orchestrator", font=("Arial", 12, "bold")).pack(pady=15)
        ttk.Label(self.splash, text="Checking server...", font=("Arial", 9)).pack(pady=(0, 10))
        
        self.progress = ttk.Progressbar(self.splash, mode='indeterminate', length=300)
        self.progress.pack(pady=10)
        self.progress.start()
    
    def update_status(self, text):
        """Update status text on splash screen"""
        self.status_text.config(text=text)
        self.splash.update()
    
    def close(self):
        """Close splash screen"""
        self.progress.stop()
        self.splash.destroy()

class ChatWindow:
    """Separate window for direct chat interface - Facebook Messenger style"""
    def __init__(self, parent, parent_app):
        self.parent_app = parent_app
        self.window = tk.Toplevel(parent)
        self.window.title("Chat - LM Studio")
        self.window.geometry("600x700")
        self.window.resizable(True, True)
        self.window.configure(bg="#fff")
        
        # Store message labels for responsive updates
        self.message_labels = []
        
        # Header with title and resolution
        header_frame = tk.Frame(self.window, bg="#f0f2f5")
        header_frame.pack(fill=tk.X, side=tk.TOP)
        
        # Title on left
        ttk.Label(header_frame, text="LM Studio Chat", font=("Arial", 14, "bold"), background="#f0f2f5").pack(side=tk.LEFT, pady=10, padx=10, fill=tk.X, expand=True)
        
        # Resolution counter on right
        self.chat_resolution_label = ttk.Label(header_frame, text="600x700", font=("Courier", 9), background="#f0f2f5", foreground="blue")
        self.chat_resolution_label.pack(side=tk.RIGHT, pady=10, padx=10)
        
        # Bind window resize event to update resolution display
        self.window.bind("<Configure>", self.update_chat_resolution)
        
        # Messages frame with scrollbar
        messages_container = tk.Frame(self.window, bg="#fff")
        messages_container.pack(fill=tk.BOTH, expand=True, side=tk.TOP)
        
        self.canvas = tk.Canvas(messages_container, bg="#fff", highlightthickness=0)
        scrollbar = ttk.Scrollbar(messages_container, orient="vertical", command=self.canvas.yview)
        self.messages_frame = tk.Frame(self.canvas, bg="#fff")
        
        self.messages_frame.bind(
            "<Configure>",
            lambda e: self.canvas.configure(scrollregion=self.canvas.bbox("all"))
        )
        
        # Bind canvas resize to update message wraplengths
        self.canvas.bind("<Configure>", self.update_message_wraplengths)
        
        self.canvas.create_window((0, 0), window=self.messages_frame, anchor="nw")
        self.canvas.configure(yscrollcommand=scrollbar.set)
        
        self.canvas.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        
        # Bind mousewheel only to canvas (not globally)
        def _on_mousewheel(event):
            try:
                if self.canvas.winfo_exists():
                    self.canvas.yview_scroll(int(-1*(event.delta/120)), "units")
            except:
                pass  # Canvas was destroyed, ignore
        
        self.canvas.bind("<MouseWheel>", _on_mousewheel)
        self.messages_frame.bind("<MouseWheel>", _on_mousewheel)
        
        # Input frame
        input_frame = tk.Frame(self.window, bg="#f0f2f5")
        input_frame.pack(fill=tk.BOTH, side=tk.BOTTOM, padx=0, pady=0)
        
        # Input field with icon
        input_sub_frame = tk.Frame(input_frame, bg="#f0f2f5")
        input_sub_frame.pack(fill=tk.X, expand=True, padx=10, pady=10)
        
        self.chat_input = tk.Text(input_sub_frame, height=2, font=("Arial", 10), wrap=tk.WORD, 
                                   bg="white", fg="#000", relief=tk.SOLID, bd=1)
        self.chat_input.pack(side=tk.LEFT, fill=tk.BOTH, expand=True, padx=(0, 8))
        self.chat_input.bind('<Control-Return>', lambda e: self.send_chat())
        
        # Send button (blue like Messenger)
        send_btn = tk.Button(input_sub_frame, text="➤", font=("Arial", 12, "bold"), 
                            bg="#0084ff", fg="white", relief=tk.FLAT, bd=0, padx=12, pady=6,
                            command=self.send_chat, cursor="hand2")
        send_btn.pack(side=tk.LEFT)
        
        # Options frame
        options_frame = tk.Frame(input_frame, bg="#f0f2f5")
        options_frame.pack(fill=tk.X, padx=10, pady=(0, 10))
        
        ttk.Button(options_frame, text="📋 Copy", command=self.copy_chat_output).pack(side=tk.LEFT, padx=(0, 5))
        ttk.Button(options_frame, text="🗑️ Clear", command=self.clear_chat_output).pack(side=tk.LEFT)
    
    def update_chat_resolution(self, event=None):
        """Update chat window resolution display"""
        width = self.window.winfo_width()
        height = self.window.winfo_height()
        if width > 1 and height > 1:  # Skip initial configure events
            self.chat_resolution_label.config(text=f"{width}x{height}")
    
    def update_message_wraplengths(self, event=None):
        """Update wraplength for all messages based on canvas width"""
        canvas_width = self.canvas.winfo_width()
        if canvas_width > 1:
            # Calculate max bubble width (canvas width - padding)
            max_width = max(canvas_width - 100, 150)  # Min 150 to prevent too narrow text
            
            # Update all existing message labels
            for label in self.message_labels:
                label.config(wraplength=max_width)
    
    def add_message(self, text, is_user=True):
        """Add a message bubble to the chat"""
        msg_frame = tk.Frame(self.messages_frame, bg="#fff")
        msg_frame.pack(fill=tk.X, padx=10, pady=5, anchor=tk.E if is_user else tk.W)
        
        # Get current canvas width for initial wraplength
        canvas_width = self.canvas.winfo_width()
        if canvas_width < 2:
            canvas_width = 600  # Default width if not yet rendered
        max_width = max(canvas_width - 100, 150)
        
        if is_user:
            # User message (right, blue)
            bubble_frame = tk.Frame(msg_frame, bg="#0084ff", relief=tk.FLAT)
            bubble_frame.pack(side=tk.RIGHT, padx=(50, 0), fill=tk.X, expand=False)
            
            msg_label = tk.Label(bubble_frame, text=text, font=("Arial", 10), 
                                fg="white", bg="#0084ff", wraplength=max_width, justify=tk.LEFT, padx=12, pady=8)
            msg_label.pack(fill=tk.BOTH, expand=True)
        else:
            # Assistant message (left, gray)
            bubble_frame = tk.Frame(msg_frame, bg="#e4e6eb", relief=tk.FLAT)
            bubble_frame.pack(side=tk.LEFT, padx=(0, 50), fill=tk.X, expand=False)
            
            msg_label = tk.Label(bubble_frame, text=text, font=("Arial", 10), 
                                fg="#000", bg="#e4e6eb", wraplength=max_width, justify=tk.LEFT, padx=12, pady=8)
            msg_label.pack(fill=tk.BOTH, expand=True)
        
        # Store label for later updates
        self.message_labels.append(msg_label)
        
        # Auto-scroll to bottom
        self.messages_frame.update_idletasks()
        self.canvas.yview_moveto(1)
    
    def send_chat(self):
        """Send a chat message to the currently loaded model"""
        if not self.parent_app.current_model:
            messagebox.showwarning("No Model", "Please load a model first.")
            return
        
        # Get user input
        user_message = self.chat_input.get("1.0", tk.END).strip()
        if not user_message:
            messagebox.showwarning("Empty Message", "Please type a message.")
            return
        
        try:
            # Display user message
            self.add_message(user_message, is_user=True)
            
            # Clear input field
            self.chat_input.delete("1.0", tk.END)
            self.window.update()
            
            # Show typing indicator
            self.add_message("Thinking...", is_user=False)
            self.window.update()
            
            # Build prompt with uploaded documents if available
            chat_prompt = user_message
            if self.parent_app.uploaded_documents:
                # Read all uploaded files
                all_content = []
                for file_path in self.parent_app.uploaded_documents:
                    with open(file_path, 'r', encoding='utf-8') as f:
                        content = f.read()
                        all_content.append(f"=== {os.path.basename(file_path)} ===\n{content}")
                
                combined_content = "\n\n".join(all_content)
                chat_prompt = f"""Here are some documents:

{combined_content}

User's question: {user_message}"""
            
            # Send to LM Studio API
            response = requests.post(
                f"{self.parent_app.api_base}/v1/chat/completions",
                json={
                    "model": self.parent_app.current_model,
                    "messages": [
                        {"role": "user", "content": chat_prompt}
                    ],
                    "temperature": self.parent_app.temperature_var.get(),
                    "max_tokens": self.parent_app.max_tokens_var.get()
                },
                timeout=60
            )
            
            if response.status_code == 200:
                result = response.json()
                assistant_message = result['choices'][0]['message']['content']
                
                # Extract token usage and update parent app
                if 'usage' in result:
                    tokens_used = result['usage'].get('total_tokens', 0)
                    self.parent_app.reasoning_tokens = tokens_used
                    self.parent_app.session_tokens += tokens_used
                    
                    # Update token display in main window
                    self.parent_app.reasoning_tokens_label.config(text=str(self.parent_app.reasoning_tokens))
                    self.parent_app.session_tokens_label.config(text=str(self.parent_app.session_tokens))
                
                # Remove typing indicator and add real response
                self.messages_frame.winfo_children()[-1].destroy()
                self.add_message(assistant_message, is_user=False)
            else:
                self.messages_frame.winfo_children()[-1].destroy()
                self.add_message(f"API Error: {response.status_code}", is_user=False)
        
        except requests.exceptions.RequestException as e:
            if self.messages_frame.winfo_children():
                self.messages_frame.winfo_children()[-1].destroy()
            self.add_message(f"Failed to connect to LM Studio:\n{str(e)}", is_user=False)
        except KeyError:
            if self.messages_frame.winfo_children():
                self.messages_frame.winfo_children()[-1].destroy()
            self.add_message("Unexpected response format from LM Studio.", is_user=False)
    
    def copy_chat_output(self):
        """Copy last assistant message to clipboard"""
        # Find the last assistant message (gray bubble)
        for widget in reversed(self.messages_frame.winfo_children()):
            for child in widget.winfo_children():
                if isinstance(child, tk.Frame) and child.cget("bg") == "#e4e6eb":
                    # Found assistant message frame
                    for label in child.winfo_children():
                        if isinstance(label, tk.Label):
                            text = label.cget("text")
                            if text.strip():
                                self.parent_app.root.clipboard_clear()
                                self.parent_app.root.clipboard_append(text)
                                messagebox.showinfo("Success", "Message copied to clipboard!")
                                return
        messagebox.showwarning("Empty", "No message to copy.")
    
    def clear_chat_output(self):
        """Clear all chat messages"""
        for widget in self.messages_frame.winfo_children():
            widget.destroy()

class LMStudioOrchestrator:
    def __init__(self, root):
        self.root = root
        self.root.title("LM Studio Multi-Model Orchestrator")
        self.root.geometry("900x624")
        self.root.resizable(False, False)  # Start locked
        
        # Window lock state
        self.window_locked = True
        
        # API Config
        self.api_base = "http://localhost:1234"
        self.model_keys = {}
        self.current_model = None
        self.uploaded_documents = []
        self.loading_model = False
        
        # Document settings
        self.max_tokens_var = tk.IntVar(value=2000)
        self.temperature_var = tk.DoubleVar(value=0.7)
        
        # Token tracking
        self.session_tokens = 0
        self.reasoning_tokens = 0
        
        # Logging
        self.error_log = []
        # Set up log file
        self.log_file_path = os.path.join(os.path.expanduser("~"), "Downloads", "lm_studio_logs.txt")
        self._initialize_log_file()
        
        # ===== TOP TAB MENU BAR =====
        menu_bar = tk.Frame(self.root, bg="#f0f0f0", relief=tk.RIDGE, bd=1)
        menu_bar.pack(fill=tk.X, side=tk.TOP)
        menu_bar.grid_rowconfigure(0, weight=1)
        
        # File Menu (Exit button)
        file_menu_btn = tk.Button(
            menu_bar,
            text="File",
            font=("Arial", 10, "bold"),
            bg="#e8e8e8",
            activebackground="#d0d0d0",
            relief=tk.FLAT,
            bd=0,
            pady=8,
            command=self.show_file_menu,
            justify=tk.CENTER
        )
        file_menu_btn.grid(row=0, column=0, sticky="nsew", padx=3, pady=5)
        menu_bar.grid_columnconfigure(0, weight=0, minsize=50)
        
        self.tab_buttons = {}
        self.tab_frames = {}
        self.current_tab = "model_control"
        
        # Tab button specs
        tabs = [
            ("model_control", "Model Control hidden, tap to open")
        ]
        
        for idx, (tab_id, tab_label) in enumerate(tabs, start=1):
            btn = tk.Button(
                menu_bar,
                text=tab_label,
                font=("Arial", 10, "bold"),
                bg="#e8e8e8",
                activebackground="#d0d0d0",
                relief=tk.FLAT,
                bd=0,
                pady=8,
                command=lambda tid=tab_id: self.switch_tab(tid),
                justify=tk.CENTER
            )
            btn.grid(row=0, column=idx, sticky="nsew", padx=3, pady=5)
            menu_bar.grid_columnconfigure(idx, weight=1)
            self.tab_buttons[tab_id] = btn
        
        # Update tab appearance to highlight active tab
        self.update_tab_appearance()
        
        # ===== MAIN CONTAINER FRAME =====
        self.main_container = tk.Frame(self.root)
        self.main_container.pack(fill=tk.BOTH, expand=True)
        
        # ===== TAB 1: MODEL CONTROL =====
        self.model_control_frame = tk.Frame(self.main_container)
        self.tab_frames["model_control"] = self.model_control_frame
        
        # Scrollable container for model control
        canvas = tk.Canvas(self.model_control_frame, bg="white", highlightthickness=0)
        scrollbar = ttk.Scrollbar(self.model_control_frame, orient="vertical", command=canvas.yview)
        scrollable_frame = ttk.Frame(canvas)
        
        scrollable_frame.bind(
            "<Configure>",
            lambda e: canvas.configure(scrollregion=canvas.bbox("all"))
        )
        
        canvas.create_window((0, 0), window=scrollable_frame, anchor="nw")
        canvas.configure(yscrollcommand=scrollbar.set)
        
        canvas.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        
        # Bind mousewheel
        def _on_mousewheel(event):
            try:
                if canvas.winfo_exists():
                    canvas.yview_scroll(int(-1*(event.delta/120)), "units")
            except:
                pass
        canvas.bind("<MouseWheel>", _on_mousewheel)
        scrollable_frame.bind("<MouseWheel>", _on_mousewheel)
        
        # ===== CONTROL PANEL =====
        control_panel = ttk.LabelFrame(scrollable_frame, text="Model Control", padding=10)
        control_panel.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)
        
        # Connection status
        ttk.Label(control_panel, text="LM Studio Status:", font=("Arial", 10, "bold")).pack(anchor=tk.W, pady=(0, 5))
        
        status_row = ttk.Frame(control_panel)
        status_row.pack(fill=tk.X, pady=(0, 5))
        
        self.status_label = ttk.Label(status_row, text="❌ Disconnected", foreground="red", font=("Arial", 9))
        self.status_label.pack(side=tk.LEFT, padx=(0, 15))
        
        ttk.Label(status_row, text="Server:", font=("Arial", 9)).pack(side=tk.LEFT, padx=(0, 5))
        self.server_label = ttk.Label(status_row, text=self.api_base, foreground="blue", font=("Courier", 9))
        self.server_label.pack(side=tk.LEFT)
        
        # Window resolution display with lock button
        resolution_frame = ttk.Frame(status_row)
        resolution_frame.pack(side=tk.RIGHT)
        
        self.resolution_label = ttk.Label(resolution_frame, text="491x624", foreground="blue", font=("Courier", 9))
        self.resolution_label.pack(side=tk.LEFT, padx=(0, 5))
        
        self.lock_button = tk.Button(resolution_frame, text="🔒", font=("Arial", 8), command=self.toggle_window_lock, relief=tk.FLAT, bd=0, padx=3, pady=0)
        self.lock_button.pack(side=tk.LEFT)
        
        # Model load status
        model_status_row = ttk.Frame(control_panel)
        model_status_row.pack(anchor=tk.W, pady=(0, 10))
        
        self.model_status_label = ttk.Label(model_status_row, text="❌ No Model Loaded", foreground="red", font=("Arial", 9))
        self.model_status_label.pack(side=tk.LEFT, padx=(0, 15))
        
        ttk.Label(model_status_row, text="Model:", font=("Arial", 9)).pack(side=tk.LEFT, padx=(0, 5))
        self.model_name_label = ttk.Label(model_status_row, text="Waiting...", foreground="blue", font=("Courier", 9))
        self.model_name_label.pack(side=tk.LEFT)
        
        # Token tracking
        token_row = ttk.Frame(control_panel)
        token_row.pack(anchor=tk.W, pady=(0, 10))
        
        ttk.Label(token_row, text="Tokens used:", font=("Arial", 9)).pack(side=tk.LEFT, padx=(0, 10))
        self.session_tokens_label = ttk.Label(token_row, text="0", foreground="green", font=("Courier", 9, "bold"))
        self.session_tokens_label.pack(side=tk.LEFT, padx=(0, 20))
        
        ttk.Label(token_row, text="Reasoning:", font=("Arial", 9)).pack(side=tk.LEFT, padx=(0, 10))
        self.reasoning_tokens_label = ttk.Label(token_row, text="0", foreground="blue", font=("Courier", 9, "bold"))
        self.reasoning_tokens_label.pack(side=tk.LEFT)
        
        tk.Button(control_panel, text="Refresh Script", command=self.refresh_script, bg="red", fg="white", font=("Arial", 9)).pack(fill=tk.X, pady=3)
        tk.Button(control_panel, text="Restart Script", command=self.restart_script, bg="red", fg="white", font=("Arial", 9)).pack(fill=tk.X, pady=3)
        
        # Model selection
        ttk.Separator(control_panel, orient="horizontal").pack(fill=tk.X, pady=15)
        ttk.Label(control_panel, text="MODEL MANAGEMENT", font=("Arial", 11, "bold")).pack(anchor=tk.W, pady=(0, 8))
        
        ttk.Label(control_panel, text="Available Models:", font=("Arial", 9)).pack(anchor=tk.W, pady=(0, 3))
        ttk.Label(control_panel, text="(double-click to load)", font=("Arial", 8), foreground="gray").pack(anchor=tk.W, pady=(0, 5))
        
        self.models_listbox = tk.Listbox(control_panel, height=4, font=("Arial", 9), selectmode=tk.SINGLE)
        self.models_listbox.pack(fill=tk.X, pady=(0, 8))
        self.models_listbox.bind('<Double-Button-1>', self.on_model_select)
        self.models_listbox.bind('<Motion>', self.on_listbox_hover)
        
        # Max tokens and temperature
        tokens_row = ttk.Frame(control_panel)
        tokens_row.pack(fill=tk.X, pady=(0, 15))
        
        ttk.Label(tokens_row, text="Max Tokens:", font=("Arial", 9)).pack(side=tk.LEFT, padx=(0, 5))
        ttk.Spinbox(tokens_row, from_=100, to=32000, textvariable=self.max_tokens_var, width=10).pack(side=tk.LEFT, padx=(0, 20))
        
        ttk.Label(tokens_row, text="Temperature:", font=("Arial", 9)).pack(side=tk.LEFT, padx=(0, 5))
        ttk.Spinbox(tokens_row, from_=0.0, to=2.0, increment=0.1, textvariable=self.temperature_var, width=10).pack(side=tk.LEFT, padx=(0, 20))
        
        ttk.Button(tokens_row, text="💬 Open Chat", command=self.open_chat_window).pack(side=tk.LEFT)
        
        # ===== DOCUMENT UPLOAD SECTION =====
        ttk.Separator(control_panel, orient="horizontal").pack(fill=tk.X, pady=15)
        ttk.Label(control_panel, text="DOCUMENT UPLOAD", font=("Arial", 11, "bold")).pack(anchor=tk.W, pady=(0, 8))
        
        doc_main_frame = ttk.Frame(control_panel)
        doc_main_frame.pack(fill=tk.BOTH, expand=True, pady=(0, 15))
        
        left_frame = ttk.Frame(doc_main_frame)
        left_frame.pack(side=tk.LEFT, fill=tk.BOTH, expand=False, padx=(0, 8))
        
        ttk.Label(left_frame, text="Uploaded Files (Max 2):", font=("Arial", 9)).pack(anchor=tk.W, pady=(0, 3))
        
        upload_button_frame = ttk.Frame(left_frame)
        upload_button_frame.pack(fill=tk.X, pady=(0, 8))
        
        ttk.Button(upload_button_frame, text="Add Files", command=self.browse_document).pack(side=tk.LEFT, padx=(0, 5))
        tk.Button(upload_button_frame, text="Submit", command=self.submit_document, bg="green", fg="white", font=("Arial", 9)).pack(side=tk.LEFT, padx=(0, 5))
        tk.Button(upload_button_frame, text="View Output", command=self.open_last_output, bg="green", fg="white", font=("Arial", 9)).pack(side=tk.LEFT)
        
        self.files_frame = ttk.Frame(left_frame)
        self.files_frame.pack(fill=tk.X)
        
        self.last_output_file = None
        
        # ===== STORY CASCADE SECTION (in Model Control tab) =====
        ttk.Separator(control_panel, orient="horizontal").pack(fill=tk.X, pady=15)
        ttk.Label(control_panel, text="STORY CASCADE", font=("Arial", 11, "bold")).pack(anchor=tk.W, pady=(0, 8))
        
        # Story prompt input (MOVED TO TOP)
        ttk.Label(control_panel, text="Story Idea/Prompt:", font=("Arial", 9)).pack(anchor=tk.W, pady=(0, 3))
        
        self.cascade_input = tk.Text(control_panel, height=3, font=("Arial", 9), wrap=tk.WORD, 
                                     bg="white", fg="#000", relief=tk.SOLID, bd=1)
        self.cascade_input.pack(fill=tk.X, pady=(0, 15))
        self.cascade_input.insert("1.0", "A mysterious figure arrives in a small town...")
        
        # Model selection for 5-pass cascade
        ttk.Label(control_panel, text="Select Model for Each Pass:", font=("Arial", 9)).pack(anchor=tk.W, pady=(0, 5))
        ttk.Label(control_panel, text="(leave blank to skip pass)", font=("Arial", 8), foreground="gray").pack(anchor=tk.W, pady=(0, 8))
        
        # Store cascade pass selections
        self.cascade_pass_vars = {}
        self.cascade_pass_dropdowns = {}
        self.cascade_pass_max_tokens = {}  # Per-pass token limits
        self.model_display_names = {}
        
        # Create 5 pass dropdowns with per-pass token limits
        for pass_num in range(1, 6):
            pass_frame = ttk.Frame(control_panel)
            pass_frame.pack(fill=tk.X, pady=(0, 8))
            
            pass_label_text = f"Pass {pass_num}"
            if pass_num == 1:
                pass_label_text += " (Create)"
            elif pass_num == 5:
                pass_label_text += " (Polish)"
            else:
                pass_label_text += " (Refine)"
            
            ttk.Label(pass_frame, text=pass_label_text, font=("Arial", 9), width=15).pack(side=tk.LEFT, padx=(0, 5))
            
            var = tk.StringVar(value="None Selected")
            self.cascade_pass_vars[pass_num] = var
            
            dropdown = ttk.Combobox(pass_frame, textvariable=var, state="readonly", width=25)
            dropdown.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=(0, 10))
            self.cascade_pass_dropdowns[pass_num] = dropdown
            
            # Per-pass max tokens
            ttk.Label(pass_frame, text="Tokens:", font=("Arial", 8)).pack(side=tk.LEFT, padx=(0, 3))
            tokens_var = tk.IntVar(value=2000)
            self.cascade_pass_max_tokens[pass_num] = tokens_var
            tokens_spinbox = ttk.Spinbox(pass_frame, from_=100, to=4000, textvariable=tokens_var, width=5)
            tokens_spinbox.pack(side=tk.LEFT, padx=(0, 5))
        
        # Temperature limiter (global for all passes)
        limiter_frame = ttk.LabelFrame(control_panel, text="Generation Settings", padding=8)
        limiter_frame.pack(fill=tk.X, pady=(15, 10))
        
        # Single row with Temperature on left and Buttons on right
        settings_row = ttk.Frame(limiter_frame)
        settings_row.pack(fill=tk.X)
        
        # Left side: Temperature
        left_frame = ttk.Frame(settings_row)
        left_frame.pack(side=tk.LEFT, fill=tk.X, expand=True)
        
        ttk.Label(left_frame, text="Temperature (Global):", font=("Arial", 9)).pack(side=tk.LEFT, padx=(0, 5))
        self.cascade_temp_var = tk.DoubleVar(value=0.8)
        temp_spinbox = ttk.Spinbox(left_frame, from_=0.0, to=2.0, increment=0.1, textvariable=self.cascade_temp_var, width=8)
        temp_spinbox.pack(side=tk.LEFT, padx=(0, 15))
        ttk.Label(left_frame, text="(0.0-2.0)", font=("Arial", 8), foreground="gray").pack(side=tk.LEFT)
        
        # Right side: Buttons
        right_frame = ttk.Frame(settings_row)
        right_frame.pack(side=tk.RIGHT, fill=tk.X)
        
        tk.Button(right_frame, text="▶ Generate", command=self.start_cascade, bg="green", fg="white", font=("Arial", 9)).pack(side=tk.LEFT, padx=(0, 5))
        tk.Button(right_frame, text="🗑️ Clear All", command=self.clear_cascade, bg="red", fg="white", font=("Arial", 9)).pack(side=tk.LEFT)
        
        # Output section
        ttk.Label(control_panel, text="Current Story Version:", font=("Arial", 9)).pack(anchor=tk.W, pady=(0, 5))
        
        cascade_output_frame = ttk.LabelFrame(control_panel, text="Latest Pass Output", padding=5)
        cascade_output_frame.pack(fill=tk.BOTH, expand=False, pady=(0, 0), ipady=60)
        
        self.cascade_output = tk.Text(cascade_output_frame, height=6, font=("Courier", 9), wrap=tk.WORD,
                                      bg="#f0f0f0", fg="#000", relief=tk.SOLID, bd=1, state=tk.DISABLED)
        self.cascade_output.pack(fill=tk.BOTH, expand=True)
        
        cascade_btn_frame = ttk.Frame(control_panel)
        cascade_btn_frame.pack(fill=tk.X, pady=(2, 0))
        tk.Button(cascade_btn_frame, text="📋 Copy Output", command=self.copy_cascade_output, bg="blue", fg="white", font=("Arial", 9)).pack(side=tk.LEFT, padx=(0, 3))
        tk.Button(cascade_btn_frame, text="💾 Save Story", command=self.save_cascade_story, bg="blue", fg="white", font=("Arial", 9)).pack(side=tk.LEFT)
        
        # Store cascade running state
        self.cascade_running = False
        
        # Initialize chat window reference
        self.chat_window = None
        
        # Initialize logs_listbox as None (no UI display, only file logging)
        self.logs_listbox = None
        
        # Store model display names for dropdown updates
        self.model_display_names = {}
        
        # Bind window resize event
        self.root.bind("<Configure>", self.update_resolution)
        
        # Bind window close (X button) to clean exit
        self.root.protocol("WM_DELETE_WINDOW", self.exit_app)
        
        # Run startup checks
        self.run_startup_checks()
    
    def switch_tab(self, tab_id):
        """Switch to a different tab"""
        # Hide all frames
        for frame in self.tab_frames.values():
            frame.pack_forget()
        
        # Show selected frame
        if tab_id in self.tab_frames:
            self.tab_frames[tab_id].pack(fill=tk.BOTH, expand=True)
            self.current_tab = tab_id
            self.update_tab_appearance()
    
    def update_tab_appearance(self):
        """Update tab button styling to highlight active tab"""
        for tab_id, btn in self.tab_buttons.items():
            if tab_id == self.current_tab:
                btn.config(bg="#4a9eff", fg="white")
            else:
                btn.config(bg="#e8e8e8", fg="black")
    
    def _initialize_log_file(self):
        """Create or append to log file with session separator"""
        try:
            with open(self.log_file_path, 'a', encoding='utf-8') as f:
                f.write(f"\n{'='*60}\nSession started: {datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n{'='*60}\n")
        except Exception as e:
            pass  # Silently fail
    
    def show_file_menu(self):
        """Show File menu with View Log and Exit options"""
        menu = tk.Menu(self.root, tearoff=0)
        menu.add_command(label="View Log File", command=self.open_log_file)
        menu.add_separator()
        menu.add_command(label="Exit", command=self.exit_app)
        
        # Get File button position for menu placement
        try:
            menu.post(self.root.winfo_x(), self.root.winfo_y() + 50)
        except:
            pass  # Fallback if positioning fails
    
    def exit_app(self):
        """Clean exit - save logs and close app"""
        self.add_log("Application closing", "SYSTEM")
        self.root.quit()
    
    def open_log_file(self):
        """Open the log file with default application"""
        if not os.path.exists(self.log_file_path):
            messagebox.showwarning("No Log File", f"Log file not found:\n{self.log_file_path}")
            return
        
        try:
            if os.name == 'nt':  # Windows
                os.startfile(self.log_file_path)
            else:  # macOS and Linux
                os.system(f'open "{self.log_file_path}"')
            self.add_log("Opened log file", "INFO")
        except Exception as e:
            messagebox.showerror("Error", f"Could not open log file:\n{str(e)}")
            self.add_log(f"Error opening log file: {str(e)}", "ERROR")
    
    def add_log(self, message, log_type="INFO"):
        """Add a message to the error logs and save to file"""
        timestamp = datetime.datetime.now().strftime("%H:%M:%S")
        log_entry = f"[{timestamp}] {log_type}: {message}"
        self.error_log.append(log_entry)
        
        # Write to log file
        try:
            with open(self.log_file_path, 'a', encoding='utf-8') as f:
                f.write(log_entry + "\n")
        except Exception as e:
            pass  # Silently fail if log write fails
        
        # Update listbox if it exists
        if self.logs_listbox and self.logs_listbox.winfo_exists():
            self.logs_listbox.insert(tk.END, log_entry)
            self.logs_listbox.see(tk.END)
        
        # Keep last 1000 entries in memory
        if len(self.error_log) > 1000:
            self.error_log.pop(0)
            if self.logs_listbox and self.logs_listbox.winfo_exists():
                self.logs_listbox.delete(0, 1)
    

    
    def clear_logs(self):
        """Clear all logs from memory and file"""
        if messagebox.askyesno("Clear Logs", "Clear all logs?"):
            if self.logs_listbox and self.logs_listbox.winfo_exists():
                self.logs_listbox.delete(0, tk.END)
            self.error_log.clear()
            # Clear log file
            try:
                with open(self.log_file_path, 'w', encoding='utf-8') as f:
                    f.write("")
            except:
                pass
            self.add_log("Logs cleared", "SYSTEM")
    
    def copy_log_entry(self):
        """Copy selected log entry to clipboard"""
        selection = self.logs_listbox.curselection()
        if selection:
            text = self.logs_listbox.get(selection[0])
            self.root.clipboard_clear()
            self.root.clipboard_append(text)
            messagebox.showinfo("Copied", "Log entry copied!")
        else:
            messagebox.showwarning("No Selection", "Select a log entry first.")

    
    def run_startup_checks(self):
        """Run startup checks in background with loading splash"""
        splash = LoadingSplash(self.root)
        self.add_log("Starting application...", "SYSTEM")
        
        def startup_thread():
            self.check_connection()
            self.refresh_models()
            splash.close()
            self.root.deiconify()
        
        thread = threading.Thread(target=startup_thread, daemon=True)
        thread.start()
    
    def update_resolution(self, event=None):
        """Update window resolution display"""
        width = self.root.winfo_width()
        height = self.root.winfo_height()
        if width > 1 and height > 1:
            self.resolution_label.config(text=f"{width}x{height}")
    
    def toggle_window_lock(self):
        """Toggle window resizing lock"""
        self.window_locked = not self.window_locked
        self.root.resizable(not self.window_locked, not self.window_locked)
        self.lock_button.config(text="🔒" if self.window_locked else "🔓")
    
    def refresh_models(self):
        """Fetch available models from LM Studio"""
        try:
            response = requests.get(f"{self.api_base}/api/v1/models", timeout=5)
            if response.status_code == 200:
                data = response.json()
                models = data.get("models", [])
                
                self.models_listbox.delete(0, tk.END)
                self.model_keys = {}
                
                llm_models = [m for m in models if m.get("type") == "llm"]
                
                if llm_models:
                    for idx, model in enumerate(llm_models):
                        display_name = model.get("display_name", "Unknown")
                        key = model.get("key", "unknown")
                        quantization = model.get("quantization", {}).get("name", "")
                        
                        display_text = f"{display_name} ({quantization})"
                        
                        self.models_listbox.insert(tk.END, display_text)
                        self.model_keys[idx] = key
                    self.add_log(f"Loaded {len(llm_models)} models", "INFO")
                else:
                    self.models_listbox.insert(tk.END, "No LLM models found")
                    self.add_log("No LLM models found", "WARNING")
                
                self.models_listbox.selection_clear(0, tk.END)
                self.update_cascade_models()  # Update cascade model keys
            else:
                self.models_listbox.delete(0, tk.END)
                self.models_listbox.insert(tk.END, "Failed to load models")
                self.add_log(f"Failed to load models: {response.status_code}", "ERROR")
        except Exception as e:
            self.models_listbox.delete(0, tk.END)
            self.models_listbox.insert(tk.END, f"Error: {str(e)}")
            self.add_log(f"Error fetching models: {str(e)}", "ERROR")
    
    def on_model_select(self, event):
        """Handle model selection from listbox"""
        if self.loading_model:
            return
        
        idx = self.models_listbox.nearest(event.y)
        if idx >= 0:
            model_key = self.model_keys.get(idx)
            if model_key:
                self.load_model(model_key)
    
    def on_listbox_hover(self, event):
        """Highlight listbox item on hover"""
        idx = self.models_listbox.nearest(event.y)
        if idx >= 0:
            self.models_listbox.selection_clear(0, tk.END)
            self.models_listbox.selection_set(idx)
            self.models_listbox.see(idx)
    
    def load_model(self, model_key):
        """Load a model by its key"""
        if not model_key:
            messagebox.showerror("Error", "Could not identify model")
            self.add_log("Failed to identify model", "ERROR")
            return
        
        self.loading_model = True
        
        try:
            response = requests.post(
                f"{self.api_base}/api/v1/models/load",
                json={"model": model_key},
                timeout=30
            )
            
            if response.status_code == 200:
                self.current_model = model_key
                self.check_connection()
                messagebox.showinfo("Success", f"Model loaded: {model_key}")
                self.add_log(f"Model loaded: {model_key}", "INFO")
            else:
                messagebox.showerror("Error", f"Failed to load model.\nStatus: {response.status_code}")
                self.add_log(f"Failed to load model: {response.status_code}", "ERROR")
        except Exception as e:
            messagebox.showerror("Error", f"Error loading model:\n{str(e)}")
            self.add_log(f"Error loading model: {str(e)}", "ERROR")
        finally:
            self.loading_model = False
    
    def refresh_script(self):
        """Refresh connection and model list"""
        self.check_connection()
        self.refresh_models()
        self.add_log("Script refreshed", "INFO")
    
    def restart_script(self):
        """Restart the application"""
        if messagebox.askyesno("Restart", "Restart? Token count will reset."):
            self.root.quit()
            subprocess.Popen([sys.executable, sys.argv[0]])
            sys.exit()
    
    def check_connection(self):
        """Check LM Studio API connection"""
        try:
            response = requests.get(f"{self.api_base}/api/v1/models", timeout=2)
            self.status_label.config(text="✅ Connected", foreground="green")
            self.add_log("Connected to LM Studio", "INFO")
            
            if response.status_code == 200:
                data = response.json()
                models = data.get("models", [])
                
                if self.current_model:
                    for model in models:
                        if model.get("key") == self.current_model:
                            display_name = model.get("display_name", "Unknown")
                            self.model_status_label.config(text="✅ Model Loaded", foreground="green")
                            self.model_name_label.config(text=display_name, foreground="blue")
                            return True
                    self.current_model = None
                
                self.model_status_label.config(text="❌ No Model Loaded", foreground="red")
                self.model_name_label.config(text="Waiting...", foreground="blue")
            return True
        except:
            self.status_label.config(text="❌ Disconnected", foreground="red")
            self.model_status_label.config(text="❌ No Model Loaded", foreground="red")
            self.model_name_label.config(text="Offline", foreground="blue")
            self.add_log("Lost connection to LM Studio", "ERROR")
            return False
    
    def browse_document(self):
        """Open file dialog for documents"""
        slots_available = 2 - len(self.uploaded_documents)
        
        if slots_available <= 0:
            messagebox.showwarning("File Limit", "Maximum 2 files. Remove one to add more.")
            return
        
        files = filedialog.askopenfilenames(
            title=f"Select Files (max {slots_available} remaining)",
            filetypes=[("Text/Markdown", "*.txt *.md"), ("Text", "*.txt"), ("Markdown", "*.md")]
        )
        
        if files:
            files_to_add = list(files)[:slots_available]
            
            for file_path in files_to_add:
                if file_path not in self.uploaded_documents:
                    self.uploaded_documents.append(file_path)
            
            self.update_files_display()
            file_count = len(files_to_add)
            filenames = ", ".join(os.path.basename(f) for f in files_to_add)
            messagebox.showinfo("Files Added", f"Added {file_count} file(s):\n{filenames}")
            self.add_log(f"Added {file_count} file(s)", "INFO")
    
    def update_files_display(self):
        """Update file chips display"""
        for widget in self.files_frame.winfo_children():
            widget.destroy()
        
        if len(self.uploaded_documents) == 0:
            ttk.Label(self.files_frame, text="No files", font=("Arial", 9), foreground="gray").pack(anchor=tk.W)
        else:
            for i, file_path in enumerate(self.uploaded_documents):
                self.create_file_chip(i, os.path.basename(file_path))
    
    def create_file_chip(self, index, filename):
        """Create a file chip with X button"""
        chip_frame = ttk.Frame(self.files_frame)
        chip_frame.pack(fill=tk.X, pady=2)
        
        ttk.Label(chip_frame, text=f"📎 {filename}", font=("Arial", 9), foreground="blue").pack(side=tk.LEFT, padx=(0, 8))
        
        remove_btn = tk.Button(chip_frame, text="✕", font=("Arial", 9, "bold"), 
                              fg="red", relief=tk.FLAT, bd=0, padx=4, 
                              command=lambda idx=index: self.remove_file_by_index(idx))
        remove_btn.pack(side=tk.LEFT)
    
    def remove_file_by_index(self, index):
        """Remove a file by index"""
        if 0 <= index < len(self.uploaded_documents):
            filename = os.path.basename(self.uploaded_documents[index])
            self.uploaded_documents.pop(index)
            self.update_files_display()
            self.add_log(f"Removed file: {filename}", "INFO")
    
    def submit_document(self):
        """Submit documents for analysis"""
        if not self.uploaded_documents:
            messagebox.showwarning("No Documents", "Add documents first.")
            return
        
        if not self.current_model:
            messagebox.showwarning("No Model", "Load a model first.")
            return
        
        try:
            messagebox.showinfo("Processing", "Analyzing documents...")
            self.add_log("Starting document analysis", "INFO")
            
            all_content = []
            for file_path in self.uploaded_documents:
                with open(file_path, 'r', encoding='utf-8') as f:
                    content = f.read()
                    all_content.append(f"=== {os.path.basename(file_path)} ===\n{content}")
            
            combined_content = "\n\n".join(all_content)
            prompt = f"""Examine thoroughly, fact check claims, verify information, and provide deep reasoning.

Documents:
{combined_content}

Provide a comprehensive analysis."""
            
            response = requests.post(
                f"{self.api_base}/v1/chat/completions",
                json={
                    "model": self.current_model,
                    "messages": [{"role": "user", "content": prompt}],
                    "temperature": self.temperature_var.get(),
                    "max_tokens": self.max_tokens_var.get()
                },
                timeout=120
            )
            
            if response.status_code == 200:
                result = response.json()
                analysis = result['choices'][0]['message']['content']
                
                if 'usage' in result:
                    tokens_used = result['usage'].get('total_tokens', 0)
                    self.reasoning_tokens = tokens_used
                    self.session_tokens += tokens_used
                    
                    self.reasoning_tokens_label.config(text=str(self.reasoning_tokens))
                    self.session_tokens_label.config(text=str(self.session_tokens))
                
                timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
                output_filename = f"analysis_{timestamp}.txt"
                output_path = os.path.join(os.path.expanduser("~"), "Downloads", output_filename)
                
                with open(output_path, 'w', encoding='utf-8') as f:
                    f.write(analysis)
                
                self.last_output_file = output_path
                messagebox.showinfo("Success", f"Saved:\n{output_filename}\n\nTokens: {self.reasoning_tokens}\nSession: {self.session_tokens}")
                self.add_log(f"Document analysis complete: {self.reasoning_tokens} tokens", "INFO")
            else:
                messagebox.showerror("API Error", f"Status: {response.status_code}")
                self.add_log(f"API error: {response.status_code}", "ERROR")
        
        except FileNotFoundError:
            messagebox.showerror("File Error", "Could not read a file.")
            self.add_log("File read error", "ERROR")
        except requests.exceptions.RequestException as e:
            messagebox.showerror("Connection Error", f"Failed to connect:\n{str(e)}")
            self.add_log(f"Connection error: {str(e)}", "ERROR")
        except KeyError:
            messagebox.showerror("Response Error", "Unexpected response format.")
            self.add_log("Unexpected response format", "ERROR")
        except Exception as e:
            messagebox.showerror("Error", f"An error occurred:\n{str(e)}")
            self.add_log(f"Error: {str(e)}", "ERROR")
    
    def open_last_output(self):
        """Open last output file"""
        if not self.last_output_file:
            messagebox.showwarning("No Output", "No analysis yet.")
            return
        
        if not os.path.exists(self.last_output_file):
            messagebox.showerror("File Not Found", f"File not found:\n{self.last_output_file}")
            self.last_output_file = None
            return
        
        try:
            if os.name == 'nt':
                os.startfile(self.last_output_file)
            else:
                os.system(f'open "{self.last_output_file}"')
        except Exception as e:
            messagebox.showerror("Error", f"Could not open:\n{str(e)}")
    
    def open_chat_window(self):
        """Open or focus chat window"""
        if self.chat_window is None or not self.chat_window.window.winfo_exists():
            self.chat_window = ChatWindow(self.root, self)
        else:
            self.chat_window.window.lift()
            self.chat_window.window.focus()
    
    def update_cascade_models(self):
        """Update cascade pass dropdowns when models list changes"""
        try:
            response = requests.get(f"{self.api_base}/api/v1/models", timeout=5)
            if response.status_code == 200:
                data = response.json()
                models = data.get("models", [])
                llm_models = [m for m in models if m.get("type") == "llm"]
                
                model_options = ["None Selected"]  # Add None Selected as first option
                self.model_display_names = {}
                
                for model in llm_models:
                    display_name = model.get("display_name", "Unknown")
                    key = model.get("key", "unknown")
                    quantization = model.get("quantization", {}).get("name", "")
                    display_text = f"{display_name} ({quantization})" if quantization else display_name
                    
                    model_options.append(display_text)
                    self.model_display_names[display_text] = key
                
                # Update all 5 pass dropdowns with available models
                for pass_num in range(1, 6):
                    if pass_num in self.cascade_pass_dropdowns:
                        self.cascade_pass_dropdowns[pass_num]['values'] = model_options
        except Exception as e:
            self.add_log(f"Error updating cascade models: {str(e)}", "ERROR")
    
    def start_cascade(self):
        """Start the 5-pass story cascade refinement"""
        if self.cascade_running:
            messagebox.showwarning("In Progress", "Cascade is already running.")
            return
        
        # Get selected models for each pass
        selected_passes = []
        for pass_num in range(1, 6):
            model_display = self.cascade_pass_vars[pass_num].get()
            if model_display != "None Selected":
                model_key = self.model_display_names.get(model_display)
                if model_key:
                    selected_passes.append((pass_num, model_display, model_key))
        
        if not selected_passes:
            messagebox.showwarning("No Models", "Select at least one model for a pass.")
            self.add_log("Cascade error: no models selected", "WARNING")
            return
        
        # Get initial prompt
        story_prompt = self.cascade_input.get("1.0", tk.END).strip()
        if not story_prompt:
            messagebox.showwarning("Empty Prompt", "Enter a story idea first.")
            self.add_log("Cascade error: empty prompt", "WARNING")
            return
        
        # Clear output
        self.cascade_output.config(state=tk.NORMAL)
        self.cascade_output.delete("1.0", tk.END)
        self.cascade_output.config(state=tk.DISABLED)
        
        self.cascade_running = True
        self.add_log(f"Starting 5-pass cascade with {len(selected_passes)} models", "INFO")
        
        # Run cascade in background thread
        def cascade_thread():
            try:
                current_story = story_prompt
                total_tokens = 0
                
                # Process through each pass
                for pass_num, model_name, model_key in selected_passes:
                    self.add_log(f"Pass {pass_num}/{len(selected_passes)}: {model_name}", "INFO")
                    
                    # Build pass-specific prompts
                    if pass_num == 1:
                        # Pass 1: Create story from prompt
                        refine_prompt = f"Write a creative and engaging short story based on this idea:\n\n{current_story}\n\nMake it around 300-400 words with vivid descriptions and interesting characters."
                    elif pass_num == 2:
                        # Pass 2: First refinement
                        refine_prompt = f"Improve this story by enhancing the narrative flow and adding more descriptive detail:\n\n{current_story}\n\nKeep it around 400-500 words."
                    elif pass_num == 3:
                        # Pass 3: Character development
                        refine_prompt = f"Deepen the story by developing character motivations, emotions, and dialogue. Make the interactions more realistic:\n\n{current_story}\n\nKeep it around 450-550 words."
                    elif pass_num == 4:
                        # Pass 4: Pacing and tension
                        refine_prompt = f"Refine the story for better pacing, build tension, and create a more compelling narrative arc:\n\n{current_story}\n\nKeep it around 450-550 words."
                    else:  # Pass 5
                        # Pass 5: Final polish
                        refine_prompt = f"Polish this story to publication quality. Enhance prose, ensure strong voice, perfect pacing, and create a satisfying conclusion:\n\n{current_story}\n\nFinal version should be 400-600 words of polished prose."
                    
                    # Call model with per-pass token limit
                    response = requests.post(
                        f"{self.api_base}/v1/chat/completions",
                        json={
                            "model": model_key,
                            "messages": [{"role": "user", "content": refine_prompt}],
                            "temperature": self.cascade_temp_var.get(),
                            "max_tokens": self.cascade_pass_max_tokens[pass_num].get()  # Use per-pass token limit
                        },
                        timeout=120
                    )
                    
                    if response.status_code == 200:
                        result = response.json()
                        current_story = result['choices'][0]['message']['content']
                        
                        # Track tokens
                        if 'usage' in result:
                            tokens_used = result['usage'].get('total_tokens', 0)
                            total_tokens += tokens_used
                            self.reasoning_tokens = tokens_used
                            self.session_tokens += tokens_used
                        
                        # ONLY update UI for the LAST pass (final output)
                        is_last_pass = (pass_num == selected_passes[-1][0])
                        if is_last_pass:
                            self.cascade_output.config(state=tk.NORMAL)
                            self.cascade_output.delete("1.0", tk.END)
                            self.cascade_output.insert(tk.END, current_story)
                            self.cascade_output.config(state=tk.DISABLED)
                            
                            # Auto-scroll to top
                            self.cascade_output.see("1.0")
                        
                        self.root.update()
                    else:
                        error_msg = f"API Error ({response.status_code}) from {model_name} (Pass {pass_num})"
                        self.cascade_output.config(state=tk.NORMAL)
                        self.cascade_output.delete("1.0", tk.END)
                        self.cascade_output.insert(tk.END, f"❌ {error_msg}\n")
                        self.cascade_output.config(state=tk.DISABLED)
                        self.add_log(error_msg, "ERROR")
                        break
                
                # Update token display
                self.reasoning_tokens_label.config(text=str(total_tokens))
                self.session_tokens_label.config(text=str(self.session_tokens))
                
                self.add_log(f"Cascade complete: {total_tokens} total tokens", "INFO")
                
            except requests.exceptions.RequestException as e:
                error_msg = f"Connection error: {str(e)}"
                self.cascade_output.config(state=tk.NORMAL)
                self.cascade_output.delete("1.0", tk.END)
                self.cascade_output.insert(tk.END, f"❌ {error_msg}\n")
                self.cascade_output.config(state=tk.DISABLED)
                self.add_log(error_msg, "ERROR")
            
            except Exception as e:
                error_msg = f"Error: {str(e)}"
                self.cascade_output.config(state=tk.NORMAL)
                self.cascade_output.delete("1.0", tk.END)
                self.cascade_output.insert(tk.END, f"❌ {error_msg}\n")
                self.cascade_output.config(state=tk.DISABLED)
                self.add_log(error_msg, "ERROR")
            
            finally:
                self.cascade_running = False
        
        thread = threading.Thread(target=cascade_thread, daemon=True)
        thread.start()
    
    def clear_cascade(self):
        """Clear cascade inputs and outputs"""
        self.cascade_input.delete("1.0", tk.END)
        self.cascade_output.config(state=tk.NORMAL)
        self.cascade_output.delete("1.0", tk.END)
        self.cascade_output.config(state=tk.DISABLED)
        # Reset all per-pass token limits to default
        for pass_num in range(1, 6):
            self.cascade_pass_max_tokens[pass_num].set(2000)
        self.add_log("Cascade cleared", "INFO")
    
    def copy_cascade_output(self):
        """Copy cascade output to clipboard"""
        text = self.cascade_output.get("1.0", tk.END).strip()
        if not text:
            messagebox.showwarning("Empty", "No story to copy")
            return
        
        self.root.clipboard_clear()
        self.root.clipboard_append(text)
        messagebox.showinfo("Copied", "Story cascade output copied to clipboard!")
        self.add_log("Copied cascade output", "INFO")
    
    def save_cascade_story(self):
        """Save the current cascade story to file"""
        text = self.cascade_output.get("1.0", tk.END).strip()
        if not text:
            messagebox.showwarning("Empty", "No story to save")
            return
        
        timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
        filename = f"story_cascade_{timestamp}.txt"
        filepath = os.path.join(os.path.expanduser("~"), "Downloads", filename)
        
        try:
            with open(filepath, 'w', encoding='utf-8') as f:
                f.write(text)
            
            messagebox.showinfo("Saved", f"Story saved:\n{filename}")
            self.add_log(f"Saved cascade story: {filename}", "INFO")
        except Exception as e:
            messagebox.showerror("Error", f"Could not save:\n{str(e)}")
            self.add_log(f"Error saving story: {str(e)}", "ERROR")


if __name__ == "__main__":
    root = tk.Tk()
    root.withdraw()
    app = LMStudioOrchestrator(root)
    root.mainloop()
