import tkinter as tk
from tkinter import ttk, messagebox, filedialog
import requests
import os
import threading

class LoadingSplash:
    """Splash screen with loading bar shown during startup checks"""
    def __init__(self, root):
        self.root = root
        self.splash = tk.Toplevel(root)
        self.splash.title("LM Studio Orchestrator")
        self.splash.geometry("400x150")
        self.splash.resizable(False, False)
        
        # Center on screen
        self.splash.update_idletasks()
        x = (self.splash.winfo_screenwidth() // 2) - 200
        y = (self.splash.winfo_screenheight() // 2) - 75
        self.splash.geometry(f"+{x}+{y}")
        
        # Remove window decorations for cleaner look
        self.splash.attributes('-topmost', True)
        
        # Content
        ttk.Label(self.splash, text="LM Studio Multi-Model Orchestrator", font=("Arial", 12, "bold")).pack(pady=15)
        ttk.Label(self.splash, text="Checking server...", font=("Arial", 9)).pack(pady=(0, 10))
        
        self.progress = ttk.Progressbar(self.splash, mode='indeterminate', length=300)
        self.progress.pack(pady=10)
        self.progress.start()
    
    def update_status(self, text):
        """Update status text on splash screen"""
        self.status_text.config(text=text)
        self.splash.update()
    
    def close(self):
        """Close splash screen"""
        self.progress.stop()
        self.splash.destroy()

class LMStudioOrchestrator:
    def __init__(self, root):
        self.root = root
        self.root.title("LM Studio Multi-Model Orchestrator")
        self.root.geometry("900x700")
        
        # API Config
        self.api_base = "http://localhost:1234"
        self.model_keys = {}  # Map listbox index to model key
        self.current_model = None  # Track currently loaded model
        self.uploaded_documents = []  # Track uploaded files
        
        # Document analysis options
        self.examine_var = tk.BooleanVar()
        self.fact_check_var = tk.BooleanVar()
        self.verify_var = tk.BooleanVar()
        self.reasoning_var = tk.BooleanVar()
        self.max_tokens_var = tk.IntVar(value=2000)
        self.temperature_var = tk.DoubleVar(value=0.7)
        
        # ===== CONTROL PANEL =====
        self.control_frame = ttk.LabelFrame(root, text="Model Control", padding=10)
        self.control_frame.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)
        
        # Connection status
        ttk.Label(self.control_frame, text="LM Studio Status:", font=("Arial", 10, "bold")).pack(anchor=tk.W, pady=(0, 5))
        
        status_row = ttk.Frame(self.control_frame)
        status_row.pack(anchor=tk.W, pady=(0, 5))
        
        self.status_label = ttk.Label(status_row, text="❌ Disconnected", foreground="red", font=("Arial", 9))
        self.status_label.pack(side=tk.LEFT, padx=(0, 15))
        
        ttk.Label(status_row, text="Server:", font=("Arial", 9)).pack(side=tk.LEFT, padx=(0, 5))
        self.server_label = ttk.Label(status_row, text=self.api_base, foreground="blue", font=("Courier", 9))
        self.server_label.pack(side=tk.LEFT)
        
        # Model load status
        model_status_row = ttk.Frame(self.control_frame)
        model_status_row.pack(anchor=tk.W, pady=(0, 10))
        
        self.model_status_label = ttk.Label(model_status_row, text="❌ No Model Loaded", foreground="red", font=("Arial", 9))
        self.model_status_label.pack(side=tk.LEFT, padx=(0, 15))
        
        ttk.Label(model_status_row, text="Model:", font=("Arial", 9)).pack(side=tk.LEFT, padx=(0, 5))
        self.model_name_label = ttk.Label(model_status_row, text="Waiting...", foreground="blue", font=("Courier", 9))
        self.model_name_label.pack(side=tk.LEFT)
        
        ttk.Button(self.control_frame, text="Check Connection", command=self.check_connection).pack(fill=tk.X, pady=3)
        ttk.Button(self.control_frame, text="Check Models", command=self.refresh_models).pack(fill=tk.X, pady=3)
        ttk.Button(self.control_frame, text="Unload Model from VRAM", command=self.unload_model).pack(fill=tk.X, pady=3)
        
        # Model selection
        ttk.Separator(self.control_frame, orient="horizontal").pack(fill=tk.X, pady=15)
        ttk.Label(self.control_frame, text="MODEL MANAGEMENT", font=("Arial", 11, "bold")).pack(anchor=tk.W, pady=(0, 8))
        
        ttk.Label(self.control_frame, text="Available Models:", font=("Arial", 9)).pack(anchor=tk.W, pady=(0, 3))
        ttk.Label(self.control_frame, text="(double click model to load)", font=("Arial", 8), foreground="gray").pack(anchor=tk.W, pady=(0, 5))
        
        # Listbox for models
        listbox_frame = ttk.Frame(self.control_frame)
        listbox_frame.pack(fill=tk.X, pady=(0, 8))
        
        scrollbar = ttk.Scrollbar(listbox_frame)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        
        self.models_listbox = tk.Listbox(listbox_frame, yscrollcommand=scrollbar.set, height=4, font=("Courier", 9))
        self.models_listbox.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        self.models_listbox.bind("<Double-Button-1>", self.on_model_double_click)
        scrollbar.config(command=self.models_listbox.yview)
        
        # Document upload section
        ttk.Separator(self.control_frame, orient="horizontal").pack(fill=tk.X, pady=15)
        ttk.Label(self.control_frame, text="DOCUMENT UPLOAD", font=("Arial", 11, "bold")).pack(anchor=tk.W, pady=(0, 8))
        
        # Analysis options
        ttk.Label(self.control_frame, text="Analysis Options:", font=("Arial", 9)).pack(anchor=tk.W, pady=(0, 5))
        
        options_frame = ttk.Frame(self.control_frame)
        options_frame.pack(anchor=tk.W, pady=(0, 8))
        
        ttk.Checkbutton(options_frame, text="Examine", variable=self.examine_var).pack(side=tk.LEFT, padx=(0, 10))
        ttk.Checkbutton(options_frame, text="Fact Check", variable=self.fact_check_var).pack(side=tk.LEFT, padx=(0, 10))
        ttk.Checkbutton(options_frame, text="Verify", variable=self.verify_var).pack(side=tk.LEFT, padx=(0, 10))
        ttk.Checkbutton(options_frame, text="Deep Reasoning", variable=self.reasoning_var).pack(side=tk.LEFT)
        
        # Max tokens and temperature control
        tokens_row = ttk.Frame(self.control_frame)
        tokens_row.pack(fill=tk.X, pady=(8, 0))
        
        ttk.Label(tokens_row, text="Max Tokens:", font=("Arial", 9)).pack(side=tk.LEFT, padx=(0, 5))
        ttk.Spinbox(tokens_row, from_=100, to=32000, textvariable=self.max_tokens_var, width=10).pack(side=tk.LEFT, padx=(0, 20))
        
        ttk.Label(tokens_row, text="Temperature:", font=("Arial", 9)).pack(side=tk.LEFT, padx=(0, 5))
        ttk.Spinbox(tokens_row, from_=0.0, to=2.0, increment=0.1, textvariable=self.temperature_var, width=10).pack(side=tk.LEFT)
        
        # File upload section
        ttk.Label(self.control_frame, text="Uploaded Files (Max 2):", font=("Arial", 9)).pack(anchor=tk.W, pady=(8, 3))
        
        # File list display
        file_list_frame = ttk.Frame(self.control_frame)
        file_list_frame.pack(fill=tk.BOTH, expand=True, pady=(0, 8))
        
        file_scrollbar = ttk.Scrollbar(file_list_frame)
        file_scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        
        self.files_listbox = tk.Listbox(file_list_frame, yscrollcommand=file_scrollbar.set, height=4, font=("Courier", 9))
        self.files_listbox.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        file_scrollbar.config(command=self.files_listbox.yview)
        
        # Browse and Submit buttons
        upload_button_frame = ttk.Frame(self.control_frame)
        upload_button_frame.pack(fill=tk.X, pady=(0, 8))
        
        ttk.Button(upload_button_frame, text="Add Files", command=self.browse_document).pack(side=tk.LEFT, padx=(0, 5))
        ttk.Button(upload_button_frame, text="Remove Selected", command=self.remove_file).pack(side=tk.LEFT, padx=(0, 5))
        ttk.Button(upload_button_frame, text="Submit", command=self.submit_document).pack(side=tk.LEFT)
        
        # Initialize with loading splash
        self.run_startup_checks()
    
    def run_startup_checks(self):
        """Run startup checks in background thread with loading splash"""
        # Show loading splash
        splash = LoadingSplash(self.root)
        
        def startup_thread():
            self.check_connection()
            self.refresh_models()
            
            # Close splash and show main window
            splash.close()
            self.root.deiconify()  # Make main window visible
        
        # Start thread
        thread = threading.Thread(target=startup_thread, daemon=True)
        thread.start()
    
    def refresh_models(self):
        """Fetch and display available models from LM Studio"""
        try:
            response = requests.get(f"{self.api_base}/api/v1/models", timeout=5)
            if response.status_code == 200:
                data = response.json()
                models = data.get("models", [])  # LM Studio returns "models" key
                
                # Clear listbox and keys mapping
                self.models_listbox.delete(0, tk.END)
                self.model_keys = {}
                
                # Populate with model names (LLMs only, filter out embeddings)
                llm_models = [m for m in models if m.get("type") == "llm"]
                
                if llm_models:
                    for idx, model in enumerate(llm_models):
                        display_name = model.get("display_name", "Unknown")
                        key = model.get("key", "unknown")
                        quantization = model.get("quantization", {}).get("name", "")
                        
                        # Display format: "Mistral 7B (Q4_K_M)" 
                        display_text = f"{display_name} ({quantization})"
                        self.models_listbox.insert(tk.END, display_text)
                        self.model_keys[idx] = key  # Store key by index
                else:
                    self.models_listbox.insert(tk.END, "No LLM models found")
            else:
                self.models_listbox.delete(0, tk.END)
                self.models_listbox.insert(tk.END, "Failed to load models")
        except Exception as e:
            self.models_listbox.delete(0, tk.END)
            self.models_listbox.insert(tk.END, f"Error: {str(e)}")
    
    def on_model_double_click(self, event):
        """Handle double-click on model to load it"""
        selection = self.models_listbox.curselection()
        if not selection:
            return
        
        index = selection[0]
        model_key = self.model_keys.get(index)
        
        if not model_key:
            messagebox.showerror("Error", "Could not identify selected model")
            return
        
        try:
            response = requests.post(
                f"{self.api_base}/api/v1/models/load",
                json={"model": model_key},
                timeout=30
            )
            
            if response.status_code == 200:
                self.current_model = model_key
                self.check_connection()
                messagebox.showinfo("Success", f"Model loaded: {model_key}")
            else:
                messagebox.showerror("Error", f"Failed to load model.\nStatus: {response.status_code}")
        except Exception as e:
            messagebox.showerror("Error", f"Error loading model:\n{str(e)}")
    
    def unload_model(self):
        """Unload current model from VRAM"""
        try:
            response = requests.get(f"{self.api_base}/api/v1/models", timeout=5)
            
            if response.status_code == 200:
                response_unload = requests.post(
                    f"{self.api_base}/api/v1/models/unload",
                    timeout=10
                )
                
                if response_unload.status_code == 200:
                    self.current_model = None
                    self.check_connection()
                    messagebox.showinfo("Success", "Model unloaded from VRAM")
                else:
                    messagebox.showerror("Error", f"Failed to unload model.\nStatus: {response_unload.status_code}")
            else:
                messagebox.showerror("Error", "Could not fetch models list.")
                
        except Exception as e:
            messagebox.showerror("Error", f"Error unloading model:\n{str(e)}")
    
    def check_connection(self):
        """Check if LM Studio API is running and update model status"""
        try:
            response = requests.get(f"{self.api_base}/api/v1/models", timeout=2)
            self.status_label.config(text="✅ Connected", foreground="green")
            
            # Check for loaded model
            if response.status_code == 200:
                data = response.json()
                models = data.get("models", [])
                
                # Find loaded model (LM Studio marks loaded models as active)
                for model in models:
                    if model.get("type") == "llm":
                        # Check if model has a loaded/active state
                        display_name = model.get("display_name", "Unknown")
                        if model.get("loaded") or model.get("status") == "loaded":
                            self.current_model = model.get("key")
                            self.model_status_label.config(text="✅ Model Loaded", foreground="green")
                            self.model_name_label.config(text=display_name, foreground="blue")
                            return True
                
                # No model loaded
                self.model_status_label.config(text="❌ No Model Loaded", foreground="red")
                self.model_name_label.config(text="Waiting...", foreground="blue")
            return True
        except:
            self.status_label.config(text="❌ Disconnected", foreground="red")
            self.model_status_label.config(text="❌ No Model Loaded", foreground="red")
            self.model_name_label.config(text="Offline", foreground="blue")
            return False
    
    def browse_document(self):
        """Open file dialog to select .txt or .md files (max 2 total)"""
        # Calculate how many slots are available
        slots_available = 2 - len(self.uploaded_documents)
        
        if slots_available <= 0:
            messagebox.showwarning("File Limit", "Maximum 2 files allowed. Remove a file to add more.")
            return
        
        files = filedialog.askopenfilenames(
            title=f"Select Text Files (max {slots_available} remaining)",
            filetypes=[
                ("Text/Markdown Files", "*.txt *.md"),
                ("Text Files", "*.txt"),
                ("Markdown Files", "*.md"),
            ]
        )
        
        if files:
            # Only add up to the available slots
            files_to_add = list(files)[:slots_available]
            
            for file_path in files_to_add:
                if file_path not in self.uploaded_documents:
                    self.uploaded_documents.append(file_path)
            
            # Update listbox display
            self.update_files_display()
            
            # Show confirmation
            file_count = len(files_to_add)
            filenames = ", ".join(os.path.basename(f) for f in files_to_add)
            messagebox.showinfo("Files Added", f"Added {file_count} file(s):\n{filenames}")
    
    def update_files_display(self):
        """Update the files listbox with current uploaded files"""
        self.files_listbox.delete(0, tk.END)
        for file_path in self.uploaded_documents:
            self.files_listbox.insert(tk.END, os.path.basename(file_path))
    
    def remove_file(self):
        """Remove selected file from upload list"""
        selection = self.files_listbox.curselection()
        if not selection:
            messagebox.showwarning("No Selection", "Please select a file to remove.")
            return
        
        index = selection[0]
        removed_file = self.uploaded_documents.pop(index)
        self.update_files_display()
        messagebox.showinfo("File Removed", f"Removed: {os.path.basename(removed_file)}")
    
    def submit_document(self):
        """Submit the selected documents for analysis"""
        if not self.uploaded_documents:
            messagebox.showwarning("No Documents", "Please add documents first.")
            return
        
        if not self.current_model:
            messagebox.showwarning("No Model", "Please load a model first.")
            return
        
        # Check if at least one analysis option is selected
        options = [self.examine_var.get(), self.fact_check_var.get(), 
                   self.verify_var.get(), self.reasoning_var.get()]
        if not any(options):
            messagebox.showwarning("No Options", "Please select at least one analysis option.")
            return
        
        try:
            # Read all uploaded files
            all_content = []
            for file_path in self.uploaded_documents:
                with open(file_path, 'r', encoding='utf-8') as f:
                    content = f.read()
                    all_content.append(f"=== {os.path.basename(file_path)} ===\n{content}")
            
            combined_content = "\n\n".join(all_content)
            
            # Build analysis instructions
            instructions = []
            if self.examine_var.get():
                instructions.append("Examine the documents thoroughly")
            if self.fact_check_var.get():
                instructions.append("Fact check the claims in the documents")
            if self.verify_var.get():
                instructions.append("Verify the information presented")
            if self.reasoning_var.get():
                instructions.append("Provide deep reasoning and analysis")
            
            instructions_text = ", ".join(instructions)
            
            # Build the prompt
            prompt = f"""Please analyze the following document(s). {instructions_text}.

Documents:
{combined_content}

Provide a comprehensive analysis based on the requested operations."""
            
            # Send to LM Studio API
            response = requests.post(
                f"{self.api_base}/v1/chat/completions",
                json={
                    "model": self.current_model,
                    "messages": [
                        {"role": "user", "content": prompt}
                    ],
                    "temperature": self.temperature_var.get(),
                    "max_tokens": self.max_tokens_var.get()
                },
                timeout=120
            )
            
            if response.status_code == 200:
                result = response.json()
                analysis = result['choices'][0]['message']['content']
                
                # Save the output to a file in the current working directory
                timestamp = os.path.basename(self.uploaded_documents[0])
                output_filename = f"{os.path.splitext(timestamp)[0]}_analysis.txt"
                output_path = os.path.join(os.getcwd(), output_filename)
                
                with open(output_path, 'w', encoding='utf-8') as f:
                    f.write(f"Document Analysis Report\n")
                    f.write(f"Files Analyzed: {len(self.uploaded_documents)}\n")
                    for file_path in self.uploaded_documents:
                        f.write(f"  - {os.path.basename(file_path)}\n")
                    f.write(f"Analysis Options: {instructions_text}\n")
                    f.write(f"Model: {self.current_model}\n")
                    f.write(f"{'='*80}\n\n")
                    f.write(analysis)
                
                messagebox.showinfo("Success", f"Analysis complete!\n\nResults saved to:\n{output_path}")
                
                # Clear uploaded documents after successful submission
                self.uploaded_documents.clear()
                self.update_files_display()
            else:
                messagebox.showerror("Error", f"API Error: {response.status_code}")
        
        except FileNotFoundError:
            messagebox.showerror("Error", "Could not read one of the selected files.")
        except requests.exceptions.RequestException as e:
            messagebox.showerror("Error", f"Failed to connect to LM Studio:\n{str(e)}")
        except KeyError:
            messagebox.showerror("Error", "Unexpected response format from LM Studio.")


if __name__ == "__main__":
    root = tk.Tk()
    # Hide main window initially - will show after startup checks
    root.withdraw()
    app = LMStudioOrchestrator(root)
    root.mainloop()
