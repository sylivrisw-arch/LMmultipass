#!/usr/bin/env python3
"""
LMSuite Prompt Editor  (lm_prompt_editor.py)
============================================
Edit every prompt LMengine.py sends to a model, save the result as a "master prompt" file, and
have the suite load it. Keep this file in the same folder as LMengine.py.

WHAT IT EDITS  (everything in CONFIG that is sent to a model)
    Discussion Roles      every role's turn prompt (Researcher, Worldbuilder, ...)
    Discussion Rules      Double-Check, Investigate Deeper, Verify Claims, Cross-Check prompts
    Discussion (general)  the compaction / summary prompt
    Final Writer          the Final Writer template
    Output Profiles       each Category's "form" and "focus" text
New roles / rules / templates you add to CONFIG later show up here automatically.

HOW IT WORKS
    Apply   checks every prompt, saves your changes to the master prompt file
            (~/Downloads/lm_master_prompt.json) and makes them live in the running suite -
            prompts are read fresh on every model call, so no restart is needed.
    Load    reads any master prompt file into the editor so you can review it, then Apply.
    Only prompts that differ from the built-in defaults are stored, so a change you make to a
    default in the code still reaches every prompt you haven't customised.
    Placeholders like {topic} and {transcript} are checked so a typo can't crash a turn.

ADDING IT TO LMengine.py  (three small edits)
    1) With the other imports at the top:
           import lm_prompt_editor

    2) Directly after the CONFIG dict closes (just under the "END CONFIGURATION" banner), so the
       saved master prompt is loaded every time the suite starts:
           lm_prompt_editor.load_master_prompt(CONFIG)

    3) In the Constraints Engine card, after the 'Token Tuner' button:
           tk.Button(engine_controls_row, text='📝 Prompt Editor',
                     command=lambda: lm_prompt_editor.open_prompt_editor(
                         self.root, CONFIG,
                         on_apply=lambda n: self.add_log(
                             f"Prompt Editor applied: {n} customised prompt(s)", "INFO")),
                     **BUTTON_STYLES['primary']).pack(side=tk.LEFT, padx=(6, 0))

    Compiling with PyInstaller picks the module up from the import in step 1.

You can also run this file on its own (python lm_prompt_editor.py) next to LMengine.py.
"""

import datetime
import json
import os
import re
import shutil
import string
import sys
import tkinter as tk
from tkinter import filedialog, messagebox, ttk

TITLE = "LMSuite Prompt Editor"
MASTER_PROMPT_PATH = os.path.join(os.path.expanduser("~"), "Downloads", "lm_master_prompt.json")
MASTER_FORMAT = "lmsuite_master_prompt"
MASTER_VERSION = 1

# CONFIG sections that hold prompts, in the order they appear in the editor.
_SCAN_SECTIONS = ("DISCUSSION_ROLES", "DISCUSSION_RULES", "DISCUSSION", "FINAL_WRITER", "OUTPUT_PROFILES")
_FRAGMENT_KEYS = ("form", "create_focus")   # OUTPUT_PROFILES text that is slotted into a template

# Which {placeholders} the code fills in for each kind of template (see the .format() call sites
# in LMengine.py). Anything else inside braces would crash the turn, so it is rejected.
PLACEHOLDERS = {
    "turn_template": {"topic", "transcript"},
    "synthesis_template": {"topic", "transcript"},
    "verify_template": {"topic", "claims_list"},
    "selfcheck_template": {"topic", "claims_list"},
    "crosscheck_template": {"topic", "existing_summary", "claims_list"},
    "followup_template": {"topic", "turn"},
    "compaction_template": {"topic", "full_transcript"},
    "final_writer_template": {"article", "form", "topic", "instructions_block", "knowledge", "create_focus"},
}

USED_BY = {
    "turn_template": "Sent to the model every time this role takes a turn in a Discussion round.",
    "synthesis_template": "Sent to the model for the Moderator's closing synthesis of the whole discussion.",
    "verify_template": "Discussion Rule: the speaker re-reads its own turn and retracts statements it isn't sure about.",
    "selfcheck_template": "Discussion Rule: checks each factual statement against the model's own knowledge.",
    "crosscheck_template": "Discussion Rule: compares the new turn with the discussion so far and flags contradictions.",
    "followup_template": "Discussion Rule: after each turn, asks the speaker for more specific detail on its strongest claim.",
    "compaction_template": "Sent when older turns are folded into the running summary (Auto-Merge / Compact Now).",
    "final_writer_template": "The main prompt for the Final Writer, which turns the whole discussion into the finished piece.",
    "form": "What the Final Writer produces for this Category (e.g. \"short story\"). Slotted into the Final Writer "
            "template as {form}. Plain text only - no curly braces.",
    "create_focus": "Extra instruction the Final Writer gets for this Category. Slotted into the Final Writer "
                    "template as {create_focus}. Plain text only - no curly braces.",
}

# The app parses the reply to these prompts, so the answer format has to stay in the prompt.
FORMAT_NOTES = {
    "verify_template": "The app reads this prompt's reply: keep the instruction to answer one line per statement "
                       "as '<number>. CONFIRM or RETRACT'.",
    "selfcheck_template": "The app reads this prompt's reply: keep the instruction to answer one line per statement "
                          "as '<number>. CONSISTENT or QUESTIONABLE'.",
    "crosscheck_template": "The app reads this prompt's reply: keep the instruction to answer one line per statement "
                           "as '<number>. OK or CONTRADICTS'.",
    "followup_template": "The app treats a reply that starts with NO FURTHER DETAIL as \"nothing to add\": keep "
                         "that instruction.",
    "final_writer_template": "Keep the instruction to return ONLY the finished piece, or any preamble the model "
                             "adds will end up in the Final Output.",
}

# Words the app looks for in the model's reply. If the prompt never mentions them the rule silently stops working.
REQUIRED_WORDS = {
    "verify_template": ["RETRACT"],
    "selfcheck_template": ["QUESTIONABLE"],
    "crosscheck_template": ["CONTRADICTS"],
    "followup_template": ["NO FURTHER DETAIL"],
}

_DEFAULTS = {}            # prompt id -> text as written in the code (captured before any override)
_startup_loaded = False   # has load_master_prompt() already run for the standard file?
_open_editor = None       # the editor window, if one is open


# ============================================================================
# Finding the prompts inside CONFIG
# ============================================================================
def _walk_strings(node, path):
    if isinstance(node, dict):
        for k, v in node.items():
            yield from _walk_strings(v, path + (k,))
    elif isinstance(node, str):
        yield path, node


def _pretty(key):
    return key.replace("_", " ").replace(" template", "").strip().title()


def _make_entry(config, path, key, kind, text):
    section = path[0]
    sub = None
    if section == "DISCUSSION_ROLES":
        group = "Discussion Roles"
        label = path[1] if key == "turn_template" else "%s (%s)" % (path[1], _pretty(key))
    elif section == "DISCUSSION_RULES":
        group = "Discussion Rules"
        rule_cfg = config.get(section, {}).get(path[1], {})
        label = rule_cfg.get("label", path[1]) if isinstance(rule_cfg, dict) else path[1]
    elif section == "DISCUSSION":
        group = "Discussion (general)"
        label = "Compaction summary" if key == "compaction_template" else _pretty(key)
    elif section == "FINAL_WRITER":
        group = "Final Writer"
        label = "Final Writer template" if key == "final_writer_template" else _pretty(key)
    else:  # OUTPUT_PROFILES
        group = "Output Profiles"
        sub = path[1]
        label = "Form (what is produced)" if key == "form" else "Focus (extra instruction)"
    title = " › ".join([group] + ([sub] if sub else []) + [label])
    return {"id": "/".join(path), "path": path, "key": key, "kind": kind, "text": text,
            "group": group, "sub": sub, "label": label, "title": title}


def collect_prompts(config):
    """Every editable prompt currently in CONFIG, as a list of dicts (see _make_entry)."""
    entries = []
    for section in _SCAN_SECTIONS:
        node = config.get(section)
        if not isinstance(node, dict):
            continue
        for path, text in _walk_strings(node, (section,)):
            key = path[-1]
            if section == "OUTPUT_PROFILES":
                if key not in _FRAGMENT_KEYS:
                    continue
                kind = "fragment"
            elif key.endswith("_template"):
                kind = "template"
            else:
                continue
            entries.append(_make_entry(config, path, key, kind, text))
    return entries


def snapshot_defaults(config):
    """Remember each prompt's text as written in the code, before any master prompt is applied."""
    for e in collect_prompts(config):
        _DEFAULTS.setdefault(e["id"], e["text"])


def _set_path(config, path, text):
    node = config
    for k in path[:-1]:
        node = node[k]
    node[path[-1]] = text


# ============================================================================
# Checking a prompt
# ============================================================================
def _parse_fields(text):
    """The set of {names} used in text. Raises ValueError with a readable message."""
    try:
        parsed = list(string.Formatter().parse(text))
    except ValueError as e:
        raise ValueError("Curly-brace problem (%s). Every { needs a matching } and only the listed "
                         "placeholders may go inside braces." % e)
    names = set()
    for _lit, field, _spec, _conv in parsed:
        if field is None:
            continue
        base = re.split(r"[.\[]", field, maxsplit=1)[0]
        if field != base:
            raise ValueError("'{%s}' is not allowed - placeholders can't use attributes or indexes." % field)
        if base == "" or base.isdigit():
            raise ValueError("An empty or numbered placeholder '{%s}' is not allowed - use a named one "
                             "like {topic}." % base)
        names.add(base)
    return names


def allowed_placeholders(key, kind, default_text=""):
    if kind == "fragment":
        return set()
    if key in PLACEHOLDERS:
        return set(PLACEHOLDERS[key])
    try:
        return _parse_fields(default_text) if default_text else set()
    except ValueError:
        return set()


def validate_prompt(key, kind, text, default_text=""):
    """Returns (errors, warnings). Errors block Apply; warnings ask for confirmation."""
    errors, warnings = [], []
    if not text.strip():
        return ["The prompt is empty."], []

    if kind == "fragment":
        if "{" in text or "}" in text:
            errors.append("Curly braces aren't allowed in this field (it is inserted into the Final Writer template).")
        return errors, warnings

    allowed = allowed_placeholders(key, kind, default_text)
    try:
        used = _parse_fields(text)
    except ValueError as e:
        return [str(e)], []

    unknown = sorted(used - allowed)
    if unknown:
        errors.append("Unknown placeholder(s): %s. Allowed here: %s." % (
            ", ".join("{%s}" % n for n in unknown),
            ", ".join("{%s}" % n for n in sorted(allowed)) or "none"))
    if not errors:
        try:
            text.format(**{n: "x" for n in allowed})
        except (KeyError, IndexError, ValueError, AttributeError, TypeError) as e:
            errors.append("This text can't be used as a template (%s)." % e)
    if errors:
        return errors, warnings

    try:
        default_fields = _parse_fields(default_text) if default_text else set()
    except ValueError:
        default_fields = set()
    for n in sorted((default_fields & allowed) - used):
        warnings.append("{%s} is no longer in the prompt, so the model won't be given that part." % n)
    for w in REQUIRED_WORDS.get(key, []):
        if w.lower() not in text.lower():
            warnings.append("The app looks for \"%s\" in the model's reply, but this prompt never asks for it - "
                            "this rule would stop working." % w)
    return errors, warnings


# ============================================================================
# Master prompt file + applying it
# ============================================================================
def read_master_file(path):
    """Return {prompt id: text} from a master prompt file. Raises ValueError with a readable message."""
    try:
        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)
    except OSError as e:
        raise ValueError("Couldn't read %s (%s)." % (path, e))
    except json.JSONDecodeError as e:
        raise ValueError("%s isn't valid JSON (%s)." % (os.path.basename(path), e))
    if not isinstance(data, dict):
        raise ValueError("%s isn't a master prompt file." % os.path.basename(path))
    if data.get("format") not in (None, MASTER_FORMAT):
        raise ValueError("%s is a different kind of file (format '%s')." % (os.path.basename(path), data.get("format")))
    prompts = data["prompts"] if "prompts" in data else data
    if not isinstance(prompts, dict) or not all(isinstance(k, str) and isinstance(v, str) for k, v in prompts.items()):
        raise ValueError("%s doesn't contain a valid set of prompts." % os.path.basename(path))
    return prompts


def save_master_file(prompts, path=None):
    """Write {prompt id: text} to a master prompt file (atomically, keeping one .bak of the old file)."""
    path = path or MASTER_PROMPT_PATH
    data = {
        "format": MASTER_FORMAT,
        "version": MASTER_VERSION,
        "saved_at": datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "note": "Only prompts that differ from the built-in defaults are stored. Edit with lm_prompt_editor.py.",
        "prompts": prompts,
    }
    folder = os.path.dirname(path)
    if folder:
        os.makedirs(folder, exist_ok=True)
    if os.path.isfile(path):
        shutil.copy2(path, path + ".bak")
    tmp = path + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2, ensure_ascii=False)
    os.replace(tmp, path)


def _resolve(entries, defaults, prompts):
    """Work out the final text for every prompt: the master prompt's text where it is valid,
    otherwise the built-in default. Returns (texts, customised_ids, problems)."""
    known = {e["id"] for e in entries}
    problems = ["'%s' is not a prompt in this version of the suite - ignored." % pid
                for pid in prompts if pid not in known]
    texts, custom = {}, []
    for e in entries:
        pid = e["id"]
        default = defaults.get(pid, e["text"])
        text = default
        if pid in prompts:
            cand = prompts[pid]
            errs = validate_prompt(e["key"], e["kind"], cand, default)[0] if isinstance(cand, str) else ["Not text."]
            if errs:
                problems.append("%s: %s Kept the built-in default." % (e["title"], errs[0]))
            else:
                text = cand
        texts[pid] = text
        if text != default:
            custom.append(pid)
    return texts, custom, problems


def apply_master_prompt(config, prompts):
    """Make CONFIG match {prompt id: text}: those prompts get the master text, every other prompt
    goes back to its built-in default. Returns (customised_ids, problems)."""
    snapshot_defaults(config)
    entries = collect_prompts(config)
    texts, custom, problems = _resolve(entries, _DEFAULTS, prompts or {})
    for e in entries:
        _set_path(config, e["path"], texts[e["id"]])
    return custom, problems


def load_master_prompt(config, path=None):
    """Startup hook: apply the saved master prompt file to CONFIG if it exists.
    Returns (customised_ids, problems); quiet and harmless when there is no file yet."""
    global _startup_loaded
    path = path or MASTER_PROMPT_PATH
    snapshot_defaults(config)
    if os.path.normpath(path) == os.path.normpath(MASTER_PROMPT_PATH):
        _startup_loaded = True
    if not os.path.isfile(path):
        return [], []
    try:
        prompts = read_master_file(path)
    except ValueError as e:
        print("[Prompt Editor] %s" % e, file=sys.stderr)
        return [], [str(e)]
    custom, problems = apply_master_prompt(config, prompts)
    for p in problems:
        print("[Prompt Editor] %s" % p, file=sys.stderr)
    return custom, problems


def ensure_loaded(config):
    """Make sure CONFIG reflects the saved master prompt (covers a missing startup hook)."""
    if not _startup_loaded:
        load_master_prompt(config)


# ============================================================================
# The editor window
# ============================================================================
def _theme(config):
    c = (config or {}).get("COLORS", {})
    f = (config or {}).get("FONTS", {})
    return {
        "bg": c.get("bg_primary", "#f4f5f7"), "card": c.get("bg_white", "#ffffff"),
        "input": c.get("bg_input", "#ffffff"), "text": c.get("text_primary", "#111827"),
        "muted": c.get("text_muted", "#6b7280"), "on_accent": c.get("text_white", "#ffffff"),
        "error": c.get("text_error", "#b91c1c"), "warn": c.get("text_warning", "#b45309"),
        "accent": c.get("button_primary", "#2563eb"), "ok": c.get("button_green", "#15803d"),
        "danger": c.get("button_red", "#b91c1c"), "border": c.get("border_gray", "#d1d5db"),
        "neutral": c.get("tab_inactive", "#e5e7eb"),
        "family": f.get("family_default", "Segoe UI"), "mono": f.get("family_mono", "Consolas"),
        "size": f.get("size_normal", 10), "small": f.get("size_small", 9), "title": f.get("size_title", 11),
    }


class PromptEditor:
    def __init__(self, parent, config, on_apply=None, on_close=None, master_path=None, standalone=False):
        self.config = config
        self.on_apply = on_apply
        self.on_close = on_close
        self.master_path = master_path or MASTER_PROMPT_PATH
        self.standalone = standalone
        self.t = _theme(config)

        snapshot_defaults(config)
        self.entries = collect_prompts(config)
        self.by_id = {e["id"]: e for e in self.entries}
        self.defaults = {e["id"]: _DEFAULTS.get(e["id"], e["text"]) for e in self.entries}
        self.baseline = {e["id"]: e["text"] for e in self.entries}   # what is live right now
        self.working = dict(self.baseline)                            # what the editor currently holds
        self.current_id = None
        self._loading = False
        self._rebuilding = False

        self.win = tk.Toplevel(parent)
        self._build_ui()
        self._rebuild_tree()
        if self.entries:
            self._select(self.entries[0]["id"])
        else:
            self._set_status("No prompts were found in CONFIG.", "err")
        self._update_counts()

    # ---- layout ---------------------------------------------------------------------------
    def _btn(self, parent, text, command, kind="primary"):
        t = self.t
        bg = {"primary": t["accent"], "ok": t["ok"], "danger": t["danger"], "neutral": t["neutral"]}[kind]
        fg = t["text"] if kind == "neutral" else t["on_accent"]
        return tk.Button(parent, text=text, command=command, bg=bg, fg=fg, activebackground=bg,
                         activeforeground=fg, relief=tk.FLAT, bd=0, padx=12, pady=6, cursor="hand2",
                         font=(t["family"], t["size"]))

    def _build_ui(self):
        t, win = self.t, self.win
        win.title(TITLE)
        win.geometry("1120x720")
        win.minsize(920, 600)
        win.configure(bg=t["bg"])
        win.protocol("WM_DELETE_WINDOW", self._close)
        win.bind("<Control-s>", lambda _e: self.apply())
        win.bind("<Control-f>", lambda _e: (self.search_entry.focus_set(), "break")[1])

        font = (t["family"], t["size"])
        font_bold = (t["family"], t["size"], "bold")
        font_small = (t["family"], t["small"])

        # Header
        header = tk.Frame(win, bg=t["bg"])
        header.pack(fill=tk.X, padx=14, pady=(12, 6))
        tk.Label(header, text="Prompt Editor", bg=t["bg"], fg=t["text"],
                 font=(t["family"], t["title"] + 4, "bold")).pack(side=tk.LEFT)
        self.count_var = tk.StringVar()
        tk.Label(header, textvariable=self.count_var, bg=t["bg"], fg=t["muted"], font=font_small).pack(side=tk.RIGHT)
        tk.Label(win, text="Master prompt file:  " + self.master_path, bg=t["bg"], fg=t["muted"], font=font_small,
                 anchor=tk.W).pack(fill=tk.X, padx=14)

        # Bottom bar (packed before the body so it always stays visible)
        bottom = tk.Frame(win, bg=t["bg"])
        bottom.pack(side=tk.BOTTOM, fill=tk.X, padx=14, pady=(6, 12))
        self.status_var = tk.StringVar()
        self.status_lbl = tk.Label(bottom, textvariable=self.status_var, bg=t["bg"], fg=t["muted"], font=font_small,
                                   anchor=tk.W, justify=tk.LEFT)
        self.status_lbl.pack(fill=tk.X, pady=(0, 6))
        bar = tk.Frame(bottom, bg=t["bg"])
        bar.pack(fill=tk.X)
        self._btn(bar, "📂 Load Master Prompt…", self.load_file, "neutral").pack(side=tk.LEFT, padx=(0, 6))
        self._btn(bar, "💾 Save As…", self.save_as, "neutral").pack(side=tk.LEFT, padx=(0, 6))
        self._btn(bar, "↺ Reset All to Defaults", self.reset_all, "danger").pack(side=tk.LEFT)
        self._btn(bar, "Close", self._close, "neutral").pack(side=tk.RIGHT)
        self._btn(bar, "✓ Apply  (Ctrl+S)", self.apply, "ok").pack(side=tk.RIGHT, padx=(0, 6))

        # Body: prompt list on the left, editor on the right
        paned = tk.PanedWindow(win, orient=tk.HORIZONTAL, sashwidth=6, bg=t["bg"], bd=0)
        paned.pack(fill=tk.BOTH, expand=True, padx=14, pady=8)

        left = tk.Frame(paned, bg=t["bg"])
        paned.add(left, minsize=260, width=360)
        search_row = tk.Frame(left, bg=t["bg"])
        search_row.pack(fill=tk.X, pady=(0, 6))
        tk.Label(search_row, text="Find:", bg=t["bg"], fg=t["muted"], font=font_small).pack(side=tk.LEFT)
        self.search_var = tk.StringVar()
        self.search_entry = tk.Entry(search_row, textvariable=self.search_var, font=font, relief=tk.SOLID, bd=1,
                                     bg=t["input"], fg=t["text"], insertbackground=t["text"])
        self.search_entry.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=(6, 0))
        self.search_var.trace_add("write", lambda *_a: self._rebuild_tree())

        style = ttk.Style(win)
        style.configure("PE.Treeview", background=t["card"], fieldbackground=t["card"], foreground=t["text"],
                        rowheight=t["size"] * 2 + 6, font=font, borderwidth=1)
        style.map("PE.Treeview", background=[("selected", t["accent"])], foreground=[("selected", t["on_accent"])])
        tree_wrap = tk.Frame(left, bg=t["bg"])
        tree_wrap.pack(fill=tk.BOTH, expand=True)
        self.tree = ttk.Treeview(tree_wrap, show="tree", selectmode="browse", style="PE.Treeview")
        tree_sb = ttk.Scrollbar(tree_wrap, orient=tk.VERTICAL, command=self.tree.yview)
        self.tree.configure(yscrollcommand=tree_sb.set)
        self.tree.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        tree_sb.pack(side=tk.RIGHT, fill=tk.Y)
        self.tree.tag_configure("custom", foreground=t["accent"])
        self.tree.tag_configure("unsaved", foreground=t["warn"])
        self.tree.bind("<<TreeviewSelect>>", self._on_select)
        tk.Label(left, text="●  customised          amber = not applied yet",
                 bg=t["bg"], fg=t["muted"], font=font_small, anchor=tk.W).pack(fill=tk.X, pady=(6, 0))

        right = tk.Frame(paned, bg=t["bg"])
        paned.add(right, minsize=420)
        self.title_lbl = tk.Label(right, text="", bg=t["bg"], fg=t["text"], font=(t["family"], t["title"], "bold"),
                                  anchor=tk.W, justify=tk.LEFT)
        self.title_lbl.pack(fill=tk.X)
        self.used_lbl = tk.Label(right, text="", bg=t["bg"], fg=t["muted"], font=font_small, anchor=tk.W,
                                 justify=tk.LEFT)
        self.used_lbl.pack(fill=tk.X, pady=(2, 0))
        self.note_lbl = tk.Label(right, text="", bg=t["bg"], fg=t["warn"], font=font_small, anchor=tk.W,
                                 justify=tk.LEFT)
        self.note_lbl.pack(fill=tk.X, pady=(2, 0))
        self.ph_frame = tk.Frame(right, bg=t["bg"])
        self.ph_frame.pack(fill=tk.X, pady=(8, 6))

        # The reset button and validation line are packed first (at the bottom) so the expanding text box
        # can never squeeze them out of a short window.
        self._btn(right, "↺ Reset this prompt to default", self.reset_current, "neutral").pack(
            side=tk.BOTTOM, anchor=tk.W, pady=(6, 0))
        self.valid_lbl = tk.Label(right, text="", bg=t["bg"], fg=t["ok"], font=font_bold, anchor=tk.W,
                                  justify=tk.LEFT)
        self.valid_lbl.pack(side=tk.BOTTOM, fill=tk.X, pady=(6, 0))

        text_wrap = tk.Frame(right, bg=t["bg"])
        text_wrap.pack(fill=tk.BOTH, expand=True)
        self.text = tk.Text(text_wrap, wrap=tk.WORD, undo=True, maxundo=-1, font=(t["mono"], t["size"]),
                            bg=t["input"], fg=t["text"], insertbackground=t["text"], relief=tk.SOLID, bd=1,
                            padx=10, pady=8, spacing3=3, height=8)
        text_sb = ttk.Scrollbar(text_wrap, orient=tk.VERTICAL, command=self.text.yview)
        self.text.configure(yscrollcommand=text_sb.set)
        self.text.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        text_sb.pack(side=tk.RIGHT, fill=tk.Y)
        self.text.bind("<<Modified>>", self._on_modified)

        def on_right_resize(event):
            wrap = max(200, event.width - 20)
            for lbl in (self.title_lbl, self.used_lbl, self.note_lbl, self.valid_lbl):
                lbl.config(wraplength=wrap)
        right.bind("<Configure>", on_right_resize)

    # ---- tree -------------------------------------------------------------------------------
    def _leaf_text(self, pid):
        mark = "● " if self.working[pid] != self.defaults[pid] else "    "
        return mark + self.by_id[pid]["label"]

    def _leaf_tags(self, pid):
        if self.working[pid] != self.baseline[pid]:
            return ("unsaved",)
        if self.working[pid] != self.defaults[pid]:
            return ("custom",)
        return ()

    def _rebuild_tree(self):
        self._rebuilding = True
        query = self.search_var.get().strip().lower()
        self.tree.delete(*self.tree.get_children())
        groups = {}
        for e in self.entries:
            hay = " ".join([e["group"], e["sub"] or "", e["label"], e["id"]]).lower()
            if query and query not in hay:
                continue
            gid = "g:" + e["group"]
            if gid not in groups:
                self.tree.insert("", "end", iid=gid, text=e["group"], open=True)
                groups[gid] = gid
            parent = gid
            if e["sub"]:
                sid = gid + "/" + e["sub"]
                if sid not in groups:
                    self.tree.insert(gid, "end", iid=sid, text=e["sub"], open=bool(query))
                    groups[sid] = sid
                parent = sid
            self.tree.insert(parent, "end", iid=e["id"], text=self._leaf_text(e["id"]), tags=self._leaf_tags(e["id"]))
        if self.current_id and self.tree.exists(self.current_id):
            self.tree.selection_set(self.current_id)
            self.tree.see(self.current_id)
        self._rebuilding = False

    def _refresh_marker(self, pid):
        if self.tree.exists(pid):
            self.tree.item(pid, text=self._leaf_text(pid), tags=self._leaf_tags(pid))

    def _refresh_all_markers(self):
        for e in self.entries:
            self._refresh_marker(e["id"])
        self._update_counts()

    def _select(self, pid):
        if not self.tree.exists(pid):
            self.search_var.set("")          # rebuilds the tree with everything visible
        if self.tree.exists(pid):
            self.tree.selection_set(pid)
            self.tree.focus(pid)
            self.tree.see(pid)
        if pid != self.current_id:
            self._show(pid)

    def _on_select(self, _event=None):
        if self._rebuilding:
            return
        sel = self.tree.selection()
        if sel and sel[0] in self.by_id and sel[0] != self.current_id:
            self._show(sel[0])

    # ---- showing / editing one prompt ---------------------------------------------------------
    def _show(self, pid):
        self.current_id = pid
        e = self.by_id[pid]
        self.title_lbl.config(text=e["title"])
        self.used_lbl.config(text=USED_BY.get(e["key"], ""))
        self.note_lbl.config(text=FORMAT_NOTES.get(e["key"], ""))
        self._build_placeholder_buttons(e)
        self._set_text(self.working[pid])
        self._validate_current()

    def _set_text(self, value):
        self._loading = True
        self.text.delete("1.0", tk.END)
        self.text.insert("1.0", value)
        self.text.edit_reset()
        self.text.edit_modified(False)
        self._loading = False

    def _build_placeholder_buttons(self, e):
        t = self.t
        for child in self.ph_frame.winfo_children():
            child.destroy()
        allowed = sorted(allowed_placeholders(e["key"], e["kind"], self.defaults[e["id"]]))
        if not allowed:
            tk.Label(self.ph_frame, text="Plain text only - no {placeholders} in this one.", bg=t["bg"],
                     fg=t["muted"], font=(t["family"], t["small"])).pack(side=tk.LEFT)
            return
        tk.Label(self.ph_frame, text="Insert placeholder:", bg=t["bg"], fg=t["muted"],
                 font=(t["family"], t["small"])).pack(side=tk.LEFT, padx=(0, 6))
        for name in allowed:
            tk.Button(self.ph_frame, text="{%s}" % name, command=lambda n=name: self._insert_placeholder(n),
                      bg=t["neutral"], fg=t["text"], relief=tk.FLAT, bd=0, padx=8, pady=2, cursor="hand2",
                      font=(t["mono"], t["small"])).pack(side=tk.LEFT, padx=(0, 4))

    def _insert_placeholder(self, name):
        self.text.insert(tk.INSERT, "{%s}" % name)
        self.text.focus_set()

    def _on_modified(self, _event=None):
        if not self.text.edit_modified():
            return
        self.text.edit_modified(False)
        if self._loading or self.current_id is None:
            return
        self.working[self.current_id] = self.text.get("1.0", "end-1c")
        self._refresh_marker(self.current_id)
        self._validate_current()
        self._update_counts()

    def _validate_current(self):
        t = self.t
        e = self.by_id[self.current_id]
        errors, warnings = validate_prompt(e["key"], e["kind"], self.working[e["id"]], self.defaults[e["id"]])
        if errors:
            self.valid_lbl.config(text="✗ " + " ".join(errors), fg=t["error"])
        elif warnings:
            self.valid_lbl.config(text="⚠ " + " ".join(warnings), fg=t["warn"])
        else:
            self.valid_lbl.config(text="✓ Valid", fg=t["ok"])

    def reset_current(self):
        if self.current_id is None:
            return
        self.working[self.current_id] = self.defaults[self.current_id]
        self._set_text(self.working[self.current_id])
        self._refresh_marker(self.current_id)
        self._validate_current()
        self._update_counts()
        self._set_status("This prompt is back to its built-in default. Press Apply to save that.", "info")

    # ---- status ------------------------------------------------------------------------------
    def _set_status(self, msg, kind="info"):
        color = {"ok": self.t["ok"], "warn": self.t["warn"], "err": self.t["error"]}.get(kind, self.t["muted"])
        self.status_var.set(msg)
        self.status_lbl.config(fg=color)

    def _update_counts(self):
        custom = sum(1 for e in self.entries if self.working[e["id"]] != self.defaults[e["id"]])
        unsaved = sum(1 for e in self.entries if self.working[e["id"]] != self.baseline[e["id"]])
        self.count_var.set("%d prompts  ·  %d customised  ·  %d not applied yet" % (len(self.entries), custom, unsaved))

    # ---- actions ---------------------------------------------------------------------------
    def _collect_valid_overrides(self):
        """{id: text} for every prompt that differs from its default - or None (after telling the
        user why) if something is invalid or the user backs out of a warning."""
        bad, warned = [], []
        for e in self.entries:
            pid = e["id"]
            errors, warnings = validate_prompt(e["key"], e["kind"], self.working[pid], self.defaults[pid])
            if errors:
                bad.append((e, errors[0]))
            elif warnings and self.working[pid] != self.defaults[pid]:
                warned.append((e, warnings[0]))
        if bad:
            self._select(bad[0][0]["id"])
            lines = "\n".join("• %s: %s" % (e["title"], msg) for e, msg in bad[:8])
            more = "\n…and %d more." % (len(bad) - 8) if len(bad) > 8 else ""
            messagebox.showerror(TITLE, "Fix these before applying:\n\n%s%s" % (lines, more), parent=self.win)
            self._set_status("Nothing was saved - %d prompt(s) need fixing." % len(bad), "err")
            return None
        if warned:
            lines = "\n".join("• %s: %s" % (e["title"], msg) for e, msg in warned[:8])
            if not messagebox.askyesno(TITLE, "These prompts look incomplete:\n\n%s\n\nApply anyway?" % lines,
                                       icon="warning", default="no", parent=self.win):
                self._select(warned[0][0]["id"])
                return None
        return {e["id"]: self.working[e["id"]] for e in self.entries if self.working[e["id"]] != self.defaults[e["id"]]}

    def apply(self):
        """Validate, save the master prompt file and make it live. Returns True on success."""
        overrides = self._collect_valid_overrides()
        if overrides is None:
            return False
        try:
            save_master_file(overrides, self.master_path)
        except OSError as e:
            messagebox.showerror(TITLE, "Couldn't save the master prompt file:\n\n%s" % e, parent=self.win)
            self._set_status("Nothing was saved: %s" % e, "err")
            return False
        custom, problems = apply_master_prompt(self.config, overrides)
        self.baseline = dict(self.working)
        self._refresh_all_markers()
        if self.standalone:
            msg = ("✓ Saved %d customised prompt(s) to the master prompt file. Restart LMSuite (or open the "
                   "Prompt Editor inside it) to use them." % len(custom))
        else:
            msg = "✓ Applied %d customised prompt(s): saved to the master prompt file and live from the next model call." % len(custom)
        self._set_status(msg, "ok")
        if problems:
            messagebox.showwarning(TITLE, "Applied, with problems:\n\n" + "\n".join(problems[:8]), parent=self.win)
        if self.on_apply:
            try:
                self.on_apply(len(custom))
            except Exception as e:  # a logging hiccup in the host app must never break Apply
                print("[Prompt Editor] on_apply callback failed: %s" % e, file=sys.stderr)
        return True

    def load_file(self):
        if self._has_unapplied() and not messagebox.askyesno(
                TITLE, "You have edits that haven't been applied. Replace them with the file you load?",
                icon="warning", default="no", parent=self.win):
            return
        path = filedialog.askopenfilename(
            parent=self.win, title="Load master prompt", initialdir=os.path.dirname(self.master_path) or None,
            filetypes=[("Master prompt (JSON)", "*.json"), ("All files", "*.*")])
        if not path:
            return
        try:
            prompts = read_master_file(path)
        except ValueError as e:
            messagebox.showerror(TITLE, str(e), parent=self.win)
            return
        texts, custom, problems = _resolve(self.entries, self.defaults, prompts)
        self.working = texts
        if self.current_id:
            self._set_text(self.working[self.current_id])
            self._validate_current()
        self._refresh_all_markers()
        self._set_status("Loaded %d customised prompt(s) from %s. Review them, then press Apply to save and use them."
                         % (len(custom), os.path.basename(path)), "warn" if problems else "info")
        if problems:
            messagebox.showwarning(TITLE, "Loaded, with problems:\n\n" + "\n".join(problems[:8]), parent=self.win)

    def save_as(self):
        overrides = self._collect_valid_overrides()
        if overrides is None:
            return
        stamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
        path = filedialog.asksaveasfilename(
            parent=self.win, title="Save master prompt as", defaultextension=".json",
            initialdir=os.path.dirname(self.master_path) or None, initialfile="master_prompt_%s.json" % stamp,
            filetypes=[("Master prompt (JSON)", "*.json"), ("All files", "*.*")])
        if not path:
            return
        try:
            save_master_file(overrides, path)
        except OSError as e:
            messagebox.showerror(TITLE, "Couldn't save:\n\n%s" % e, parent=self.win)
            return
        self._set_status("Saved a copy to %s (the suite keeps using %s until you Apply)."
                         % (path, os.path.basename(self.master_path)), "ok")

    def reset_all(self):
        if not messagebox.askyesno(TITLE, "Put every prompt back to its built-in default?\n\nNothing is saved until "
                                   "you press Apply.", icon="warning", default="no", parent=self.win):
            return
        self.working = dict(self.defaults)
        if self.current_id:
            self._set_text(self.working[self.current_id])
            self._validate_current()
        self._refresh_all_markers()
        self._set_status("All prompts reset to their defaults. Press Apply to save that.", "info")

    def _has_unapplied(self):
        return any(self.working[e["id"]] != self.baseline[e["id"]] for e in self.entries)

    def _close(self):
        global _open_editor
        if self._has_unapplied():
            answer = messagebox.askyesnocancel(
                TITLE, "You have edits that haven't been applied.\n\nYes = Apply them and close\n"
                       "No = throw them away and close\nCancel = keep editing", icon="warning", parent=self.win)
            if answer is None:
                return
            if answer and not self.apply():
                return
        if _open_editor is self:
            _open_editor = None
        self.win.destroy()
        if self.on_close:
            self.on_close()


def open_prompt_editor(parent, config, on_apply=None, master_path=None):
    """Open (or raise) the Prompt Editor. `config` is LMengine's CONFIG dict; changes are made to it in
    place, so they take effect on the next model call. `on_apply(n)` is called after each Apply."""
    global _open_editor
    if _open_editor is not None:
        try:
            if _open_editor.win.winfo_exists():
                _open_editor.win.deiconify()
                _open_editor.win.lift()
                _open_editor.win.focus_force()
                return _open_editor
        except tk.TclError:
            pass
        _open_editor = None
    ensure_loaded(config)
    _open_editor = PromptEditor(parent, config, on_apply=on_apply, master_path=master_path)
    return _open_editor


def main():
    """Stand-alone mode: edit the prompts of the LMengine.py sitting next to this file."""
    global _open_editor
    here = os.path.dirname(sys.executable if getattr(sys, "frozen", False) else os.path.abspath(__file__))
    if here not in sys.path:
        sys.path.insert(0, here)
    root = tk.Tk()
    root.withdraw()
    try:
        import LMengine
    except Exception as e:
        messagebox.showerror(TITLE, "Couldn't load LMengine.py from this folder:\n\n%s\n\nKeep lm_prompt_editor.py "
                                    "next to LMengine.py." % e)
        return
    try:
        ttk.Style().theme_use("clam")
    except tk.TclError:
        pass
    ensure_loaded(LMengine.CONFIG)
    _open_editor = PromptEditor(root, LMengine.CONFIG, on_close=root.destroy, standalone=True)
    root.mainloop()


if __name__ == "__main__":
    main()
