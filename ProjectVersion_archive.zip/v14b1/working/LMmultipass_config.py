import tkinter as tk
from tkinter import ttk, messagebox, filedialog
import requests
import os
import threading
import datetime
import sys
import subprocess
import psutil

# Constraint Engine
try:
    from constraint_engine import (
        ConstraintEngine, 
        NoDoubleSpaces, CapitalizeFirst, NoTrailingWhitespace, 
        IsNonEmpty, MaxLength, NoCharacters,
        NoContradictions, ResponseLength
    )
    CONSTRAINT_ENGINE_AVAILABLE = True
except ImportError:
    CONSTRAINT_ENGINE_AVAILABLE = False

# Constraint Engine GUI
try:
    from constraint_engine_gui import ConstraintEngineGUI, engine_to_config, config_to_engine
    CONSTRAINT_GUI_AVAILABLE = True
except ImportError:
    CONSTRAINT_GUI_AVAILABLE = False

# ============================================================================
# CONFIGURATION - Edit everything here to customize the app
# ============================================================================
CONFIG = {
    # ===== API SETTINGS =====
    'API': {
        'base_url': 'http://localhost:1234',
        'models_endpoint': '/api/v1/models',
        'load_model_endpoint': '/api/v1/models/load',
        'chat_endpoint': '/v1/chat/completions',
        'timeout_connect': 2,
        'timeout_models': 5,
        'timeout_load': 30,
        'timeout_chat': 300,
    },
    
    # ===== PASS DESCRIPTIONS - EDIT THESE FOR DIFFERENT CASCADE BEHAVIORS =====
    'CASCADE_PASSES': {
        1: {
            'name': 'Pass 1',
            'role': 'Create',
            'prompt_template': 'Write a creative and engaging short story based on this idea:\n\n{story}\n\nMake it around 300-400 words with vivid descriptions and interesting characters.',
        },
        2: {
            'name': 'Pass 2',
            'role': 'Refine',
            'prompt_template': 'Improve this story by enhancing the narrative flow and adding more descriptive detail:\n\n{story}\n\nKeep it around 400-500 words.',
        },
        3: {
            'name': 'Pass 3',
            'role': 'Refine',
            'prompt_template': 'Deepen the story by developing character motivations, emotions, and dialogue. Make the interactions more realistic:\n\n{story}\n\nKeep it around 450-550 words.',
        },
        4: {
            'name': 'Pass 4',
            'role': 'Refine',
            'prompt_template': 'Refine the story for better pacing, build tension, and create a more compelling narrative arc:\n\n{story}\n\nKeep it around 450-550 words.',
        },
        5: {
            'name': 'Pass 5',
            'role': 'Polish',
            'prompt_template': 'Polish this story to publication quality. Enhance prose, ensure strong voice, perfect pacing, and create a satisfying conclusion:\n\n{story}\n\nFinal version should be 400-600 words of polished prose.',
        },
    },
    
    # ===== COLORS =====
    'COLORS': {
        'bg_primary': '#f0f2f7',           # Main background
        'bg_secondary': '#f9f9f9',         # Light gray backgrounds
        'bg_white': 'white',                # Card backgrounds
        'bg_menu': '#f0f0f0',              # Menu bar background
        'bg_input': 'white',               # Input field background
        
        'text_primary': '#000',             # Main text
        'text_secondary': '#333',           # Headings
        'text_muted': 'gray',              # Faded text
        'text_white': 'white',             # White text
        'text_error': '#dc2626',           # Error red
        'text_blue': '#0066cc',            # Link blue
        
        'button_primary': '#0084ff',       # Main button color
        'button_green': '#4CAF50',         # Save/success buttons
        'button_red': '#dc2626',           # Delete/cancel buttons
        'button_disabled': '#ccc',         # Disabled button
        
        'border_light': '#e8ecf4',         # Card borders
        'border_gray': '#d0d0d0',          # Separators
        'border_dark': '#e8e8e8',          # Menu borders
        
        'status_online': 'green',          # Connected status
        'status_offline': 'red',           # Disconnected status
        'tab_active': '#4a9eff',           # Active tab background
        'tab_inactive': '#e8e8e8',         # Inactive tab background
    },
    
    # ===== FONTS =====
    'FONTS': {
        'family_default': 'Arial',
        'family_mono': 'Courier',
        
        'size_large': 14,                  # Large titles
        'size_title': 12,                  # Window/card titles
        'size_header': 11,                 # Section headers
        'size_normal': 10,                 # Normal text
        'size_small': 9,                   # Small text
        'size_tiny': 8,                    # Tiny text
    },
    
    # ===== DIMENSIONS =====
    'DIMENSIONS': {
        'window_width': 900,
        'window_height': 624,
        'splash_width': 400,
        'splash_height': 150,
        'settings_width': 550,
        'settings_height': 500,
        
        'padding_huge': 20,                # Large padding
        'padding_large': 15,               # Card padding
        'padding_normal': 12,              # Standard padding
        'padding_small': 8,                # Small padding
        'padding_tiny': 3,                 # Tiny padding
        
        'margin_large': 15,                # Large margins
        'margin_normal': 12,               # Standard margins
        'margin_small': 5,                 # Small margins
        
        'chat_height': 200,                # Chat message container height
        'cascade_output_height': 20,       # Story output text area height
        'model_list_height': 4,            # Model listbox height
        'chat_input_height': 2,            # Chat input height
        'story_prompt_height': 3,          # Story prompt input height
        
        'card_relief': tk.FLAT,
        'card_border_width': 3,
        'card_border': tk.SOLID,
    },
    
    # ===== TEXT & LABELS =====
    'TEXT': {
        # Window titles
        'app_title': 'LM Studio Multi-Model Orchestrator',
        'settings_title': 'Settings (beta)',
        'error_title': 'LM Studio Error',
        
        # Status messages
        'status_connected': '✅ Connected',
        'status_disconnected': '❌ Disconnected',
        'status_model_loaded': '✅ Model Loaded',
        'status_no_model': '❌ No Model Loaded',
        'status_waiting': 'Waiting...',
        'status_offline': 'Offline',
        'status_thinking': 'Thinking...',
        'status_detecting': 'Detecting...',
        
        # Card headers
        'card_status': 'Status',
        'card_model_loader': 'Model Loader',
        'card_story_cascade': 'Story Cascade',
        'card_chat': 'Chat',
        
        # Labels & fields
        'label_lm_studio_status': 'LM Studio Status:',
        'label_server': 'Server:',
        'label_model': 'Model:',
        'label_model_loaded': 'Model:',
        'label_tokens_used': 'Tokens used:',
        'label_reasoning': 'Reasoning:',
        'label_max_tokens': 'Max Tokens:',
        'label_temperature': 'Temperature:',
        'label_available_models': 'Available Models:',
        'label_double_click': '(double-click to load)',
        'label_system_resources': 'System Resources:',
        'label_vram': 'VRAM:',
        'label_ram': 'RAM:',
        'label_total': 'Total:',
        'label_story_idea': 'Story Idea/Prompt:',
        'label_select_model_pass': 'Select Model for Each Pass:',
        'label_leave_blank': '(leave blank to skip pass)',
        'label_pass': 'Pass',
        'label_create': 'Create',
        'label_refine': 'Refine',
        'label_polish': 'Polish',
        'label_tokens': 'Tokens:',
        'label_temp_global': 'Temperature (Global):',
        'label_temp_range': '(0.0-2.0)',
        'label_pass_polished': 'Pass 5 - Polished:',
        
        # Button labels
        'btn_refresh': 'Refresh Script',
        'btn_restart': 'Restart Script',
        'btn_generate': '▶ Generate',
        'btn_clear_all': '🗑️ Clear All',
        'btn_copy_output': '📋 Copy Output',
        'btn_save_story': '💾 Save Story',
        'btn_send': '➤',
        'btn_clear_chat': '🗑️ Clear',
        'btn_file': 'File',
        'btn_settings': 'Settings (beta)',
        'btn_view_log': 'View Log File',
        'btn_exit': 'Exit',
        'btn_apply_test': '✓ Apply & Test',
        'btn_close': 'Close',
        'btn_apply': '✓ Apply',
        'btn_save': 'Save',
        'btn_cancel': 'Cancel',
        'btn_pick_color': 'Pick Color',
        
        # Section headers in settings
        'settings_server_config': '🌐 Server Configuration',
        'settings_api_info': '📡 APIs Used',
        'settings_dev_settings': '🛠️  Developer Settings',
        'settings_color_custom': '🎨 Color Customization',
        'settings_header_custom': '📝 Section Header Customization',
        
        # Settings fields
        'settings_server_addr': 'LM Studio Server Address:',
        'settings_default': 'Default: http://localhost:1234',
        'settings_quick_start': 'Skip loading splash screen (Quick Start)',
        'settings_quick_start_desc': 'Bypasses the startup connection check',
        'settings_main_res': 'Main Window Resolution:',
        'settings_splash_res': 'Splash Window Resolution:',
        'settings_splash_note': 'Note: Restart app for resolution changes to take effect',
        'settings_text_color': 'Main Text Color:',
        'settings_heading_color': 'Section Header Color:',
        'settings_bg_color': 'Background Color:',
        'settings_button_color': 'Button Color:',
        'settings_font_size': 'Font Size:',
        'settings_font_weight': 'Font Weight:',
        
        # API info text
        'api_models_list': '• /api/v1/models - List available models',
        'api_models_load': '• /api/v1/models/load - Load a specific model',
        'api_chat': '• /v1/chat/completions - Chat endpoint for responses',
        
        # Messages
        'msg_no_model_selected': 'Please select a model for chat.',
        'msg_empty_message': 'Please type a message.',
        'msg_empty_prompt': 'Enter a story idea first.',
        'msg_in_progress': 'Cascade is already running.',
        'msg_no_models_cascade': 'Select at least one model for a pass.',
        'msg_empty_story': 'No story to copy',
        'msg_empty_to_save': 'No story to save',
        'msg_copied': 'Story cascade output copied to clipboard!',
        'msg_no_log': 'Log file not found:',
        'msg_restart_confirm': 'Restart? Token count will reset.',
        'msg_clear_logs': 'Clear all logs?',
        'msg_log_copied': 'Log entry copied!',
        'msg_no_selection': 'Select a log entry first.',
        'msg_no_model_identified': 'Could not identify model',
        'msg_empty_server': 'Please enter a server address first.',
        
        # Error messages
        'error_failed_load': 'Failed to load model.\nStatus:',
        'error_load_model': 'Error loading model:',
        'error_api_error': 'API Error:',
        'error_connection': 'Failed to connect to LM Studio:',
        'error_unexpected': 'Unexpected response format from LM Studio.',
        'error_cascade_no_models': 'Cascade error: no models selected',
        'error_cascade_empty': 'Cascade error: empty prompt',
        'error_save_file': 'Could not save:',
        'error_invalid_input': 'Invalid input',
        'error_invalid_resolution': 'Resolution values must be numbers!',
        
        # Popup titles
        'popup_success': 'Success',
        'popup_connected': 'Connected to server!',
        'popup_error': 'Error',
        'popup_warning': 'Warning',
        'popup_info': 'Info',
    },
    
    # ===== DEFAULT VALUES =====
    'DEFAULTS': {
        'max_tokens': 2000,
        'temperature': 0.7,
        'cascade_temperature': 0.8,
        'cascade_pass_tokens': 2000,
        'model_dropdown_width': 25,
        'model_display_width': 22,
    },
    
    # ===== CASCADE CATEGORIES =====
    'CASCADE_CATEGORIES': [
        'Story',
        'Coding',
        'Music',
        'Sports',
        'Movies',
        'Jokes',
        'Advice',
        'Electronics',
        'Articles',
        'Scripts',
        'Marketing',
        'Educational',
    ],
    
    # ===== PASS DESCRIPTIONS =====
    'CASCADE_PASSES': {
        1: {
            'name': 'Pass 1',
            'role': 'Create',
            'prompt_template': 'Write a creative and engaging short story based on this idea:\n\n{story}\n\nMake it around 300-400 words with vivid descriptions and interesting characters.',
        },
        2: {
            'name': 'Pass 2',
            'role': 'Refine',
            'prompt_template': 'Improve this story by enhancing the narrative flow and adding more descriptive detail:\n\n{story}\n\nKeep it around 400-500 words.',
        },
        3: {
            'name': 'Pass 3',
            'role': 'Refine',
            'prompt_template': 'Deepen the story by developing character motivations, emotions, and dialogue. Make the interactions more realistic:\n\n{story}\n\nKeep it around 450-550 words.',
        },
        4: {
            'name': 'Pass 4',
            'role': 'Refine',
            'prompt_template': 'Refine the story for better pacing, build tension, and create a more compelling narrative arc:\n\n{story}\n\nKeep it around 450-550 words.',
        },
        5: {
            'name': 'Pass 5',
            'role': 'Polish',
            'prompt_template': 'Polish this story to publication quality. Enhance prose, ensure strong voice, perfect pacing, and create a satisfying conclusion:\n\n{story}\n\nFinal version should be 400-600 words of polished prose.',
        },
    },
}

# ============================================================================
# END CONFIGURATION
# ============================================================================


class LoadingSplash:
    """Splash screen with loading bar shown during startup checks"""
    def __init__(self, root):
        self.root = root
        self.splash = tk.Toplevel(root)
        self.splash.title(CONFIG['TEXT']['app_title'])
        w, h = CONFIG['DIMENSIONS']['splash_width'], CONFIG['DIMENSIONS']['splash_height']
        self.splash.geometry(f"{w}x{h}")
        self.splash.resizable(False, False)
        
        # Center on screen
        self.splash.update_idletasks()
        x = (self.splash.winfo_screenwidth() // 2) - (w // 2)
        y = (self.splash.winfo_screenheight() // 2) - (h // 2)
        self.splash.geometry(f"+{x}+{y}")
        
        # Remove window decorations for cleaner look
        self.splash.attributes('-topmost', True)
        
        # Content
        font = (CONFIG['FONTS']['family_default'], CONFIG['FONTS']['size_title'], 'bold')
        ttk.Label(self.splash, text=CONFIG['TEXT']['app_title'], font=font).pack(
            pady=CONFIG['DIMENSIONS']['padding_large'])
        ttk.Label(self.splash, text="Checking server...", 
                 font=(CONFIG['FONTS']['family_default'], CONFIG['FONTS']['size_small'])).pack(
            pady=(0, CONFIG['DIMENSIONS']['padding_normal']))
        
        self.progress = ttk.Progressbar(self.splash, mode='indeterminate', length=300)
        self.progress.pack(pady=CONFIG['DIMENSIONS']['padding_normal'])
        self.progress.start()
    
    def close(self):
        """Close splash screen"""
        self.progress.stop()
        self.splash.destroy()


class LMStudioOrchestrator:
    def __init__(self, root):
        self.root = root
        self.root.title(CONFIG['TEXT']['app_title'])
        w, h = CONFIG['DIMENSIONS']['window_width'], CONFIG['DIMENSIONS']['window_height']
        self.root.geometry(f"{w}x{h}")
        self.root.resizable(False, False)
        
        # Window lock state
        self.window_locked = True
        
        # API Config
        self.api_base = CONFIG['API']['base_url']
        self.model_keys = {}
        self.current_model = None
        self.loading_model = False
        
        # Document settings
        self.max_tokens_var = tk.IntVar(value=CONFIG['DEFAULTS']['max_tokens'])
        self.temperature_var = tk.DoubleVar(value=CONFIG['DEFAULTS']['temperature'])
        self.cascade_category_var = tk.StringVar(value=CONFIG['CASCADE_CATEGORIES'][0])
        
        # Token tracking
        self.session_tokens = 0
        self.reasoning_tokens = 0
        
        # Logging
        self.error_log = []
        self.log_file_path = os.path.join(os.path.expanduser("~"), "Downloads", "lm_studio_logs.txt")
        self._initialize_log_file()
        
        # Settings storage
        self.settings = {
            'api_base': CONFIG['API']['base_url'],
            'quick_start_enabled': False,
            'main_window_width': CONFIG['DIMENSIONS']['window_width'],
            'main_window_height': CONFIG['DIMENSIONS']['window_height'],
            'splash_window_width': CONFIG['DIMENSIONS']['splash_width'],
            'splash_window_height': CONFIG['DIMENSIONS']['splash_height'],
        }
        self.settings_file = os.path.join(os.path.expanduser("~"), "Downloads", "lm_studio_settings.txt")
        self.load_settings()
        
        # Constraint Engine
        self.engine = None
        self.engine_loaded = False
        self._init_constraint_engine()
        
        # Build UI
        self._build_ui()
        
        # Bind window events
        self.root.bind("<Configure>", self.update_resolution)
        self.root.protocol("WM_DELETE_WINDOW", self.exit_app)
        
        # Run startup checks
        self.run_startup_checks()
        self.root.after(1000, self.update_system_resources)
    
    def _init_constraint_engine(self):
        """Initialize constraint engine with default story constraints"""
        if not CONSTRAINT_ENGINE_AVAILABLE:
            self.add_log("Constraint Engine: constraint_engine.py not found", "WARNING")
            return
        
        try:
            self.engine = ConstraintEngine(name="StoryValidator")
            
            # Separate constraints (fast, per-item)
            self.engine.add_separate(IsNonEmpty("IsNonEmpty"))
            self.engine.add_separate(NoDoubleSpaces("NoDoubleSpaces"))
            self.engine.add_separate(NoTrailingWhitespace("NoTrailingWhitespace"))
            self.engine.add_separate(CapitalizeFirst("CapitalizeFirst"))
            self.engine.add_separate(MaxLength("MaxLength", max_len=10000))
            
            # Collective constraints (global, cross-checking)
            self.engine.add_collective(ResponseLength("ResponseLength", min_length=50))
            self.engine.add_collective(NoContradictions("NoContradictions"))
            
            self.engine_loaded = True
            sep_count = len(self.engine.separate_constraints)
            col_count = len(self.engine.collective_constraints)
            self.add_log(f"Constraint Engine loaded: {sep_count} separate, {col_count} collective", "INFO")
        except Exception as e:
            self.engine_loaded = False
            self.add_log(f"Constraint Engine failed to load: {str(e)}", "ERROR")
    
    def open_engine_editor(self):
        """Open the constraint engine GUI editor"""
        if not CONSTRAINT_GUI_AVAILABLE:
            messagebox.showwarning("Not Available", 
                                   "constraint_engine_gui.py not found.\nPlace it in the same folder.")
            return
        
        def on_apply(new_engine):
            """Callback: GUI editor sends back the updated engine"""
            self.engine = new_engine
            self.engine_loaded = True
            
            sep_count = len(self.engine.separate_constraints)
            col_count = len(self.engine.collective_constraints)
            
            # Update status label in the UI
            self.engine_status_label.config(
                text=f"✅ Loaded ({sep_count} separate, {col_count} collective)",
                foreground=CONFIG['COLORS']['status_online']
            )
            
            self.add_log(f"Engine updated from editor: {sep_count} separate, {col_count} collective", "INFO")
        
        editor_window = tk.Toplevel(self.root)
        ConstraintEngineGUI(editor_window, engine=self.engine, on_apply=on_apply)
    
    def _build_ui(self):
        """Build the main UI"""
        # ===== TOP TAB MENU BAR =====
        menu_bar = tk.Frame(self.root, bg=CONFIG['COLORS']['bg_menu'], relief=tk.RIDGE, bd=1)
        menu_bar.pack(fill=tk.X, side=tk.TOP)
        menu_bar.grid_rowconfigure(0, weight=1)
        
        # File Menu button
        font_btn = (CONFIG['FONTS']['family_default'], CONFIG['FONTS']['size_normal'], 'bold')
        file_menu_btn = tk.Button(
            menu_bar, text=CONFIG['TEXT']['btn_file'], font=font_btn,
            bg=CONFIG['COLORS']['tab_inactive'], activebackground=CONFIG['COLORS']['border_gray'],
            relief=tk.FLAT, bd=0, pady=CONFIG['DIMENSIONS']['padding_small'],
            command=self.show_file_menu, justify=tk.CENTER
        )
        file_menu_btn.grid(row=0, column=0, sticky="nsew", padx=3, pady=5)
        menu_bar.grid_columnconfigure(0, weight=0, minsize=50)
        
        self.tab_buttons = {}
        self.tab_frames = {}
        self.current_tab = "model_control"
        
        tabs = [("model_control", CONFIG['TEXT']['card_model_loader'] + " hidden, tap to open")]
        for idx, (tab_id, tab_label) in enumerate(tabs, start=1):
            btn = tk.Button(
                menu_bar, text=tab_label, font=font_btn,
                bg=CONFIG['COLORS']['tab_inactive'], activebackground=CONFIG['COLORS']['border_gray'],
                relief=tk.FLAT, bd=0, pady=CONFIG['DIMENSIONS']['padding_small'],
                command=lambda tid=tab_id: self.switch_tab(tid), justify=tk.CENTER
            )
            btn.grid(row=0, column=idx, sticky="nsew", padx=3, pady=5)
            menu_bar.grid_columnconfigure(idx, weight=1)
            self.tab_buttons[tab_id] = btn
        
        self.update_tab_appearance()
        
        # ===== MAIN CONTAINER FRAME =====
        self.main_container = tk.Frame(self.root, bg=CONFIG['COLORS']['bg_primary'])
        self.main_container.pack(fill=tk.BOTH, expand=True)
        
        # ===== TAB 1: MODEL CONTROL =====
        self.model_control_frame = tk.Frame(self.main_container, bg=CONFIG['COLORS']['bg_primary'])
        self.tab_frames["model_control"] = self.model_control_frame
        
        # Scrollable container
        canvas = tk.Canvas(self.model_control_frame, bg=CONFIG['COLORS']['bg_primary'], highlightthickness=0)
        scrollbar = ttk.Scrollbar(self.model_control_frame, orient="vertical", command=canvas.yview)
        scrollable_frame = ttk.Frame(canvas, padding=CONFIG['DIMENSIONS']['padding_large'])
        scrollable_frame.configure(style='TFrame')
        
        scrollable_frame.bind(
            "<Configure>",
            lambda e: canvas.configure(scrollregion=canvas.bbox("all"))
        )
        
        canvas.create_window((0, 0), window=scrollable_frame, anchor="nw")
        canvas.configure(yscrollcommand=scrollbar.set, bg=CONFIG['COLORS']['bg_primary'])
        canvas.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        
        def _on_mousewheel(event):
            try:
                if canvas.winfo_exists():
                    canvas.yview_scroll(int(-1*(event.delta/120)), "units")
            except:
                pass
        canvas.bind("<MouseWheel>", _on_mousewheel)
        scrollable_frame.bind("<MouseWheel>", _on_mousewheel)
        
        # ===== CONTROL PANEL (Card 1) =====
        control_panel = tk.Frame(
            scrollable_frame, bg=CONFIG['COLORS']['bg_white'], relief=CONFIG['DIMENSIONS']['card_relief'], bd=0,
            highlightthickness=CONFIG['DIMENSIONS']['card_border_width'], highlightbackground=CONFIG['COLORS']['border_light'],
            highlightcolor=CONFIG['COLORS']['border_light']
        )
        control_panel.pack(fill=tk.BOTH, expand=False, padx=CONFIG['DIMENSIONS']['padding_normal'], 
                          pady=(0, CONFIG['DIMENSIONS']['padding_large']))
        
        # Card header
        card_header = tk.Frame(control_panel, bg=CONFIG['COLORS']['bg_white'])
        card_header.pack(fill=tk.X, padx=CONFIG['DIMENSIONS']['padding_large'], 
                        pady=(CONFIG['DIMENSIONS']['padding_large'], CONFIG['DIMENSIONS']['padding_normal']))
        font_header = (CONFIG['FONTS']['family_default'], CONFIG['FONTS']['size_header'], 'bold')
        ttk.Label(card_header, text=CONFIG['TEXT']['card_status'], font=font_header, 
                 background=CONFIG['COLORS']['bg_white']).pack(anchor=tk.W)
        
        # Card content
        card_content = tk.Frame(control_panel, bg=CONFIG['COLORS']['bg_white'])
        card_content.pack(fill=tk.BOTH, expand=True, padx=CONFIG['DIMENSIONS']['padding_large'], 
                         pady=(0, CONFIG['DIMENSIONS']['padding_large']))
        
        font_label = (CONFIG['FONTS']['family_default'], CONFIG['FONTS']['size_normal'], 'bold')
        font_small = (CONFIG['FONTS']['family_default'], CONFIG['FONTS']['size_small'])
        
        # Status row
        ttk.Label(card_content, text=CONFIG['TEXT']['label_lm_studio_status'], font=font_label, 
                 background=CONFIG['COLORS']['bg_white']).pack(anchor=tk.W, pady=(0, CONFIG['DIMENSIONS']['padding_tiny']))
        
        status_row = tk.Frame(card_content, bg=CONFIG['COLORS']['bg_white'])
        status_row.pack(fill=tk.X, pady=(0, CONFIG['DIMENSIONS']['padding_tiny']))
        
        self.status_label = tk.Label(status_row, text=CONFIG['TEXT']['status_disconnected'], 
                                     foreground=CONFIG['COLORS']['status_offline'], font=font_small, 
                                     bg=CONFIG['COLORS']['bg_white'])
        self.status_label.pack(side=tk.LEFT, padx=(0, 15))
        
        tk.Label(status_row, text=CONFIG['TEXT']['label_server'], font=font_small, 
                bg=CONFIG['COLORS']['bg_white']).pack(side=tk.LEFT, padx=(0, 5))
        self.server_label = tk.Label(status_row, text=self.api_base, foreground=CONFIG['COLORS']['text_blue'], 
                                     font=(CONFIG['FONTS']['family_mono'], CONFIG['FONTS']['size_small']), 
                                     bg=CONFIG['COLORS']['bg_white'])
        self.server_label.pack(side=tk.LEFT)
        
        # Resolution display with lock button
        resolution_frame = tk.Frame(status_row, bg=CONFIG['COLORS']['bg_white'])
        resolution_frame.pack(side=tk.RIGHT)
        
        self.resolution_label = tk.Label(resolution_frame, text="491x624", 
                                         foreground=CONFIG['COLORS']['text_blue'],
                                         font=(CONFIG['FONTS']['family_mono'], CONFIG['FONTS']['size_small']), 
                                         bg=CONFIG['COLORS']['bg_white'])
        self.resolution_label.pack(side=tk.LEFT, padx=(0, 5))
        
        self.lock_button = tk.Button(resolution_frame, text="🔒", 
                                     font=(CONFIG['FONTS']['family_default'], CONFIG['FONTS']['size_tiny']),
                                     command=self.toggle_window_lock, relief=tk.FLAT, bd=0, padx=3, pady=0, 
                                     bg=CONFIG['COLORS']['bg_white'])
        self.lock_button.pack(side=tk.LEFT)
        
        # LMs available row
        lms_row = tk.Frame(card_content, bg=CONFIG['COLORS']['bg_white'])
        lms_row.pack(anchor=tk.W, pady=(0, CONFIG['DIMENSIONS']['padding_normal']))
        
        tk.Label(lms_row, text=CONFIG['TEXT']['label_available_models'], font=font_small, 
                bg=CONFIG['COLORS']['bg_white']).pack(side=tk.LEFT, padx=(0, 5))
        self.lms_count_label = tk.Label(lms_row, text="0", foreground=CONFIG['COLORS']['text_blue'],
                                        font=(CONFIG['FONTS']['family_mono'], CONFIG['FONTS']['size_small'], 'bold'), 
                                        bg=CONFIG['COLORS']['bg_white'])
        self.lms_count_label.pack(side=tk.LEFT)
        
        # Token tracking
        token_row = tk.Frame(card_content, bg=CONFIG['COLORS']['bg_white'])
        token_row.pack(anchor=tk.W, pady=(0, CONFIG['DIMENSIONS']['padding_normal']))
        
        tk.Label(token_row, text=CONFIG['TEXT']['label_tokens_used'], font=font_small, 
                bg=CONFIG['COLORS']['bg_white']).pack(side=tk.LEFT, padx=(0, 10))
        self.session_tokens_label = tk.Label(token_row, text="0", foreground=CONFIG['COLORS']['status_online'], 
                                             font=(CONFIG['FONTS']['family_mono'], CONFIG['FONTS']['size_small'], 'bold'), 
                                             bg=CONFIG['COLORS']['bg_white'])
        self.session_tokens_label.pack(side=tk.LEFT, padx=(0, 20))
        
        tk.Label(token_row, text=CONFIG['TEXT']['label_reasoning'], font=font_small, 
                bg=CONFIG['COLORS']['bg_white']).pack(side=tk.LEFT, padx=(0, 10))
        self.reasoning_tokens_label = tk.Label(token_row, text="0", foreground=CONFIG['COLORS']['text_blue'], 
                                               font=(CONFIG['FONTS']['family_mono'], CONFIG['FONTS']['size_small'], 'bold'), 
                                               bg=CONFIG['COLORS']['bg_white'])
        self.reasoning_tokens_label.pack(side=tk.LEFT)
        
        # Constraint Engine status
        engine_row = tk.Frame(card_content, bg=CONFIG['COLORS']['bg_white'])
        engine_row.pack(anchor=tk.W, pady=(0, CONFIG['DIMENSIONS']['padding_normal']))
        
        tk.Label(engine_row, text='Constraint Engine:', font=font_small, 
                bg=CONFIG['COLORS']['bg_white']).pack(side=tk.LEFT, padx=(0, 10))
        
        if self.engine_loaded:
            sep_count = len(self.engine.separate_constraints)
            col_count = len(self.engine.collective_constraints)
            engine_status_text = f"✅ Loaded ({sep_count} separate, {col_count} collective)"
            engine_status_color = CONFIG['COLORS']['status_online']
        else:
            engine_status_text = "❌ Not Loaded"
            engine_status_color = CONFIG['COLORS']['status_offline']
        
        self.engine_status_label = tk.Label(
            engine_row, text=engine_status_text, foreground=engine_status_color,
            font=(CONFIG['FONTS']['family_mono'], CONFIG['FONTS']['size_small'], 'bold'), 
            bg=CONFIG['COLORS']['bg_white']
        )
        self.engine_status_label.pack(side=tk.LEFT)
        
        # Edit Engine button (only if GUI available)
        if CONSTRAINT_GUI_AVAILABLE:
            tk.Button(engine_row, text='⚙️ Edit', command=self.open_engine_editor,
                     bg=CONFIG['COLORS']['button_primary'], fg=CONFIG['COLORS']['text_white'],
                     font=(CONFIG['FONTS']['family_default'], CONFIG['FONTS']['size_tiny']),
                     relief=tk.FLAT, padx=8, pady=1).pack(side=tk.LEFT, padx=(10, 0))
        
        font_btn_small = (CONFIG['FONTS']['family_default'], CONFIG['FONTS']['size_small'])
        tk.Button(card_content, text=CONFIG['TEXT']['btn_refresh'], command=self.refresh_script, 
                 bg=CONFIG['COLORS']['button_red'], fg=CONFIG['COLORS']['text_white'], 
                 font=font_btn_small).pack(fill=tk.X, pady=CONFIG['DIMENSIONS']['padding_tiny'])
        tk.Button(card_content, text=CONFIG['TEXT']['btn_restart'], command=self.restart_script, 
                 bg=CONFIG['COLORS']['button_red'], fg=CONFIG['COLORS']['text_white'], 
                 font=font_btn_small).pack(fill=tk.X, pady=CONFIG['DIMENSIONS']['padding_tiny'])
        
        # ===== STORY CASCADE (Card 2) =====
        cascade_card = tk.Frame(
            scrollable_frame, bg=CONFIG['COLORS']['bg_white'], relief=CONFIG['DIMENSIONS']['card_relief'], bd=0,
            highlightthickness=CONFIG['DIMENSIONS']['card_border_width'], highlightbackground=CONFIG['COLORS']['border_light'],
            highlightcolor=CONFIG['COLORS']['border_light']
        )
        cascade_card.pack(fill=tk.BOTH, expand=False, padx=CONFIG['DIMENSIONS']['padding_normal'], 
                         pady=(0, CONFIG['DIMENSIONS']['padding_large']))
        
        # Category selector header
        cascade_card_header = tk.Frame(cascade_card, bg=CONFIG['COLORS']['bg_white'])
        cascade_card_header.pack(fill=tk.X, padx=CONFIG['DIMENSIONS']['padding_large'], 
                                pady=(CONFIG['DIMENSIONS']['padding_large'], CONFIG['DIMENSIONS']['padding_normal']))
        
        tk.Label(cascade_card_header, text='Category:', font=font_label, 
                bg=CONFIG['COLORS']['bg_white']).pack(side=tk.LEFT, padx=(0, 10))
        
        category_dropdown = ttk.Combobox(cascade_card_header, textvariable=self.cascade_category_var, 
                                        values=CONFIG['CASCADE_CATEGORIES'], state="readonly", 
                                        width=15)
        category_dropdown.pack(side=tk.LEFT, padx=(0, 10))
        
        tk.Button(cascade_card_header, text='⚙️ Edit Passes', command=self.edit_cascade_config,
                 bg=CONFIG['COLORS']['button_primary'], fg=CONFIG['COLORS']['text_white'],
                 font=(CONFIG['FONTS']['family_default'], CONFIG['FONTS']['size_small']),
                 relief=tk.FLAT, padx=10, pady=3).pack(side=tk.LEFT)
        
        cascade_card_content = tk.Frame(cascade_card, bg=CONFIG['COLORS']['bg_white'])
        cascade_card_content.pack(fill=tk.BOTH, expand=True, padx=CONFIG['DIMENSIONS']['padding_large'], 
                                 pady=(0, CONFIG['DIMENSIONS']['padding_large']))
        
        # Story prompt input
        tk.Label(cascade_card_content, text=CONFIG['TEXT']['label_story_idea'], font=font_label, 
                bg=CONFIG['COLORS']['bg_white']).pack(anchor=tk.W, pady=(0, CONFIG['DIMENSIONS']['padding_tiny']))
        
        self.cascade_input = tk.Text(cascade_card_content, height=CONFIG['DIMENSIONS']['story_prompt_height'], 
                                     font=font_small, wrap=tk.WORD, bg=CONFIG['COLORS']['bg_input'],
                                     fg=CONFIG['COLORS']['text_primary'], relief=tk.SOLID, bd=1)
        self.cascade_input.pack(fill=tk.X, pady=(0, CONFIG['DIMENSIONS']['padding_large']))
        self.cascade_input.insert("1.0", "A mysterious figure arrives in a small town...")
        
        # Model selection
        tk.Label(cascade_card_content, text=CONFIG['TEXT']['label_select_model_pass'], font=font_label, 
                bg=CONFIG['COLORS']['bg_white']).pack(anchor=tk.W, pady=(0, CONFIG['DIMENSIONS']['padding_small']))
        tk.Label(cascade_card_content, text=CONFIG['TEXT']['label_leave_blank'], font=font_small, 
                foreground=CONFIG['COLORS']['text_muted'], bg=CONFIG['COLORS']['bg_white']).pack(
            anchor=tk.W, pady=(0, CONFIG['DIMENSIONS']['padding_normal']))
        
        # Store cascade selections
        self.cascade_pass_vars = {}
        self.cascade_pass_dropdowns = {}
        self.cascade_pass_max_tokens = {}
        self.model_display_names = {}
        
        # Create 5 pass dropdowns
        for pass_num in range(1, 6):
            pass_frame = tk.Frame(cascade_card_content, bg=CONFIG['COLORS']['bg_white'])
            pass_frame.pack(fill=tk.X, pady=(0, CONFIG['DIMENSIONS']['padding_normal']))
            
            pass_config = CONFIG['CASCADE_PASSES'][pass_num]
            pass_label_text = f"{pass_config['name']} ({pass_config['role']})"
            
            tk.Label(pass_frame, text=pass_label_text, font=font_small, 
                    bg=CONFIG['COLORS']['bg_white']).pack(anchor=tk.W, pady=(0, 3))
            
            var = tk.StringVar(value="None Selected")
            self.cascade_pass_vars[pass_num] = var
            
            dropdown = ttk.Combobox(pass_frame, textvariable=var, state="readonly", 
                                   width=CONFIG['DEFAULTS']['model_display_width'])
            dropdown.pack(fill=tk.X, pady=(0, 5))
            self.cascade_pass_dropdowns[pass_num] = dropdown
            
            # Per-pass tokens row
            tokens_row = tk.Frame(pass_frame, bg=CONFIG['COLORS']['bg_white'])
            tokens_row.pack(fill=tk.X, pady=(0, 3))
            
            tk.Label(tokens_row, text=CONFIG['TEXT']['label_tokens'], font=font_small, 
                    bg=CONFIG['COLORS']['bg_white']).pack(side=tk.LEFT, padx=(0, 5))
            
            # Pass 5 (Polish) gets higher tokens by default
            if pass_num == 5:
                tokens_var = tk.IntVar(value=8000)
                ttk.Spinbox(tokens_row, from_=100, to=32000, textvariable=tokens_var, width=5).pack(side=tk.LEFT, padx=(0, 5))
                tk.Label(tokens_row, text='(higher limits)', font=font_small, 
                        foreground=CONFIG['COLORS']['status_online'], bg=CONFIG['COLORS']['bg_white']).pack(side=tk.LEFT)
            else:
                tokens_var = tk.IntVar(value=CONFIG['DEFAULTS']['cascade_pass_tokens'])
                ttk.Spinbox(tokens_row, from_=100, to=4000, textvariable=tokens_var, width=5).pack(side=tk.LEFT)
            
            self.cascade_pass_max_tokens[pass_num] = tokens_var
        
        # Temperature and buttons
        limiter_frame = tk.Frame(cascade_card_content, bg=CONFIG['COLORS']['bg_white'], relief=tk.FLAT, bd=0)
        limiter_frame.pack(fill=tk.X, pady=(CONFIG['DIMENSIONS']['padding_large'], CONFIG['DIMENSIONS']['padding_normal']))
        
        # Timeout row (above)
        timeout_row = tk.Frame(limiter_frame, bg=CONFIG['COLORS']['bg_white'])
        timeout_row.pack(fill=tk.X, pady=(0, CONFIG['DIMENSIONS']['padding_small']))
        
        tk.Label(timeout_row, text='Server Timeout (Global):', font=font_small, 
                bg=CONFIG['COLORS']['bg_white']).pack(side=tk.LEFT, padx=(0, 5))
        self.timeout_var = tk.IntVar(value=CONFIG['API']['timeout_chat'])
        ttk.Spinbox(timeout_row, from_=30, to=600, increment=30, textvariable=self.timeout_var, width=8).pack(side=tk.LEFT, padx=(0, 5))
        tk.Label(timeout_row, text='(30-600 seconds)', font=font_small, 
                foreground=CONFIG['COLORS']['text_muted'], bg=CONFIG['COLORS']['bg_white']).pack(side=tk.LEFT)
        
        # Temperature row (below)
        settings_row = tk.Frame(limiter_frame, bg=CONFIG['COLORS']['bg_white'])
        settings_row.pack(fill=tk.X, pady=(CONFIG['DIMENSIONS']['padding_small'], CONFIG['DIMENSIONS']['padding_small']))
        
        left_frame = tk.Frame(settings_row, bg=CONFIG['COLORS']['bg_white'])
        left_frame.pack(side=tk.LEFT, fill=tk.X, expand=True)
        
        tk.Label(left_frame, text=CONFIG['TEXT']['label_temp_global'], font=font_small, 
                bg=CONFIG['COLORS']['bg_white']).pack(side=tk.LEFT, padx=(0, 5))
        self.cascade_temp_var = tk.DoubleVar(value=CONFIG['DEFAULTS']['cascade_temperature'])
        ttk.Spinbox(left_frame, from_=0.0, to=2.0, increment=0.1, textvariable=self.cascade_temp_var, width=8).pack(
            side=tk.LEFT, padx=(0, 15))
        tk.Label(left_frame, text=CONFIG['TEXT']['label_temp_range'], font=font_small, 
                foreground=CONFIG['COLORS']['text_muted'], bg=CONFIG['COLORS']['bg_white']).pack(side=tk.LEFT)
        
        right_frame = tk.Frame(settings_row, bg=CONFIG['COLORS']['bg_white'])
        right_frame.pack(side=tk.RIGHT, fill=tk.X)
        
        tk.Button(right_frame, text=CONFIG['TEXT']['btn_generate'], command=self.start_cascade, 
                 bg=CONFIG['COLORS']['status_online'], fg=CONFIG['COLORS']['text_white'], 
                 font=font_btn_small).pack(side=tk.LEFT, padx=(0, 5))
        tk.Button(right_frame, text=CONFIG['TEXT']['btn_clear_all'], command=self.clear_cascade, 
                 bg=CONFIG['COLORS']['button_red'], fg=CONFIG['COLORS']['text_white'], 
                 font=font_btn_small).pack(side=tk.LEFT)
        
        # Output section
        tk.Label(cascade_card_content, text=CONFIG['TEXT']['label_pass_polished'], font=font_label, 
                bg=CONFIG['COLORS']['bg_white']).pack(anchor=tk.W, pady=(0, CONFIG['DIMENSIONS']['padding_small']))
        
        cascade_output_frame = tk.Frame(cascade_card_content, bg=CONFIG['COLORS']['bg_white'], relief=tk.SOLID, bd=1)
        cascade_output_frame.pack(fill=tk.BOTH, expand=False, pady=(0, CONFIG['DIMENSIONS']['padding_normal']))
        
        self.cascade_output = tk.Text(cascade_output_frame, height=CONFIG['DIMENSIONS']['cascade_output_height'], 
                                      font=(CONFIG['FONTS']['family_mono'], CONFIG['FONTS']['size_small']),
                                      wrap=tk.WORD, bg=CONFIG['COLORS']['bg_secondary'],
                                      fg=CONFIG['COLORS']['text_primary'], relief=tk.SOLID, bd=0, state=tk.DISABLED)
        self.cascade_output.pack(fill=tk.BOTH, expand=True)
        
        cascade_btn_frame = tk.Frame(cascade_card_content, bg=CONFIG['COLORS']['bg_white'])
        cascade_btn_frame.pack(fill=tk.X)
        tk.Button(cascade_btn_frame, text=CONFIG['TEXT']['btn_copy_output'], command=self.copy_cascade_output, 
                 bg=CONFIG['COLORS']['button_primary'], fg=CONFIG['COLORS']['text_white'], 
                 font=font_btn_small).pack(side=tk.LEFT, padx=(0, 3))
        tk.Button(cascade_btn_frame, text=CONFIG['TEXT']['btn_save_story'], command=self.save_cascade_story, 
                 bg=CONFIG['COLORS']['button_primary'], fg=CONFIG['COLORS']['text_white'], 
                 font=font_btn_small).pack(side=tk.LEFT)
        
        self.cascade_running = False
        self.logs_listbox = None
        self.model_display_names = {}
    
    def switch_tab(self, tab_id):
        """Switch to a different tab"""
        for frame in self.tab_frames.values():
            frame.pack_forget()
        
        if tab_id in self.tab_frames:
            self.tab_frames[tab_id].pack(fill=tk.BOTH, expand=True)
            self.current_tab = tab_id
            self.update_tab_appearance()
    
    def update_tab_appearance(self):
        """Update tab button styling"""
        for tab_id, btn in self.tab_buttons.items():
            if tab_id == self.current_tab:
                btn.config(bg=CONFIG['COLORS']['tab_active'], fg=CONFIG['COLORS']['text_white'])
            else:
                btn.config(bg=CONFIG['COLORS']['tab_inactive'], fg=CONFIG['COLORS']['text_primary'])
    
    def _initialize_log_file(self):
        """Create or append to log file"""
        try:
            with open(self.log_file_path, 'a', encoding='utf-8') as f:
                f.write(f"\n{'='*60}\nSession started: {datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n{'='*60}\n")
        except:
            pass
    
    def show_file_menu(self):
        """Show File menu"""
        menu = tk.Menu(self.root, tearoff=0)
        menu.add_command(label=CONFIG['TEXT']['btn_settings'], command=self.open_settings)
        menu.add_separator()
        menu.add_command(label=CONFIG['TEXT']['btn_view_log'], command=self.open_log_file)
        menu.add_separator()
        menu.add_command(label=CONFIG['TEXT']['btn_exit'], command=self.exit_app)
        
        try:
            menu.post(self.root.winfo_x(), self.root.winfo_y() + 50)
        except:
            pass
    
    def exit_app(self):
        """Clean exit"""
        self.add_log("Application closing", "SYSTEM")
        self.save_settings()
        self.root.quit()
    
    def edit_cascade_config(self):
        """Open the cascade config in text editor"""
        try:
            script_path = os.path.abspath(__file__)
            if os.name == 'nt':
                # Windows - open with Notepad
                os.system(f'notepad "{script_path}"')
            elif os.uname().sysname == 'Darwin':
                # macOS - open with TextEdit
                os.system(f'open -a TextEdit "{script_path}"')
            else:
                # Linux - open with gedit or nano
                os.system(f'gedit "{script_path}" &')
            self.add_log("Opened config file for editing", "INFO")
        except Exception as e:
            messagebox.showerror(CONFIG['TEXT']['popup_error'], 
                                f"Could not open config file:\n{str(e)}")
            self.add_log(f"Error opening config: {str(e)}", "ERROR")
    
    def load_settings(self):
        """Load settings from file"""
        try:
            if os.path.exists(self.settings_file):
                import json
                with open(self.settings_file, 'r', encoding='utf-8') as f:
                    saved_settings = json.load(f)
                    self.settings.update(saved_settings)
                self.api_base = self.settings['api_base']
        except:
            pass
    
    def save_settings(self):
        """Save settings to file"""
        try:
            import json
            with open(self.settings_file, 'w', encoding='utf-8') as f:
                json.dump(self.settings, f, indent=2)
            self.add_log("Settings saved", "INFO")
        except Exception as e:
            self.add_log(f"Error saving settings: {str(e)}", "ERROR")
    
    def open_settings(self):
        """Open settings window"""
        settings_win = tk.Toplevel(self.root)
        settings_win.title(CONFIG['TEXT']['settings_title'])
        w, h = CONFIG['DIMENSIONS']['settings_width'], CONFIG['DIMENSIONS']['settings_height']
        settings_win.geometry(f"{w}x{h}")
        settings_win.resizable(False, False)
        settings_win.grab_set()
        
        # Center on parent
        self.root.update_idletasks()
        x = self.root.winfo_x() + (self.root.winfo_width() // 2) - (w // 2)
        y = self.root.winfo_y() + (self.root.winfo_height() // 2) - (h // 2)
        settings_win.geometry(f"+{x}+{y}")
        
        # Note: Settings UI simplified for space - full version has all color picker fields
        # The key improvement is that all TEXT and COLORS/DIMENSIONS reference CONFIG
        
        messagebox.showinfo(CONFIG['TEXT']['popup_info'], 
                           "Settings panel customizable via CONFIG dictionary at top of code.\n"
                           "Edit colors, text, dimensions, and API endpoints there.")
        settings_win.destroy()
    
    def open_log_file(self):
        """Open log file"""
        if not os.path.exists(self.log_file_path):
            messagebox.showwarning(CONFIG['TEXT']['popup_warning'], 
                                  f"{CONFIG['TEXT']['msg_no_log']}\n{self.log_file_path}")
            return
        
        try:
            if os.name == 'nt':
                os.startfile(self.log_file_path)
            else:
                os.system(f'open "{self.log_file_path}"')
            self.add_log("Opened log file", "INFO")
        except Exception as e:
            messagebox.showerror(CONFIG['TEXT']['popup_error'], f"Could not open log:\n{str(e)}")
            self.add_log(f"Error opening log: {str(e)}", "ERROR")
    
    def add_log(self, message, log_type="INFO"):
        """Add log message"""
        timestamp = datetime.datetime.now().strftime("%H:%M:%S")
        log_entry = f"[{timestamp}] {log_type}: {message}"
        self.error_log.append(log_entry)
        
        try:
            with open(self.log_file_path, 'a', encoding='utf-8') as f:
                f.write(log_entry + "\n")
        except:
            pass
        
        if len(self.error_log) > 1000:
            self.error_log.pop(0)
    
    def run_startup_checks(self):
        """Run startup checks"""
        splash = LoadingSplash(self.root)
        self.add_log("Starting application...", "SYSTEM")
        
        def startup_thread():
            self.is_connected = self.check_connection()
            self.refresh_models()
            splash.close()
            self.root.deiconify()
        
        thread = threading.Thread(target=startup_thread, daemon=True)
        thread.start()
    
    def update_resolution(self, event=None):
        """Update resolution display"""
        width = self.root.winfo_width()
        height = self.root.winfo_height()
        if width > 1 and height > 1:
            self.resolution_label.config(text=f"{width}x{height}")
    
    def toggle_window_lock(self):
        """Toggle window lock"""
        self.window_locked = not self.window_locked
        self.root.resizable(not self.window_locked, not self.window_locked)
        self.lock_button.config(text="🔒" if self.window_locked else "🔓")
    
    def refresh_models(self):
        """Fetch available models"""
        try:
            response = requests.get(f"{self.api_base}{CONFIG['API']['models_endpoint']}", 
                                   timeout=CONFIG['API']['timeout_models'])
            if response.status_code == 200:
                data = response.json()
                models = data.get("models", [])
                
                self.model_keys = {}
                
                llm_models = [m for m in models if m.get("type") == "llm"]
                
                if llm_models:
                    for idx, model in enumerate(llm_models):
                        key = model.get("key", "unknown")
                        self.model_keys[idx] = key
                    self.lms_count_label.config(text=str(len(llm_models)))
                    self.add_log(f"Loaded {len(llm_models)} models", "INFO")
                else:
                    self.lms_count_label.config(text="0")
                    self.add_log("No LLM models found", "WARNING")
                
                self.update_cascade_models()
            else:
                self.lms_count_label.config(text="0")
                self.add_log(f"Failed to load models: {response.status_code}", "ERROR")
        except Exception as e:
            self.lms_count_label.config(text="0")
            self.add_log(f"Error fetching models: {str(e)}", "ERROR")
    
    def on_model_select(self, event):
        """Handle model selection"""
        if self.loading_model:
            return
        
        idx = self.models_listbox.nearest(event.y)
        if idx >= 0:
            model_key = self.model_keys.get(idx)
            if model_key:
                self.load_model(model_key)
    
    def load_model(self, model_key):
        """Load a model"""
        if not model_key:
            messagebox.showerror(CONFIG['TEXT']['popup_error'], CONFIG['TEXT']['msg_no_model_identified'])
            self.add_log("Failed to identify model", "ERROR")
            return
        
        self.loading_model = True
        
        try:
            response = requests.post(
                f"{self.api_base}{CONFIG['API']['load_model_endpoint']}",
                json={"model": model_key},
                timeout=CONFIG['API']['timeout_load']
            )
            
            if response.status_code == 200:
                self.current_model = model_key
                self.check_connection()
                messagebox.showinfo(CONFIG['TEXT']['popup_success'], f"Model loaded: {model_key}")
                self.add_log(f"Model loaded: {model_key}", "INFO")
            else:
                messagebox.showerror(CONFIG['TEXT']['popup_error'], 
                                    f"{CONFIG['TEXT']['error_failed_load']}{response.status_code}")
                self.add_log(f"Failed to load model: {response.status_code}", "ERROR")
        except Exception as e:
            messagebox.showerror(CONFIG['TEXT']['popup_error'], f"{CONFIG['TEXT']['error_load_model']}\n{str(e)}")
            self.add_log(f"Error loading model: {str(e)}", "ERROR")
        finally:
            self.loading_model = False
    
    def refresh_script(self):
        """Refresh connection"""
        self.check_connection()
        self.refresh_models()
        self.add_log("Script refreshed", "INFO")
    
    def restart_script(self):
        """Restart application"""
        if messagebox.askyesno(CONFIG['TEXT']['popup_info'], CONFIG['TEXT']['msg_restart_confirm']):
            self.root.quit()
            subprocess.Popen([sys.executable, sys.argv[0]])
            sys.exit()
    
    def check_connection(self):
        """Check LM Studio connection"""
        try:
            response = requests.get(f"{self.api_base}{CONFIG['API']['models_endpoint']}", 
                                   timeout=CONFIG['API']['timeout_connect'])
            self.status_label.config(text=CONFIG['TEXT']['status_connected'], 
                                    foreground=CONFIG['COLORS']['status_online'])
            self.add_log("Connected to LM Studio", "INFO")
            
            if response.status_code == 200:
                data = response.json()
                models = data.get("models", [])
                llm_models = [m for m in models if m.get("type") == "llm"]
                self.lms_count_label.config(text=str(len(llm_models)))
            return True
        except:
            self.status_label.config(text=CONFIG['TEXT']['status_disconnected'], 
                                    foreground=CONFIG['COLORS']['status_offline'])
            self.lms_count_label.config(text="0")
            self.add_log("Lost connection to LM Studio", "ERROR")
            return False
    
    def update_system_resources(self):
        """Periodically update system resources"""
        def resource_thread():
            try:
                ram_info = psutil.virtual_memory()
                ram_used = ram_info.used / (1024**3)
                ram_total = ram_info.total / (1024**3)
                ram_percent = ram_info.percent
                
                vram_used = None
                vram_total = None
                try:
                    import subprocess
                    result = subprocess.run(
                        ['nvidia-smi', '--query-gpu=memory.used,memory.total', '--format=csv,nounits,noheader'],
                        capture_output=True, text=True, timeout=2
                    )
                    if result.returncode == 0:
                        parts = result.stdout.strip().split(',')
                        if len(parts) == 2:
                            vram_used = float(parts[0].strip()) / 1024
                            vram_total = float(parts[1].strip()) / 1024
                except:
                    pass
                
                self.root.after(0, self._update_resource_ui, ram_used, ram_total, ram_percent, vram_used, vram_total)
            except Exception as e:
                self.add_log(f"Error getting system resources: {str(e)}", "ERROR")
        
        thread = threading.Thread(target=resource_thread, daemon=True)
        thread.start()
        self.root.after(2000, self.update_system_resources)
    
    def _update_resource_ui(self, ram_used, ram_total, ram_percent, vram_used, vram_total):
        """Update resource display"""
        try:
            if ram_used is not None:
                ram_text = f"{ram_used:.1f} GB / {ram_total:.1f} GB ({ram_percent:.0f}%)"
                self.ram_label.config(text=ram_text)
            
            if vram_used is not None and vram_total is not None:
                vram_percent = (vram_used / vram_total) * 100
                vram_text = f"{vram_used:.1f} GB / {vram_total:.1f} GB ({vram_percent:.0f}%)"
                self.vram_label.config(text=vram_text)
                
                total_used = vram_used + ram_used
                total_available = vram_total + ram_total
                total_percent = (total_used / total_available) * 100
                total_text = f"{total_used:.1f} GB / {total_available:.1f} GB ({total_percent:.0f}%)"
                self.total_label.config(text=total_text)
            else:
                self.vram_label.config(text="N/A (nvidia-smi not found)")
                if ram_used is not None:
                    total_text = f"{ram_used:.1f} GB / {ram_total:.1f} GB ({ram_percent:.0f}%)"
                    self.total_label.config(text=total_text)
        except:
            pass
    
    
    def update_cascade_models(self):
        """Update cascade model dropdowns"""
        try:
            response = requests.get(f"{self.api_base}{CONFIG['API']['models_endpoint']}", 
                                   timeout=CONFIG['API']['timeout_models'])
            if response.status_code == 200:
                data = response.json()
                models = data.get("models", [])
                llm_models = [m for m in models if m.get("type") == "llm"]
                
                model_options = ["None Selected"]
                self.model_display_names = {}
                
                for model in llm_models:
                    display_name = model.get("display_name", "Unknown")
                    key = model.get("key", "unknown")
                    quantization = model.get("quantization", {}).get("name", "")
                    display_text = f"{display_name} ({quantization})" if quantization else display_name
                    
                    model_options.append(display_text)
                    self.model_display_names[display_text] = key
                
                for pass_num in range(1, 6):
                    if pass_num in self.cascade_pass_dropdowns:
                        self.cascade_pass_dropdowns[pass_num]['values'] = model_options
        except Exception as e:
            self.add_log(f"Error updating cascade models: {str(e)}", "ERROR")
    
    def start_cascade(self):
        """Start cascade refinement"""
        if self.cascade_running:
            messagebox.showwarning(CONFIG['TEXT']['popup_warning'], CONFIG['TEXT']['msg_in_progress'])
            return
        
        selected_passes = []
        for pass_num in range(1, 6):
            model_display = self.cascade_pass_vars[pass_num].get()
            if model_display != "None Selected":
                model_key = self.model_display_names.get(model_display)
                if model_key:
                    selected_passes.append((pass_num, model_display, model_key))
        
        if not selected_passes:
            messagebox.showwarning(CONFIG['TEXT']['popup_warning'], CONFIG['TEXT']['msg_no_models_cascade'])
            self.add_log(CONFIG['TEXT']['error_cascade_no_models'], "WARNING")
            return
        
        story_prompt = self.cascade_input.get("1.0", tk.END).strip()
        if not story_prompt:
            messagebox.showwarning(CONFIG['TEXT']['popup_warning'], CONFIG['TEXT']['msg_empty_prompt'])
            self.add_log(CONFIG['TEXT']['error_cascade_empty'], "WARNING")
            return
        
        self.cascade_output.config(state=tk.NORMAL)
        self.cascade_output.delete("1.0", tk.END)
        self.cascade_output.config(state=tk.DISABLED)
        
        self.cascade_running = True
        self.add_log(f"Starting 5-pass cascade with {len(selected_passes)} models", "INFO")
        
        def _append_output(text):
            """Thread-safe append to cascade output"""
            self.cascade_output.config(state=tk.NORMAL)
            self.cascade_output.insert(tk.END, text)
            self.cascade_output.see(tk.END)
            self.cascade_output.config(state=tk.DISABLED)
            self.root.update()
        
        def _set_output(text):
            """Thread-safe replace cascade output"""
            self.cascade_output.config(state=tk.NORMAL)
            self.cascade_output.delete("1.0", tk.END)
            self.cascade_output.insert(tk.END, text)
            self.cascade_output.see("1.0")
            self.cascade_output.config(state=tk.DISABLED)
            self.root.update()
        
        def _format_validation_report(pass_num, pass_role, validation_result):
            """Format constraint validation results as readable report"""
            lines = []
            lines.append(f"{'─' * 50}")
            lines.append(f"  Constraint Engine — Pass {pass_num} ({pass_role}) Validation")
            lines.append(f"{'─' * 50}")
            
            total_time = 0
            fixes_applied = 0
            
            for entry in validation_result.get('log', []):
                name = entry['constraint']
                passed = entry['passed']
                ms = entry.get('duration_ms', 0)
                fixed = entry.get('fixed', False)
                phase = entry.get('phase', 'unknown')
                total_time += ms
                
                if fixed:
                    fixes_applied += 1
                    icon = "🔧"
                    status = "FIXED"
                elif passed:
                    icon = "✓"
                    status = "passed"
                else:
                    icon = "✗"
                    status = "FAILED"
                
                phase_tag = "S" if phase == "separate" else "C"
                lines.append(f"  {icon} [{phase_tag}] {name}: {status} ({ms:.2f}ms)")
            
            # Summary line
            success = validation_result.get('success', False)
            total_constraints = len(validation_result.get('log', []))
            summary_icon = "✓" if success else "✗"
            lines.append(f"{'─' * 50}")
            lines.append(f"  {summary_icon} {total_constraints} constraints checked in {total_time:.2f}ms | {fixes_applied} fixes applied")
            
            if not success:
                failed_at = validation_result.get('failed_at', 'unknown')
                lines.append(f"  ⚠ HALTED at: {failed_at}")
            
            lines.append(f"{'─' * 50}\n")
            return "\n".join(lines)
        
        def cascade_thread():
            try:
                current_story = story_prompt
                total_tokens = 0
                
                # Show engine status at start
                if self.engine_loaded:
                    desc = self.engine.describe()
                    _append_output(f"Constraint Engine: {len(desc['separate'])} separate, {len(desc['collective'])} collective constraints active\n\n")
                else:
                    _append_output("⚠ Constraint Engine not loaded — running without validation\n\n")
                
                for pass_idx, (pass_num, model_name, model_key) in enumerate(selected_passes):
                    pass_config = CONFIG['CASCADE_PASSES'][pass_num]
                    is_last_pass = (pass_idx == len(selected_passes) - 1)
                    
                    # Show pass header
                    _append_output(f"▶ Pass {pass_num} ({pass_config['role']}): {model_name}\n")
                    _append_output(f"  Sending to LM Studio...\n")
                    self.add_log(f"Pass {pass_num}/{len(selected_passes)}: {model_name}", "INFO")
                    
                    refine_prompt = pass_config['prompt_template'].format(story=current_story)
                    
                    response = requests.post(
                        f"{self.api_base}{CONFIG['API']['chat_endpoint']}",
                        json={
                            "model": model_key,
                            "messages": [{"role": "user", "content": refine_prompt}],
                            "temperature": self.cascade_temp_var.get(),
                            "max_tokens": self.cascade_pass_max_tokens[pass_num].get()
                        },
                        timeout=self.timeout_var.get()
                    )
                    
                    if response.status_code == 200:
                        result = response.json()
                        current_story = result['choices'][0]['message']['content']
                        
                        if 'usage' in result:
                            tokens_used = result['usage'].get('total_tokens', 0)
                            total_tokens += tokens_used
                            self.reasoning_tokens = tokens_used
                            self.session_tokens += tokens_used
                        
                        _append_output(f"  ✓ Response received ({len(current_story)} chars)\n")
                        
                        # === CONSTRAINT VALIDATION ===
                        if self.engine_loaded and self.engine:
                            _append_output(f"  Running constraint validation...\n")
                            
                            validation_result = self.engine.validate(current_story, auto_fix=True)
                            report = _format_validation_report(pass_num, pass_config['role'], validation_result)
                            _append_output(report)
                            
                            # Use the (potentially fixed) data
                            if validation_result.get('success') and 'data' in validation_result:
                                current_story = validation_result['data']
                            
                            # Log validation outcome
                            if validation_result.get('success'):
                                fixes = sum(1 for e in validation_result.get('log', []) if e.get('fixed'))
                                self.add_log(f"Pass {pass_num} validation: PASSED ({fixes} fixes)", "INFO")
                            else:
                                failed = validation_result.get('failed_at', 'unknown')
                                self.add_log(f"Pass {pass_num} validation: FAILED at {failed}", "WARNING")
                        
                        # Show feeding indicator between passes
                        if not is_last_pass:
                            _append_output(f"  ➜ Feeding validated output to next pass...\n\n")
                        else:
                            # Final pass — show the polished story
                            _append_output(f"\n{'═' * 50}\n")
                            _append_output(f"  FINAL OUTPUT (Pass {pass_num} — {pass_config['role']})\n")
                            _append_output(f"{'═' * 50}\n\n")
                            _append_output(current_story)
                        
                    else:
                        error_msg = f"API Error ({response.status_code}) from {model_name} (Pass {pass_num})"
                        _append_output(f"\n❌ {error_msg}\n")
                        self.add_log(error_msg, "ERROR")
                        break
                
                self.reasoning_tokens_label.config(text=str(total_tokens))
                self.session_tokens_label.config(text=str(self.session_tokens))
                self.add_log(f"Cascade complete: {total_tokens} total tokens", "INFO")
                
            except requests.exceptions.RequestException as e:
                error_msg = f"Connection error: {str(e)}"
                _set_output(f"❌ {error_msg}\n")
                self.add_log(error_msg, "ERROR")
            except Exception as e:
                error_msg = f"Error: {str(e)}"
                _set_output(f"❌ {error_msg}\n")
                self.add_log(error_msg, "ERROR")
            finally:
                self.cascade_running = False
        
        thread = threading.Thread(target=cascade_thread, daemon=True)
        thread.start()
    
    def clear_cascade(self):
        """Clear cascade"""
        self.cascade_input.delete("1.0", tk.END)
        self.cascade_output.config(state=tk.NORMAL)
        self.cascade_output.delete("1.0", tk.END)
        self.cascade_output.config(state=tk.DISABLED)
        for pass_num in range(1, 6):
            self.cascade_pass_max_tokens[pass_num].set(CONFIG['DEFAULTS']['cascade_pass_tokens'])
        self.add_log("Cascade cleared", "INFO")
    
    def copy_cascade_output(self):
        """Copy cascade output"""
        text = self.cascade_output.get("1.0", tk.END).strip()
        if not text:
            messagebox.showwarning(CONFIG['TEXT']['popup_warning'], CONFIG['TEXT']['msg_empty_story'])
            return
        
        self.root.clipboard_clear()
        self.root.clipboard_append(text)
        messagebox.showinfo(CONFIG['TEXT']['popup_info'], CONFIG['TEXT']['msg_copied'])
        self.add_log("Copied cascade output", "INFO")
    
    def save_cascade_story(self):
        """Save cascade story"""
        text = self.cascade_output.get("1.0", tk.END).strip()
        if not text:
            messagebox.showwarning(CONFIG['TEXT']['popup_warning'], CONFIG['TEXT']['msg_empty_to_save'])
            return
        
        timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
        filename = f"story_cascade_{timestamp}.txt"
        filepath = os.path.join(os.path.expanduser("~"), "Downloads", filename)
        
        try:
            with open(filepath, 'w', encoding='utf-8') as f:
                f.write(text)
            
            messagebox.showinfo(CONFIG['TEXT']['popup_info'], f"Story saved:\n{filename}")
            self.add_log(f"Saved cascade story: {filename}", "INFO")
        except Exception as e:
            messagebox.showerror(CONFIG['TEXT']['popup_error'], f"{CONFIG['TEXT']['error_save_file']}\n{str(e)}")
            self.add_log(f"Error saving story: {str(e)}", "ERROR")


if __name__ == "__main__":
    root = tk.Tk()
    root.withdraw()
    app = LMStudioOrchestrator(root)
    root.mainloop()
