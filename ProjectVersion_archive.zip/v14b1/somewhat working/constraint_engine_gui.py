"""
Constraint Engine GUI - Visual editor for constraint configurations
Can run standalone or be launched from LMmultipass.

Place in same folder as constraint_engine.py
"""

import tkinter as tk
from tkinter import ttk, messagebox, filedialog
import json
import os
import time

from constraint_engine import (
    ConstraintEngine, SeparateConstraint, CollectiveConstraint,
    NoDoubleSpaces, CapitalizeFirst, ValidJSON, NoTrailingWhitespace,
    IsNonEmpty, MaxLength, ContainsKeyword, NoCharacters,
    NoContradictions, JSONFieldsPopulated, ResponseLength, LogicalFlow
)


# ============================================================================
# CONSTRAINT REGISTRY - Maps type names to classes and their editable params
# ============================================================================

CONSTRAINT_REGISTRY = {
    # Separate constraints
    "NoDoubleSpaces": {
        "class": NoDoubleSpaces,
        "category": "separate",
        "description": "Collapse multiple spaces into one",
        "auto_fix": True,
        "params": {}
    },
    "CapitalizeFirst": {
        "class": CapitalizeFirst,
        "category": "separate",
        "description": "First character must be uppercase",
        "auto_fix": True,
        "params": {}
    },
    "NoTrailingWhitespace": {
        "class": NoTrailingWhitespace,
        "category": "separate",
        "description": "Strip trailing spaces, newlines, tabs",
        "auto_fix": True,
        "params": {}
    },
    "IsNonEmpty": {
        "class": IsNonEmpty,
        "category": "separate",
        "description": "Reject empty or None data",
        "auto_fix": False,
        "params": {}
    },
    "MaxLength": {
        "class": MaxLength,
        "category": "separate",
        "description": "Enforce maximum character length",
        "auto_fix": True,
        "params": {
            "max_len": {"type": "int", "default": 10000, "label": "Max Characters", "min": 1, "max": 100000}
        }
    },
    "ContainsKeyword": {
        "class": ContainsKeyword,
        "category": "separate",
        "description": "Output must contain a specific keyword",
        "auto_fix": False,
        "params": {
            "keyword": {"type": "str", "default": "", "label": "Required Keyword"}
        }
    },
    "NoCharacters": {
        "class": NoCharacters,
        "category": "separate",
        "description": "Ban specific characters from output",
        "auto_fix": True,
        "params": {
            "banned_chars": {"type": "str", "default": "", "label": "Banned Characters"}
        }
    },
    "ValidJSON": {
        "class": ValidJSON,
        "category": "separate",
        "description": "Must be valid JSON (optional required fields)",
        "auto_fix": False,
        "params": {
            "required_fields": {"type": "list", "default": [], "label": "Required Fields (comma-separated)"}
        }
    },
    # Collective constraints
    "NoContradictions": {
        "class": NoContradictions,
        "category": "collective",
        "description": "Detect contradictory statements",
        "auto_fix": False,
        "params": {}
    },
    "ResponseLength": {
        "class": ResponseLength,
        "category": "collective",
        "description": "Enforce minimum response length",
        "auto_fix": False,
        "params": {
            "min_length": {"type": "int", "default": 50, "label": "Min Characters", "min": 1, "max": 50000}
        }
    },
    "JSONFieldsPopulated": {
        "class": JSONFieldsPopulated,
        "category": "collective",
        "description": "All required JSON fields must have content",
        "auto_fix": False,
        "params": {
            "required_fields": {"type": "list", "default": [], "label": "Required Fields (comma-separated)"}
        }
    },
    "LogicalFlow": {
        "class": LogicalFlow,
        "category": "collective",
        "description": "Keywords must appear in a specific order",
        "auto_fix": False,
        "params": {
            "required_order": {"type": "list", "default": [], "label": "Keywords in Order (comma-separated)"}
        }
    },
}


# ============================================================================
# SERIALIZATION - Save/load constraint configs to JSON
# ============================================================================

def engine_to_config(engine: ConstraintEngine) -> dict:
    """Serialize a ConstraintEngine to a saveable dict"""
    config = {"name": engine.name, "separate": [], "collective": []}
    
    for c in engine.separate_constraints:
        entry = {"type": type(c).__name__, "name": c.name}
        reg = CONSTRAINT_REGISTRY.get(type(c).__name__, {})
        for param_name in reg.get("params", {}):
            entry[param_name] = getattr(c, param_name, reg["params"][param_name]["default"])
        config["separate"].append(entry)
    
    for c in engine.collective_constraints:
        entry = {"type": type(c).__name__, "name": c.name}
        reg = CONSTRAINT_REGISTRY.get(type(c).__name__, {})
        for param_name in reg.get("params", {}):
            entry[param_name] = getattr(c, param_name, reg["params"][param_name]["default"])
        config["collective"].append(entry)
    
    return config


def config_to_engine(config: dict) -> ConstraintEngine:
    """Rebuild a ConstraintEngine from a saved config dict"""
    engine = ConstraintEngine(name=config.get("name", "ConstraintEngine"))
    
    for entry in config.get("separate", []):
        ctype = entry.get("type")
        if ctype in CONSTRAINT_REGISTRY:
            reg = CONSTRAINT_REGISTRY[ctype]
            kwargs = {"name": entry.get("name", ctype)}
            for param_name, param_info in reg["params"].items():
                if param_name in entry:
                    kwargs[param_name] = entry[param_name]
                else:
                    kwargs[param_name] = param_info["default"]
            engine.add_separate(reg["class"](**kwargs))
    
    for entry in config.get("collective", []):
        ctype = entry.get("type")
        if ctype in CONSTRAINT_REGISTRY:
            reg = CONSTRAINT_REGISTRY[ctype]
            kwargs = {"name": entry.get("name", ctype)}
            for param_name, param_info in reg["params"].items():
                if param_name in entry:
                    kwargs[param_name] = entry[param_name]
                else:
                    kwargs[param_name] = param_info["default"]
            engine.add_collective(reg["class"](**kwargs))
    
    return engine


# ============================================================================
# GUI
# ============================================================================

COLORS = {
    'bg': '#1e1e2e',
    'bg_card': '#2a2a3d',
    'bg_input': '#363650',
    'bg_selected': '#3d3d5c',
    'text': '#e0e0e0',
    'text_muted': '#8888aa',
    'text_heading': '#ffffff',
    'accent': '#6c8cff',
    'accent_hover': '#8aa4ff',
    'green': '#4ec98b',
    'red': '#e05555',
    'orange': '#e0a040',
    'yellow': '#e0d060',
    'border': '#3a3a55',
    'separate_tag': '#4ec98b',
    'collective_tag': '#6c8cff',
}

FONTS = {
    'heading': ('Arial', 13, 'bold'),
    'subheading': ('Arial', 11, 'bold'),
    'normal': ('Arial', 10),
    'small': ('Arial', 9),
    'mono': ('Courier', 10),
    'mono_small': ('Courier', 9),
}


class ConstraintEngineGUI:
    """Visual editor for ConstraintEngine configurations"""
    
    def __init__(self, root, engine: ConstraintEngine = None, on_apply=None):
        """
        root: tk.Tk or tk.Toplevel
        engine: existing ConstraintEngine to edit (or None for fresh)
        on_apply: callback(engine) called when user clicks Apply
        """
        self.root = root
        self.root.title("Constraint Engine Editor")
        self.root.geometry("820x700")
        self.root.configure(bg=COLORS['bg'])
        self.root.resizable(True, True)
        self.root.minsize(700, 500)
        
        self.on_apply = on_apply
        self.config_path = os.path.join(os.path.expanduser("~"), "Downloads", "constraint_engine_config.json")
        self.unsaved_changes = False
        
        # Build working config from engine or defaults
        if engine:
            self.working_config = engine_to_config(engine)
        else:
            self.working_config = self._default_config()
        
        self._build_ui()
        self._refresh_list()
        self.root.protocol("WM_DELETE_WINDOW", self._on_close)
    
    def _default_config(self):
        return {
            "name": "StoryValidator",
            "separate": [
                {"type": "IsNonEmpty", "name": "IsNonEmpty"},
                {"type": "NoDoubleSpaces", "name": "NoDoubleSpaces"},
                {"type": "NoTrailingWhitespace", "name": "NoTrailingWhitespace"},
                {"type": "CapitalizeFirst", "name": "CapitalizeFirst"},
                {"type": "MaxLength", "name": "MaxLength", "max_len": 10000},
            ],
            "collective": [
                {"type": "ResponseLength", "name": "ResponseLength", "min_length": 50},
                {"type": "NoContradictions", "name": "NoContradictions"},
            ]
        }
    
    # ====================================================================
    # UI BUILD
    # ====================================================================
    
    def _build_ui(self):
        # Title bar
        title_frame = tk.Frame(self.root, bg=COLORS['bg'])
        title_frame.pack(fill=tk.X, padx=15, pady=(12, 0))
        
        tk.Label(title_frame, text="Constraint Engine Editor", font=FONTS['heading'],
                 bg=COLORS['bg'], fg=COLORS['text_heading']).pack(side=tk.LEFT)
        
        self.status_label = tk.Label(title_frame, text="", font=FONTS['small'],
                                      bg=COLORS['bg'], fg=COLORS['text_muted'])
        self.status_label.pack(side=tk.RIGHT)
        self._update_status()
        
        # Engine name row
        name_frame = tk.Frame(self.root, bg=COLORS['bg'])
        name_frame.pack(fill=tk.X, padx=15, pady=(8, 0))
        
        tk.Label(name_frame, text="Engine Name:", font=FONTS['normal'],
                 bg=COLORS['bg'], fg=COLORS['text_muted']).pack(side=tk.LEFT, padx=(0, 8))
        self.name_var = tk.StringVar(value=self.working_config.get("name", "ConstraintEngine"))
        name_entry = tk.Entry(name_frame, textvariable=self.name_var, font=FONTS['mono'],
                              bg=COLORS['bg_input'], fg=COLORS['text'], insertbackground=COLORS['text'],
                              relief=tk.FLAT, bd=0, width=30)
        name_entry.pack(side=tk.LEFT, padx=(0, 15), ipady=4, ipadx=6)
        self.name_var.trace_add("write", lambda *_: self._mark_changed())
        
        # Main split: left = constraint list, right = editor
        body = tk.Frame(self.root, bg=COLORS['bg'])
        body.pack(fill=tk.BOTH, expand=True, padx=15, pady=(10, 0))
        body.columnconfigure(0, weight=1)
        body.columnconfigure(1, weight=1)
        body.rowconfigure(0, weight=1)
        
        # ── LEFT: Constraint List ──
        left = tk.Frame(body, bg=COLORS['bg_card'], highlightthickness=1,
                        highlightbackground=COLORS['border'])
        left.grid(row=0, column=0, sticky="nsew", padx=(0, 6))
        left.rowconfigure(1, weight=1)
        left.columnconfigure(0, weight=1)
        
        # List header
        lh = tk.Frame(left, bg=COLORS['bg_card'])
        lh.grid(row=0, column=0, sticky="ew", padx=10, pady=(10, 5))
        tk.Label(lh, text="Active Constraints", font=FONTS['subheading'],
                 bg=COLORS['bg_card'], fg=COLORS['text_heading']).pack(side=tk.LEFT)
        
        # Constraint listbox
        list_frame = tk.Frame(left, bg=COLORS['bg_card'])
        list_frame.grid(row=1, column=0, sticky="nsew", padx=10, pady=(0, 5))
        list_frame.rowconfigure(0, weight=1)
        list_frame.columnconfigure(0, weight=1)
        
        self.constraint_listbox = tk.Listbox(
            list_frame, font=FONTS['mono'], bg=COLORS['bg_input'], fg=COLORS['text'],
            selectbackground=COLORS['accent'], selectforeground=COLORS['text_heading'],
            relief=tk.FLAT, bd=0, highlightthickness=0, activestyle='none'
        )
        self.constraint_listbox.grid(row=0, column=0, sticky="nsew")
        self.constraint_listbox.bind("<<ListboxSelect>>", self._on_select)
        
        scrollbar = ttk.Scrollbar(list_frame, orient=tk.VERTICAL, command=self.constraint_listbox.yview)
        scrollbar.grid(row=0, column=1, sticky="ns")
        self.constraint_listbox.config(yscrollcommand=scrollbar.set)
        
        # List buttons
        lb = tk.Frame(left, bg=COLORS['bg_card'])
        lb.grid(row=2, column=0, sticky="ew", padx=10, pady=(0, 10))
        
        btn_style = {"font": FONTS['small'], "relief": tk.FLAT, "bd": 0, "padx": 10, "pady": 4, "cursor": "hand2"}
        
        tk.Button(lb, text="▲ Up", bg=COLORS['bg_input'], fg=COLORS['text'],
                  command=self._move_up, **btn_style).pack(side=tk.LEFT, padx=(0, 3))
        tk.Button(lb, text="▼ Down", bg=COLORS['bg_input'], fg=COLORS['text'],
                  command=self._move_down, **btn_style).pack(side=tk.LEFT, padx=(0, 3))
        tk.Button(lb, text="✕ Remove", bg=COLORS['red'], fg=COLORS['text_heading'],
                  command=self._remove_selected, **btn_style).pack(side=tk.RIGHT)
        
        # ── RIGHT: Editor Panel ──
        right = tk.Frame(body, bg=COLORS['bg_card'], highlightthickness=1,
                         highlightbackground=COLORS['border'])
        right.grid(row=0, column=1, sticky="nsew", padx=(6, 0))
        right.rowconfigure(1, weight=1)
        right.columnconfigure(0, weight=1)
        
        # Editor header
        rh = tk.Frame(right, bg=COLORS['bg_card'])
        rh.grid(row=0, column=0, sticky="ew", padx=10, pady=(10, 5))
        tk.Label(rh, text="Edit Constraint", font=FONTS['subheading'],
                 bg=COLORS['bg_card'], fg=COLORS['text_heading']).pack(side=tk.LEFT)
        
        # Editor content (dynamic)
        self.editor_frame = tk.Frame(right, bg=COLORS['bg_card'])
        self.editor_frame.grid(row=1, column=0, sticky="nsew", padx=10, pady=(0, 10))
        
        self._show_no_selection()
        
        # ── ADD CONSTRAINT SECTION ──
        add_frame = tk.Frame(self.root, bg=COLORS['bg_card'], highlightthickness=1,
                             highlightbackground=COLORS['border'])
        add_frame.pack(fill=tk.X, padx=15, pady=(10, 0))
        
        add_inner = tk.Frame(add_frame, bg=COLORS['bg_card'])
        add_inner.pack(fill=tk.X, padx=10, pady=10)
        
        tk.Label(add_inner, text="Add Constraint:", font=FONTS['subheading'],
                 bg=COLORS['bg_card'], fg=COLORS['text_heading']).pack(side=tk.LEFT, padx=(0, 10))
        
        # Type dropdown
        self.add_type_var = tk.StringVar(value="NoDoubleSpaces")
        type_names = sorted(CONSTRAINT_REGISTRY.keys())
        self.add_dropdown = ttk.Combobox(add_inner, textvariable=self.add_type_var,
                                          values=type_names, state="readonly", width=22)
        self.add_dropdown.pack(side=tk.LEFT, padx=(0, 8))
        self.add_dropdown.bind("<<ComboboxSelected>>", self._update_add_preview)
        
        # Preview label
        self.add_preview = tk.Label(add_inner, text="", font=FONTS['small'],
                                     bg=COLORS['bg_card'], fg=COLORS['text_muted'])
        self.add_preview.pack(side=tk.LEFT, padx=(0, 10), fill=tk.X, expand=True)
        self._update_add_preview()
        
        tk.Button(add_inner, text="+ Add", font=FONTS['normal'], bg=COLORS['green'],
                  fg=COLORS['bg'], relief=tk.FLAT, bd=0, padx=14, pady=4,
                  cursor="hand2", command=self._add_constraint).pack(side=tk.RIGHT)
        
        # ── TEST SECTION ──
        test_frame = tk.Frame(self.root, bg=COLORS['bg_card'], highlightthickness=1,
                              highlightbackground=COLORS['border'])
        test_frame.pack(fill=tk.X, padx=15, pady=(10, 0))
        
        test_header = tk.Frame(test_frame, bg=COLORS['bg_card'])
        test_header.pack(fill=tk.X, padx=10, pady=(10, 5))
        tk.Label(test_header, text="Test Engine", font=FONTS['subheading'],
                 bg=COLORS['bg_card'], fg=COLORS['text_heading']).pack(side=tk.LEFT)
        
        tk.Button(test_header, text="▶ Run Test", font=FONTS['small'], bg=COLORS['accent'],
                  fg=COLORS['text_heading'], relief=tk.FLAT, bd=0, padx=12, pady=3,
                  cursor="hand2", command=self._run_test).pack(side=tk.RIGHT)
        
        self.test_auto_fix_var = tk.BooleanVar(value=True)
        tk.Checkbutton(test_header, text="Auto-fix", variable=self.test_auto_fix_var,
                        font=FONTS['small'], bg=COLORS['bg_card'], fg=COLORS['text'],
                        selectcolor=COLORS['bg_input'], activebackground=COLORS['bg_card'],
                        activeforeground=COLORS['text']).pack(side=tk.RIGHT, padx=(0, 10))
        
        test_body = tk.Frame(test_frame, bg=COLORS['bg_card'])
        test_body.pack(fill=tk.X, padx=10, pady=(0, 10))
        test_body.columnconfigure(0, weight=1)
        test_body.columnconfigure(1, weight=1)
        
        self.test_input = tk.Text(test_body, height=3, font=FONTS['mono_small'],
                                   bg=COLORS['bg_input'], fg=COLORS['text'],
                                   insertbackground=COLORS['text'], relief=tk.FLAT, bd=0, wrap=tk.WORD)
        self.test_input.grid(row=0, column=0, sticky="nsew", padx=(0, 4), ipady=4, ipadx=4)
        self.test_input.insert("1.0", "  hello world.  This is a  test with  double spaces.  ")
        
        self.test_output = tk.Text(test_body, height=3, font=FONTS['mono_small'],
                                    bg=COLORS['bg_input'], fg=COLORS['green'],
                                    relief=tk.FLAT, bd=0, wrap=tk.WORD, state=tk.DISABLED)
        self.test_output.grid(row=0, column=1, sticky="nsew", padx=(4, 0), ipady=4, ipadx=4)
        
        # ── BOTTOM BUTTONS ──
        bottom = tk.Frame(self.root, bg=COLORS['bg'])
        bottom.pack(fill=tk.X, padx=15, pady=(12, 15))
        
        tk.Button(bottom, text="💾 Save Config", font=FONTS['normal'], bg=COLORS['bg_input'],
                  fg=COLORS['text'], relief=tk.FLAT, bd=0, padx=14, pady=6,
                  cursor="hand2", command=self._save_config).pack(side=tk.LEFT, padx=(0, 6))
        
        tk.Button(bottom, text="📂 Load Config", font=FONTS['normal'], bg=COLORS['bg_input'],
                  fg=COLORS['text'], relief=tk.FLAT, bd=0, padx=14, pady=6,
                  cursor="hand2", command=self._load_config).pack(side=tk.LEFT, padx=(0, 6))
        
        tk.Button(bottom, text="🔄 Reset Defaults", font=FONTS['normal'], bg=COLORS['orange'],
                  fg=COLORS['bg'], relief=tk.FLAT, bd=0, padx=14, pady=6,
                  cursor="hand2", command=self._reset_defaults).pack(side=tk.LEFT)
        
        self.apply_btn = tk.Button(bottom, text="✓ Apply to Engine", font=('Arial', 11, 'bold'),
                                    bg=COLORS['green'], fg=COLORS['bg'], relief=tk.FLAT, bd=0,
                                    padx=20, pady=6, cursor="hand2", command=self._apply)
        self.apply_btn.pack(side=tk.RIGHT)
    
    # ====================================================================
    # CONSTRAINT LIST MANAGEMENT
    # ====================================================================
    
    def _get_all_entries(self):
        """Return flat list of (category, index, entry) for display order"""
        items = []
        for i, entry in enumerate(self.working_config.get("separate", [])):
            items.append(("separate", i, entry))
        for i, entry in enumerate(self.working_config.get("collective", [])):
            items.append(("collective", i, entry))
        return items
    
    def _refresh_list(self):
        self.constraint_listbox.delete(0, tk.END)
        
        items = self._get_all_entries()
        if not items:
            self.constraint_listbox.insert(tk.END, "  (no constraints loaded)")
            return
        
        last_cat = None
        for cat, idx, entry in items:
            if cat != last_cat:
                header = f"── {'SEPARATE (Fast)' if cat == 'separate' else 'COLLECTIVE (Global)'} ──"
                self.constraint_listbox.insert(tk.END, header)
                self.constraint_listbox.itemconfig(tk.END, fg=COLORS['text_muted'], selectbackground=COLORS['bg_input'])
                last_cat = cat
            
            tag = "[S]" if cat == "separate" else "[C]"
            ctype = entry.get("type", "?")
            name = entry.get("name", ctype)
            
            # Show key param value if any
            reg = CONSTRAINT_REGISTRY.get(ctype, {})
            param_str = ""
            for pname, pinfo in reg.get("params", {}).items():
                val = entry.get(pname, pinfo["default"])
                if isinstance(val, list):
                    val = ", ".join(str(v) for v in val) if val else "(none)"
                param_str = f" = {val}"
                break  # Show first param only
            
            fix_icon = "🔧" if reg.get("auto_fix") else "  "
            line = f"  {tag} {fix_icon} {name}{param_str}"
            self.constraint_listbox.insert(tk.END, line)
        
        self._update_status()
    
    def _update_status(self):
        sep = len(self.working_config.get("separate", []))
        col = len(self.working_config.get("collective", []))
        changed = " ●" if self.unsaved_changes else ""
        self.status_label.config(text=f"{sep} separate, {col} collective{changed}")
    
    def _mark_changed(self):
        self.unsaved_changes = True
        self._update_status()
    
    def _resolve_selection(self):
        """Map listbox selection index to (category, config_index) or None"""
        sel = self.constraint_listbox.curselection()
        if not sel:
            return None
        
        lb_idx = sel[0]
        text = self.constraint_listbox.get(lb_idx)
        
        # Skip header rows
        if text.startswith("──") or text.startswith("  (no"):
            return None
        
        # Count real entries before this index
        real_idx = -1
        for i in range(lb_idx + 1):
            t = self.constraint_listbox.get(i)
            if not t.startswith("──") and not t.startswith("  (no"):
                real_idx += 1
        
        # Map to category + index
        sep_count = len(self.working_config.get("separate", []))
        if real_idx < sep_count:
            return ("separate", real_idx)
        else:
            return ("collective", real_idx - sep_count)
    
    def _on_select(self, event=None):
        resolved = self._resolve_selection()
        if resolved is None:
            self._show_no_selection()
            return
        
        cat, idx = resolved
        entry = self.working_config[cat][idx]
        self._show_editor(cat, idx, entry)
    
    def _move_up(self):
        resolved = self._resolve_selection()
        if resolved is None:
            return
        cat, idx = resolved
        if idx <= 0:
            return
        lst = self.working_config[cat]
        lst[idx], lst[idx - 1] = lst[idx - 1], lst[idx]
        self._mark_changed()
        self._refresh_list()
        # Reselect
        self._select_entry(cat, idx - 1)
    
    def _move_down(self):
        resolved = self._resolve_selection()
        if resolved is None:
            return
        cat, idx = resolved
        lst = self.working_config[cat]
        if idx >= len(lst) - 1:
            return
        lst[idx], lst[idx + 1] = lst[idx + 1], lst[idx]
        self._mark_changed()
        self._refresh_list()
        self._select_entry(cat, idx + 1)
    
    def _select_entry(self, cat, idx):
        """Select a specific entry in the listbox after refresh"""
        # Count listbox position: headers + entries
        lb_idx = 0
        # Separate header
        if self.working_config.get("separate"):
            lb_idx += 1  # header row
            if cat == "separate":
                lb_idx += idx
                self.constraint_listbox.selection_set(lb_idx)
                self.constraint_listbox.see(lb_idx)
                self._on_select()
                return
            lb_idx += len(self.working_config["separate"])
        
        # Collective header
        if self.working_config.get("collective"):
            lb_idx += 1  # header row
            if cat == "collective":
                lb_idx += idx
                self.constraint_listbox.selection_set(lb_idx)
                self.constraint_listbox.see(lb_idx)
                self._on_select()
                return
    
    def _remove_selected(self):
        resolved = self._resolve_selection()
        if resolved is None:
            return
        cat, idx = resolved
        entry = self.working_config[cat][idx]
        name = entry.get("name", entry.get("type", "?"))
        if messagebox.askyesno("Remove Constraint", f"Remove '{name}'?"):
            self.working_config[cat].pop(idx)
            self._mark_changed()
            self._refresh_list()
            self._show_no_selection()
    
    def _add_constraint(self):
        ctype = self.add_type_var.get()
        if ctype not in CONSTRAINT_REGISTRY:
            return
        
        reg = CONSTRAINT_REGISTRY[ctype]
        entry = {"type": ctype, "name": ctype}
        
        for pname, pinfo in reg["params"].items():
            entry[pname] = pinfo["default"]
        
        cat = reg["category"]
        self.working_config[cat].append(entry)
        self._mark_changed()
        self._refresh_list()
        
        # Select the new entry
        idx = len(self.working_config[cat]) - 1
        self._select_entry(cat, idx)
    
    def _update_add_preview(self, event=None):
        ctype = self.add_type_var.get()
        reg = CONSTRAINT_REGISTRY.get(ctype, {})
        cat = reg.get("category", "?")
        desc = reg.get("description", "")
        fix = "🔧 auto-fix" if reg.get("auto_fix") else "no auto-fix"
        tag = "Separate" if cat == "separate" else "Collective"
        self.add_preview.config(text=f"{tag} · {desc} · {fix}")
    
    # ====================================================================
    # EDITOR PANEL
    # ====================================================================
    
    def _show_no_selection(self):
        for w in self.editor_frame.winfo_children():
            w.destroy()
        
        tk.Label(self.editor_frame, text="Select a constraint\nfrom the list to edit it",
                 font=FONTS['normal'], bg=COLORS['bg_card'], fg=COLORS['text_muted'],
                 justify=tk.CENTER).pack(expand=True)
    
    def _show_editor(self, cat, idx, entry):
        for w in self.editor_frame.winfo_children():
            w.destroy()
        
        ctype = entry.get("type", "?")
        reg = CONSTRAINT_REGISTRY.get(ctype, {})
        
        # Type and category
        header = tk.Frame(self.editor_frame, bg=COLORS['bg_card'])
        header.pack(fill=tk.X, pady=(0, 10))
        
        tag_color = COLORS['separate_tag'] if cat == "separate" else COLORS['collective_tag']
        tag_text = "SEPARATE" if cat == "separate" else "COLLECTIVE"
        tk.Label(header, text=tag_text, font=FONTS['small'], bg=tag_color,
                 fg=COLORS['bg'], padx=6, pady=1).pack(side=tk.LEFT, padx=(0, 8))
        
        tk.Label(header, text=ctype, font=FONTS['subheading'],
                 bg=COLORS['bg_card'], fg=COLORS['text_heading']).pack(side=tk.LEFT)
        
        # Description
        desc = reg.get("description", "No description")
        tk.Label(self.editor_frame, text=desc, font=FONTS['small'],
                 bg=COLORS['bg_card'], fg=COLORS['text_muted'], anchor=tk.W).pack(fill=tk.X, pady=(0, 5))
        
        fix = "🔧 Can auto-fix failures" if reg.get("auto_fix") else "⚠ Cannot auto-fix (validate only)"
        tk.Label(self.editor_frame, text=fix, font=FONTS['small'],
                 bg=COLORS['bg_card'], fg=COLORS['text_muted'], anchor=tk.W).pack(fill=tk.X, pady=(0, 12))
        
        # Separator
        tk.Frame(self.editor_frame, bg=COLORS['border'], height=1).pack(fill=tk.X, pady=(0, 12))
        
        # Name field
        name_row = tk.Frame(self.editor_frame, bg=COLORS['bg_card'])
        name_row.pack(fill=tk.X, pady=(0, 10))
        
        tk.Label(name_row, text="Display Name:", font=FONTS['normal'],
                 bg=COLORS['bg_card'], fg=COLORS['text']).pack(anchor=tk.W)
        
        name_var = tk.StringVar(value=entry.get("name", ctype))
        name_entry = tk.Entry(name_row, textvariable=name_var, font=FONTS['mono'],
                              bg=COLORS['bg_input'], fg=COLORS['text'],
                              insertbackground=COLORS['text'], relief=tk.FLAT, bd=0)
        name_entry.pack(fill=tk.X, ipady=4, ipadx=6, pady=(3, 0))
        
        # Parameter fields
        param_vars = {}
        for pname, pinfo in reg.get("params", {}).items():
            row = tk.Frame(self.editor_frame, bg=COLORS['bg_card'])
            row.pack(fill=tk.X, pady=(0, 10))
            
            tk.Label(row, text=f"{pinfo['label']}:", font=FONTS['normal'],
                     bg=COLORS['bg_card'], fg=COLORS['text']).pack(anchor=tk.W)
            
            current_val = entry.get(pname, pinfo["default"])
            
            if pinfo["type"] == "int":
                var = tk.IntVar(value=current_val)
                spin = ttk.Spinbox(row, from_=pinfo.get("min", 0), to=pinfo.get("max", 999999),
                                    textvariable=var, width=12)
                spin.pack(anchor=tk.W, pady=(3, 0))
                param_vars[pname] = ("int", var)
                
            elif pinfo["type"] == "str":
                var = tk.StringVar(value=current_val)
                ent = tk.Entry(row, textvariable=var, font=FONTS['mono'],
                               bg=COLORS['bg_input'], fg=COLORS['text'],
                               insertbackground=COLORS['text'], relief=tk.FLAT, bd=0)
                ent.pack(fill=tk.X, ipady=4, ipadx=6, pady=(3, 0))
                param_vars[pname] = ("str", var)
                
            elif pinfo["type"] == "list":
                # Show as comma-separated string
                if isinstance(current_val, list):
                    display = ", ".join(str(v) for v in current_val)
                else:
                    display = str(current_val)
                var = tk.StringVar(value=display)
                ent = tk.Entry(row, textvariable=var, font=FONTS['mono'],
                               bg=COLORS['bg_input'], fg=COLORS['text'],
                               insertbackground=COLORS['text'], relief=tk.FLAT, bd=0)
                ent.pack(fill=tk.X, ipady=4, ipadx=6, pady=(3, 0))
                
                tk.Label(row, text="Separate items with commas", font=FONTS['small'],
                         bg=COLORS['bg_card'], fg=COLORS['text_muted']).pack(anchor=tk.W, pady=(2, 0))
                param_vars[pname] = ("list", var)
        
        if not reg.get("params"):
            tk.Label(self.editor_frame, text="This constraint has no configurable parameters.",
                     font=FONTS['small'], bg=COLORS['bg_card'], fg=COLORS['text_muted']).pack(
                anchor=tk.W, pady=(0, 10))
        
        # Save button for this constraint
        tk.Frame(self.editor_frame, bg=COLORS['bg_card']).pack(fill=tk.BOTH, expand=True)
        
        def _save_edits():
            entry["name"] = name_var.get().strip() or ctype
            for pname, (ptype, var) in param_vars.items():
                if ptype == "int":
                    try:
                        entry[pname] = var.get()
                    except:
                        entry[pname] = CONSTRAINT_REGISTRY[ctype]["params"][pname]["default"]
                elif ptype == "str":
                    entry[pname] = var.get()
                elif ptype == "list":
                    raw = var.get().strip()
                    if raw:
                        entry[pname] = [item.strip() for item in raw.split(",") if item.strip()]
                    else:
                        entry[pname] = []
            
            self._mark_changed()
            self._refresh_list()
            self._select_entry(cat, idx)
        
        btn_frame = tk.Frame(self.editor_frame, bg=COLORS['bg_card'])
        btn_frame.pack(fill=tk.X, pady=(10, 0))
        
        tk.Button(btn_frame, text="💾 Save Changes", font=FONTS['normal'], bg=COLORS['accent'],
                  fg=COLORS['text_heading'], relief=tk.FLAT, bd=0, padx=14, pady=5,
                  cursor="hand2", command=_save_edits).pack(side=tk.RIGHT)
    
    # ====================================================================
    # TEST ENGINE
    # ====================================================================
    
    def _run_test(self):
        test_data = self.test_input.get("1.0", tk.END).strip()
        if not test_data:
            self._set_test_output("Enter test text first", COLORS['red'])
            return
        
        # Build engine from current config
        try:
            engine = config_to_engine(self.working_config)
        except Exception as e:
            self._set_test_output(f"Engine build error: {e}", COLORS['red'])
            return
        
        auto_fix = self.test_auto_fix_var.get()
        
        start = time.time()
        result = engine.validate(test_data, auto_fix=auto_fix)
        elapsed = (time.time() - start) * 1000
        
        lines = []
        for entry in result.get("log", []):
            name = entry["constraint"]
            phase = "S" if entry.get("phase") == "separate" else "C"
            ms = entry.get("duration_ms", 0)
            
            if entry.get("fixed"):
                lines.append(f"🔧 [{phase}] {name}: FIXED ({ms:.2f}ms)")
            elif entry["passed"]:
                lines.append(f"✓ [{phase}] {name}: passed ({ms:.2f}ms)")
            else:
                lines.append(f"✗ [{phase}] {name}: FAILED ({ms:.2f}ms)")
        
        fixes = sum(1 for e in result.get("log", []) if e.get("fixed"))
        
        if result.get("success"):
            lines.append(f"\n✓ ALL PASSED ({elapsed:.2f}ms, {fixes} fixes)")
            if auto_fix and "data" in result:
                output = result["data"]
                if output != test_data:
                    lines.append(f"\nFixed output:\n{output}")
            color = COLORS['green']
        else:
            failed = result.get("failed_at", "unknown")
            lines.append(f"\n✗ FAILED at: {failed} ({elapsed:.2f}ms)")
            color = COLORS['red']
        
        self._set_test_output("\n".join(lines), color)
    
    def _set_test_output(self, text, color=COLORS['green']):
        self.test_output.config(state=tk.NORMAL, fg=color)
        self.test_output.delete("1.0", tk.END)
        self.test_output.insert("1.0", text)
        self.test_output.config(state=tk.DISABLED)
    
    # ====================================================================
    # SAVE / LOAD / APPLY
    # ====================================================================
    
    def _save_config(self):
        self.working_config["name"] = self.name_var.get().strip() or "ConstraintEngine"
        
        path = filedialog.asksaveasfilename(
            title="Save Constraint Config",
            initialdir=os.path.expanduser("~/Downloads"),
            initialfile="constraint_engine_config.json",
            defaultextension=".json",
            filetypes=[("JSON files", "*.json"), ("All files", "*.*")]
        )
        if not path:
            return
        
        try:
            with open(path, 'w', encoding='utf-8') as f:
                json.dump(self.working_config, f, indent=2)
            self.config_path = path
            self.unsaved_changes = False
            self._update_status()
            messagebox.showinfo("Saved", f"Config saved:\n{os.path.basename(path)}")
        except Exception as e:
            messagebox.showerror("Error", f"Failed to save:\n{e}")
    
    def _load_config(self):
        path = filedialog.askopenfilename(
            title="Load Constraint Config",
            initialdir=os.path.expanduser("~/Downloads"),
            filetypes=[("JSON files", "*.json"), ("All files", "*.*")]
        )
        if not path:
            return
        
        try:
            with open(path, 'r', encoding='utf-8') as f:
                loaded = json.load(f)
            
            # Validate structure
            if "separate" not in loaded and "collective" not in loaded:
                messagebox.showerror("Error", "Invalid config file — missing separate/collective keys")
                return
            
            self.working_config = loaded
            self.name_var.set(loaded.get("name", "ConstraintEngine"))
            self.config_path = path
            self.unsaved_changes = False
            self._refresh_list()
            self._show_no_selection()
            messagebox.showinfo("Loaded", f"Config loaded:\n{os.path.basename(path)}")
        except Exception as e:
            messagebox.showerror("Error", f"Failed to load:\n{e}")
    
    def _reset_defaults(self):
        if messagebox.askyesno("Reset", "Reset all constraints to defaults?"):
            self.working_config = self._default_config()
            self.name_var.set(self.working_config["name"])
            self._mark_changed()
            self._refresh_list()
            self._show_no_selection()
    
    def _apply(self):
        """Build engine from config and fire the callback"""
        self.working_config["name"] = self.name_var.get().strip() or "ConstraintEngine"
        
        try:
            engine = config_to_engine(self.working_config)
        except Exception as e:
            messagebox.showerror("Error", f"Failed to build engine:\n{e}")
            return
        
        sep = len(engine.separate_constraints)
        col = len(engine.collective_constraints)
        
        if self.on_apply:
            self.on_apply(engine)
            self.unsaved_changes = False
            self._update_status()
            messagebox.showinfo("Applied", f"Engine applied: {sep} separate, {col} collective constraints")
        else:
            # Standalone mode — just confirm it builds
            self.unsaved_changes = False
            self._update_status()
            messagebox.showinfo("Validated",
                                f"Engine builds successfully:\n{sep} separate, {col} collective constraints\n\n"
                                f"(No LMmultipass connected — save config to use it)")
    
    def _on_close(self):
        if self.unsaved_changes:
            if not messagebox.askyesno("Unsaved Changes", "You have unsaved changes. Close anyway?"):
                return
        self.root.destroy()
    
    def get_engine(self) -> ConstraintEngine:
        """Build and return engine from current config"""
        self.working_config["name"] = self.name_var.get().strip() or "ConstraintEngine"
        return config_to_engine(self.working_config)


# ============================================================================
# STANDALONE ENTRY POINT
# ============================================================================

if __name__ == "__main__":
    root = tk.Tk()
    app = ConstraintEngineGUI(root)
    root.mainloop()
