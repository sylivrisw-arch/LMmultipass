"""
Constraint Engine - Validates and transforms data
Separate: Individual piece validation (fast)
Collective: Whole output validation (complex)
"""

from abc import ABC, abstractmethod
import json
import re
import time
from typing import Any, List, Dict, Union


class Constraint(ABC):
    """Base constraint - all constraints inherit from this"""
    
    def __init__(self, name: str):
        self.name = name
        self.passed = False
        self.execution_time = 0
    
    @abstractmethod
    def validate(self, data: Any) -> bool:
        """Does data pass this constraint?"""
        pass
    
    @abstractmethod
    def fix(self, data: Any) -> Any:
        """Fix data if it fails"""
        pass
    
    def describe(self):
        """Human-readable description"""
        return f"{self.name}"


# ============================================================================
# SEPARATE CONSTRAINTS (Local, Fast, Per-Item)
# ============================================================================

class SeparateConstraint(Constraint):
    """Validates individual pieces in isolation"""
    pass


class NoDoubleSpaces(SeparateConstraint):
    """Remove multiple spaces"""
    
    def validate(self, data: str) -> bool:
        return "  " not in data
    
    def fix(self, data: str) -> str:
        return re.sub(r"  +", " ", data)


class CapitalizeFirst(SeparateConstraint):
    """First letter must be capitalized"""
    
    def validate(self, data: str) -> bool:
        if not data:
            return True
        return data[0].isupper()
    
    def fix(self, data: str) -> str:
        if not data:
            return data
        return data[0].upper() + data[1:]


class ValidJSON(SeparateConstraint):
    """Must be valid JSON"""
    
    def __init__(self, name: str = "ValidJSON", required_fields: List[str] = None):
        super().__init__(name)
        self.required_fields = required_fields or []
    
    def validate(self, data: Union[str, dict]) -> bool:
        try:
            if isinstance(data, str):
                parsed = json.loads(data)
            else:
                parsed = data
            
            # Check required fields
            if isinstance(parsed, dict):
                for field in self.required_fields:
                    if field not in parsed:
                        return False
            
            return True
        except:
            return False
    
    def fix(self, data: str) -> str:
        # Can't really fix invalid JSON at this layer
        return data


class NoTrailingWhitespace(SeparateConstraint):
    """Remove trailing spaces"""
    
    def validate(self, data: str) -> bool:
        if isinstance(data, str):
            return not data.endswith((" ", "\n", "\t"))
        return True
    
    def fix(self, data: str) -> str:
        if isinstance(data, str):
            return data.rstrip()
        return data


class IsNonEmpty(SeparateConstraint):
    """Data must not be empty"""
    
    def validate(self, data: Any) -> bool:
        if isinstance(data, (str, list, dict)):
            return len(data) > 0
        return data is not None
    
    def fix(self, data: Any) -> Any:
        return data  # Can't fix empty data


class MaxLength(SeparateConstraint):
    """Enforce maximum length"""
    
    def __init__(self, name: str = "MaxLength", max_len: int = 1000):
        super().__init__(name)
        self.max_len = max_len
    
    def validate(self, data: str) -> bool:
        return len(data) <= self.max_len
    
    def fix(self, data: str) -> str:
        return data[:self.max_len]


class ContainsKeyword(SeparateConstraint):
    """Must contain specific keyword"""
    
    def __init__(self, name: str = "ContainsKeyword", keyword: str = ""):
        super().__init__(name)
        self.keyword = keyword
    
    def validate(self, data: str) -> bool:
        return self.keyword.lower() in data.lower()
    
    def fix(self, data: str) -> str:
        # Can't fix missing keyword
        return data


class NoCharacters(SeparateConstraint):
    """Ban specific characters"""
    
    def __init__(self, name: str = "NoCharacters", banned_chars: str = ""):
        super().__init__(name)
        self.banned_chars = banned_chars
    
    def validate(self, data: str) -> bool:
        return not any(char in data for char in self.banned_chars)
    
    def fix(self, data: str) -> str:
        for char in self.banned_chars:
            data = data.replace(char, "")
        return data


# ============================================================================
# COLLECTIVE CONSTRAINTS (Global, Complex, Whole-Output)
# ============================================================================

class CollectiveConstraint(Constraint):
    """Validates entire output or relationships between pieces"""
    pass


class NoContradictions(CollectiveConstraint):
    """Output must not contradict itself"""
    
    def validate(self, data: Union[str, dict]) -> bool:
        if isinstance(data, dict):
            data = json.dumps(data)
        
        # Simple contradiction detection
        contradictions = [
            ("no fever", "high fever"),
            ("not", "must"),
            ("false", "true"),
        ]
        
        data_lower = data.lower()
        for neg, pos in contradictions:
            if neg in data_lower and pos in data_lower:
                return False
        
        return True
    
    def fix(self, data: Any) -> Any:
        # Can't auto-fix contradictions
        return data


class JSONFieldsPopulated(CollectiveConstraint):
    """All required JSON fields must have content"""
    
    def __init__(self, name: str = "JSONFieldsPopulated", required_fields: List[str] = None):
        super().__init__(name)
        self.required_fields = required_fields or []
    
    def validate(self, data: Union[str, dict]) -> bool:
        try:
            if isinstance(data, str):
                parsed = json.loads(data)
            else:
                parsed = data
            
            for field in self.required_fields:
                if field not in parsed or not parsed[field]:
                    return False
            
            return True
        except:
            return False
    
    def fix(self, data: Any) -> Any:
        return data


class ResponseLength(CollectiveConstraint):
    """Response must meet minimum length requirements"""
    
    def __init__(self, name: str = "ResponseLength", min_length: int = 50):
        super().__init__(name)
        self.min_length = min_length
    
    def validate(self, data: str) -> bool:
        if isinstance(data, dict):
            data = json.dumps(data)
        return len(data) >= self.min_length
    
    def fix(self, data: str) -> str:
        # Can't fix too-short response
        return data


class LogicalFlow(CollectiveConstraint):
    """Output must follow logical progression"""
    
    def __init__(self, name: str = "LogicalFlow", required_order: List[str] = None):
        super().__init__(name)
        self.required_order = required_order or []
    
    def validate(self, data: str) -> bool:
        if isinstance(data, dict):
            data = json.dumps(data)
        
        data_lower = data.lower()
        last_pos = -1
        
        for keyword in self.required_order:
            pos = data_lower.find(keyword.lower())
            if pos == -1:
                return False
            if pos <= last_pos:
                return False  # Wrong order
            last_pos = pos
        
        return True
    
    def fix(self, data: Any) -> Any:
        return data


# ============================================================================
# CONSTRAINT ENGINE (Orchestrates everything)
# ============================================================================

class ConstraintEngine:
    """Main engine that applies constraints"""
    
    def __init__(self, name: str = "ConstraintEngine"):
        self.name = name
        self.separate_constraints: List[SeparateConstraint] = []
        self.collective_constraints: List[CollectiveConstraint] = []
        self.execution_log: List[Dict] = []
    
    def add_separate(self, constraint: SeparateConstraint):
        """Add a separate (fast, local) constraint"""
        self.separate_constraints.append(constraint)
    
    def add_collective(self, constraint: CollectiveConstraint):
        """Add a collective (slow, global) constraint"""
        self.collective_constraints.append(constraint)
    
    def validate_separate(self, data: Any) -> Dict:
        """Run all separate constraints"""
        results = []
        
        for constraint in self.separate_constraints:
            start = time.time()
            passed = constraint.validate(data)
            duration = (time.time() - start) * 1000
            
            results.append({
                "constraint": constraint.name,
                "passed": passed,
                "duration_ms": duration
            })
            
            if not passed:
                return {
                    "success": False,
                    "failed_at": constraint.name,
                    "results": results
                }
        
        return {"success": True, "results": results}
    
    def validate_collective(self, data: Any) -> Dict:
        """Run all collective constraints"""
        results = []
        
        for constraint in self.collective_constraints:
            start = time.time()
            passed = constraint.validate(data)
            duration = (time.time() - start) * 1000
            
            results.append({
                "constraint": constraint.name,
                "passed": passed,
                "duration_ms": duration
            })
            
            if not passed:
                return {
                    "success": False,
                    "failed_at": constraint.name,
                    "results": results
                }
        
        return {"success": True, "results": results}
    
    def validate(self, data: Any, auto_fix: bool = False) -> Dict:
        """Run all constraints (separate then collective)"""
        current = data
        log = []
        
        # Phase 1: Separate constraints (fast)
        print(f"[{self.name}] Phase 1: Running {len(self.separate_constraints)} separate constraints...")
        for constraint in self.separate_constraints:
            start = time.time()
            passed = constraint.validate(current)
            duration = (time.time() - start) * 1000
            
            log.append({
                "phase": "separate",
                "constraint": constraint.name,
                "passed": passed,
                "duration_ms": duration
            })
            
            if not passed:
                if auto_fix:
                    print(f"  ✗ {constraint.name} FAILED, attempting fix...")
                    current = constraint.fix(current)
                    log[-1]["fixed"] = True
                else:
                    print(f"  ✗ {constraint.name} FAILED")
                    return {
                        "success": False,
                        "failed_at": constraint.name,
                        "phase": "separate",
                        "log": log
                    }
            else:
                print(f"  ✓ {constraint.name} passed")
        
        # Phase 2: Collective constraints (slow, only if phase 1 passed)
        if len(self.collective_constraints) > 0:
            print(f"\n[{self.name}] Phase 2: Running {len(self.collective_constraints)} collective constraints...")
            for constraint in self.collective_constraints:
                start = time.time()
                passed = constraint.validate(current)
                duration = (time.time() - start) * 1000
                
                log.append({
                    "phase": "collective",
                    "constraint": constraint.name,
                    "passed": passed,
                    "duration_ms": duration
                })
                
                if not passed:
                    if auto_fix:
                        print(f"  ✗ {constraint.name} FAILED, attempting fix...")
                        current = constraint.fix(current)
                        log[-1]["fixed"] = True
                    else:
                        print(f"  ✗ {constraint.name} FAILED")
                        return {
                            "success": False,
                            "failed_at": constraint.name,
                            "phase": "collective",
                            "log": log
                        }
                else:
                    print(f"  ✓ {constraint.name} passed")
        
        self.execution_log = log
        
        print(f"\n✓ All constraints passed!")
        return {
            "success": True,
            "data": current,
            "log": log
        }
    
    def describe(self) -> Dict:
        """Show what constraints are loaded"""
        return {
            "separate": [c.name for c in self.separate_constraints],
            "collective": [c.name for c in self.collective_constraints]
        }
