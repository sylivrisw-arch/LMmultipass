"""
LMSuite — LM Studio Multi-Model Orchestrator
Single-file build with the Constraint Engine merged in directly
(no more cross-file imports between LMSuite and constraint_engine.py)
"""

import tkinter as tk
from tkinter import ttk, messagebox, filedialog
import requests
import os
import threading
import datetime
import sys
import subprocess
import psutil
import time
import re
import json
import difflib
from abc import ABC, abstractmethod
from typing import Any, List, Dict, Union


# ============================================================================
# CONSTRAINT ENGINE — SEPARATE CONSTRAINTS (Local, Fast, Per-Item)
# ============================================================================

class Constraint(ABC):
    """Base constraint - all constraints inherit from this"""

    def __init__(self, name: str):
        self.name = name
        self.passed = False
        self.execution_time = 0

    @abstractmethod
    def validate(self, data: Any) -> bool:
        """Does data pass this constraint?"""
        pass

    @abstractmethod
    def fix(self, data: Any) -> Any:
        """Fix data if it fails"""
        pass

    def describe(self):
        """Human-readable description"""
        return f"{self.name}"


class SeparateConstraint(Constraint):
    """Validates individual pieces in isolation"""
    pass


class NoDoubleSpaces(SeparateConstraint):
    """Remove multiple spaces"""

    def validate(self, data: str) -> bool:
        return "  " not in data

    def fix(self, data: str) -> str:
        return re.sub(r"  +", " ", data)


class CapitalizeFirst(SeparateConstraint):
    """First letter must be capitalized"""

    def validate(self, data: str) -> bool:
        if not data:
            return True
        return data[0].isupper()

    def fix(self, data: str) -> str:
        if not data:
            return data
        return data[0].upper() + data[1:]


class ValidJSON(SeparateConstraint):
    """Must be valid JSON"""

    def __init__(self, name: str = "ValidJSON", required_fields: List[str] = None):
        super().__init__(name)
        self.required_fields = required_fields or []

    def validate(self, data: Union[str, dict]) -> bool:
        try:
            if isinstance(data, str):
                parsed = json.loads(data)
            else:
                parsed = data

            if isinstance(parsed, dict):
                for field in self.required_fields:
                    if field not in parsed:
                        return False

            return True
        except Exception:
            return False

    def fix(self, data: str) -> str:
        return data


class NoTrailingWhitespace(SeparateConstraint):
    """Remove trailing spaces"""

    def validate(self, data: str) -> bool:
        if isinstance(data, str):
            return not data.endswith((" ", "\n", "\t"))
        return True

    def fix(self, data: str) -> str:
        if isinstance(data, str):
            return data.rstrip()
        return data


class IsNonEmpty(SeparateConstraint):
    """Data must not be empty"""

    def validate(self, data: Any) -> bool:
        if isinstance(data, (str, list, dict)):
            return len(data) > 0
        return data is not None

    def fix(self, data: Any) -> Any:
        return data


class MaxLength(SeparateConstraint):
    """Enforce maximum length"""

    def __init__(self, name: str = "MaxLength", max_len: int = 1000):
        super().__init__(name)
        self.max_len = max_len

    def validate(self, data: str) -> bool:
        return len(data) <= self.max_len

    def fix(self, data: str) -> str:
        return data[:self.max_len]


class ContainsKeyword(SeparateConstraint):
    """Must contain specific keyword"""

    def __init__(self, name: str = "ContainsKeyword", keyword: str = ""):
        super().__init__(name)
        self.keyword = keyword

    def validate(self, data: str) -> bool:
        return self.keyword.lower() in data.lower()

    def fix(self, data: str) -> str:
        return data


class NoCharacters(SeparateConstraint):
    """Ban specific characters"""

    def __init__(self, name: str = "NoCharacters", banned_chars: str = ""):
        super().__init__(name)
        self.banned_chars = banned_chars

    def validate(self, data: str) -> bool:
        return not any(char in data for char in self.banned_chars)

    def fix(self, data: str) -> str:
        for char in self.banned_chars:
            data = data.replace(char, "")
        return data


class NoMarkdown(SeparateConstraint):
    """Strip markdown formatting"""

    def validate(self, data: str) -> bool:
        markdown_chars = ['#', '*', '_', '`', '[', ']', '!', '~']
        return not any(char in data for char in markdown_chars)

    def fix(self, data: str) -> str:
        markdown_chars = ['#', '*', '_', '`', '[', ']', '!', '~']
        for char in markdown_chars:
            data = data.replace(char, "")
        return data


class IsEnglish(SeparateConstraint):
    """Ensure content is primarily English"""

    def __init__(self, name: str = "IsEnglish", min_english_ratio: float = 0.85):
        super().__init__(name)
        self.min_english_ratio = min_english_ratio

    def validate(self, data: str) -> bool:
        if not data:
            return True

        english_chars = sum(1 for c in data if ord(c) < 128 and (c.isalpha() or c.isdigit() or c in " .,!?;:-'\"()"))
        ratio = english_chars / len(data)
        return ratio >= self.min_english_ratio

    def fix(self, data: str) -> str:
        return "".join(c for c in data if ord(c) < 128)


# ============================================================================
# CONSTRAINT ENGINE — COLLECTIVE CONSTRAINTS (Global, Complex, Whole-Output)
# ============================================================================

class CollectiveConstraint(Constraint):
    """Validates entire output or relationships between pieces"""
    pass


class NoContradictions(CollectiveConstraint):
    """Output must not contradict itself"""

    def validate(self, data: Union[str, dict]) -> bool:
        if isinstance(data, dict):
            data = json.dumps(data)

        contradictions = [
            ("no fever", "high fever"),
            ("not", "must"),
            ("false", "true"),
        ]

        data_lower = data.lower()
        for neg, pos in contradictions:
            if neg in data_lower and pos in data_lower:
                return False

        return True

    def fix(self, data: Any) -> Any:
        return data


class JSONFieldsPopulated(CollectiveConstraint):
    """All required JSON fields must have content"""

    def __init__(self, name: str = "JSONFieldsPopulated", required_fields: List[str] = None):
        super().__init__(name)
        self.required_fields = required_fields or []

    def validate(self, data: Union[str, dict]) -> bool:
        try:
            if isinstance(data, str):
                parsed = json.loads(data)
            else:
                parsed = data

            for field in self.required_fields:
                if field not in parsed or not parsed[field]:
                    return False

            return True
        except Exception:
            return False

    def fix(self, data: Any) -> Any:
        return data


class LogicalFlow(CollectiveConstraint):
    """Output must follow logical progression"""

    def __init__(self, name: str = "LogicalFlow", required_order: List[str] = None):
        super().__init__(name)
        self.required_order = required_order or []

    def validate(self, data: str) -> bool:
        if isinstance(data, dict):
            data = json.dumps(data)

        data_lower = data.lower()
        last_pos = -1

        for keyword in self.required_order:
            pos = data_lower.find(keyword.lower())
            if pos == -1:
                return False
            if pos <= last_pos:
                return False
            last_pos = pos

        return True

    def fix(self, data: Any) -> Any:
        return data


class NoRepetition(CollectiveConstraint):
    """Detect and penalize repetitive n-grams"""

    def __init__(self, name: str = "NoRepetition", ngram_size: int = 3):
        super().__init__(name)
        self.ngram_size = ngram_size

    def validate(self, data: str) -> bool:
        if isinstance(data, dict):
            data = json.dumps(data)

        words = data.lower().split()
        if len(words) < self.ngram_size * 2:
            return True

        ngrams = []
        for i in range(len(words) - self.ngram_size + 1):
            ngram = tuple(words[i:i + self.ngram_size])
            ngrams.append(ngram)

        return len(ngrams) == len(set(ngrams))

    def fix(self, data: str) -> str:
        return data


class FactualGrounding(CollectiveConstraint):
    """Encourage factual statements"""

    def __init__(self, name: str = "FactualGrounding", disallow_words: List[str] = None):
        super().__init__(name)
        self.disallow_words = disallow_words or []

    def validate(self, data: str) -> bool:
        if isinstance(data, dict):
            data = json.dumps(data)

        data_lower = data.lower()
        for word in self.disallow_words:
            if word.lower() in data_lower:
                return False
        return True

    def fix(self, data: str) -> str:
        result = data
        for word in self.disallow_words:
            result = re.sub(r'\b' + re.escape(word) + r'\b', '', result, flags=re.IGNORECASE)
        return result


class StyleConsistency(CollectiveConstraint):
    """Enforce style consistency across output"""

    def __init__(self, name: str = "StyleConsistency", enforce_style: str = "formal"):
        super().__init__(name)
        self.enforce_style = enforce_style

    def validate(self, data: str) -> bool:
        if isinstance(data, dict):
            data = json.dumps(data)

        if self.enforce_style == "formal":
            contractions = ["can't", "won't", "don't", "isn't", "aren't", "wasn't", "weren't"]
            for contraction in contractions:
                if contraction.lower() in data.lower():
                    return False

        return True

    def fix(self, data: str) -> str:
        if self.enforce_style == "formal":
            replacements = {
                "can't": "cannot", "won't": "will not", "don't": "do not",
                "doesn't": "does not", "didn't": "did not", "isn't": "is not",
                "aren't": "are not", "wasn't": "was not", "weren't": "were not",
                "haven't": "have not", "hasn't": "has not", "hadn't": "had not",
            }
            result = data
            for contraction, expansion in replacements.items():
                result = re.sub(r'\b' + re.escape(contraction) + r'\b', expansion, result, flags=re.IGNORECASE)
            return result
        return data


# ============================================================================
# CONSTRAINT ENGINE — ORCHESTRATOR
# ============================================================================

class ConstraintEngine:
    """Main engine that applies constraints"""

    def __init__(self, name: str = "ConstraintEngine"):
        self.name = name
        self.separate_constraints: List[SeparateConstraint] = []
        self.collective_constraints: List[CollectiveConstraint] = []
        self.execution_log: List[Dict] = []

    def add_separate(self, constraint: SeparateConstraint):
        self.separate_constraints.append(constraint)

    def add_collective(self, constraint: CollectiveConstraint):
        self.collective_constraints.append(constraint)

    def validate_separate(self, data: Any) -> Dict:
        results = []
        for constraint in self.separate_constraints:
            start = time.time()
            passed = constraint.validate(data)
            duration = (time.time() - start) * 1000
            results.append({"constraint": constraint.name, "passed": passed, "duration_ms": duration})
            if not passed:
                return {"success": False, "failed_at": constraint.name, "results": results}
        return {"success": True, "results": results}

    def validate_collective(self, data: Any) -> Dict:
        results = []
        for constraint in self.collective_constraints:
            start = time.time()
            passed = constraint.validate(data)
            duration = (time.time() - start) * 1000
            results.append({"constraint": constraint.name, "passed": passed, "duration_ms": duration})
            if not passed:
                return {"success": False, "failed_at": constraint.name, "results": results}
        return {"success": True, "results": results}

    def validate(self, data: Any, auto_fix: bool = False) -> Dict:
        """Run all constraints (separate then collective)"""
        current = data
        log = []

        for constraint in self.separate_constraints:
            start = time.time()
            passed = constraint.validate(current)
            duration = (time.time() - start) * 1000
            log.append({"phase": "separate", "constraint": constraint.name, "passed": passed, "duration_ms": duration})

            if not passed:
                if auto_fix:
                    current = constraint.fix(current)
                    fixed_passed = constraint.validate(current)
                    if fixed_passed:
                        log[-1]["fixed"] = True
                    else:
                        return {"success": False, "failed_at": constraint.name, "phase": "separate", "log": log}
                else:
                    return {"success": False, "failed_at": constraint.name, "phase": "separate", "log": log}

        if len(self.collective_constraints) > 0:
            for constraint in self.collective_constraints:
                start = time.time()
                passed = constraint.validate(current)
                duration = (time.time() - start) * 1000
                log.append({"phase": "collective", "constraint": constraint.name, "passed": passed, "duration_ms": duration})

                if not passed:
                    if auto_fix:
                        current = constraint.fix(current)
                        fixed_passed = constraint.validate(current)
                        if fixed_passed:
                            log[-1]["fixed"] = True
                        else:
                            return {"success": False, "failed_at": constraint.name, "phase": "collective", "log": log}
                    else:
                        return {"success": False, "failed_at": constraint.name, "phase": "collective", "log": log}

        self.execution_log = log
        return {"success": True, "data": current, "log": log}

    def describe(self) -> Dict:
        return {
            "separate": [c.name for c in self.separate_constraints],
            "collective": [c.name for c in self.collective_constraints]
        }


# ============================================================================
# CONSTRAINT REGISTRY - Maps type names to classes and their editable params
# ============================================================================

CONSTRAINT_REGISTRY = {
    "NoDoubleSpaces": {
        "class": NoDoubleSpaces, "category": "separate",
        "description": "Collapse multiple spaces into one", "auto_fix": True, "params": {}
    },
    "CapitalizeFirst": {
        "class": CapitalizeFirst, "category": "separate",
        "description": "First character must be uppercase", "auto_fix": True, "params": {}
    },
    "NoTrailingWhitespace": {
        "class": NoTrailingWhitespace, "category": "separate",
        "description": "Strip trailing spaces, newlines, tabs", "auto_fix": True, "params": {}
    },
    "IsNonEmpty": {
        "class": IsNonEmpty, "category": "separate",
        "description": "Reject empty or None data", "auto_fix": False, "params": {}
    },
    "MaxLength": {
        "class": MaxLength, "category": "separate",
        "description": "Enforce maximum character length", "auto_fix": True,
        "params": {"max_len": {"type": "int", "default": 10000, "label": "Max Characters", "min": 1, "max": 100000}}
    },
    "ContainsKeyword": {
        "class": ContainsKeyword, "category": "separate",
        "description": "Output must contain a specific keyword", "auto_fix": False,
        "params": {"keyword": {"type": "str", "default": "", "label": "Required Keyword"}}
    },
    "NoCharacters": {
        "class": NoCharacters, "category": "separate",
        "description": "Ban specific characters from output", "auto_fix": True,
        "params": {"banned_chars": {"type": "str", "default": "", "label": "Banned Characters"}}
    },
    "ValidJSON": {
        "class": ValidJSON, "category": "separate",
        "description": "Must be valid JSON (optional required fields)", "auto_fix": False,
        "params": {"required_fields": {"type": "list", "default": [], "label": "Required Fields (comma-separated)"}}
    },
    "NoMarkdown": {
        "class": NoMarkdown, "category": "separate",
        "description": "Strip markdown formatting characters", "auto_fix": True, "params": {}
    },
    "IsEnglish": {
        "class": IsEnglish, "category": "separate",
        "description": "Ensure content is primarily English", "auto_fix": True,
        "params": {"min_english_ratio": {"type": "float", "default": 0.85, "label": "Min English Ratio (0.0-1.0)"}}
    },
    "NoContradictions": {
        "class": NoContradictions, "category": "collective",
        "description": "Detect contradictory statements", "auto_fix": False, "params": {}
    },
    "JSONFieldsPopulated": {
        "class": JSONFieldsPopulated, "category": "collective",
        "description": "All required JSON fields must have content", "auto_fix": False,
        "params": {"required_fields": {"type": "list", "default": [], "label": "Required Fields (comma-separated)"}}
    },
    "LogicalFlow": {
        "class": LogicalFlow, "category": "collective",
        "description": "Keywords must appear in a specific order", "auto_fix": False,
        "params": {"required_order": {"type": "list", "default": [], "label": "Keywords in Order (comma-separated)"}}
    },
    "NoRepetition": {
        "class": NoRepetition, "category": "collective",
        "description": "Detect and penalize repetitive n-grams", "auto_fix": False,
        "params": {"ngram_size": {"type": "int", "default": 3, "label": "N-gram Size", "min": 2, "max": 10}}
    },
    "FactualGrounding": {
        "class": FactualGrounding, "category": "collective",
        "description": "Encourage factual statements", "auto_fix": True,
        "params": {"disallow_words": {"type": "list", "default": [], "label": "Disallow Words (comma-separated)"}}
    },
    "StyleConsistency": {
        "class": StyleConsistency, "category": "collective",
        "description": "Enforce style consistency across output", "auto_fix": True,
        "params": {"enforce_style": {"type": "str", "default": "formal", "label": "Style (formal/casual)"}}
    },
}


# ============================================================================
# SERIALIZATION - Save/load constraint configs to JSON
# ============================================================================

def engine_to_config(engine: ConstraintEngine) -> dict:
    """Serialize a ConstraintEngine to a saveable dict"""
    config = {"name": engine.name, "separate": [], "collective": []}

    for c in engine.separate_constraints:
        entry = {"type": type(c).__name__, "name": c.name}
        reg = CONSTRAINT_REGISTRY.get(type(c).__name__, {})
        for param_name in reg.get("params", {}):
            entry[param_name] = getattr(c, param_name, reg["params"][param_name]["default"])
        config["separate"].append(entry)

    for c in engine.collective_constraints:
        entry = {"type": type(c).__name__, "name": c.name}
        reg = CONSTRAINT_REGISTRY.get(type(c).__name__, {})
        for param_name in reg.get("params", {}):
            entry[param_name] = getattr(c, param_name, reg["params"][param_name]["default"])
        config["collective"].append(entry)

    return config


def config_to_engine(config: dict) -> ConstraintEngine:
    """Rebuild a ConstraintEngine from a saved config dict"""
    engine = ConstraintEngine(name=config.get("name", "ConstraintEngine"))

    for entry in config.get("separate", []):
        ctype = entry.get("type")
        if ctype in CONSTRAINT_REGISTRY:
            reg = CONSTRAINT_REGISTRY[ctype]
            kwargs = {"name": entry.get("name", ctype)}
            for param_name, param_info in reg["params"].items():
                kwargs[param_name] = entry.get(param_name, param_info["default"])
            engine.add_separate(reg["class"](**kwargs))

    for entry in config.get("collective", []):
        ctype = entry.get("type")
        if ctype in CONSTRAINT_REGISTRY:
            reg = CONSTRAINT_REGISTRY[ctype]
            kwargs = {"name": entry.get("name", ctype)}
            for param_name, param_info in reg["params"].items():
                kwargs[param_name] = entry.get(param_name, param_info["default"])
            engine.add_collective(reg["class"](**kwargs))

    return engine


# ============================================================================
# CONSTRAINT ENGINE — VISUAL EDITOR (ConstraintEngineGUI)
# ============================================================================

CE_COLORS = {
    'bg': '#1e1e2e',
    'bg_card': '#2a2a3d',
    'bg_input': '#363650',
    'bg_selected': '#3d3d5c',
    'text': '#e0e0e0',
    'text_muted': '#8888aa',
    'text_heading': '#ffffff',
    'accent': '#6c8cff',
    'accent_hover': '#8aa4ff',
    'green': '#4ec98b',
    'red': '#e05555',
    'orange': '#e0a040',
    'yellow': '#e0d060',
    'border': '#3a3a55',
    'separate_tag': '#4ec98b',
    'collective_tag': '#6c8cff',
}

CE_FONTS = {
    'heading': ('Arial', 13, 'bold'),
    'subheading': ('Arial', 11, 'bold'),
    'normal': ('Arial', 10),
    'small': ('Arial', 9),
    'mono': ('Courier', 10),
    'mono_small': ('Courier', 9),
}


class ConstraintEngineGUI:
    """Visual editor for ConstraintEngine configurations"""
    
    def __init__(self, root, engine: ConstraintEngine = None, on_apply=None):
        """
        root: tk.Tk or tk.Toplevel
        engine: existing ConstraintEngine to edit (or None for fresh)
        on_apply: callback(engine) called when user clicks Apply
        """
        self.root = root
        self.root.title("Constraint Engine Editor")
        self.root.geometry("820x700")
        self.root.configure(bg=CE_COLORS['bg'])
        self.root.resizable(True, True)
        self.root.minsize(700, 500)
        
        self.on_apply = on_apply
        self.config_path = os.path.join(os.path.expanduser("~"), "Downloads", "constraint_engine_config.json")
        self.unsaved_changes = False
        
        # Build working config from engine or defaults
        if engine:
            self.working_config = engine_to_config(engine)
        else:
            self.working_config = self._default_config()
        
        self._build_ui()
        self._refresh_list()
        self.root.protocol("WM_DELETE_WINDOW", self._on_close)
    
    def _default_config(self):
        return {
            "name": "StoryValidator",
            "separate": [
                {"type": "IsNonEmpty", "name": "IsNonEmpty"},
                {"type": "NoDoubleSpaces", "name": "NoDoubleSpaces"},
                {"type": "NoTrailingWhitespace", "name": "NoTrailingWhitespace"},
                {"type": "CapitalizeFirst", "name": "CapitalizeFirst"},
                {"type": "MaxLength", "name": "MaxLength", "max_len": 10000},
            ],
            "collective": [
                {"type": "NoContradictions", "name": "NoContradictions"},
            ]
        }
    
    # ====================================================================
    # UI BUILD
    # ====================================================================
    
    def _build_ui(self):
        # Title bar
        title_frame = tk.Frame(self.root, bg=CE_COLORS['bg'])
        title_frame.pack(fill=tk.X, padx=15, pady=(12, 0))
        
        tk.Label(title_frame, text="Constraint Engine Editor", font=CE_FONTS['heading'],
                 bg=CE_COLORS['bg'], fg=CE_COLORS['text_heading']).pack(side=tk.LEFT)
        
        self.status_label = tk.Label(title_frame, text="", font=CE_FONTS['small'],
                                      bg=CE_COLORS['bg'], fg=CE_COLORS['text_muted'])
        self.status_label.pack(side=tk.RIGHT)
        self._update_status()
        
        # Engine name row
        name_frame = tk.Frame(self.root, bg=CE_COLORS['bg'])
        name_frame.pack(fill=tk.X, padx=15, pady=(8, 0))
        
        tk.Label(name_frame, text="Engine Name:", font=CE_FONTS['normal'],
                 bg=CE_COLORS['bg'], fg=CE_COLORS['text_muted']).pack(side=tk.LEFT, padx=(0, 8))
        self.name_var = tk.StringVar(value=self.working_config.get("name", "ConstraintEngine"))
        name_entry = tk.Entry(name_frame, textvariable=self.name_var, font=CE_FONTS['mono'],
                              bg=CE_COLORS['bg_input'], fg=CE_COLORS['text'], insertbackground=CE_COLORS['text'],
                              relief=tk.FLAT, bd=0, width=30)
        name_entry.pack(side=tk.LEFT, padx=(0, 15), ipady=4, ipadx=6)
        self.name_var.trace_add("write", lambda *_: self._mark_changed())
        
        # Main split: left = constraint list, right = editor
        body = tk.Frame(self.root, bg=CE_COLORS['bg'])
        body.pack(fill=tk.BOTH, expand=True, padx=15, pady=(10, 0))
        body.columnconfigure(0, weight=1)
        body.columnconfigure(1, weight=1)
        body.rowconfigure(0, weight=1)
        
        # ── LEFT: Constraint List ──
        left = tk.Frame(body, bg=CE_COLORS['bg_card'], highlightthickness=1,
                        highlightbackground=CE_COLORS['border'])
        left.grid(row=0, column=0, sticky="nsew", padx=(0, 6))
        left.rowconfigure(1, weight=1)
        left.columnconfigure(0, weight=1)
        
        # List header
        lh = tk.Frame(left, bg=CE_COLORS['bg_card'])
        lh.grid(row=0, column=0, sticky="ew", padx=10, pady=(10, 5))
        tk.Label(lh, text="Active Constraints", font=CE_FONTS['subheading'],
                 bg=CE_COLORS['bg_card'], fg=CE_COLORS['text_heading']).pack(side=tk.LEFT)
        
        # Constraint listbox
        list_frame = tk.Frame(left, bg=CE_COLORS['bg_card'])
        list_frame.grid(row=1, column=0, sticky="nsew", padx=10, pady=(0, 5))
        list_frame.rowconfigure(0, weight=1)
        list_frame.columnconfigure(0, weight=1)
        
        self.constraint_listbox = tk.Listbox(
            list_frame, font=CE_FONTS['mono'], bg=CE_COLORS['bg_input'], fg=CE_COLORS['text'],
            selectbackground=CE_COLORS['accent'], selectforeground=CE_COLORS['text_heading'],
            relief=tk.FLAT, bd=0, highlightthickness=0, activestyle='none'
        )
        self.constraint_listbox.grid(row=0, column=0, sticky="nsew")
        self.constraint_listbox.bind("<<ListboxSelect>>", self._on_select)
        
        scrollbar = ttk.Scrollbar(list_frame, orient=tk.VERTICAL, command=self.constraint_listbox.yview)
        scrollbar.grid(row=0, column=1, sticky="ns")
        self.constraint_listbox.config(yscrollcommand=scrollbar.set)
        
        # List buttons
        lb = tk.Frame(left, bg=CE_COLORS['bg_card'])
        lb.grid(row=2, column=0, sticky="ew", padx=10, pady=(0, 10))
        
        btn_style = {"font": CE_FONTS['small'], "relief": tk.FLAT, "bd": 0, "padx": 10, "pady": 4, "cursor": "hand2"}
        
        tk.Button(lb, text="▲ Up", bg=CE_COLORS['bg_input'], fg=CE_COLORS['text'],
                  command=self._move_up, **btn_style).pack(side=tk.LEFT, padx=(0, 3))
        tk.Button(lb, text="▼ Down", bg=CE_COLORS['bg_input'], fg=CE_COLORS['text'],
                  command=self._move_down, **btn_style).pack(side=tk.LEFT, padx=(0, 3))
        tk.Button(lb, text="✕ Remove", bg=CE_COLORS['red'], fg=CE_COLORS['text_heading'],
                  command=self._remove_selected, **btn_style).pack(side=tk.RIGHT)
        
        # ── RIGHT: Editor Panel ──
        right = tk.Frame(body, bg=CE_COLORS['bg_card'], highlightthickness=1,
                         highlightbackground=CE_COLORS['border'])
        right.grid(row=0, column=1, sticky="nsew", padx=(6, 0))
        right.rowconfigure(1, weight=1)
        right.columnconfigure(0, weight=1)
        
        # Editor header
        rh = tk.Frame(right, bg=CE_COLORS['bg_card'])
        rh.grid(row=0, column=0, sticky="ew", padx=10, pady=(10, 5))
        tk.Label(rh, text="Edit Constraint", font=CE_FONTS['subheading'],
                 bg=CE_COLORS['bg_card'], fg=CE_COLORS['text_heading']).pack(side=tk.LEFT)
        
        # Editor content (dynamic)
        self.editor_frame = tk.Frame(right, bg=CE_COLORS['bg_card'])
        self.editor_frame.grid(row=1, column=0, sticky="nsew", padx=10, pady=(0, 10))
        
        self._show_no_selection()
        
        # ── ADD CONSTRAINT SECTION ──
        add_frame = tk.Frame(self.root, bg=CE_COLORS['bg_card'], highlightthickness=1,
                             highlightbackground=CE_COLORS['border'])
        add_frame.pack(fill=tk.X, padx=15, pady=(10, 0))
        
        add_inner = tk.Frame(add_frame, bg=CE_COLORS['bg_card'])
        add_inner.pack(fill=tk.X, padx=10, pady=10)
        
        tk.Label(add_inner, text="Add Constraint:", font=CE_FONTS['subheading'],
                 bg=CE_COLORS['bg_card'], fg=CE_COLORS['text_heading']).pack(side=tk.LEFT, padx=(0, 10))
        
        # Type dropdown
        self.add_type_var = tk.StringVar(value="NoDoubleSpaces")
        type_names = sorted(CONSTRAINT_REGISTRY.keys())
        self.add_dropdown = ttk.Combobox(add_inner, textvariable=self.add_type_var,
                                          values=type_names, state="readonly", width=22)
        self.add_dropdown.pack(side=tk.LEFT, padx=(0, 8))
        self.add_dropdown.bind("<<ComboboxSelected>>", self._update_add_preview)
        
        # Preview label
        self.add_preview = tk.Label(add_inner, text="", font=CE_FONTS['small'],
                                     bg=CE_COLORS['bg_card'], fg=CE_COLORS['text_muted'])
        self.add_preview.pack(side=tk.LEFT, padx=(0, 10), fill=tk.X, expand=True)
        self._update_add_preview()
        
        tk.Button(add_inner, text="+ Add", font=CE_FONTS['normal'], bg=CE_COLORS['green'],
                  fg=CE_COLORS['bg'], relief=tk.FLAT, bd=0, padx=14, pady=4,
                  cursor="hand2", command=self._add_constraint).pack(side=tk.RIGHT)
        
        # ── TEST SECTION ──
        test_frame = tk.Frame(self.root, bg=CE_COLORS['bg_card'], highlightthickness=1,
                              highlightbackground=CE_COLORS['border'])
        test_frame.pack(fill=tk.X, padx=15, pady=(10, 0))
        
        test_header = tk.Frame(test_frame, bg=CE_COLORS['bg_card'])
        test_header.pack(fill=tk.X, padx=10, pady=(10, 5))
        tk.Label(test_header, text="Test Engine", font=CE_FONTS['subheading'],
                 bg=CE_COLORS['bg_card'], fg=CE_COLORS['text_heading']).pack(side=tk.LEFT)
        
        tk.Button(test_header, text="▶ Run Test", font=CE_FONTS['small'], bg=CE_COLORS['accent'],
                  fg=CE_COLORS['text_heading'], relief=tk.FLAT, bd=0, padx=12, pady=3,
                  cursor="hand2", command=self._run_test).pack(side=tk.RIGHT)
        
        self.test_auto_fix_var = tk.BooleanVar(value=True)
        tk.Checkbutton(test_header, text="Auto-fix", variable=self.test_auto_fix_var,
                        font=CE_FONTS['small'], bg=CE_COLORS['bg_card'], fg=CE_COLORS['text'],
                        selectcolor=CE_COLORS['bg_input'], activebackground=CE_COLORS['bg_card'],
                        activeforeground=CE_COLORS['text']).pack(side=tk.RIGHT, padx=(0, 10))
        
        test_body = tk.Frame(test_frame, bg=CE_COLORS['bg_card'])
        test_body.pack(fill=tk.X, padx=10, pady=(0, 10))
        test_body.columnconfigure(0, weight=1)
        test_body.columnconfigure(1, weight=1)
        
        self.test_input = tk.Text(test_body, height=3, font=CE_FONTS['mono_small'],
                                   bg=CE_COLORS['bg_input'], fg=CE_COLORS['text'],
                                   insertbackground=CE_COLORS['text'], relief=tk.FLAT, bd=0, wrap=tk.WORD)
        self.test_input.grid(row=0, column=0, sticky="nsew", padx=(0, 4), ipady=4, ipadx=4)
        self.test_input.insert("1.0", "  hello world.  This is a  test with  double spaces.  ")
        
        self.test_output = tk.Text(test_body, height=3, font=CE_FONTS['mono_small'],
                                    bg=CE_COLORS['bg_input'], fg=CE_COLORS['green'],
                                    relief=tk.FLAT, bd=0, wrap=tk.WORD, state=tk.DISABLED)
        self.test_output.grid(row=0, column=1, sticky="nsew", padx=(4, 0), ipady=4, ipadx=4)
        
        # ── BOTTOM BUTTONS ──
        bottom = tk.Frame(self.root, bg=CE_COLORS['bg'])
        bottom.pack(fill=tk.X, padx=15, pady=(12, 15))
        
        tk.Button(bottom, text="💾 Save Config", font=CE_FONTS['normal'], bg=CE_COLORS['bg_input'],
                  fg=CE_COLORS['text'], relief=tk.FLAT, bd=0, padx=14, pady=6,
                  cursor="hand2", command=self._save_config).pack(side=tk.LEFT, padx=(0, 6))
        
        tk.Button(bottom, text="📂 Load Config", font=CE_FONTS['normal'], bg=CE_COLORS['bg_input'],
                  fg=CE_COLORS['text'], relief=tk.FLAT, bd=0, padx=14, pady=6,
                  cursor="hand2", command=self._load_config).pack(side=tk.LEFT, padx=(0, 6))
        
        tk.Button(bottom, text="🔄 Reset Defaults", font=CE_FONTS['normal'], bg=CE_COLORS['orange'],
                  fg=CE_COLORS['bg'], relief=tk.FLAT, bd=0, padx=14, pady=6,
                  cursor="hand2", command=self._reset_defaults).pack(side=tk.LEFT)
        
        self.apply_btn = tk.Button(bottom, text="✓ Apply to Engine", font=('Arial', 11, 'bold'),
                                    bg=CE_COLORS['green'], fg=CE_COLORS['bg'], relief=tk.FLAT, bd=0,
                                    padx=20, pady=6, cursor="hand2", command=self._apply)
        self.apply_btn.pack(side=tk.RIGHT)
    
    # ====================================================================
    # CONSTRAINT LIST MANAGEMENT
    # ====================================================================
    
    def _get_all_entries(self):
        """Return flat list of (category, index, entry) for display order"""
        items = []
        for i, entry in enumerate(self.working_config.get("separate", [])):
            items.append(("separate", i, entry))
        for i, entry in enumerate(self.working_config.get("collective", [])):
            items.append(("collective", i, entry))
        return items
    
    def _refresh_list(self):
        self.constraint_listbox.delete(0, tk.END)
        
        items = self._get_all_entries()
        if not items:
            self.constraint_listbox.insert(tk.END, "  (no constraints loaded)")
            return
        
        last_cat = None
        for cat, idx, entry in items:
            if cat != last_cat:
                header = f"── {'SEPARATE (Fast)' if cat == 'separate' else 'COLLECTIVE (Global)'} ──"
                self.constraint_listbox.insert(tk.END, header)
                self.constraint_listbox.itemconfig(tk.END, fg=CE_COLORS['text_muted'], selectbackground=CE_COLORS['bg_input'])
                last_cat = cat
            
            tag = "[S]" if cat == "separate" else "[C]"
            ctype = entry.get("type", "?")
            name = entry.get("name", ctype)
            
            # Show key param value if any
            reg = CONSTRAINT_REGISTRY.get(ctype, {})
            param_str = ""
            for pname, pinfo in reg.get("params", {}).items():
                val = entry.get(pname, pinfo["default"])
                if isinstance(val, list):
                    val = ", ".join(str(v) for v in val) if val else "(none)"
                param_str = f" = {val}"
                break  # Show first param only
            
            fix_icon = "🔧" if reg.get("auto_fix") else "  "
            line = f"  {tag} {fix_icon} {name}{param_str}"
            self.constraint_listbox.insert(tk.END, line)
        
        self._update_status()
    
    def _update_status(self):
        sep = len(self.working_config.get("separate", []))
        col = len(self.working_config.get("collective", []))
        changed = " ●" if self.unsaved_changes else ""
        self.status_label.config(text=f"{sep} separate, {col} collective{changed}")
    
    def _mark_changed(self):
        self.unsaved_changes = True
        self._update_status()
    
    def _resolve_selection(self):
        """Map listbox selection index to (category, config_index) or None"""
        sel = self.constraint_listbox.curselection()
        if not sel:
            return None
        
        lb_idx = sel[0]
        text = self.constraint_listbox.get(lb_idx)
        
        # Skip header rows
        if text.startswith("──") or text.startswith("  (no"):
            return None
        
        # Count real entries before this index
        real_idx = -1
        for i in range(lb_idx + 1):
            t = self.constraint_listbox.get(i)
            if not t.startswith("──") and not t.startswith("  (no"):
                real_idx += 1
        
        # Map to category + index
        sep_count = len(self.working_config.get("separate", []))
        if real_idx < sep_count:
            return ("separate", real_idx)
        else:
            return ("collective", real_idx - sep_count)
    
    def _on_select(self, event=None):
        resolved = self._resolve_selection()
        if resolved is None:
            self._show_no_selection()
            return
        
        cat, idx = resolved
        entry = self.working_config[cat][idx]
        self._show_editor(cat, idx, entry)
    
    def _move_up(self):
        resolved = self._resolve_selection()
        if resolved is None:
            return
        cat, idx = resolved
        if idx <= 0:
            return
        lst = self.working_config[cat]
        lst[idx], lst[idx - 1] = lst[idx - 1], lst[idx]
        self._mark_changed()
        self._refresh_list()
        # Reselect
        self._select_entry(cat, idx - 1)
    
    def _move_down(self):
        resolved = self._resolve_selection()
        if resolved is None:
            return
        cat, idx = resolved
        lst = self.working_config[cat]
        if idx >= len(lst) - 1:
            return
        lst[idx], lst[idx + 1] = lst[idx + 1], lst[idx]
        self._mark_changed()
        self._refresh_list()
        self._select_entry(cat, idx + 1)
    
    def _select_entry(self, cat, idx):
        """Select a specific entry in the listbox after refresh"""
        # Count listbox position: headers + entries
        lb_idx = 0
        # Separate header
        if self.working_config.get("separate"):
            lb_idx += 1  # header row
            if cat == "separate":
                lb_idx += idx
                self.constraint_listbox.selection_set(lb_idx)
                self.constraint_listbox.see(lb_idx)
                self._on_select()
                return
            lb_idx += len(self.working_config["separate"])
        
        # Collective header
        if self.working_config.get("collective"):
            lb_idx += 1  # header row
            if cat == "collective":
                lb_idx += idx
                self.constraint_listbox.selection_set(lb_idx)
                self.constraint_listbox.see(lb_idx)
                self._on_select()
                return
    
    def _remove_selected(self):
        resolved = self._resolve_selection()
        if resolved is None:
            return
        cat, idx = resolved
        entry = self.working_config[cat][idx]
        name = entry.get("name", entry.get("type", "?"))
        if messagebox.askyesno("Remove Constraint", f"Remove '{name}'?"):
            self.working_config[cat].pop(idx)
            self._mark_changed()
            self._refresh_list()
            self._show_no_selection()
    
    def _add_constraint(self):
        ctype = self.add_type_var.get()
        if ctype not in CONSTRAINT_REGISTRY:
            return
        
        reg = CONSTRAINT_REGISTRY[ctype]
        entry = {"type": ctype, "name": ctype}
        
        for pname, pinfo in reg["params"].items():
            entry[pname] = pinfo["default"]
        
        cat = reg["category"]
        self.working_config[cat].append(entry)
        self._mark_changed()
        self._refresh_list()
        
        # Select the new entry
        idx = len(self.working_config[cat]) - 1
        self._select_entry(cat, idx)
    
    def _update_add_preview(self, event=None):
        ctype = self.add_type_var.get()
        reg = CONSTRAINT_REGISTRY.get(ctype, {})
        cat = reg.get("category", "?")
        desc = reg.get("description", "")
        fix = "🔧 auto-fix" if reg.get("auto_fix") else "no auto-fix"
        tag = "Separate" if cat == "separate" else "Collective"
        self.add_preview.config(text=f"{tag} · {desc} · {fix}")
    
    # ====================================================================
    # EDITOR PANEL
    # ====================================================================
    
    def _show_no_selection(self):
        for w in self.editor_frame.winfo_children():
            w.destroy()
        
        tk.Label(self.editor_frame, text="Select a constraint\nfrom the list to edit it",
                 font=CE_FONTS['normal'], bg=CE_COLORS['bg_card'], fg=CE_COLORS['text_muted'],
                 justify=tk.CENTER).pack(expand=True)
    
    def _show_editor(self, cat, idx, entry):
        for w in self.editor_frame.winfo_children():
            w.destroy()
        
        ctype = entry.get("type", "?")
        reg = CONSTRAINT_REGISTRY.get(ctype, {})
        
        # Type and category
        header = tk.Frame(self.editor_frame, bg=CE_COLORS['bg_card'])
        header.pack(fill=tk.X, pady=(0, 10))
        
        tag_color = CE_COLORS['separate_tag'] if cat == "separate" else CE_COLORS['collective_tag']
        tag_text = "SEPARATE" if cat == "separate" else "COLLECTIVE"
        tk.Label(header, text=tag_text, font=CE_FONTS['small'], bg=tag_color,
                 fg=CE_COLORS['bg'], padx=6, pady=1).pack(side=tk.LEFT, padx=(0, 8))
        
        tk.Label(header, text=ctype, font=CE_FONTS['subheading'],
                 bg=CE_COLORS['bg_card'], fg=CE_COLORS['text_heading']).pack(side=tk.LEFT)
        
        # Description
        desc = reg.get("description", "No description")
        tk.Label(self.editor_frame, text=desc, font=CE_FONTS['small'],
                 bg=CE_COLORS['bg_card'], fg=CE_COLORS['text_muted'], anchor=tk.W).pack(fill=tk.X, pady=(0, 5))
        
        fix = "🔧 Can auto-fix failures" if reg.get("auto_fix") else "⚠ Cannot auto-fix (validate only)"
        tk.Label(self.editor_frame, text=fix, font=CE_FONTS['small'],
                 bg=CE_COLORS['bg_card'], fg=CE_COLORS['text_muted'], anchor=tk.W).pack(fill=tk.X, pady=(0, 12))
        
        # Separator
        tk.Frame(self.editor_frame, bg=CE_COLORS['border'], height=1).pack(fill=tk.X, pady=(0, 12))
        
        # Name field
        name_row = tk.Frame(self.editor_frame, bg=CE_COLORS['bg_card'])
        name_row.pack(fill=tk.X, pady=(0, 10))
        
        tk.Label(name_row, text="Display Name:", font=CE_FONTS['normal'],
                 bg=CE_COLORS['bg_card'], fg=CE_COLORS['text']).pack(anchor=tk.W)
        
        name_var = tk.StringVar(value=entry.get("name", ctype))
        name_entry = tk.Entry(name_row, textvariable=name_var, font=CE_FONTS['mono'],
                              bg=CE_COLORS['bg_input'], fg=CE_COLORS['text'],
                              insertbackground=CE_COLORS['text'], relief=tk.FLAT, bd=0)
        name_entry.pack(fill=tk.X, ipady=4, ipadx=6, pady=(3, 0))
        
        # Parameter fields
        param_vars = {}
        for pname, pinfo in reg.get("params", {}).items():
            row = tk.Frame(self.editor_frame, bg=CE_COLORS['bg_card'])
            row.pack(fill=tk.X, pady=(0, 10))
            
            tk.Label(row, text=f"{pinfo['label']}:", font=CE_FONTS['normal'],
                     bg=CE_COLORS['bg_card'], fg=CE_COLORS['text']).pack(anchor=tk.W)
            
            current_val = entry.get(pname, pinfo["default"])
            
            if pinfo["type"] == "int":
                var = tk.IntVar(value=current_val)
                spin = ttk.Spinbox(row, from_=pinfo.get("min", 0), to=pinfo.get("max", 999999),
                                    textvariable=var, width=12)
                spin.pack(anchor=tk.W, pady=(3, 0))
                param_vars[pname] = ("int", var)
                
            elif pinfo["type"] == "float":
                var = tk.DoubleVar(value=float(current_val))
                spin = ttk.Spinbox(row, from_=pinfo.get("min", 0.0), to=pinfo.get("max", 1.0),
                                    increment=0.05, textvariable=var, width=12)
                spin.pack(anchor=tk.W, pady=(3, 0))
                param_vars[pname] = ("float", var)
                
            elif pinfo["type"] == "str":
                var = tk.StringVar(value=current_val)
                ent = tk.Entry(row, textvariable=var, font=CE_FONTS['mono'],
                               bg=CE_COLORS['bg_input'], fg=CE_COLORS['text'],
                               insertbackground=CE_COLORS['text'], relief=tk.FLAT, bd=0)
                ent.pack(fill=tk.X, ipady=4, ipadx=6, pady=(3, 0))
                param_vars[pname] = ("str", var)
                
            elif pinfo["type"] == "list":
                # Show as comma-separated string
                if isinstance(current_val, list):
                    display = ", ".join(str(v) for v in current_val)
                else:
                    display = str(current_val)
                var = tk.StringVar(value=display)
                ent = tk.Entry(row, textvariable=var, font=CE_FONTS['mono'],
                               bg=CE_COLORS['bg_input'], fg=CE_COLORS['text'],
                               insertbackground=CE_COLORS['text'], relief=tk.FLAT, bd=0)
                ent.pack(fill=tk.X, ipady=4, ipadx=6, pady=(3, 0))
                
                tk.Label(row, text="Separate items with commas", font=CE_FONTS['small'],
                         bg=CE_COLORS['bg_card'], fg=CE_COLORS['text_muted']).pack(anchor=tk.W, pady=(2, 0))
                param_vars[pname] = ("list", var)
        
        if not reg.get("params"):
            tk.Label(self.editor_frame, text="This constraint has no configurable parameters.",
                     font=CE_FONTS['small'], bg=CE_COLORS['bg_card'], fg=CE_COLORS['text_muted']).pack(
                anchor=tk.W, pady=(0, 10))
        
        # Save button for this constraint
        tk.Frame(self.editor_frame, bg=CE_COLORS['bg_card']).pack(fill=tk.BOTH, expand=True)
        
        def _save_edits():
            entry["name"] = name_var.get().strip() or ctype
            for pname, (ptype, var) in param_vars.items():
                if ptype == "int":
                    try:
                        entry[pname] = var.get()
                    except (ValueError, tk.TclError):
                        entry[pname] = CONSTRAINT_REGISTRY[ctype]["params"][pname]["default"]
                elif ptype == "float":
                    try:
                        entry[pname] = var.get()
                    except (ValueError, tk.TclError):
                        entry[pname] = CONSTRAINT_REGISTRY[ctype]["params"][pname]["default"]
                elif ptype == "str":
                    entry[pname] = var.get()
                elif ptype == "list":
                    raw = var.get().strip()
                    if raw:
                        entry[pname] = [item.strip() for item in raw.split(",") if item.strip()]
                    else:
                        entry[pname] = []
            
            self._mark_changed()
            self._refresh_list()
            self._select_entry(cat, idx)
        
        btn_frame = tk.Frame(self.editor_frame, bg=CE_COLORS['bg_card'])
        btn_frame.pack(fill=tk.X, pady=(10, 0))
        
        tk.Button(btn_frame, text="💾 Save Changes", font=CE_FONTS['normal'], bg=CE_COLORS['accent'],
                  fg=CE_COLORS['text_heading'], relief=tk.FLAT, bd=0, padx=14, pady=5,
                  cursor="hand2", command=_save_edits).pack(side=tk.RIGHT)
    
    # ====================================================================
    # TEST ENGINE
    # ====================================================================
    
    def _run_test(self):
        test_data = self.test_input.get("1.0", tk.END).strip()
        if not test_data:
            self._set_test_output("Enter test text first", CE_COLORS['red'])
            return
        
        # Build engine from current config
        try:
            engine = config_to_engine(self.working_config)
        except Exception as e:
            self._set_test_output(f"Engine build error: {e}", CE_COLORS['red'])
            return
        
        auto_fix = self.test_auto_fix_var.get()
        
        start = time.time()
        result = engine.validate(test_data, auto_fix=auto_fix)
        elapsed = (time.time() - start) * 1000
        
        lines = []
        for entry in result.get("log", []):
            name = entry["constraint"]
            phase = "S" if entry.get("phase") == "separate" else "C"
            ms = entry.get("duration_ms", 0)
            
            if entry.get("fixed"):
                lines.append(f"🔧 [{phase}] {name}: FIXED ({ms:.2f}ms)")
            elif entry["passed"]:
                lines.append(f"✓ [{phase}] {name}: passed ({ms:.2f}ms)")
            else:
                lines.append(f"✗ [{phase}] {name}: FAILED ({ms:.2f}ms)")
        
        fixes = sum(1 for e in result.get("log", []) if e.get("fixed"))
        
        if result.get("success"):
            lines.append(f"\n✓ ALL PASSED ({elapsed:.2f}ms, {fixes} fixes)")
            if auto_fix and "data" in result:
                output = result["data"]
                if output != test_data:
                    lines.append(f"\nFixed output:\n{output}")
            color = CE_COLORS['green']
        else:
            failed = result.get("failed_at", "unknown")
            lines.append(f"\n✗ FAILED at: {failed} ({elapsed:.2f}ms)")
            color = CE_COLORS['red']
        
        self._set_test_output("\n".join(lines), color)
    
    def _set_test_output(self, text, color=CE_COLORS['green']):
        self.test_output.config(state=tk.NORMAL, fg=color)
        self.test_output.delete("1.0", tk.END)
        self.test_output.insert("1.0", text)
        self.test_output.config(state=tk.DISABLED)
    
    # ====================================================================
    # SAVE / LOAD / APPLY
    # ====================================================================
    
    def _save_config(self):
        self.working_config["name"] = self.name_var.get().strip() or "ConstraintEngine"
        
        path = filedialog.asksaveasfilename(
            title="Save Constraint Config",
            initialdir=os.path.expanduser("~/Downloads"),
            initialfile="constraint_engine_config.json",
            defaultextension=".json",
            filetypes=[("JSON files", "*.json"), ("All files", "*.*")]
        )
        if not path:
            return
        
        try:
            with open(path, 'w', encoding='utf-8') as f:
                json.dump(self.working_config, f, indent=2)
            self.config_path = path
            self.unsaved_changes = False
            self._update_status()
            messagebox.showinfo("Saved", f"Config saved:\n{os.path.basename(path)}")
        except Exception as e:
            messagebox.showerror("Error", f"Failed to save:\n{e}")
    
    def _load_config(self):
        path = filedialog.askopenfilename(
            title="Load Constraint Config",
            initialdir=os.path.expanduser("~/Downloads"),
            filetypes=[("JSON files", "*.json"), ("All files", "*.*")]
        )
        if not path:
            return
        
        try:
            with open(path, 'r', encoding='utf-8') as f:
                loaded = json.load(f)
            
            # Validate structure
            if "separate" not in loaded and "collective" not in loaded:
                messagebox.showerror("Error", "Invalid config file — missing separate/collective keys")
                return
            
            self.working_config = loaded
            self.name_var.set(loaded.get("name", "ConstraintEngine"))
            self.config_path = path
            self.unsaved_changes = False
            self._refresh_list()
            self._show_no_selection()
            messagebox.showinfo("Loaded", f"Config loaded:\n{os.path.basename(path)}")
        except Exception as e:
            messagebox.showerror("Error", f"Failed to load:\n{e}")
    
    def _reset_defaults(self):
        if messagebox.askyesno("Reset", "Reset all constraints to defaults?"):
            self.working_config = self._default_config()
            self.name_var.set(self.working_config["name"])
            self._mark_changed()
            self._refresh_list()
            self._show_no_selection()
    
    def _apply(self):
        """Build engine from config and fire the callback"""
        self.working_config["name"] = self.name_var.get().strip() or "ConstraintEngine"
        
        try:
            engine = config_to_engine(self.working_config)
        except Exception as e:
            messagebox.showerror("Error", f"Failed to build engine:\n{e}")
            return
        
        sep = len(engine.separate_constraints)
        col = len(engine.collective_constraints)
        
        if self.on_apply:
            self.on_apply(engine)
            self.unsaved_changes = False
            self._update_status()
            messagebox.showinfo("Applied", f"Engine applied: {sep} separate, {col} collective constraints")
        else:
            # Standalone mode — just confirm it builds
            self.unsaved_changes = False
            self._update_status()
            messagebox.showinfo("Validated",
                                f"Engine builds successfully:\n{sep} separate, {col} collective constraints\n\n"
                                f"(No LMSuite connected — save config to use it)")
    
    def _on_close(self):
        if self.unsaved_changes:
            if not messagebox.askyesno("Unsaved Changes", "You have unsaved changes. Close anyway?"):
                return
        self.root.destroy()
    
    def get_engine(self) -> ConstraintEngine:
        """Build and return engine from current config"""
        self.working_config["name"] = self.name_var.get().strip() or "ConstraintEngine"
        return config_to_engine(self.working_config)

# ============================================================================
# CONFIGURATION - Edit everything here to customize the app
# ============================================================================
CONFIG = {
    # ===== API SETTINGS =====
    'API': {
        'base_url': 'http://localhost:1234',
        'models_endpoint': '/api/v1/models',
        'load_model_endpoint': '/api/v1/models/load',
        'chat_endpoint': '/v1/chat/completions',
        'timeout_connect': 2,
        'timeout_models': 5,
        'timeout_load': 30,
        'timeout_chat': 300,
    },
    
    # ===== COLORS =====
    'COLORS': {
        'bg_primary': '#f0f2f7',           # Main background
        'bg_secondary': '#f9f9f9',         # Light gray backgrounds
        'bg_white': 'white',                # Card backgrounds
        'bg_menu': '#f0f0f0',              # Menu bar background
        'bg_input': 'white',               # Input field background
        
        'text_primary': '#000',             # Main text
        'text_secondary': '#333',           # Headings
        'text_muted': 'gray',              # Faded text
        'text_white': 'white',             # White text
        'text_error': '#dc2626',           # Error red
        'text_blue': '#0066cc',            # Link blue
        
        'button_primary': '#0084ff',       # Main button color
        'button_green': '#4CAF50',         # Save/success buttons
        'button_red': '#dc2626',           # Delete/cancel buttons
        'button_disabled': '#ccc',         # Disabled button
        
        'border_light': '#e8ecf4',         # Card borders
        'border_gray': '#d0d0d0',          # Separators
        'border_dark': '#e8e8e8',          # Menu borders
        
        'status_online': 'green',          # Connected status
        'status_offline': 'red',           # Disconnected status
        'tab_active': '#4a9eff',           # Active tab background
        'tab_inactive': '#e8e8e8',         # Inactive tab background
    },
    
    # ===== FONTS =====
    'FONTS': {
        'family_default': 'Arial',
        'family_mono': 'Courier',
        
        'size_large': 14,                  # Large titles
        'size_title': 12,                  # Window/card titles
        'size_header': 11,                 # Section headers
        'size_normal': 10,                 # Normal text
        'size_small': 9,                   # Small text
        'size_tiny': 8,                    # Tiny text
    },
    
    # ===== DIMENSIONS =====
    'DIMENSIONS': {
        'window_width': 900,
        'window_height': 624,
        'splash_width': 400,
        'splash_height': 150,
        'settings_width': 550,
        'settings_height': 500,
        
        'padding_huge': 20,                # Large padding
        'padding_large': 15,               # Card padding
        'padding_normal': 12,              # Standard padding
        'padding_small': 8,                # Small padding
        'padding_tiny': 3,                 # Tiny padding
        
        'margin_large': 15,                # Large margins
        'margin_normal': 12,               # Standard margins
        'margin_small': 5,                 # Small margins
        
        'chat_height': 200,                # Chat message container height
        'cascade_output_height': 20,       # Story output text area height
        'model_list_height': 4,            # Model listbox height
        'chat_input_height': 2,            # Chat input height
        'story_prompt_height': 3,          # Story prompt input height
        
        'card_relief': tk.FLAT,
        'card_border_width': 3,
        'card_border': tk.SOLID,
    },
    
    # ===== TEXT & LABELS =====
    'TEXT': {
        # Window titles
        'app_title': 'LMSuite — LM Studio Multi-Model Orchestrator',
        'settings_title': 'Settings (beta)',
        'error_title': 'LM Studio Error',
        
        # Status messages
        'status_connected': '✅ Connected',
        'status_disconnected': '❌ Disconnected',
        'status_model_loaded': '✅ Model Loaded',
        'status_no_model': '❌ No Model Loaded',
        'status_waiting': 'Waiting...',
        'status_offline': 'Offline',
        'status_thinking': 'Thinking...',
        'status_detecting': 'Detecting...',
        
        # Card headers
        'card_status': 'Status',
        'card_model_loader': 'Model Loader',
        'card_story_cascade': 'Story Cascade',
        'card_chat': 'Chat',
        
        # Labels & fields
        'label_lm_studio_status': 'LM Studio Status:',
        'label_server': 'Server:',
        'label_model': 'Model:',
        'label_model_loaded': 'Model:',
        'label_tokens_used': 'Tokens used:',
        'label_reasoning': 'Reasoning:',
        'label_max_tokens': 'Max Tokens:',
        'label_temperature': 'Temperature:',
        'label_available_models': 'Available Models:',
        'label_double_click': '(double-click to load)',
        'label_system_resources': 'System Resources:',
        'label_vram': 'VRAM:',
        'label_ram': 'RAM:',
        'label_total': 'Total:',
        'label_story_idea': 'Story Idea/Prompt:',
        'label_select_model_pass': 'Select Model for Each Pass:',
        'label_leave_blank': '(leave blank to skip pass)',
        'label_pass': 'Pass',
        'label_create': 'Create',
        'label_refine': 'Refine',
        'label_polish': 'Polish',
        'label_tokens': 'Tokens:',
        'label_temp_global': 'Temperature (Global):',
        'label_temp_range': '(0.0-2.0)',
        'label_pass_polished': 'Pass 5 - Polished:',
        
        # Button labels
        'btn_refresh': 'Refresh Script',
        'btn_restart': 'Restart Script',
        'btn_generate': '▶ Generate',
        'btn_clear_all': '🗑️ Clear All',
        'btn_copy_output': '📋 Copy Output',
        'btn_save_story': '💾 Save Story',
        'btn_send': '➤',
        'btn_clear_chat': '🗑️ Clear',
        'btn_file': 'File',
        'btn_settings': 'Settings (beta)',
        'btn_view_log': 'View Log File',
        'btn_exit': 'Exit',
        'btn_apply_test': '✓ Apply & Test',
        'btn_close': 'Close',
        'btn_apply': '✓ Apply',
        'btn_save': 'Save',
        'btn_cancel': 'Cancel',
        'btn_pick_color': 'Pick Color',
        
        # Section headers in settings
        'settings_server_config': '🌐 Server Configuration',
        'settings_api_info': '📡 APIs Used',
        'settings_dev_settings': '🛠️  Developer Settings',
        'settings_color_custom': '🎨 Color Customization',
        'settings_header_custom': '📝 Section Header Customization',
        
        # Settings fields
        'settings_server_addr': 'LM Studio Server Address:',
        'settings_default': 'Default: http://localhost:1234',
        'settings_quick_start': 'Skip loading splash screen (Quick Start)',
        'settings_quick_start_desc': 'Bypasses the startup connection check',
        'settings_main_res': 'Main Window Resolution:',
        'settings_splash_res': 'Splash Window Resolution:',
        'settings_splash_note': 'Note: Restart app for resolution changes to take effect',
        'settings_text_color': 'Main Text Color:',
        'settings_heading_color': 'Section Header Color:',
        'settings_bg_color': 'Background Color:',
        'settings_button_color': 'Button Color:',
        'settings_font_size': 'Font Size:',
        'settings_font_weight': 'Font Weight:',
        
        # API info text
        'api_models_list': '• /api/v1/models - List available models',
        'api_models_load': '• /api/v1/models/load - Load a specific model',
        'api_chat': '• /v1/chat/completions - Chat endpoint for responses',
        
        # Messages
        'msg_no_model_selected': 'Please select a model for chat.',
        'msg_empty_message': 'Please type a message.',
        'msg_empty_prompt': 'Enter a story idea first.',
        'msg_in_progress': 'Cascade is already running.',
        'msg_no_models_cascade': 'Select at least one model for a pass.',
        'msg_empty_story': 'No story to copy',
        'msg_empty_to_save': 'No story to save',
        'msg_copied': 'Story cascade output copied to clipboard!',
        'msg_no_log': 'Log file not found:',
        'msg_restart_confirm': 'Restart? Token count will reset.',
        'msg_clear_logs': 'Clear all logs?',
        'msg_log_copied': 'Log entry copied!',
        'msg_no_selection': 'Select a log entry first.',
        'msg_no_model_identified': 'Could not identify model',
        'msg_empty_server': 'Please enter a server address first.',
        
        # Error messages
        'error_failed_load': 'Failed to load model.\nStatus:',
        'error_load_model': 'Error loading model:',
        'error_api_error': 'API Error:',
        'error_connection': 'Failed to connect to LM Studio:',
        'error_unexpected': 'Unexpected response format from LM Studio.',
        'error_cascade_no_models': 'Cascade error: no models selected',
        'error_cascade_empty': 'Cascade error: empty prompt',
        'error_save_file': 'Could not save:',
        'error_invalid_input': 'Invalid input',
        'error_invalid_resolution': 'Resolution values must be numbers!',
        
        # Popup titles
        'popup_success': 'Success',
        'popup_connected': 'Connected to server!',
        'popup_error': 'Error',
        'popup_warning': 'Warning',
        'popup_info': 'Info',
        
        # Research mode
        'card_research': 'Research',
        'label_research_topic': 'Research Topic / Focus:',
        'label_research_model': 'Research Model:',
        'label_research_log': 'Research Log:',
        'btn_load_folder': '📂 Load Source Folder',
        'btn_load_files': '📄 Load File(s)',
        'btn_research_start': '▶ Start',
        'btn_research_pause': '⏸ Pause',
        'btn_research_resume': '▶ Resume',
        'btn_research_stop': '■ Stop',
        'btn_open_knowledge': '📄 Open Knowledge File',
        'btn_compact_now': '🔄 Compact Now',
        'text_no_folder_loaded': 'No folder loaded',
        'status_research_stopped': '■ Stopped',
        'status_research_running': '● Running',
        'status_research_paused': '⏸ Paused',
        'msg_research_running': 'Research is already running.',
        'msg_no_folder': 'Load a source folder first.',
        'msg_no_topic': 'Enter a research topic/focus first.',
        'msg_no_research_model': 'Select a research model first.',
        'msg_no_files_found': 'No .txt, .md, or .pdf files found in that folder.',
        'msg_no_knowledge_yet': 'No knowledge base saved yet.',
        'msg_pause_before_compact': 'Pause or stop the research run before compacting manually — '
                                     'they both write to the same knowledge base.',
        'msg_new_topic_title': 'New Topic',
    },
    
    # ===== DEFAULT VALUES =====
    'DEFAULTS': {
        'max_tokens': 2000,
        'temperature': 0.7,
        'cascade_temperature': 0.8,
        'cascade_pass_tokens': 2000,
        'model_dropdown_width': 25,
        'model_display_width': 22,
    },
    
    # ===== CASCADE CATEGORIES =====
    'CASCADE_CATEGORIES': [
        'Story',
        'Coding',
        'Music',
        'Sports',
        'Movies',
        'Jokes',
        'Advice',
        'Electronics',
        'Articles',
        'Scripts',
        'Marketing',
        'Educational',
    ],
    
    # ===== PASS DESCRIPTIONS - EDIT THESE FOR DIFFERENT CASCADE BEHAVIORS =====
    'CASCADE_PASSES': {
        'SUPERVISOR': {
            'name': 'Supervisor',
            'role': 'Final Review',
            'rating_template': '''Rate this finished story on a scale of 1-10 for each criterion:

FINAL STORY:
{story}

Rate (1-10):
1. Narrative quality and coherence: __/10
2. Completeness and satisfying resolution: __/10
3. Writing quality and prose: __/10

Average rating: __/10

Brief assessment (1-2 sentences):

Respond ONLY with the rating and assessment, no preamble.''',
        },
        1: {
            'name': 'Pass 1',
            'role': 'Create',
            'prompt_template': 'Write a creative and engaging short story based on this idea:\n\n{story}\n\nMake it around 300-400 words with vivid descriptions and interesting characters.',
        },
        2: {
            'name': 'Pass 2',
            'role': 'Refine',
            'prompt_template': 'Improve this story by enhancing the narrative flow and adding more descriptive detail:\n\n{story}\n\nKeep it around 400-500 words.',
        },
        3: {
            'name': 'Pass 3',
            'role': 'Refine',
            'prompt_template': 'Deepen the story by developing character motivations, emotions, and dialogue. Make the interactions more realistic:\n\n{story}\n\nKeep it around 450-550 words.',
        },
        4: {
            'name': 'Pass 4',
            'role': 'Refine',
            'prompt_template': 'Refine the story for better pacing, build tension, and create a more compelling narrative arc:\n\n{story}\n\nKeep it around 450-550 words.',
        },
        5: {
            'name': 'Pass 5',
            'role': 'Polish',
            'prompt_template': 'Polish this story to publication quality. Enhance prose, ensure strong voice, perfect pacing, and create a satisfying conclusion:\n\n{story}\n\nFinal version should be 400-600 words of polished prose.',
        },
    },
    
    # ===== RESEARCH MODE - DOCUMENT-GROUNDED RESEARCH LOOP =====
    'RESEARCH': {
        'chunk_size': 2000,
        'chunk_overlap': 200,
        'novelty_threshold': 3,          # below this score, round counts as "low novelty"
        'low_novelty_stop_streak': 3,    # this many low-novelty rounds in a row -> auto-pause
        'compact_every_n_rounds': 10,
        'summary_context_chars': 6000,   # how much of the existing KB to show back as "already known"
                                          # (was 1500 — too small: early claims aged out of context and
                                          #  got silently re-extracted as "new" many rounds later)
        'dedup_similarity_threshold': 0.72,  # sequence-similarity cutoff for the deterministic dedup filter
        'research_template': (
            "You are researching the topic: {topic}\n\n"
            "SOURCE EXCERPT (from {source}):\n{chunk}\n\n"
            "KNOWLEDGE ALREADY RECORDED (do not repeat any of this, including reworded versions of it):\n"
            "{existing_summary}\n\n"
            "Extract 2-5 NEW factual claims from the source excerpt above that are relevant to the "
            "topic and are NOT already covered — even in different wording — by the knowledge already "
            "recorded. Prioritize concrete specifics (numbers, vote counts, percentages, dates, names) "
            "over claims that just restate a general point already captured above. When the source "
            "states someone's exact title or role, preserve it verbatim rather than substituting a "
            "different one that implies something different (e.g. 'ranking member' and 'chair' are "
            "NOT interchangeable — use exactly what the source says). For each claim, write one line "
            "in exactly this format:\n"
            "CLAIM: <the fact or finding> | CONFIDENCE: <high/medium/low>\n\n"
            "If nothing new and relevant is found in this excerpt, respond with exactly: NO NEW CLAIMS"
        ),
        'novelty_template': (
            "Topic: {topic}\n\n"
            "EXISTING KNOWLEDGE BASE (summary):\n{existing_summary}\n\n"
            "NEWLY EXTRACTED CLAIMS THIS ROUND:\n{new_claims}\n\n"
            "Rate how much genuinely NEW, non-redundant information the new claims add on top of the "
            "existing knowledge base, on a scale of 0-10 (0 = pure repetition of what's already known, "
            "10 = major new information).\n"
            "Respond ONLY in this format:\nNOVELTY: <number>\nREASON: <one short sentence>"
        ),
        'compaction_template': (
            "Topic: {topic}\n\n"
            "Below is an accumulated knowledge base of claims gathered from source documents across "
            "several rounds. Some may be duplicates, near-duplicates, or could be merged/organized "
            "better.\n\n{full_knowledge}\n\n"
            "Rewrite this into a clean, de-duplicated, well-organized set of claims grouped under short "
            "subtopic headings ('## <Subtopic>'). Keep each claim's confidence level and source(s). "
            "Preserve all genuinely distinct information — only remove true duplicates and merge "
            "near-duplicates (combine their sources). Format each claim as exactly:\n"
            "CLAIM: <fact> | CONFIDENCE: <level> | SOURCES: <comma-separated source names>"
        ),
    },
}

# ============================================================================
# END CONFIGURATION
# ============================================================================


class LoadingSplash:
    """Splash screen with loading bar shown during startup checks"""
    def __init__(self, root):
        self.root = root
        self.splash = tk.Toplevel(root)
        self.splash.title(CONFIG['TEXT']['app_title'])
        w, h = CONFIG['DIMENSIONS']['splash_width'], CONFIG['DIMENSIONS']['splash_height']
        self.splash.geometry(f"{w}x{h}")
        self.splash.resizable(False, False)
        
        # Center on screen
        self.splash.update_idletasks()
        x = (self.splash.winfo_screenwidth() // 2) - (w // 2)
        y = (self.splash.winfo_screenheight() // 2) - (h // 2)
        self.splash.geometry(f"+{x}+{y}")
        
        # Remove window decorations for cleaner look
        self.splash.attributes('-topmost', True)
        
        # Content
        font = (CONFIG['FONTS']['family_default'], CONFIG['FONTS']['size_title'], 'bold')
        ttk.Label(self.splash, text=CONFIG['TEXT']['app_title'], font=font).pack(
            pady=CONFIG['DIMENSIONS']['padding_large'])
        ttk.Label(self.splash, text="Checking server...", 
                 font=(CONFIG['FONTS']['family_default'], CONFIG['FONTS']['size_small'])).pack(
            pady=(0, CONFIG['DIMENSIONS']['padding_normal']))
        
        self.progress = ttk.Progressbar(self.splash, mode='indeterminate', length=300)
        self.progress.pack(pady=CONFIG['DIMENSIONS']['padding_normal'])
        self.progress.start()
    
    def close(self):
        """Close splash screen"""
        self.progress.stop()
        self.splash.destroy()


class LMStudioOrchestrator:
    def __init__(self, root):
        self.root = root
        self.root.title(CONFIG['TEXT']['app_title'])
        w, h = CONFIG['DIMENSIONS']['window_width'], CONFIG['DIMENSIONS']['window_height']
        self.root.geometry(f"{w}x{h}")
        self.root.resizable(False, False)
        
        # Window lock state
        self.window_locked = True

        # Connection state (set for real by check_connection(), but referenced
        # before that first runs if anything checks it during startup)
        self.is_connected = False
        
        # API Config
        self.api_base = CONFIG['API']['base_url']
        self.model_keys = {}
        self.current_model = None
        self.loading_model = False
        
        # Document settings
        self.max_tokens_var = tk.IntVar(value=CONFIG['DEFAULTS']['max_tokens'])
        self.temperature_var = tk.DoubleVar(value=CONFIG['DEFAULTS']['temperature'])
        self.cascade_category_var = tk.StringVar(value=CONFIG['CASCADE_CATEGORIES'][0])
        
        # Token tracking
        self.session_tokens = 0
        self.reasoning_tokens = 0
        
        # Logging
        self.error_log = []
        self.log_file_path = os.path.join(os.path.expanduser("~"), "Downloads", "lm_studio_logs.txt")
        self._initialize_log_file()
        
        # Settings storage
        self.settings = {
            'api_base': CONFIG['API']['base_url'],
            'quick_start_enabled': False,
            'main_window_width': CONFIG['DIMENSIONS']['window_width'],
            'main_window_height': CONFIG['DIMENSIONS']['window_height'],
            'splash_window_width': CONFIG['DIMENSIONS']['splash_width'],
            'splash_window_height': CONFIG['DIMENSIONS']['splash_height'],
        }
        self.settings_file = os.path.join(os.path.expanduser("~"), "Downloads", "lm_studio_settings.txt")
        self.load_settings()
        
        # Constraint Engine
        self.engine = None
        self.engine_loaded = False
        self.engine_enabled_var = tk.BooleanVar(value=True)
        self._init_constraint_engine()
        
        # Supervisor state
        self.current_pass_num = 0
        
        # Research mode state (Variant 3 — document-grounded research loop)
        self.research_running = False
        self.research_paused = False
        self.research_stop_requested = False
        self.research_folder = None
        self.research_chunks = []          # [{"source": filename, "text": chunk_text}, ...]
        self.research_chunk_idx = 0
        self.research_round = 0
        self.research_low_novelty_streak = 0
        self.research_knowledge = {"topic": "", "entries": []}
        self.research_knowledge_path = None
        self.research_last_compaction_round = 0
        self.research_compacting = False
        self.research_topic_var = tk.StringVar(value="")
        self.research_model_var = tk.StringVar(value="None Selected")
        
        # Build UI
        self._build_ui()
        
        # Bind window events
        self.root.bind("<Configure>", self.update_resolution)
        self.root.protocol("WM_DELETE_WINDOW", self.exit_app)
        
        # Run startup checks
        self.run_startup_checks()
        self.root.after(1000, self.update_system_resources)
    
    def _init_constraint_engine(self):
        """Initialize constraint engine with default story constraints"""
        try:
            self.engine = ConstraintEngine(name="StoryValidator")
            
            # Separate constraints (fast, per-item)
            self.engine.add_separate(IsNonEmpty("IsNonEmpty"))
            self.engine.add_separate(NoDoubleSpaces("NoDoubleSpaces"))
            self.engine.add_separate(NoTrailingWhitespace("NoTrailingWhitespace"))
            self.engine.add_separate(CapitalizeFirst("CapitalizeFirst"))
            self.engine.add_separate(MaxLength("MaxLength", max_len=10000))
            
            # Collective constraints (global, cross-checking)
            self.engine.add_collective(NoContradictions("NoContradictions"))
            
            self.engine_loaded = True
            sep_count = len(self.engine.separate_constraints)
            col_count = len(self.engine.collective_constraints)
            self.add_log(f"Constraint Engine loaded: {sep_count} separate, {col_count} collective", "INFO")
        except Exception as e:
            self.engine_loaded = False
            self.add_log(f"Constraint Engine failed to load: {str(e)}", "ERROR")
    
    def open_engine_editor(self):
        """Open the constraint engine GUI editor"""
        def on_apply(new_engine):
            """Callback: GUI editor sends back the updated engine"""
            self.engine = new_engine
            self.engine_loaded = True
            self._update_engine_status_display()
            
            sep_count = len(self.engine.separate_constraints)
            col_count = len(self.engine.collective_constraints)
            self.add_log(f"Engine updated from editor: {sep_count} separate, {col_count} collective", "INFO")
        
        editor_window = tk.Toplevel(self.root)
        ConstraintEngineGUI(editor_window, engine=self.engine, on_apply=on_apply)

    def toggle_engine(self):
        """Handle the Constraints Engine enable/disable checkbox"""
        self._update_engine_status_display()
        state = "enabled" if self.engine_enabled_var.get() else "disabled"
        self.add_log(f"Constraint Engine {state}", "INFO")

    def _update_engine_status_display(self):
        """Refresh the status label in the Constraints Engine card"""
        if not hasattr(self, 'engine_running_label'):
            return
        
        if not self.engine_loaded or not self.engine:
            self.engine_running_label.config(text="❌ Not Loaded", foreground=CONFIG['COLORS']['status_offline'])
            return
        
        sep_count = len(self.engine.separate_constraints)
        col_count = len(self.engine.collective_constraints)
        
        if self.engine_enabled_var.get():
            self.engine_running_label.config(
                text=f"✅ Engine Running ({sep_count} separate, {col_count} collective)",
                foreground=CONFIG['COLORS']['status_online']
            )
        else:
            self.engine_running_label.config(
                text=f"⏸ Loaded, Disabled ({sep_count} separate, {col_count} collective)",
                foreground=CONFIG['COLORS']['text_muted']
            )
    
    def open_engine_config(self):
        """Load a saved constraint engine JSON config and apply it"""
        file_path = filedialog.askopenfilename(
            title="Open Constraint Engine Config",
            initialdir=os.path.expanduser("~/Downloads"),
            filetypes=[("JSON files", "*.json"), ("All files", "*.*")]
        )
        
        if not file_path:
            return
        
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                loaded_config = json.load(f)
            
            if "separate" not in loaded_config and "collective" not in loaded_config:
                messagebox.showerror("Error", "Invalid config file — missing separate/collective keys")
                return
            
            self.engine = config_to_engine(loaded_config)
            self.engine_loaded = True
            self._update_engine_status_display()
            
            sep_count = len(self.engine.separate_constraints)
            col_count = len(self.engine.collective_constraints)
            
            messagebox.showinfo("Loaded", f"Constraint config loaded:\n{os.path.basename(file_path)}\n\n{sep_count} separate, {col_count} collective constraints")
            self.add_log(f"Constraint config loaded from: {file_path}", "INFO")
            
        except Exception as e:
            messagebox.showerror("Error", f"Failed to load config:\n{str(e)}")
            self.add_log(f"Error loading constraint config: {str(e)}", "ERROR")
    
    def _build_ui(self):
        """Build the main UI"""
        # ===== TOP TAB MENU BAR =====
        menu_bar = tk.Frame(self.root, bg=CONFIG['COLORS']['bg_menu'], relief=tk.RIDGE, bd=1)
        menu_bar.pack(fill=tk.X, side=tk.TOP)
        menu_bar.grid_rowconfigure(0, weight=1)
        
        # File Menu button
        font_btn = (CONFIG['FONTS']['family_default'], CONFIG['FONTS']['size_normal'], 'bold')
        file_menu_btn = tk.Button(
            menu_bar, text=CONFIG['TEXT']['btn_file'], font=font_btn,
            bg=CONFIG['COLORS']['tab_inactive'], activebackground=CONFIG['COLORS']['border_gray'],
            relief=tk.FLAT, bd=0, pady=CONFIG['DIMENSIONS']['padding_small'],
            command=self.show_file_menu, justify=tk.CENTER
        )
        file_menu_btn.grid(row=0, column=0, sticky="nsew", padx=3, pady=5)
        menu_bar.grid_columnconfigure(0, weight=0, minsize=50)
        
        self.tab_buttons = {}
        self.tab_frames = {}
        self.current_tab = "model_control"
        
        tabs = [("model_control", CONFIG['TEXT']['card_model_loader'] + " hidden, tap to open")]
        for idx, (tab_id, tab_label) in enumerate(tabs, start=1):
            btn = tk.Button(
                menu_bar, text=tab_label, font=font_btn,
                bg=CONFIG['COLORS']['tab_inactive'], activebackground=CONFIG['COLORS']['border_gray'],
                relief=tk.FLAT, bd=0, pady=CONFIG['DIMENSIONS']['padding_small'],
                command=lambda tid=tab_id: self.switch_tab(tid), justify=tk.CENTER
            )
            btn.grid(row=0, column=idx, sticky="nsew", padx=3, pady=5)
            menu_bar.grid_columnconfigure(idx, weight=1)
            self.tab_buttons[tab_id] = btn
        
        self.update_tab_appearance()
        
        # ===== MAIN CONTAINER FRAME =====
        self.main_container = tk.Frame(self.root, bg=CONFIG['COLORS']['bg_primary'])
        self.main_container.pack(fill=tk.BOTH, expand=True)
        
        # ===== TAB 1: MODEL CONTROL =====
        self.model_control_frame = tk.Frame(self.main_container, bg=CONFIG['COLORS']['bg_primary'])
        self.tab_frames["model_control"] = self.model_control_frame
        
        # Scrollable container
        canvas = tk.Canvas(self.model_control_frame, bg=CONFIG['COLORS']['bg_primary'], highlightthickness=0)
        scrollbar = ttk.Scrollbar(self.model_control_frame, orient="vertical", command=canvas.yview)
        scrollable_frame = ttk.Frame(canvas, padding=CONFIG['DIMENSIONS']['padding_large'])
        scrollable_frame.configure(style='TFrame')
        
        scrollable_frame.bind(
            "<Configure>",
            lambda e: canvas.configure(scrollregion=canvas.bbox("all"))
        )
        
        canvas.create_window((0, 0), window=scrollable_frame, anchor="nw")
        canvas.configure(yscrollcommand=scrollbar.set, bg=CONFIG['COLORS']['bg_primary'])
        canvas.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        
        def _on_mousewheel(event):
            try:
                if canvas.winfo_exists():
                    canvas.yview_scroll(int(-1*(event.delta/120)), "units")
            except tk.TclError:
                pass
        canvas.bind("<MouseWheel>", _on_mousewheel)
        scrollable_frame.bind("<MouseWheel>", _on_mousewheel)
        
        # ===== CONTROL PANEL (Card 1) =====
        control_panel = tk.Frame(
            scrollable_frame, bg=CONFIG['COLORS']['bg_white'], relief=CONFIG['DIMENSIONS']['card_relief'], bd=0,
            highlightthickness=CONFIG['DIMENSIONS']['card_border_width'], highlightbackground=CONFIG['COLORS']['border_light'],
            highlightcolor=CONFIG['COLORS']['border_light']
        )
        control_panel.pack(fill=tk.BOTH, expand=False, padx=CONFIG['DIMENSIONS']['padding_normal'], 
                          pady=(0, CONFIG['DIMENSIONS']['padding_large']))
        
        # Card header
        card_header = tk.Frame(control_panel, bg=CONFIG['COLORS']['bg_white'])
        card_header.pack(fill=tk.X, padx=CONFIG['DIMENSIONS']['padding_large'], 
                        pady=(CONFIG['DIMENSIONS']['padding_large'], CONFIG['DIMENSIONS']['padding_normal']))
        font_header = (CONFIG['FONTS']['family_default'], CONFIG['FONTS']['size_header'], 'bold')
        ttk.Label(card_header, text=CONFIG['TEXT']['card_status'], font=font_header, 
                 background=CONFIG['COLORS']['bg_white']).pack(anchor=tk.W)
        
        # Card content
        card_content = tk.Frame(control_panel, bg=CONFIG['COLORS']['bg_white'])
        card_content.pack(fill=tk.BOTH, expand=True, padx=CONFIG['DIMENSIONS']['padding_large'], 
                         pady=(0, CONFIG['DIMENSIONS']['padding_large']))
        
        font_label = (CONFIG['FONTS']['family_default'], CONFIG['FONTS']['size_normal'], 'bold')
        font_small = (CONFIG['FONTS']['family_default'], CONFIG['FONTS']['size_small'])
        
        # Status row
        ttk.Label(card_content, text=CONFIG['TEXT']['label_lm_studio_status'], font=font_label, 
                 background=CONFIG['COLORS']['bg_white']).pack(anchor=tk.W, pady=(0, CONFIG['DIMENSIONS']['padding_tiny']))
        
        status_row = tk.Frame(card_content, bg=CONFIG['COLORS']['bg_white'])
        status_row.pack(fill=tk.X, pady=(0, CONFIG['DIMENSIONS']['padding_tiny']))
        
        self.status_label = tk.Label(status_row, text=CONFIG['TEXT']['status_disconnected'], 
                                     foreground=CONFIG['COLORS']['status_offline'], font=font_small, 
                                     bg=CONFIG['COLORS']['bg_white'])
        self.status_label.pack(side=tk.LEFT, padx=(0, 15))
        
        tk.Label(status_row, text=CONFIG['TEXT']['label_server'], font=font_small, 
                bg=CONFIG['COLORS']['bg_white']).pack(side=tk.LEFT, padx=(0, 5))
        self.server_label = tk.Label(status_row, text=self.api_base, foreground=CONFIG['COLORS']['text_blue'], 
                                     font=(CONFIG['FONTS']['family_mono'], CONFIG['FONTS']['size_small']), 
                                     bg=CONFIG['COLORS']['bg_white'])
        self.server_label.pack(side=tk.LEFT)
        
        # Resolution display with lock button
        resolution_frame = tk.Frame(status_row, bg=CONFIG['COLORS']['bg_white'])
        resolution_frame.pack(side=tk.RIGHT)
        
        self.resolution_label = tk.Label(resolution_frame, text="491x624", 
                                         foreground=CONFIG['COLORS']['text_blue'],
                                         font=(CONFIG['FONTS']['family_mono'], CONFIG['FONTS']['size_small']), 
                                         bg=CONFIG['COLORS']['bg_white'])
        self.resolution_label.pack(side=tk.LEFT, padx=(0, 5))
        
        self.lock_button = tk.Button(resolution_frame, text="🔒", 
                                     font=(CONFIG['FONTS']['family_default'], CONFIG['FONTS']['size_tiny']),
                                     command=self.toggle_window_lock, relief=tk.FLAT, bd=0, padx=3, pady=0, 
                                     bg=CONFIG['COLORS']['bg_white'])
        self.lock_button.pack(side=tk.LEFT)
        
        # LMs available row
        lms_row = tk.Frame(card_content, bg=CONFIG['COLORS']['bg_white'])
        lms_row.pack(anchor=tk.W, pady=(0, CONFIG['DIMENSIONS']['padding_normal']))
        
        tk.Label(lms_row, text=CONFIG['TEXT']['label_available_models'], font=font_small, 
                bg=CONFIG['COLORS']['bg_white']).pack(side=tk.LEFT, padx=(0, 5))
        self.lms_count_label = tk.Label(lms_row, text="0", foreground=CONFIG['COLORS']['text_blue'],
                                        font=(CONFIG['FONTS']['family_mono'], CONFIG['FONTS']['size_small'], 'bold'), 
                                        bg=CONFIG['COLORS']['bg_white'])
        self.lms_count_label.pack(side=tk.LEFT)
        
        # Token tracking
        token_row = tk.Frame(card_content, bg=CONFIG['COLORS']['bg_white'])
        token_row.pack(anchor=tk.W, pady=(0, CONFIG['DIMENSIONS']['padding_normal']))
        
        tk.Label(token_row, text=CONFIG['TEXT']['label_tokens_used'], font=font_small, 
                bg=CONFIG['COLORS']['bg_white']).pack(side=tk.LEFT, padx=(0, 10))
        self.session_tokens_label = tk.Label(token_row, text="0", foreground=CONFIG['COLORS']['status_online'], 
                                             font=(CONFIG['FONTS']['family_mono'], CONFIG['FONTS']['size_small'], 'bold'), 
                                             bg=CONFIG['COLORS']['bg_white'])
        self.session_tokens_label.pack(side=tk.LEFT, padx=(0, 20))
        
        tk.Label(token_row, text=CONFIG['TEXT']['label_reasoning'], font=font_small, 
                bg=CONFIG['COLORS']['bg_white']).pack(side=tk.LEFT, padx=(0, 10))
        self.reasoning_tokens_label = tk.Label(token_row, text="0", foreground=CONFIG['COLORS']['text_blue'], 
                                               font=(CONFIG['FONTS']['family_mono'], CONFIG['FONTS']['size_small'], 'bold'), 
                                               bg=CONFIG['COLORS']['bg_white'])
        self.reasoning_tokens_label.pack(side=tk.LEFT)
        
        font_btn_small = (CONFIG['FONTS']['family_default'], CONFIG['FONTS']['size_small'])
        tk.Button(card_content, text=CONFIG['TEXT']['btn_refresh'], command=self.refresh_script, 
                 bg=CONFIG['COLORS']['button_red'], fg=CONFIG['COLORS']['text_white'], 
                 font=font_btn_small).pack(fill=tk.X, pady=CONFIG['DIMENSIONS']['padding_tiny'])
        tk.Button(card_content, text=CONFIG['TEXT']['btn_restart'], command=self.restart_script, 
                 bg=CONFIG['COLORS']['button_red'], fg=CONFIG['COLORS']['text_white'], 
                 font=font_btn_small).pack(fill=tk.X, pady=CONFIG['DIMENSIONS']['padding_tiny'])
        
        # ===== CONSTRAINTS ENGINE (Card 1.5) =====
        engine_card = tk.Frame(
            scrollable_frame, bg=CONFIG['COLORS']['bg_white'], relief=CONFIG['DIMENSIONS']['card_relief'], bd=0,
            highlightthickness=CONFIG['DIMENSIONS']['card_border_width'], highlightbackground=CONFIG['COLORS']['border_light'],
            highlightcolor=CONFIG['COLORS']['border_light']
        )
        engine_card.pack(fill=tk.BOTH, expand=False, padx=CONFIG['DIMENSIONS']['padding_normal'], 
                        pady=(0, CONFIG['DIMENSIONS']['padding_large']))
        
        # Card header: title + running status, right-aligned (same pattern as Supervisor card)
        engine_card_header = tk.Frame(engine_card, bg=CONFIG['COLORS']['bg_white'])
        engine_card_header.pack(fill=tk.X, padx=CONFIG['DIMENSIONS']['padding_large'], 
                                pady=(CONFIG['DIMENSIONS']['padding_large'], CONFIG['DIMENSIONS']['padding_normal']))
        
        tk.Label(engine_card_header, text="Constraints Engine", font=font_header, 
                background=CONFIG['COLORS']['bg_white']).pack(anchor=tk.W, side=tk.LEFT)
        
        self.engine_running_label = tk.Label(
            engine_card_header, text="❌ Not Loaded",
            font=(CONFIG['FONTS']['family_mono'], CONFIG['FONTS']['size_small'], 'bold'),
            background=CONFIG['COLORS']['bg_white'], foreground=CONFIG['COLORS']['status_offline']
        )
        self.engine_running_label.pack(anchor=tk.E, side=tk.RIGHT)
        
        # Card content
        engine_card_content = tk.Frame(engine_card, bg=CONFIG['COLORS']['bg_white'])
        engine_card_content.pack(fill=tk.BOTH, expand=True, padx=CONFIG['DIMENSIONS']['padding_large'], 
                                 pady=(0, CONFIG['DIMENSIONS']['padding_large']))
        
        engine_controls_row = tk.Frame(engine_card_content, bg=CONFIG['COLORS']['bg_white'])
        engine_controls_row.pack(fill=tk.X)
        
        tk.Checkbutton(engine_controls_row, text="Enabled", variable=self.engine_enabled_var,
                        command=self.toggle_engine, font=font_small, bg=CONFIG['COLORS']['bg_white'],
                        fg=CONFIG['COLORS']['text_primary'], selectcolor=CONFIG['COLORS']['bg_input'],
                        activebackground=CONFIG['COLORS']['bg_white']).pack(side=tk.LEFT, padx=(0, 15))
        
        tk.Button(engine_controls_row, text='📂 Open Config', command=self.open_engine_config,
                 bg=CONFIG['COLORS']['button_primary'], fg=CONFIG['COLORS']['text_white'],
                 font=(CONFIG['FONTS']['family_default'], CONFIG['FONTS']['size_small']),
                 relief=tk.FLAT, padx=10, pady=3).pack(side=tk.LEFT, padx=(0, 6))
        
        tk.Button(engine_controls_row, text='⚙️ Edit Engine', command=self.open_engine_editor,
                 bg=CONFIG['COLORS']['button_primary'], fg=CONFIG['COLORS']['text_white'],
                 font=(CONFIG['FONTS']['family_default'], CONFIG['FONTS']['size_small']),
                 relief=tk.FLAT, padx=10, pady=3).pack(side=tk.LEFT)
        
        self._update_engine_status_display()
        
        # ===== STORY CASCADE (Card 2) =====
        cascade_card = tk.Frame(
            scrollable_frame, bg=CONFIG['COLORS']['bg_white'], relief=CONFIG['DIMENSIONS']['card_relief'], bd=0,
            highlightthickness=CONFIG['DIMENSIONS']['card_border_width'], highlightbackground=CONFIG['COLORS']['border_light'],
            highlightcolor=CONFIG['COLORS']['border_light']
        )
        cascade_card.pack(fill=tk.BOTH, expand=False, padx=CONFIG['DIMENSIONS']['padding_normal'], 
                         pady=(0, CONFIG['DIMENSIONS']['padding_large']))
        
        # Category selector header
        cascade_card_header = tk.Frame(cascade_card, bg=CONFIG['COLORS']['bg_white'])
        cascade_card_header.pack(fill=tk.X, padx=CONFIG['DIMENSIONS']['padding_large'], 
                                pady=(CONFIG['DIMENSIONS']['padding_large'], CONFIG['DIMENSIONS']['padding_normal']))
        
        tk.Label(cascade_card_header, text='Category:', font=font_label, 
                bg=CONFIG['COLORS']['bg_white']).pack(side=tk.LEFT, padx=(0, 10))
        
        category_dropdown = ttk.Combobox(cascade_card_header, textvariable=self.cascade_category_var, 
                                        values=CONFIG['CASCADE_CATEGORIES'], state="readonly", 
                                        width=15)
        category_dropdown.pack(side=tk.LEFT, padx=(0, 10))
        
        tk.Button(cascade_card_header, text='⚙️ Edit Passes', command=self.edit_cascade_config,
                 bg=CONFIG['COLORS']['button_primary'], fg=CONFIG['COLORS']['text_white'],
                 font=(CONFIG['FONTS']['family_default'], CONFIG['FONTS']['size_small']),
                 relief=tk.FLAT, padx=10, pady=3).pack(side=tk.LEFT)
        
        cascade_card_content = tk.Frame(cascade_card, bg=CONFIG['COLORS']['bg_white'])
        cascade_card_content.pack(fill=tk.BOTH, expand=True, padx=CONFIG['DIMENSIONS']['padding_large'], 
                                 pady=(0, CONFIG['DIMENSIONS']['padding_large']))
        
        # Story prompt input
        tk.Label(cascade_card_content, text=CONFIG['TEXT']['label_story_idea'], font=font_label, 
                bg=CONFIG['COLORS']['bg_white']).pack(anchor=tk.W, pady=(0, CONFIG['DIMENSIONS']['padding_tiny']))
        
        self.cascade_input = tk.Text(cascade_card_content, height=CONFIG['DIMENSIONS']['story_prompt_height'], 
                                     font=font_small, wrap=tk.WORD, bg=CONFIG['COLORS']['bg_input'],
                                     fg=CONFIG['COLORS']['text_primary'], relief=tk.SOLID, bd=1)
        self.cascade_input.pack(fill=tk.X, pady=(0, CONFIG['DIMENSIONS']['padding_large']))
        self.cascade_input.insert("1.0", "A mysterious figure arrives in a small town...")
        
        # Model selection
        tk.Label(cascade_card_content, text=CONFIG['TEXT']['label_select_model_pass'], font=font_label, 
                bg=CONFIG['COLORS']['bg_white']).pack(anchor=tk.W, pady=(0, CONFIG['DIMENSIONS']['padding_small']))
        tk.Label(cascade_card_content, text=CONFIG['TEXT']['label_leave_blank'], font=font_small, 
                foreground=CONFIG['COLORS']['text_muted'], bg=CONFIG['COLORS']['bg_white']).pack(
            anchor=tk.W, pady=(0, CONFIG['DIMENSIONS']['padding_normal']))
        
        # Store cascade selections
        self.cascade_pass_vars = {}
        self.cascade_pass_dropdowns = {}
        self.cascade_pass_max_tokens = {}
        self.model_display_names = {}
        
        # Create 5 pass dropdowns
        for pass_num in range(1, 6):
            pass_frame = tk.Frame(cascade_card_content, bg=CONFIG['COLORS']['bg_white'])
            pass_frame.pack(fill=tk.X, pady=(0, CONFIG['DIMENSIONS']['padding_normal']))
            
            pass_config = CONFIG['CASCADE_PASSES'][pass_num]
            pass_label_text = f"{pass_config['name']} ({pass_config['role']})"
            
            tk.Label(pass_frame, text=pass_label_text, font=font_small, 
                    bg=CONFIG['COLORS']['bg_white']).pack(anchor=tk.W, pady=(0, 3))
            
            var = tk.StringVar(value="None Selected")
            self.cascade_pass_vars[pass_num] = var
            
            dropdown = ttk.Combobox(pass_frame, textvariable=var, state="readonly", 
                                   width=CONFIG['DEFAULTS']['model_display_width'])
            dropdown.pack(fill=tk.X, pady=(0, 5))
            self.cascade_pass_dropdowns[pass_num] = dropdown
            
            # Per-pass tokens row
            tokens_row = tk.Frame(pass_frame, bg=CONFIG['COLORS']['bg_white'])
            tokens_row.pack(fill=tk.X, pady=(0, 3))
            
            tk.Label(tokens_row, text=CONFIG['TEXT']['label_tokens'], font=font_small, 
                    bg=CONFIG['COLORS']['bg_white']).pack(side=tk.LEFT, padx=(0, 5))
            
            # Pass 5 (Polish) gets higher tokens by default
            if pass_num == 5:
                tokens_var = tk.IntVar(value=8000)
                ttk.Spinbox(tokens_row, from_=100, to=32000, textvariable=tokens_var, width=5).pack(side=tk.LEFT, padx=(0, 5))
                tk.Label(tokens_row, text='(higher limits)', font=font_small, 
                        foreground=CONFIG['COLORS']['status_online'], bg=CONFIG['COLORS']['bg_white']).pack(side=tk.LEFT)
            else:
                tokens_var = tk.IntVar(value=CONFIG['DEFAULTS']['cascade_pass_tokens'])
                ttk.Spinbox(tokens_row, from_=100, to=4000, textvariable=tokens_var, width=5).pack(side=tk.LEFT)
            
            self.cascade_pass_max_tokens[pass_num] = tokens_var
        
        # Temperature and buttons
        limiter_frame = tk.Frame(cascade_card_content, bg=CONFIG['COLORS']['bg_white'], relief=tk.FLAT, bd=0)
        limiter_frame.pack(fill=tk.X, pady=(CONFIG['DIMENSIONS']['padding_large'], CONFIG['DIMENSIONS']['padding_normal']))
        
        # Timeout row (above)
        timeout_row = tk.Frame(limiter_frame, bg=CONFIG['COLORS']['bg_white'])
        timeout_row.pack(fill=tk.X, pady=(0, CONFIG['DIMENSIONS']['padding_small']))
        
        tk.Label(timeout_row, text='Server Timeout (Global):', font=font_small, 
                bg=CONFIG['COLORS']['bg_white']).pack(side=tk.LEFT, padx=(0, 5))
        self.timeout_var = tk.IntVar(value=CONFIG['API']['timeout_chat'])
        ttk.Spinbox(timeout_row, from_=30, to=600, increment=30, textvariable=self.timeout_var, width=8).pack(side=tk.LEFT, padx=(0, 5))
        tk.Label(timeout_row, text='(30-600 seconds)', font=font_small, 
                foreground=CONFIG['COLORS']['text_muted'], bg=CONFIG['COLORS']['bg_white']).pack(side=tk.LEFT)
        
        # Temperature row (below)
        settings_row = tk.Frame(limiter_frame, bg=CONFIG['COLORS']['bg_white'])
        settings_row.pack(fill=tk.X, pady=(CONFIG['DIMENSIONS']['padding_small'], CONFIG['DIMENSIONS']['padding_small']))
        
        left_frame = tk.Frame(settings_row, bg=CONFIG['COLORS']['bg_white'])
        left_frame.pack(side=tk.LEFT, fill=tk.X, expand=True)
        
        tk.Label(left_frame, text=CONFIG['TEXT']['label_temp_global'], font=font_small, 
                bg=CONFIG['COLORS']['bg_white']).pack(side=tk.LEFT, padx=(0, 5))
        self.cascade_temp_var = tk.DoubleVar(value=CONFIG['DEFAULTS']['cascade_temperature'])
        ttk.Spinbox(left_frame, from_=0.0, to=2.0, increment=0.1, textvariable=self.cascade_temp_var, width=8).pack(
            side=tk.LEFT, padx=(0, 15))
        tk.Label(left_frame, text=CONFIG['TEXT']['label_temp_range'], font=font_small, 
                foreground=CONFIG['COLORS']['text_muted'], bg=CONFIG['COLORS']['bg_white']).pack(side=tk.LEFT)
        
        right_frame = tk.Frame(settings_row, bg=CONFIG['COLORS']['bg_white'])
        right_frame.pack(side=tk.RIGHT, fill=tk.X)
        
        tk.Button(right_frame, text=CONFIG['TEXT']['btn_generate'], command=self.start_cascade, 
                 bg=CONFIG['COLORS']['status_online'], fg=CONFIG['COLORS']['text_white'], 
                 font=font_btn_small).pack(side=tk.LEFT, padx=(0, 5))
        tk.Button(right_frame, text=CONFIG['TEXT']['btn_clear_all'], command=self.clear_cascade, 
                 bg=CONFIG['COLORS']['button_red'], fg=CONFIG['COLORS']['text_white'], 
                 font=font_btn_small).pack(side=tk.LEFT)
        
        # Output section
        tk.Label(cascade_card_content, text=CONFIG['TEXT']['label_pass_polished'], font=font_label, 
                bg=CONFIG['COLORS']['bg_white']).pack(anchor=tk.W, pady=(0, CONFIG['DIMENSIONS']['padding_small']))
        
        cascade_output_frame = tk.Frame(cascade_card_content, bg=CONFIG['COLORS']['bg_white'], relief=tk.SOLID, bd=1)
        cascade_output_frame.pack(fill=tk.BOTH, expand=False, pady=(0, CONFIG['DIMENSIONS']['padding_normal']))
        
        self.cascade_output = tk.Text(cascade_output_frame, height=CONFIG['DIMENSIONS']['cascade_output_height'], 
                                      font=(CONFIG['FONTS']['family_mono'], CONFIG['FONTS']['size_small']),
                                      wrap=tk.WORD, bg=CONFIG['COLORS']['bg_secondary'],
                                      fg=CONFIG['COLORS']['text_primary'], relief=tk.SOLID, bd=0, state=tk.DISABLED)
        self.cascade_output.pack(fill=tk.BOTH, expand=True)
        
        cascade_btn_frame = tk.Frame(cascade_card_content, bg=CONFIG['COLORS']['bg_white'])
        cascade_btn_frame.pack(fill=tk.X)
        tk.Button(cascade_btn_frame, text=CONFIG['TEXT']['btn_copy_output'], command=self.copy_cascade_output, 
                 bg=CONFIG['COLORS']['button_primary'], fg=CONFIG['COLORS']['text_white'], 
                 font=font_btn_small).pack(side=tk.LEFT, padx=(0, 3))
        tk.Button(cascade_btn_frame, text=CONFIG['TEXT']['btn_save_story'], command=self.save_cascade_story, 
                 bg=CONFIG['COLORS']['button_primary'], fg=CONFIG['COLORS']['text_white'], 
                 font=font_btn_small).pack(side=tk.LEFT)
        
        self.cascade_running = False
        self.logs_listbox = None
        self.model_display_names = {}
        
        # ===== SUPERVISOR OVERSIGHT PANEL (Card 3) =====
        supervisor_card = tk.Frame(
            scrollable_frame, bg=CONFIG['COLORS']['bg_white'], relief=CONFIG['DIMENSIONS']['card_relief'], bd=0,
            highlightthickness=CONFIG['DIMENSIONS']['card_border_width'], highlightbackground=CONFIG['COLORS']['border_light'],
            highlightcolor=CONFIG['COLORS']['border_light']
        )
        supervisor_card.pack(fill=tk.BOTH, expand=False, padx=CONFIG['DIMENSIONS']['padding_normal'], 
                             pady=(0, CONFIG['DIMENSIONS']['padding_large']))
        
        # Card header
        supervisor_header = tk.Frame(supervisor_card, bg=CONFIG['COLORS']['bg_white'])
        supervisor_header.pack(fill=tk.X, padx=CONFIG['DIMENSIONS']['padding_large'], 
                               pady=(CONFIG['DIMENSIONS']['padding_large'], CONFIG['DIMENSIONS']['padding_normal']))
        
        tk.Label(supervisor_header, text="Supervisor Analysis", font=font_header, 
                background=CONFIG['COLORS']['bg_white']).pack(anchor=tk.W, side=tk.LEFT)
        
        self.supervisor_rating_label = tk.Label(supervisor_header, text="Rating: —", 
                                                font=(CONFIG['FONTS']['family_mono'], CONFIG['FONTS']['size_small'], 'bold'),
                                                background=CONFIG['COLORS']['bg_white'], 
                                                foreground=CONFIG['COLORS']['text_muted'])
        self.supervisor_rating_label.pack(anchor=tk.E, side=tk.RIGHT, padx=(10, 0))
        
        # Card content
        supervisor_content = tk.Frame(supervisor_card, bg=CONFIG['COLORS']['bg_white'])
        supervisor_content.pack(fill=tk.BOTH, expand=True, padx=CONFIG['DIMENSIONS']['padding_large'], 
                               pady=(0, CONFIG['DIMENSIONS']['padding_large']))
        
        # Supervisor model selector
        tk.Label(supervisor_content, text="Select Supervisor Model:", font=font_label, 
                bg=CONFIG['COLORS']['bg_white']).pack(anchor=tk.W, pady=(0, CONFIG['DIMENSIONS']['padding_small']))
        
        self.supervisor_pass_var = tk.StringVar(value="None Selected")
        self.supervisor_dropdown = ttk.Combobox(supervisor_content, textvariable=self.supervisor_pass_var, 
                                               state="readonly", width=CONFIG['DEFAULTS']['model_display_width'])
        self.supervisor_dropdown.pack(fill=tk.X, pady=(0, CONFIG['DIMENSIONS']['padding_normal']))
        
        # Supervisor output box
        tk.Label(supervisor_content, text="Analysis & Recommendation:", font=font_label, 
                bg=CONFIG['COLORS']['bg_white']).pack(anchor=tk.W, pady=(0, CONFIG['DIMENSIONS']['padding_small']))
        
        supervisor_output_frame = tk.Frame(supervisor_content, bg=CONFIG['COLORS']['bg_white'], relief=tk.SOLID, bd=1)
        supervisor_output_frame.pack(fill=tk.BOTH, expand=True, pady=(0, CONFIG['DIMENSIONS']['padding_normal']))
        
        self.supervisor_output = tk.Text(supervisor_output_frame, height=6, 
                                         font=(CONFIG['FONTS']['family_mono'], CONFIG['FONTS']['size_small']),
                                         wrap=tk.WORD, bg=CONFIG['COLORS']['bg_secondary'],
                                         fg=CONFIG['COLORS']['text_primary'], relief=tk.SOLID, bd=0, state=tk.DISABLED)
        self.supervisor_output.pack(fill=tk.BOTH, expand=True)
        
        # ===== RESEARCH MODE (Card 4) — document-grounded research loop =====
        research_card = tk.Frame(
            scrollable_frame, bg=CONFIG['COLORS']['bg_white'], relief=CONFIG['DIMENSIONS']['card_relief'], bd=0,
            highlightthickness=CONFIG['DIMENSIONS']['card_border_width'], highlightbackground=CONFIG['COLORS']['border_light'],
            highlightcolor=CONFIG['COLORS']['border_light']
        )
        research_card.pack(fill=tk.BOTH, expand=False, padx=CONFIG['DIMENSIONS']['padding_normal'], 
                           pady=(0, CONFIG['DIMENSIONS']['padding_large']))
        
        # Card header: title + live status, right-aligned (same pattern as other cards)
        research_header = tk.Frame(research_card, bg=CONFIG['COLORS']['bg_white'])
        research_header.pack(fill=tk.X, padx=CONFIG['DIMENSIONS']['padding_large'], 
                             pady=(CONFIG['DIMENSIONS']['padding_large'], CONFIG['DIMENSIONS']['padding_normal']))
        
        tk.Label(research_header, text=CONFIG['TEXT']['card_research'], font=font_header, 
                background=CONFIG['COLORS']['bg_white']).pack(anchor=tk.W, side=tk.LEFT)
        
        self.research_status_label = tk.Label(
            research_header, text=f"{CONFIG['TEXT']['status_research_stopped']} — Round 0 · 0 claims",
            font=(CONFIG['FONTS']['family_mono'], CONFIG['FONTS']['size_small'], 'bold'),
            background=CONFIG['COLORS']['bg_white'], foreground=CONFIG['COLORS']['status_offline']
        )
        self.research_status_label.pack(anchor=tk.E, side=tk.RIGHT)
        
        # Card content
        research_content = tk.Frame(research_card, bg=CONFIG['COLORS']['bg_white'])
        research_content.pack(fill=tk.BOTH, expand=True, padx=CONFIG['DIMENSIONS']['padding_large'], 
                              pady=(0, CONFIG['DIMENSIONS']['padding_large']))
        
        # Source folder row
        folder_row = tk.Frame(research_content, bg=CONFIG['COLORS']['bg_white'])
        folder_row.pack(fill=tk.X, pady=(0, CONFIG['DIMENSIONS']['padding_normal']))
        
        tk.Button(folder_row, text=CONFIG['TEXT']['btn_load_folder'], command=self.load_research_folder,
                 bg=CONFIG['COLORS']['button_primary'], fg=CONFIG['COLORS']['text_white'],
                 font=font_btn_small, relief=tk.FLAT, padx=10, pady=3).pack(side=tk.LEFT, padx=(0, 6))
        
        tk.Button(folder_row, text=CONFIG['TEXT']['btn_load_files'], command=self.load_research_files,
                 bg=CONFIG['COLORS']['button_primary'], fg=CONFIG['COLORS']['text_white'],
                 font=font_btn_small, relief=tk.FLAT, padx=10, pady=3).pack(side=tk.LEFT, padx=(0, 10))
        
        self.research_folder_label = tk.Label(folder_row, text=CONFIG['TEXT']['text_no_folder_loaded'],
                                              font=font_small, foreground=CONFIG['COLORS']['text_muted'],
                                              bg=CONFIG['COLORS']['bg_white'])
        self.research_folder_label.pack(side=tk.LEFT)
        
        # Topic input
        tk.Label(research_content, text=CONFIG['TEXT']['label_research_topic'], font=font_label,
                bg=CONFIG['COLORS']['bg_white']).pack(anchor=tk.W, pady=(0, CONFIG['DIMENSIONS']['padding_tiny']))
        
        topic_entry = tk.Entry(research_content, textvariable=self.research_topic_var, font=font_small,
                               bg=CONFIG['COLORS']['bg_input'], relief=tk.SOLID, bd=1)
        topic_entry.pack(fill=tk.X, pady=(0, CONFIG['DIMENSIONS']['padding_normal']), ipady=4)
        
        # Model selector
        tk.Label(research_content, text=CONFIG['TEXT']['label_research_model'], font=font_label,
                bg=CONFIG['COLORS']['bg_white']).pack(anchor=tk.W, pady=(0, CONFIG['DIMENSIONS']['padding_tiny']))
        
        self.research_dropdown = ttk.Combobox(research_content, textvariable=self.research_model_var,
                                              state="readonly", width=CONFIG['DEFAULTS']['model_display_width'])
        self.research_dropdown.pack(fill=tk.X, pady=(0, CONFIG['DIMENSIONS']['padding_normal']))
        
        # Control buttons
        research_btn_row = tk.Frame(research_content, bg=CONFIG['COLORS']['bg_white'])
        research_btn_row.pack(fill=tk.X, pady=(0, CONFIG['DIMENSIONS']['padding_normal']))
        
        tk.Button(research_btn_row, text=CONFIG['TEXT']['btn_research_start'], command=self.start_research,
                 bg=CONFIG['COLORS']['status_online'], fg=CONFIG['COLORS']['text_white'],
                 font=font_btn_small).pack(side=tk.LEFT, padx=(0, 5))
        
        self.pause_research_btn = tk.Button(research_btn_row, text=CONFIG['TEXT']['btn_research_pause'],
                                            command=self.pause_research, bg=CONFIG['COLORS']['button_primary'],
                                            fg=CONFIG['COLORS']['text_white'], font=font_btn_small)
        self.pause_research_btn.pack(side=tk.LEFT, padx=(0, 5))
        
        tk.Button(research_btn_row, text=CONFIG['TEXT']['btn_research_stop'], command=self.stop_research,
                 bg=CONFIG['COLORS']['button_red'], fg=CONFIG['COLORS']['text_white'],
                 font=font_btn_small).pack(side=tk.LEFT, padx=(0, 5))
        
        tk.Button(research_btn_row, text=CONFIG['TEXT']['btn_compact_now'], command=self.compact_research_now,
                 bg=CONFIG['COLORS']['button_primary'], fg=CONFIG['COLORS']['text_white'],
                 font=font_btn_small).pack(side=tk.LEFT, padx=(0, 5))
        
        tk.Button(research_btn_row, text=CONFIG['TEXT']['btn_open_knowledge'], command=self.open_knowledge_file,
                 bg=CONFIG['COLORS']['button_primary'], fg=CONFIG['COLORS']['text_white'],
                 font=font_btn_small).pack(side=tk.LEFT)
        
        # Live research log
        tk.Label(research_content, text=CONFIG['TEXT']['label_research_log'], font=font_label,
                bg=CONFIG['COLORS']['bg_white']).pack(anchor=tk.W, pady=(0, CONFIG['DIMENSIONS']['padding_small']))
        
        research_output_frame = tk.Frame(research_content, bg=CONFIG['COLORS']['bg_white'], relief=tk.SOLID, bd=1)
        research_output_frame.pack(fill=tk.BOTH, expand=False)
        
        self.research_output = tk.Text(research_output_frame, height=12,
                                       font=(CONFIG['FONTS']['family_mono'], CONFIG['FONTS']['size_small']),
                                       wrap=tk.WORD, bg=CONFIG['COLORS']['bg_secondary'],
                                       fg=CONFIG['COLORS']['text_primary'], relief=tk.SOLID, bd=0, state=tk.DISABLED)
        self.research_output.pack(fill=tk.BOTH, expand=True)
    
    def switch_tab(self, tab_id):
        """Switch to a different tab"""
        for frame in self.tab_frames.values():
            frame.pack_forget()
        
        if tab_id in self.tab_frames:
            self.tab_frames[tab_id].pack(fill=tk.BOTH, expand=True)
            self.current_tab = tab_id
            self.update_tab_appearance()
    
    def update_tab_appearance(self):
        """Update tab button styling"""
        for tab_id, btn in self.tab_buttons.items():
            if tab_id == self.current_tab:
                btn.config(bg=CONFIG['COLORS']['tab_active'], fg=CONFIG['COLORS']['text_white'])
            else:
                btn.config(bg=CONFIG['COLORS']['tab_inactive'], fg=CONFIG['COLORS']['text_primary'])
    
    def _initialize_log_file(self):
        """Create or append to log file"""
        try:
            with open(self.log_file_path, 'a', encoding='utf-8') as f:
                f.write(f"\n{'='*60}\nSession started: {datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n{'='*60}\n")
        except OSError:
            pass
    
    def show_file_menu(self):
        """Show File menu"""
        menu = tk.Menu(self.root, tearoff=0)
        menu.add_command(label=CONFIG['TEXT']['btn_settings'], command=self.open_settings)
        menu.add_separator()
        menu.add_command(label=CONFIG['TEXT']['btn_view_log'], command=self.open_log_file)
        menu.add_separator()
        menu.add_command(label=CONFIG['TEXT']['btn_exit'], command=self.exit_app)
        
        try:
            menu.post(self.root.winfo_x(), self.root.winfo_y() + 50)
        except tk.TclError:
            pass
    
    def exit_app(self):
        """Clean exit"""
        self.add_log("Application closing", "SYSTEM")
        self.save_settings()
        self.root.quit()
    
    def edit_cascade_config(self):
        """Open the cascade config in text editor"""
        try:
            script_path = os.path.abspath(__file__)
            if os.name == 'nt':
                # Windows - open with Notepad
                os.system(f'notepad "{script_path}"')
            elif os.uname().sysname == 'Darwin':
                # macOS - open with TextEdit
                os.system(f'open -a TextEdit "{script_path}"')
            else:
                # Linux - open with gedit or nano
                os.system(f'gedit "{script_path}" &')
            self.add_log("Opened config file for editing", "INFO")
        except Exception as e:
            messagebox.showerror(CONFIG['TEXT']['popup_error'], 
                                f"Could not open config file:\n{str(e)}")
            self.add_log(f"Error opening config: {str(e)}", "ERROR")
    
    def load_settings(self):
        """Load settings from file"""
        try:
            if os.path.exists(self.settings_file):
                import json
                with open(self.settings_file, 'r', encoding='utf-8') as f:
                    saved_settings = json.load(f)
                    self.settings.update(saved_settings)
                self.api_base = self.settings['api_base']
        except (OSError, json.JSONDecodeError, KeyError) as e:
            self.add_log(f"Could not load settings, using defaults: {str(e)}", "WARNING")
    
    def save_settings(self):
        """Save settings to file"""
        try:
            import json
            with open(self.settings_file, 'w', encoding='utf-8') as f:
                json.dump(self.settings, f, indent=2)
            self.add_log("Settings saved", "INFO")
        except Exception as e:
            self.add_log(f"Error saving settings: {str(e)}", "ERROR")
    
    def open_settings(self):
        """Open settings window"""
        settings_win = tk.Toplevel(self.root)
        settings_win.title(CONFIG['TEXT']['settings_title'])
        w, h = CONFIG['DIMENSIONS']['settings_width'], CONFIG['DIMENSIONS']['settings_height']
        settings_win.geometry(f"{w}x{h}")
        settings_win.resizable(False, False)
        settings_win.grab_set()
        
        # Center on parent
        self.root.update_idletasks()
        x = self.root.winfo_x() + (self.root.winfo_width() // 2) - (w // 2)
        y = self.root.winfo_y() + (self.root.winfo_height() // 2) - (h // 2)
        settings_win.geometry(f"+{x}+{y}")
        
        # Note: Settings UI simplified for space - full version has all color picker fields
        # The key improvement is that all TEXT and COLORS/DIMENSIONS reference CONFIG
        
        messagebox.showinfo(CONFIG['TEXT']['popup_info'], 
                           "Settings panel customizable via CONFIG dictionary at top of code.\n"
                           "Edit colors, text, dimensions, and API endpoints there.")
        settings_win.destroy()
    
    def open_log_file(self):
        """Open log file"""
        if not os.path.exists(self.log_file_path):
            messagebox.showwarning(CONFIG['TEXT']['popup_warning'], 
                                  f"{CONFIG['TEXT']['msg_no_log']}\n{self.log_file_path}")
            return
        
        try:
            if os.name == 'nt':
                os.startfile(self.log_file_path)
            else:
                os.system(f'open "{self.log_file_path}"')
            self.add_log("Opened log file", "INFO")
        except Exception as e:
            messagebox.showerror(CONFIG['TEXT']['popup_error'], f"Could not open log:\n{str(e)}")
            self.add_log(f"Error opening log: {str(e)}", "ERROR")
    
    def add_log(self, message, log_type="INFO"):
        """Add log message"""
        timestamp = datetime.datetime.now().strftime("%H:%M:%S")
        log_entry = f"[{timestamp}] {log_type}: {message}"
        self.error_log.append(log_entry)
        
        try:
            with open(self.log_file_path, 'a', encoding='utf-8') as f:
                f.write(log_entry + "\n")
        except OSError:
            pass
        
        if len(self.error_log) > 1000:
            self.error_log.pop(0)
    
    def run_startup_checks(self):
        """Run startup checks"""
        splash = LoadingSplash(self.root)
        self.add_log("Starting application...", "SYSTEM")
        
        def startup_thread():
            self.is_connected = self.check_connection()
            self.refresh_models()
            # splash.close() and deiconify() touch Tkinter widgets — this
            # function runs on a background thread, so marshal them onto
            # the main thread instead of calling them directly.
            def finish_startup():
                splash.close()
                self.root.deiconify()
            self.root.after(0, finish_startup)

        thread = threading.Thread(target=startup_thread, daemon=True)
        thread.start()
    
    def update_resolution(self, event=None):
        """Update resolution display"""
        width = self.root.winfo_width()
        height = self.root.winfo_height()
        if width > 1 and height > 1:
            self.resolution_label.config(text=f"{width}x{height}")
    
    def toggle_window_lock(self):
        """Toggle window lock"""
        self.window_locked = not self.window_locked
        self.root.resizable(not self.window_locked, not self.window_locked)
        self.lock_button.config(text="🔒" if self.window_locked else "🔓")
    
    def refresh_models(self):
        """Fetch available models. Safe to call from any thread — this method
        itself may run on a background thread (e.g. startup), so all widget
        updates are marshalled onto the main thread via root.after()."""
        try:
            response = requests.get(f"{self.api_base}{CONFIG['API']['models_endpoint']}",
                                   timeout=CONFIG['API']['timeout_models'])
            if response.status_code == 200:
                data = response.json()
                models = data.get("models", [])

                self.model_keys = {}

                llm_models = [m for m in models if m.get("type") == "llm"]

                if llm_models:
                    for idx, model in enumerate(llm_models):
                        key = model.get("key", "unknown")
                        self.model_keys[idx] = key
                    self.root.after(0, lambda: self.lms_count_label.config(text=str(len(llm_models))))
                    self.add_log(f"Loaded {len(llm_models)} models", "INFO")
                else:
                    self.root.after(0, lambda: self.lms_count_label.config(text="0"))
                    self.add_log("No LLM models found", "WARNING")

                self.update_cascade_models()
            else:
                self.root.after(0, lambda: self.lms_count_label.config(text="0"))
                self.add_log(f"Failed to load models: {response.status_code}", "ERROR")
        except Exception as e:
            self.root.after(0, lambda: self.lms_count_label.config(text="0"))
            self.add_log(f"Error fetching models: {str(e)}", "ERROR")
    
    def on_model_select(self, event):
        """Handle model selection"""
        if self.loading_model:
            return
        
        idx = self.models_listbox.nearest(event.y)
        if idx >= 0:
            model_key = self.model_keys.get(idx)
            if model_key:
                self.load_model(model_key)
    
    def load_model(self, model_key):
        """Load a model"""
        if not model_key:
            messagebox.showerror(CONFIG['TEXT']['popup_error'], CONFIG['TEXT']['msg_no_model_identified'])
            self.add_log("Failed to identify model", "ERROR")
            return
        
        self.loading_model = True
        
        try:
            response = requests.post(
                f"{self.api_base}{CONFIG['API']['load_model_endpoint']}",
                json={"model": model_key},
                timeout=CONFIG['API']['timeout_load']
            )
            
            if response.status_code == 200:
                self.current_model = model_key
                self.check_connection()
                messagebox.showinfo(CONFIG['TEXT']['popup_success'], f"Model loaded: {model_key}")
                self.add_log(f"Model loaded: {model_key}", "INFO")
            else:
                messagebox.showerror(CONFIG['TEXT']['popup_error'], 
                                    f"{CONFIG['TEXT']['error_failed_load']}{response.status_code}")
                self.add_log(f"Failed to load model: {response.status_code}", "ERROR")
        except Exception as e:
            messagebox.showerror(CONFIG['TEXT']['popup_error'], f"{CONFIG['TEXT']['error_load_model']}\n{str(e)}")
            self.add_log(f"Error loading model: {str(e)}", "ERROR")
        finally:
            self.loading_model = False
    
    def refresh_script(self):
        """Refresh connection"""
        self.check_connection()
        self.refresh_models()
        self.add_log("Script refreshed", "INFO")
    
    def restart_script(self):
        """Restart application"""
        if messagebox.askyesno(CONFIG['TEXT']['popup_info'], CONFIG['TEXT']['msg_restart_confirm']):
            self.root.quit()
            subprocess.Popen([sys.executable, sys.argv[0]])
            sys.exit()
    
    def check_connection(self):
        """Check LM Studio connection. Safe to call from any thread — this
        method itself may run on a background thread (e.g. startup), so all
        widget updates are marshalled onto the main thread via root.after()."""
        try:
            response = requests.get(f"{self.api_base}{CONFIG['API']['models_endpoint']}",
                                   timeout=CONFIG['API']['timeout_connect'])
            self.root.after(0, lambda: self.status_label.config(
                text=CONFIG['TEXT']['status_connected'], foreground=CONFIG['COLORS']['status_online']))
            self.add_log("Connected to LM Studio", "INFO")

            if response.status_code == 200:
                data = response.json()
                models = data.get("models", [])
                llm_models = [m for m in models if m.get("type") == "llm"]
                self.root.after(0, lambda: self.lms_count_label.config(text=str(len(llm_models))))
            return True
        except Exception as e:
            self.root.after(0, lambda: self.status_label.config(
                text=CONFIG['TEXT']['status_disconnected'], foreground=CONFIG['COLORS']['status_offline']))
            self.root.after(0, lambda: self.lms_count_label.config(text="0"))
            self.add_log(f"Lost connection to LM Studio: {str(e)}", "ERROR")
            return False
    
    def update_system_resources(self):
        """Periodically update system resources"""
        def resource_thread():
            try:
                ram_info = psutil.virtual_memory()
                ram_used = ram_info.used / (1024**3)
                ram_total = ram_info.total / (1024**3)
                ram_percent = ram_info.percent
                
                vram_used = None
                vram_total = None
                try:
                    import subprocess
                    result = subprocess.run(
                        ['nvidia-smi', '--query-gpu=memory.used,memory.total', '--format=csv,nounits,noheader'],
                        capture_output=True, text=True, timeout=2
                    )
                    if result.returncode == 0:
                        parts = result.stdout.strip().split(',')
                        if len(parts) == 2:
                            vram_used = float(parts[0].strip()) / 1024
                            vram_total = float(parts[1].strip()) / 1024
                except Exception:
                    pass  # nvidia-smi not available — GPU memory stats just won't be shown
                
                self.root.after(0, self._update_resource_ui, ram_used, ram_total, ram_percent, vram_used, vram_total)
            except Exception as e:
                self.add_log(f"Error getting system resources: {str(e)}", "ERROR")
        
        thread = threading.Thread(target=resource_thread, daemon=True)
        thread.start()
        self.root.after(2000, self.update_system_resources)
    
    def _update_resource_ui(self, ram_used, ram_total, ram_percent, vram_used, vram_total):
        """Update resource display"""
        try:
            if ram_used is not None:
                ram_text = f"{ram_used:.1f} GB / {ram_total:.1f} GB ({ram_percent:.0f}%)"
                self.ram_label.config(text=ram_text)
            
            if vram_used is not None and vram_total is not None:
                vram_percent = (vram_used / vram_total) * 100
                vram_text = f"{vram_used:.1f} GB / {vram_total:.1f} GB ({vram_percent:.0f}%)"
                self.vram_label.config(text=vram_text)
                
                total_used = vram_used + ram_used
                total_available = vram_total + ram_total
                total_percent = (total_used / total_available) * 100
                total_text = f"{total_used:.1f} GB / {total_available:.1f} GB ({total_percent:.0f}%)"
                self.total_label.config(text=total_text)
            else:
                self.vram_label.config(text="N/A (nvidia-smi not found)")
                if ram_used is not None:
                    total_text = f"{ram_used:.1f} GB / {ram_total:.1f} GB ({ram_percent:.0f}%)"
                    self.total_label.config(text=total_text)
        except Exception as e:
            self.add_log(f"Error updating resource display: {str(e)}", "ERROR")
    
    
    def update_cascade_models(self):
        """Update cascade model dropdowns. Safe to call from any thread —
        this method itself may run on a background thread (e.g. startup), so
        all widget updates are marshalled onto the main thread via
        root.after()."""
        try:
            response = requests.get(f"{self.api_base}{CONFIG['API']['models_endpoint']}",
                                   timeout=CONFIG['API']['timeout_models'])
            if response.status_code == 200:
                data = response.json()
                models = data.get("models", [])
                llm_models = [m for m in models if m.get("type") == "llm"]

                model_options = ["None Selected"]
                self.model_display_names = {}

                for model in llm_models:
                    display_name = model.get("display_name", "Unknown")
                    key = model.get("key", "unknown")
                    quantization = model.get("quantization", {}).get("name", "")
                    display_text = f"{display_name} ({quantization})" if quantization else display_name

                    model_options.append(display_text)
                    self.model_display_names[display_text] = key

                def update_dropdowns():
                    for pass_num in range(1, 6):
                        if pass_num in self.cascade_pass_dropdowns:
                            self.cascade_pass_dropdowns[pass_num]['values'] = model_options

                    # Update supervisor dropdown
                    if hasattr(self, 'supervisor_dropdown'):
                        self.supervisor_dropdown['values'] = model_options

                    # Update research dropdown
                    if hasattr(self, 'research_dropdown'):
                        self.research_dropdown['values'] = model_options
                self.root.after(0, update_dropdowns)
        except Exception as e:
            self.add_log(f"Error updating cascade models: {str(e)}", "ERROR")
    
    def _get_supervisor_rating(self, current_story, pass_num):
        """Get supervisor analysis and rating"""
        supervisor_model = self.supervisor_pass_var.get()
        if supervisor_model == "None Selected":
            return None
        
        supervisor_model_key = self.model_display_names.get(supervisor_model)
        if not supervisor_model_key:
            self.add_log(f"Supervisor model '{supervisor_model}' not found in available models", "ERROR")
            return None
        
        rating_prompt = CONFIG['CASCADE_PASSES']['SUPERVISOR']['rating_template'].format(
            story=current_story[:1500]  # Limit context for rating
        )
        
        try:
            response = requests.post(
                f"{self.api_base}{CONFIG['API']['chat_endpoint']}",
                json={
                    "model": supervisor_model_key,
                    "messages": [{"role": "user", "content": rating_prompt}],
                    "temperature": 0.5,  # Low temp for consistent ratings
                    "max_tokens": 300
                },
                timeout=self.timeout_var.get()
            )
            
            if response.status_code == 200:
                result = response.json()
                analysis = result['choices'][0]['message']['content']
                
                # Extract numeric rating from response
                lines = analysis.split('\n')
                rating = None
                for line in lines:
                    if 'Average rating:' in line or 'rating:' in line.lower():
                        # Try to extract the number
                        match = re.search(r'(\d+\.?\d*)\s*/?10', line)
                        if match:
                            rating = float(match.group(1))
                            break

                if rating is None:
                    self.add_log("Could not extract rating from supervisor response", "WARNING")
                    rating = 0

                return {
                    'analysis': analysis,
                    'rating': rating,
                    'model': supervisor_model
                }
        except Exception as e:
            self.add_log(f"Supervisor error: {str(e)}", "ERROR")
        
        return None
    
    def _display_supervisor_analysis(self, analysis_data):
        """Display the Pass 6 supervisor analysis (final polished story) in the output box"""
        if not analysis_data:
            return
        
        analysis_text = analysis_data['analysis']
        rating = analysis_data['rating']
        model = analysis_data['model']
        
        # Update output box
        self.supervisor_output.config(state=tk.NORMAL)
        self.supervisor_output.delete("1.0", tk.END)
        
        header = f"Pass 6 (Supervisor Rating) — Rated by {model}\n{'─' * 50}\n\n"
        self.supervisor_output.insert(tk.END, header)
        self.supervisor_output.insert(tk.END, analysis_text)
        self.supervisor_output.config(state=tk.DISABLED)
        
        # Update rating display with color coding
        if rating >= 8.0:
            color = CONFIG['COLORS']['status_online']  # Green
            status = "EXCELLENT"
        elif rating >= 6.0:
            color = CONFIG['COLORS']['button_green']  # Yellow-ish
            status = "GOOD"
        else:
            color = CONFIG['COLORS']['text_error']  # Red
            status = "FLAG"
        
        self.supervisor_rating_label.config(
            text=f"Rating: {rating:.1f}/10 [{status}]",
            foreground=color
        )
        
        self.add_log(f"Pass 6 supervisor rating (final story): {rating:.1f}/10", "INFO")
    
    def start_cascade(self):
        """Start cascade refinement"""
        if self.cascade_running:
            messagebox.showwarning(CONFIG['TEXT']['popup_warning'], CONFIG['TEXT']['msg_in_progress'])
            return
        
        selected_passes = []
        for pass_num in range(1, 6):
            model_display = self.cascade_pass_vars[pass_num].get()
            if model_display != "None Selected":
                model_key = self.model_display_names.get(model_display)
                if model_key:
                    selected_passes.append((pass_num, model_display, model_key))
                else:
                    self.add_log(f"Pass {pass_num} model '{model_display}' not found in available models — skipping", "ERROR")
        
        if not selected_passes:
            messagebox.showwarning(CONFIG['TEXT']['popup_warning'], CONFIG['TEXT']['msg_no_models_cascade'])
            self.add_log(CONFIG['TEXT']['error_cascade_no_models'], "WARNING")
            return
        
        story_prompt = self.cascade_input.get("1.0", tk.END).strip()
        if not story_prompt:
            messagebox.showwarning(CONFIG['TEXT']['popup_warning'], CONFIG['TEXT']['msg_empty_prompt'])
            self.add_log(CONFIG['TEXT']['error_cascade_empty'], "WARNING")
            return
        
        self.cascade_output.config(state=tk.NORMAL)
        self.cascade_output.delete("1.0", tk.END)
        self.cascade_output.config(state=tk.DISABLED)
        
        self.cascade_running = True
        self.add_log(f"Starting 5-pass cascade with {len(selected_passes)} models", "INFO")
        
        def _append_output(text):
            """Thread-safe append to cascade output — called from the cascade
            background thread, so the actual widget mutation is marshalled
            onto the main thread via root.after()."""
            def update_widget():
                self.cascade_output.config(state=tk.NORMAL)
                self.cascade_output.insert(tk.END, text)
                self.cascade_output.see(tk.END)
                self.cascade_output.config(state=tk.DISABLED)
            self.root.after(0, update_widget)

        def _set_output(text):
            """Thread-safe replace cascade output — see _append_output."""
            def update_widget():
                self.cascade_output.config(state=tk.NORMAL)
                self.cascade_output.delete("1.0", tk.END)
                self.cascade_output.insert(tk.END, text)
                self.cascade_output.see("1.0")
                self.cascade_output.config(state=tk.DISABLED)
            self.root.after(0, update_widget)
        
        def _format_validation_report(pass_num, pass_role, validation_result):
            """Format constraint validation results as readable report"""
            lines = []
            lines.append(f"{'─' * 50}")
            lines.append(f"  Constraint Engine — Pass {pass_num} ({pass_role}) Validation")
            lines.append(f"{'─' * 50}")
            
            total_time = 0
            fixes_applied = 0
            
            for entry in validation_result.get('log', []):
                name = entry['constraint']
                passed = entry['passed']
                ms = entry.get('duration_ms', 0)
                fixed = entry.get('fixed', False)
                phase = entry.get('phase', 'unknown')
                total_time += ms
                
                if fixed:
                    fixes_applied += 1
                    icon = "🔧"
                    status = "FIXED"
                elif passed:
                    icon = "✓"
                    status = "passed"
                else:
                    icon = "✗"
                    status = "FAILED"
                
                phase_tag = "S" if phase == "separate" else "C"
                lines.append(f"  {icon} [{phase_tag}] {name}: {status} ({ms:.2f}ms)")
            
            # Summary line
            success = validation_result.get('success', False)
            total_constraints = len(validation_result.get('log', []))
            summary_icon = "✓" if success else "✗"
            lines.append(f"{'─' * 50}")
            lines.append(f"  {summary_icon} {total_constraints} constraints checked in {total_time:.2f}ms | {fixes_applied} fixes applied")
            
            if not success:
                failed_at = validation_result.get('failed_at', 'unknown')
                lines.append(f"  ⚠ HALTED at: {failed_at}")
            
            lines.append(f"{'─' * 50}\n")
            return "\n".join(lines)
        
        def cascade_thread():
            try:
                current_story = story_prompt
                total_tokens = 0
                
                # Show engine status at start
                if self.engine_loaded and self.engine_enabled_var.get():
                    desc = self.engine.describe()
                    _append_output(f"Constraint Engine: {len(desc['separate'])} separate, {len(desc['collective'])} collective constraints active\n\n")
                elif self.engine_loaded and not self.engine_enabled_var.get():
                    _append_output("⏸ Constraint Engine loaded but disabled — running without validation\n\n")
                else:
                    _append_output("⚠ Constraint Engine not loaded — running without validation\n\n")
                
                supervisor_enabled = self.supervisor_pass_var.get() != "None Selected"
                
                for pass_idx, (pass_num, model_name, model_key) in enumerate(selected_passes):
                    pass_config = CONFIG['CASCADE_PASSES'].get(pass_num)
                    if not pass_config:
                        error_msg = f"Invalid pass number: {pass_num}"
                        _append_output(f"❌ {error_msg}\n")
                        self.add_log(error_msg, "ERROR")
                        continue
                    is_last_pass = (pass_idx == len(selected_passes) - 1)
                    
                    self.current_pass_num = pass_num
                    
                    # Show pass header
                    _append_output(f"▶ Pass {pass_num} ({pass_config['role']}): {model_name}\n")
                    _append_output(f"  Sending to LM Studio...\n")
                    self.add_log(f"Pass {pass_num}/{len(selected_passes)}: {model_name}", "INFO")
                    
                    refine_prompt = pass_config['prompt_template'].format(story=current_story)
                    
                    response = requests.post(
                        f"{self.api_base}{CONFIG['API']['chat_endpoint']}",
                        json={
                            "model": model_key,
                            "messages": [{"role": "user", "content": refine_prompt}],
                            "temperature": self.cascade_temp_var.get(),
                            "max_tokens": self.cascade_pass_max_tokens[pass_num].get()
                        },
                        timeout=self.timeout_var.get()
                    )
                    
                    if response.status_code == 200:
                        result = response.json()
                        current_story = result['choices'][0]['message']['content']
                        
                        if 'usage' in result:
                            tokens_used = result['usage'].get('total_tokens', 0)
                            total_tokens += tokens_used
                            self.reasoning_tokens = tokens_used
                            self.session_tokens += tokens_used
                        
                        _append_output(f"  ✓ Response received ({len(current_story)} chars)\n")
                        
                        # === CONSTRAINT VALIDATION ===
                        if self.engine_loaded and self.engine and self.engine_enabled_var.get():
                            _append_output(f"  Running constraint validation...\n")
                            
                            validation_result = self.engine.validate(current_story, auto_fix=True)
                            report = _format_validation_report(pass_num, pass_config['role'], validation_result)
                            _append_output(report)
                            
                            # Use the (potentially fixed) data
                            if validation_result.get('success') and 'data' in validation_result:
                                current_story = validation_result['data']
                            
                            # Log validation outcome
                            if validation_result.get('success'):
                                fixes = sum(1 for e in validation_result.get('log', []) if e.get('fixed'))
                                self.add_log(f"Pass {pass_num} validation: PASSED ({fixes} fixes)", "INFO")
                            else:
                                failed = validation_result.get('failed_at', 'unknown')
                                self.add_log(f"Pass {pass_num} validation: FAILED at {failed}", "WARNING")
                        
                        # Feed to next pass, or show the final polished story
                        if not is_last_pass:
                            _append_output(f"  ➜ Feeding validated output to next pass...\n\n")
                        else:
                            # Final pass — show the polished story
                            _append_output(f"\n{'═' * 50}\n")
                            _append_output(f"  FINAL OUTPUT (Pass {pass_num} — {pass_config['role']})\n")
                            _append_output(f"{'═' * 50}\n\n")
                            _append_output(current_story)
                        
                    else:
                        error_msg = f"API Error ({response.status_code}) from {model_name} (Pass {pass_num})"
                        _append_output(f"\n❌ {error_msg}\n")
                        self.add_log(error_msg, "ERROR")
                        break
                
                # === SUPERVISOR RATING — Pass 6, runs once on the finished story ===
                if supervisor_enabled and current_story:
                    _append_output(f"\n{'─' * 50}\n")
                    _append_output(f"▶ Pass 6 (Supervisor Rating): {self.supervisor_pass_var.get()}\n")
                    _append_output(f"  Awaiting supervisor analysis...\n\n")

                    analysis = self._get_supervisor_rating(current_story, 6)
                    
                    if analysis:
                        rating = analysis['rating']
                        self.root.after(0, self._display_supervisor_analysis, analysis)
                        _append_output(f"✓ Supervisor rating: {rating:.1f}/10\n")
                    else:
                        _append_output(f"  ⚠ Supervisor analysis unavailable\n")
                        self.add_log("Pass 6 supervisor analysis unavailable", "WARNING")
                
                self.root.after(0, lambda: self.reasoning_tokens_label.config(text=str(total_tokens)))
                self.root.after(0, lambda: self.session_tokens_label.config(text=str(self.session_tokens)))
                self.add_log(f"Cascade complete: {total_tokens} total tokens", "INFO")
                
            except requests.exceptions.RequestException as e:
                error_msg = f"Connection error: {str(e)}"
                _set_output(f"❌ {error_msg}\n")
                self.add_log(error_msg, "ERROR")
            except Exception as e:
                error_msg = f"Error: {str(e)}"
                _set_output(f"❌ {error_msg}\n")
                self.add_log(error_msg, "ERROR")
            finally:
                self.cascade_running = False
        
        thread = threading.Thread(target=cascade_thread, daemon=True)
        thread.start()
    
    def clear_cascade(self):
        """Clear cascade"""
        self.cascade_input.delete("1.0", tk.END)
        self.cascade_output.config(state=tk.NORMAL)
        self.cascade_output.delete("1.0", tk.END)
        self.cascade_output.config(state=tk.DISABLED)
        for pass_num in range(1, 6):
            self.cascade_pass_max_tokens[pass_num].set(CONFIG['DEFAULTS']['cascade_pass_tokens'])
        self.add_log("Cascade cleared", "INFO")
    
    def copy_cascade_output(self):
        """Copy cascade output"""
        text = self.cascade_output.get("1.0", tk.END).strip()
        if not text:
            messagebox.showwarning(CONFIG['TEXT']['popup_warning'], CONFIG['TEXT']['msg_empty_story'])
            return
        
        self.root.clipboard_clear()
        self.root.clipboard_append(text)
        messagebox.showinfo(CONFIG['TEXT']['popup_info'], CONFIG['TEXT']['msg_copied'])
        self.add_log("Copied cascade output", "INFO")
    
    def save_cascade_story(self):
        """Save cascade story"""
        text = self.cascade_output.get("1.0", tk.END).strip()
        if not text:
            messagebox.showwarning(CONFIG['TEXT']['popup_warning'], CONFIG['TEXT']['msg_empty_to_save'])
            return
        
        timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
        filename = f"story_cascade_{timestamp}.txt"
        filepath = os.path.join(os.path.expanduser("~"), "Downloads", filename)
        
        try:
            with open(filepath, 'w', encoding='utf-8') as f:
                f.write(text)
            
            messagebox.showinfo(CONFIG['TEXT']['popup_info'], f"Story saved:\n{filename}")
            self.add_log(f"Saved cascade story: {filename}", "INFO")
        except Exception as e:
            messagebox.showerror(CONFIG['TEXT']['popup_error'], f"{CONFIG['TEXT']['error_save_file']}\n{str(e)}")
            self.add_log(f"Error saving story: {str(e)}", "ERROR")
    
    # ====================================================================
    # RESEARCH MODE — Variant 3: document-grounded infinite research loop
    # ====================================================================
    
    def _extract_text_from_file(self, filepath):
        """Read a source document. .txt/.md need no dependency; .pdf uses PyPDF2 if available."""
        ext = os.path.splitext(filepath)[1].lower()
        try:
            if ext in ('.txt', '.md'):
                with open(filepath, 'r', encoding='utf-8', errors='ignore') as f:
                    return f.read()
            elif ext == '.pdf':
                try:
                    import PyPDF2
                except ImportError:
                    self.add_log(f"PyPDF2 not installed — skipping PDF: {os.path.basename(filepath)}", "WARNING")
                    return None
                text_parts = []
                with open(filepath, 'rb') as f:
                    reader = PyPDF2.PdfReader(f)
                    for page in reader.pages:
                        text_parts.append(page.extract_text() or "")
                return "\n".join(text_parts)
            return None
        except Exception as e:
            self.add_log(f"Error reading {filepath}: {str(e)}", "ERROR")
            return None
    
    def _chunk_text(self, text, filename):
        """Split a document into overlapping chunks for round-by-round processing."""
        chunk_size = CONFIG['RESEARCH']['chunk_size']
        overlap = CONFIG['RESEARCH']['chunk_overlap']
        chunks = []
        start = 0
        n = len(text)
        while start < n:
            end = min(start + chunk_size, n)
            piece = text[start:end].strip()
            if piece:
                chunks.append({"source": filename, "text": piece})
            if end == n:
                break
            start = end - overlap
        return chunks
    
    def _load_document_paths(self, filepaths):
        """Shared loader: extract + chunk a list of file paths, appending to research_chunks"""
        loaded_count = 0
        for fpath in filepaths:
            text = self._extract_text_from_file(fpath)
            if text and text.strip():
                self.research_chunks.extend(self._chunk_text(text, os.path.basename(fpath)))
                loaded_count += 1
        return loaded_count
    
    def _update_research_folder_label(self):
        """Refresh the 'what's loaded' label next to the Load buttons"""
        total_chunks = len(self.research_chunks)
        if not total_chunks:
            self.research_folder_label.config(text=CONFIG['TEXT']['text_no_folder_loaded'])
        elif self.research_folder:
            self.research_folder_label.config(
                text=f"{os.path.basename(self.research_folder)} ({total_chunks} chunks)"
            )
        else:
            self.research_folder_label.config(text=f"{total_chunks} chunk(s) loaded from individual file(s)")
    
    def load_research_folder(self):
        """Load and chunk every .txt/.md/.pdf file in a folder as the research source material.
        Replaces whatever was previously loaded (folder or loose files)."""
        folder = filedialog.askdirectory(title="Select Research Source Folder")
        if not folder:
            return
        
        supported_ext = ('.txt', '.md', '.pdf')
        try:
            files = [os.path.join(folder, f) for f in os.listdir(folder) if f.lower().endswith(supported_ext)]
        except Exception as e:
            messagebox.showerror(CONFIG['TEXT']['popup_error'], f"Could not read folder:\n{str(e)}")
            return
        
        if not files:
            messagebox.showwarning(CONFIG['TEXT']['popup_warning'], CONFIG['TEXT']['msg_no_files_found'])
            return
        
        self.research_folder = folder
        self.research_chunks = []
        loaded_count = self._load_document_paths(files)
        
        self.research_chunk_idx = 0
        self._update_research_folder_label()
        self.add_log(f"Research: loaded {loaded_count} documents, {len(self.research_chunks)} chunks from {folder}", "INFO")
    
    def load_research_files(self):
        """Load one or more individual .txt/.md/.pdf files — for when there's no folder to point at.
        Adds to whatever's already loaded rather than replacing it."""
        filepaths = filedialog.askopenfilenames(
            title="Select Research Source File(s)",
            filetypes=[
                ("Supported files", "*.txt *.md *.pdf"),
                ("Text files", "*.txt"),
                ("Markdown files", "*.md"),
                ("PDF files", "*.pdf"),
                ("All files", "*.*"),
            ]
        )
        if not filepaths:
            return
        
        loaded_count = self._load_document_paths(list(filepaths))
        if loaded_count == 0:
            messagebox.showwarning(CONFIG['TEXT']['popup_warning'],
                                   "Could not extract text from the selected file(s).")
            return
        
        self._update_research_folder_label()
        self.add_log(f"Research: loaded {loaded_count} individual file(s), "
                     f"{len(self.research_chunks)} total chunks", "INFO")
    
    def start_research(self):
        """Start (or resume into) the research loop on a background thread"""
        if self.research_running:
            messagebox.showwarning(CONFIG['TEXT']['popup_warning'], CONFIG['TEXT']['msg_research_running'])
            return
        
        if not self.research_chunks:
            messagebox.showwarning(CONFIG['TEXT']['popup_warning'], CONFIG['TEXT']['msg_no_folder'])
            return
        
        topic = self.research_topic_var.get().strip()
        if not topic:
            messagebox.showwarning(CONFIG['TEXT']['popup_warning'], CONFIG['TEXT']['msg_no_topic'])
            return
        
        model_display = self.research_model_var.get()
        if model_display == "None Selected":
            messagebox.showwarning(CONFIG['TEXT']['popup_warning'], CONFIG['TEXT']['msg_no_research_model'])
            return
        
        model_key = self.model_display_names.get(model_display)
        if not model_key:
            self.add_log(f"Research model '{model_display}' not found in available models", "ERROR")
            messagebox.showwarning(CONFIG['TEXT']['popup_warning'], CONFIG['TEXT']['msg_no_research_model'])
            return
        
        existing_topic = self.research_knowledge.get("topic", "")
        if existing_topic and existing_topic != topic and self.research_knowledge.get("entries"):
            if not messagebox.askyesno(
                CONFIG['TEXT']['msg_new_topic_title'],
                f"Current knowledge base is for '{existing_topic}'. Starting '{topic}' will replace it "
                f"in memory (already-saved files on disk are unaffected). Continue?"
            ):
                return
            self.research_knowledge = {"topic": topic, "entries": []}
            self.research_round = 0
            self.research_low_novelty_streak = 0
            self.research_chunk_idx = 0
            self.research_knowledge_path = None
            self.research_last_compaction_round = 0
        elif not existing_topic:
            self.research_knowledge = {"topic": topic, "entries": []}
        
        self.research_running = True
        self.research_paused = False
        self.research_stop_requested = False
        self.pause_research_btn.config(text=CONFIG['TEXT']['btn_research_pause'])
        self._update_research_status_display()
        self.add_log(f"Research started: topic='{topic}', model={model_display}", "INFO")
        
        thread = threading.Thread(target=self._research_loop, args=(topic, model_key), daemon=True)
        thread.start()
    
    def pause_research(self):
        """Toggle pause/resume — the loop thread checks this flag between rounds"""
        if not self.research_running:
            return
        self.research_paused = not self.research_paused
        self.pause_research_btn.config(
            text=CONFIG['TEXT']['btn_research_resume'] if self.research_paused else CONFIG['TEXT']['btn_research_pause']
        )
        self.add_log(f"Research {'paused' if self.research_paused else 'resumed'}", "INFO")
        self._update_research_status_display()
    
    def stop_research(self):
        """Request a clean stop — loop thread exits at the next round boundary"""
        if not self.research_running:
            return
        self.research_stop_requested = True
        self.research_paused = False
        self.add_log("Research stop requested", "INFO")
    
    def _append_research_output(self, text):
        """Thread-safe append to the research log box — safe to call from
        any thread; the widget mutation always runs on the main thread."""
        def update_widget():
            self.research_output.config(state=tk.NORMAL)
            self.research_output.insert(tk.END, text)
            self.research_output.see(tk.END)
            self.research_output.config(state=tk.DISABLED)
        self.root.after(0, update_widget)
    
    def _update_research_status_display(self):
        """Refresh the status label in the Research card header"""
        if not hasattr(self, 'research_status_label'):
            return
        
        entries_count = len(self.research_knowledge.get("entries", []))
        
        if self.research_running and self.research_paused:
            state_text = CONFIG['TEXT']['status_research_paused']
            color = CONFIG['COLORS']['text_muted']
        elif self.research_running:
            state_text = CONFIG['TEXT']['status_research_running']
            color = CONFIG['COLORS']['status_online']
        else:
            state_text = CONFIG['TEXT']['status_research_stopped']
            color = CONFIG['COLORS']['status_offline']
        
        self.research_status_label.config(
            text=f"{state_text} — Round {self.research_round} · {entries_count} claims · "
                 f"streak {self.research_low_novelty_streak}",
            foreground=color
        )
    
    def _parse_claims(self, raw_text, source, round_num):
        """Parse 'CLAIM: ... | CONFIDENCE: ...' lines out of a model response"""
        entries = []
        for line in raw_text.split('\n'):
            line = line.strip()
            if not line.upper().startswith('CLAIM:'):
                continue
            body = line[len('CLAIM:'):].strip()
            if '|' in body:
                claim_part, conf_part = body.split('|', 1)
                claim = claim_part.strip()
                conf_match = re.search(r'(high|medium|low)', conf_part, re.IGNORECASE)
                confidence = conf_match.group(1).lower() if conf_match else "medium"
            else:
                claim = body
                confidence = "medium"
            if claim:
                entries.append({"claim": claim, "confidence": confidence, "source": source, "round": round_num})
        return entries
    
    def _is_near_duplicate(self, claim_text, existing_entries, threshold=None):
        """Deterministic dedup check — sequence similarity against every existing claim, no API call.
        Catches reworded repeats (e.g. two phrasings of the same senator-vote fact) that a context-window
        summary can miss once older entries have aged out of what the model is shown."""
        if threshold is None:
            threshold = CONFIG['RESEARCH']['dedup_similarity_threshold']
        a = claim_text.lower().strip()
        for e in existing_entries:
            b = e['claim'].lower().strip()
            if difflib.SequenceMatcher(None, a, b).ratio() >= threshold:
                return True
        return False
    
    def _summarize_knowledge_base(self, max_chars=None):
        """Compact text view of what's already known, fed back to the model to avoid repetition"""
        if max_chars is None:
            max_chars = CONFIG['RESEARCH']['summary_context_chars']
        entries = self.research_knowledge.get("entries", [])
        if not entries:
            return ""
        text = "\n".join(f"- {e['claim']}" for e in entries)
        if len(text) > max_chars:
            text = text[-max_chars:]  # keep the most recently added knowledge in context
        return text
    
    def _save_knowledge_base(self):
        """Write the structured knowledge base to a JSON file in Downloads"""
        if not self.research_knowledge_path:
            topic_slug = re.sub(r'[^a-zA-Z0-9_-]+', '_', self.research_knowledge.get("topic", "research")).strip('_')[:50]
            timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
            filename = f"research_{topic_slug or 'topic'}_{timestamp}.json"
            self.research_knowledge_path = os.path.join(os.path.expanduser("~"), "Downloads", filename)
        
        try:
            payload = {
                "topic": self.research_knowledge.get("topic", ""),
                "round": self.research_round,
                "generated": datetime.datetime.now().isoformat(),
                "entries": self.research_knowledge.get("entries", [])
            }
            with open(self.research_knowledge_path, 'w', encoding='utf-8') as f:
                json.dump(payload, f, indent=2)
        except Exception as e:
            self.add_log(f"Error saving knowledge base: {str(e)}", "ERROR")
    
    def open_knowledge_file(self):
        """Open the saved knowledge base JSON in the default viewer"""
        if not self.research_knowledge_path or not os.path.exists(self.research_knowledge_path):
            messagebox.showwarning(CONFIG['TEXT']['popup_warning'], CONFIG['TEXT']['msg_no_knowledge_yet'])
            return
        try:
            if os.name == 'nt':
                os.startfile(self.research_knowledge_path)
            else:
                os.system(f'open "{self.research_knowledge_path}"')
            self.add_log("Opened knowledge base file", "INFO")
        except Exception as e:
            messagebox.showerror(CONFIG['TEXT']['popup_error'], f"Could not open file:\n{str(e)}")
    
    def compact_research_now(self):
        """Manually trigger a compaction pass on demand, outside the automatic schedule.
        Requires the loop to not be actively running (or to be paused) since compaction replaces
        the entries list wholesale — running it concurrently with an active round risks one of the
        two overwriting the other's write to research_knowledge."""
        if not self.research_knowledge.get("entries"):
            messagebox.showwarning(CONFIG['TEXT']['popup_warning'], CONFIG['TEXT']['msg_no_knowledge_yet'])
            return
        
        if self.research_running and not self.research_paused:
            messagebox.showwarning(CONFIG['TEXT']['popup_warning'], CONFIG['TEXT']['msg_pause_before_compact'])
            return
        
        if self.research_compacting:
            return  # a manual compaction is already in flight
        
        model_display = self.research_model_var.get()
        model_key = self.model_display_names.get(model_display)
        if model_display == "None Selected" or not model_key:
            if model_display != "None Selected":
                self.add_log(f"Research model '{model_display}' not found in available models", "ERROR")
            messagebox.showwarning(CONFIG['TEXT']['popup_warning'], CONFIG['TEXT']['msg_no_research_model'])
            return
        
        topic = self.research_knowledge.get("topic") or self.research_topic_var.get().strip()
        if not topic:
            messagebox.showwarning(CONFIG['TEXT']['popup_warning'], CONFIG['TEXT']['msg_no_topic'])
            return
        
        entry_count = len(self.research_knowledge.get("entries", []))
        self.research_compacting = True
        self._append_research_output(f"\n🔄 Manual compaction requested ({entry_count} entries)...\n")
        self.add_log(f"Manual compaction requested: {entry_count} entries", "INFO")
        
        def _run():
            try:
                self._compact_knowledge_base(topic, model_key)
                self.research_last_compaction_round = self.research_round
                new_count = len(self.research_knowledge.get("entries", []))
                self.root.after(0, self._append_research_output,
                                f"  ✓ Manual compaction complete ({new_count} entries after merge)\n")
                self.root.after(0, self._update_research_status_display)
            finally:
                self.research_compacting = False
        
        thread = threading.Thread(target=_run, daemon=True)
        thread.start()
    
    def _maybe_compact(self, topic, model_key, log):
        """Run a compaction pass if there's enough to merge and this round hasn't already been
        compacted (the periodic check, the auto-pause point, and the loop-exit point can all land
        on the same round, so this guard stops it running twice for one round's worth of entries)."""
        if len(self.research_knowledge.get("entries", [])) <= 5:
            return
        if self.research_round == self.research_last_compaction_round:
            return
        
        log(f"\n🔄 Compacting knowledge base ({len(self.research_knowledge['entries'])} entries)...\n")
        self._compact_knowledge_base(topic, model_key)
        log(f"  ✓ Compaction complete ({len(self.research_knowledge['entries'])} entries after merge)\n")
        self.research_last_compaction_round = self.research_round
        self.root.after(0, self._update_research_status_display)
    
    def _compact_knowledge_base(self, topic, model_key):
        """Periodic cleanup pass: de-duplicate and re-group the accumulated claims"""
        entries = self.research_knowledge.get("entries", [])
        full_text = "\n".join(
            f"CLAIM: {e['claim']} | CONFIDENCE: {e['confidence']} | SOURCE: {e['source']}"
            for e in entries
        )
        
        prompt = CONFIG['RESEARCH']['compaction_template'].format(topic=topic, full_knowledge=full_text[:6000])
        
        try:
            response = requests.post(
                f"{self.api_base}{CONFIG['API']['chat_endpoint']}",
                json={
                    "model": model_key,
                    "messages": [{"role": "user", "content": prompt}],
                    "temperature": 0.3,
                    "max_tokens": 2000
                },
                timeout=self.timeout_var.get()
            )
            if response.status_code != 200:
                self.add_log(f"Compaction API error: {response.status_code}", "WARNING")
                return
            
            compacted_text = response.json()['choices'][0]['message']['content']
            new_entries = []
            for line in compacted_text.split('\n'):
                line = line.strip()
                if not line.upper().startswith('CLAIM:'):
                    continue
                body = line[len('CLAIM:'):].strip()
                parts = body.split('|')
                claim = parts[0].strip()
                confidence, sources = "medium", "unknown"
                for p in parts[1:]:
                    p = p.strip()
                    if p.upper().startswith('CONFIDENCE:'):
                        confidence = p.split(':', 1)[1].strip().lower()
                    elif p.upper().startswith('SOURCES:'):
                        sources = p.split(':', 1)[1].strip()
                if claim:
                    new_entries.append({"claim": claim, "confidence": confidence, "source": sources,
                                        "round": self.research_round})
            
            if new_entries:
                self.research_knowledge["entries"] = new_entries
                self._save_knowledge_base()
        except Exception as e:
            self.add_log(f"Compaction error: {str(e)}", "ERROR")
    
    def _research_loop(self, topic, model_key):
        """Background thread: research -> validate -> score novelty -> record, round after round"""
        rcfg = CONFIG['RESEARCH']
        novelty_threshold = rcfg['novelty_threshold']
        low_novelty_stop = rcfg['low_novelty_stop_streak']
        compact_every = rcfg['compact_every_n_rounds']
        
        def log(text):
            self.root.after(0, self._append_research_output, text)
        
        try:
            while not self.research_stop_requested:
                while self.research_paused and not self.research_stop_requested:
                    time.sleep(0.5)
                if self.research_stop_requested:
                    break
                
                if self.research_chunk_idx >= len(self.research_chunks):
                    self.research_chunk_idx = 0  # loop back through the source material
                    if self.research_round > 0:
                        log(f"\n↻ Completed a full pass over the loaded source material — "
                            f"starting again from the top\n")
                
                chunk = self.research_chunks[self.research_chunk_idx]
                self.research_round += 1
                
                log(f"\n▶ Round {self.research_round} — source: {chunk['source']} "
                    f"(chunk {self.research_chunk_idx + 1}/{len(self.research_chunks)})\n")
                
                existing_summary = self._summarize_knowledge_base()
                
                research_prompt = rcfg['research_template'].format(
                    topic=topic, source=chunk['source'], chunk=chunk['text'],
                    existing_summary=existing_summary if existing_summary else "(none yet)"
                )
                
                response = requests.post(
                    f"{self.api_base}{CONFIG['API']['chat_endpoint']}",
                    json={
                        "model": model_key,
                        "messages": [{"role": "user", "content": research_prompt}],
                        "temperature": 0.4,
                        "max_tokens": 600
                    },
                    timeout=self.timeout_var.get()
                )
                
                if response.status_code != 200:
                    log(f"  ❌ API error {response.status_code} — skipping to next chunk\n")
                    self.add_log(f"Research API error: {response.status_code}", "ERROR")
                    self.research_chunk_idx += 1
                    time.sleep(1)
                    continue
                
                result = response.json()
                raw_claims = result['choices'][0]['message']['content'].strip()
                
                if 'usage' in result:
                    tokens_used = result['usage'].get('total_tokens', 0)
                    self.session_tokens += tokens_used
                    self.root.after(0, lambda: self.session_tokens_label.config(text=str(self.session_tokens)))
                
                novelty_score = 0
                new_entries = []
                
                if raw_claims.upper().startswith("NO NEW CLAIMS"):
                    log("  — No new claims found in this excerpt\n")
                else:
                    new_entries = self._parse_claims(raw_claims, chunk['source'], self.research_round)
                    
                    # Run the same Constraint Engine used by the cascade over the raw claim text
                    if new_entries and self.engine_loaded and self.engine and self.engine_enabled_var.get():
                        validation_result = self.engine.validate(raw_claims, auto_fix=True)
                        if not validation_result.get('success'):
                            log(f"  ⚠ Constraint validation failed at {validation_result.get('failed_at')} "
                                f"— discarding round\n")
                            new_entries = []
                    
                    # Deterministic dedup filter — catches reworded repeats of existing claims before
                    # spending an API call on novelty scoring. This runs against the FULL entry list,
                    # not the truncated "existing_summary" text, so it can't miss claims that aged out
                    # of what the model was shown.
                    if new_entries:
                        all_entries = self.research_knowledge.get("entries", [])
                        before_count = len(new_entries)
                        new_entries = [e for e in new_entries if not self._is_near_duplicate(e['claim'], all_entries)]
                        skipped = before_count - len(new_entries)
                        if skipped:
                            log(f"  ⊘ {skipped} claim(s) filtered as near-duplicates of existing knowledge\n")
                    
                    if new_entries:
                        log(f"  + {len(new_entries)} new claim(s) extracted\n")
                        for e in new_entries:
                            log(f"    • {e['claim']} ({e['confidence']})\n")
                        
                        claims_text = "\n".join(f"- {e['claim']}" for e in new_entries)
                        novelty_prompt = rcfg['novelty_template'].format(
                            topic=topic,
                            existing_summary=existing_summary if existing_summary else "(none yet)",
                            new_claims=claims_text
                        )
                        nov_response = requests.post(
                            f"{self.api_base}{CONFIG['API']['chat_endpoint']}",
                            json={
                                "model": model_key,
                                "messages": [{"role": "user", "content": novelty_prompt}],
                                "temperature": 0.3,
                                "max_tokens": 150
                            },
                            timeout=self.timeout_var.get()
                        )
                        novelty_score = 5  # default if the score can't be parsed out
                        if nov_response.status_code == 200:
                            nov_text = nov_response.json()['choices'][0]['message']['content']
                            match = re.search(r'NOVELTY:\s*(\d+)', nov_text, re.IGNORECASE)
                            if match:
                                novelty_score = int(match.group(1))
                        
                        log(f"  Novelty score: {novelty_score}/10\n")
                        
                        if novelty_score >= novelty_threshold:
                            self.research_knowledge["entries"].extend(new_entries)
                            self._save_knowledge_base()
                        else:
                            log("  (below novelty threshold — not recorded)\n")
                
                if novelty_score < novelty_threshold:
                    self.research_low_novelty_streak += 1
                else:
                    self.research_low_novelty_streak = 0
                
                self.root.after(0, self._update_research_status_display)
                
                if self.research_low_novelty_streak >= low_novelty_stop:
                    log(f"\n⏸ {low_novelty_stop} consecutive low-novelty rounds — auto-pausing "
                        f"(topic may be exhausted for this source material)\n")
                    self.add_log("Research auto-paused: topic likely exhausted", "INFO")
                    self.research_paused = True
                    self.research_low_novelty_streak = 0
                    self.root.after(0, lambda: self.pause_research_btn.config(
                        text=CONFIG['TEXT']['btn_research_resume']))
                    self.root.after(0, self._update_research_status_display)
                    # A short run (e.g. one small document) may never reach the periodic compaction
                    # interval below before pausing — make sure at least one cleanup pass happens here
                    # too, since paraphrase-level duplicates need the model's full-context judgment,
                    # not the lexical dedup filter, to catch.
                    self._maybe_compact(topic, model_key, log)
                
                if self.research_round % compact_every == 0 and len(self.research_knowledge["entries"]) > 5:
                    self._maybe_compact(topic, model_key, log)
                
                self.add_log(f"Research round {self.research_round} complete: novelty={novelty_score}", "INFO")
                self.research_chunk_idx += 1
                time.sleep(0.3)  # brief pacing between rounds
            
            # Same reasoning as the auto-pause case: a run that's stopped manually before ever hitting
            # the periodic interval or the low-novelty streak still deserves one cleanup pass.
            self._maybe_compact(topic, model_key, log)
            
            log(f"\n■ Research stopped at round {self.research_round} "
                f"({len(self.research_knowledge.get('entries', []))} total claims saved)\n")
            self.add_log(f"Research stopped: {len(self.research_knowledge.get('entries', []))} total entries", "INFO")
        
        except requests.exceptions.RequestException as e:
            log(f"\n❌ Connection error: {str(e)}\n")
            self.add_log(f"Research connection error: {str(e)}", "ERROR")
        except Exception as e:
            log(f"\n❌ Error: {str(e)}\n")
            self.add_log(f"Research error: {str(e)}", "ERROR")
        finally:
            self.research_running = False
            self.root.after(0, self._update_research_status_display)


if __name__ == "__main__":
    root = tk.Tk()
    root.withdraw()
    app = LMStudioOrchestrator(root)
    root.mainloop()
