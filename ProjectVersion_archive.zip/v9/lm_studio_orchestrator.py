import tkinter as tk
from tkinter import ttk, messagebox, filedialog
import requests
import os
import threading

class LoadingSplash:
    """Splash screen with loading bar shown during startup checks"""
    def __init__(self, root):
        self.root = root
        self.splash = tk.Toplevel(root)
        self.splash.title("LM Studio Orchestrator")
        self.splash.geometry("400x150")
        self.splash.resizable(False, False)
        
        # Center on screen
        self.splash.update_idletasks()
        x = (self.splash.winfo_screenwidth() // 2) - 200
        y = (self.splash.winfo_screenheight() // 2) - 75
        self.splash.geometry(f"+{x}+{y}")
        
        # Remove window decorations for cleaner look
        self.splash.attributes('-topmost', True)
        
        # Content
        ttk.Label(self.splash, text="LM Studio Multi-Model Orchestrator", font=("Arial", 12, "bold")).pack(pady=15)
        ttk.Label(self.splash, text="Checking server...", font=("Arial", 9)).pack(pady=(0, 10))
        
        self.progress = ttk.Progressbar(self.splash, mode='indeterminate', length=300)
        self.progress.pack(pady=10)
        self.progress.start()
    
    def update_status(self, text):
        """Update status text on splash screen"""
        self.status_text.config(text=text)
        self.splash.update()
    
    def close(self):
        """Close splash screen"""
        self.progress.stop()
        self.splash.destroy()

class LMStudioOrchestrator:
    def __init__(self, root):
        self.root = root
        self.root.title("LM Studio Multi-Model Orchestrator")
        self.root.geometry("610x845")
        self.root.resizable(True, True)  # Allow full resizing
        
        # Window lock state
        self.window_locked = False
        
        # API Config
        self.api_base = "http://localhost:1234"
        self.model_keys = {}  # Map listbox index to model key
        self.current_model = None  # Track currently loaded model
        self.uploaded_documents = []  # Track uploaded files
        self.loading_model = False  # Prevent multiple simultaneous loads
        
        # Document settings
        self.max_tokens_var = tk.IntVar(value=2000)
        self.temperature_var = tk.DoubleVar(value=0.7)
        
        # ===== SCROLLABLE CONTAINER =====
        # Create canvas and scrollbar for scrolling
        canvas = tk.Canvas(root, bg="white", highlightthickness=0)
        scrollbar = ttk.Scrollbar(root, orient="vertical", command=canvas.yview)
        scrollable_frame = ttk.Frame(canvas)
        
        scrollable_frame.bind(
            "<Configure>",
            lambda e: canvas.configure(scrollregion=canvas.bbox("all"))
        )
        
        canvas.create_window((0, 0), window=scrollable_frame, anchor="nw")
        canvas.configure(yscrollcommand=scrollbar.set)
        
        # Pack canvas and scrollbar
        canvas.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        
        # Bind mousewheel for scrolling
        def _on_mousewheel(event):
            canvas.yview_scroll(int(-1*(event.delta/120)), "units")
        canvas.bind_all("<MouseWheel>", _on_mousewheel)
        
        # ===== CONTROL PANEL =====
        self.control_frame = ttk.LabelFrame(scrollable_frame, text="Model Control", padding=10)
        self.control_frame.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)
        
        # Connection status
        ttk.Label(self.control_frame, text="LM Studio Status:", font=("Arial", 10, "bold")).pack(anchor=tk.W, pady=(0, 5))
        
        status_row = ttk.Frame(self.control_frame)
        status_row.pack(fill=tk.X, pady=(0, 5))
        
        self.status_label = ttk.Label(status_row, text="❌ Disconnected", foreground="red", font=("Arial", 9))
        self.status_label.pack(side=tk.LEFT, padx=(0, 15))
        
        ttk.Label(status_row, text="Server:", font=("Arial", 9)).pack(side=tk.LEFT, padx=(0, 5))
        self.server_label = ttk.Label(status_row, text=self.api_base, foreground="blue", font=("Courier", 9))
        self.server_label.pack(side=tk.LEFT)
        
        # Window resolution display (top right) with lock button
        resolution_frame = ttk.Frame(status_row)
        resolution_frame.pack(side=tk.RIGHT)
        
        self.resolution_label = ttk.Label(resolution_frame, text="900x700", foreground="blue", font=("Courier", 9))
        self.resolution_label.pack(side=tk.LEFT, padx=(0, 5))
        
        self.lock_button = tk.Button(resolution_frame, text="🔓", font=("Arial", 8), command=self.toggle_window_lock, relief=tk.FLAT, bd=0, padx=3, pady=0)
        self.lock_button.pack(side=tk.LEFT)
        
        # Model load status
        model_status_row = ttk.Frame(self.control_frame)
        model_status_row.pack(anchor=tk.W, pady=(0, 10))
        
        self.model_status_label = ttk.Label(model_status_row, text="❌ No Model Loaded", foreground="red", font=("Arial", 9))
        self.model_status_label.pack(side=tk.LEFT, padx=(0, 15))
        
        ttk.Label(model_status_row, text="Model:", font=("Arial", 9)).pack(side=tk.LEFT, padx=(0, 5))
        self.model_name_label = ttk.Label(model_status_row, text="Waiting...", foreground="blue", font=("Courier", 9))
        self.model_name_label.pack(side=tk.LEFT)
        
        ttk.Button(self.control_frame, text="Refresh Script", command=self.refresh_script).pack(fill=tk.X, pady=3)
        
        # Model selection
        ttk.Separator(self.control_frame, orient="horizontal").pack(fill=tk.X, pady=15)
        ttk.Label(self.control_frame, text="MODEL MANAGEMENT", font=("Arial", 11, "bold")).pack(anchor=tk.W, pady=(0, 8))
        
        ttk.Label(self.control_frame, text="Available Models:", font=("Arial", 9)).pack(anchor=tk.W, pady=(0, 3))
        ttk.Label(self.control_frame, text="(click model to load)", font=("Arial", 8), foreground="gray").pack(anchor=tk.W, pady=(0, 5))
        
        # Listbox for models (vertical list)
        self.models_listbox = tk.Listbox(self.control_frame, height=4, font=("Arial", 9), selectmode=tk.SINGLE)
        self.models_listbox.pack(fill=tk.X, pady=(0, 8))
        self.models_listbox.bind('<Double-Button-1>', self.on_model_select)  # Double-click to load
        self.models_listbox.bind('<Motion>', self.on_listbox_hover)  # Hover effect
        
        self.model_keys = {}  # Map listbox index to model key
        
        # Max tokens and temperature control
        tokens_row = ttk.Frame(self.control_frame)
        tokens_row.pack(fill=tk.X, pady=(0, 15))
        
        ttk.Label(tokens_row, text="Max Tokens:", font=("Arial", 9)).pack(side=tk.LEFT, padx=(0, 5))
        ttk.Spinbox(tokens_row, from_=100, to=32000, textvariable=self.max_tokens_var, width=10).pack(side=tk.LEFT, padx=(0, 20))
        
        ttk.Label(tokens_row, text="Temperature:", font=("Arial", 9)).pack(side=tk.LEFT, padx=(0, 5))
        ttk.Spinbox(tokens_row, from_=0.0, to=2.0, increment=0.1, textvariable=self.temperature_var, width=10).pack(side=tk.LEFT)
        
        # Document upload section
        ttk.Separator(self.control_frame, orient="horizontal").pack(fill=tk.X, pady=15)
        ttk.Label(self.control_frame, text="DOCUMENT UPLOAD", font=("Arial", 11, "bold")).pack(anchor=tk.W, pady=(0, 8))
        
        # Main document frame (left and right layout)
        doc_main_frame = ttk.Frame(self.control_frame)
        doc_main_frame.pack(fill=tk.BOTH, expand=True, pady=(0, 15))
        
        # Left side - File input
        left_frame = ttk.Frame(doc_main_frame)
        left_frame.pack(side=tk.LEFT, fill=tk.BOTH, expand=False, padx=(0, 8))
        
        ttk.Label(left_frame, text="Uploaded Files (Max 2):", font=("Arial", 9)).pack(anchor=tk.W, pady=(0, 3))
        
        # File chips frame (will contain file entries with X buttons)
        self.files_frame = ttk.Frame(left_frame)
        self.files_frame.pack(fill=tk.X, pady=(0, 8))
        
        # Browse and Submit buttons
        upload_button_frame = ttk.Frame(left_frame)
        upload_button_frame.pack(fill=tk.X)
        
        ttk.Button(upload_button_frame, text="Add Files", command=self.browse_document).pack(side=tk.LEFT, padx=(0, 5))
        ttk.Button(upload_button_frame, text="Submit", command=self.submit_document).pack(side=tk.LEFT)
        
        # Right side - Output
        right_frame = ttk.Frame(doc_main_frame)
        right_frame.pack(side=tk.RIGHT, fill=tk.BOTH, expand=True, padx=(8, 0))
        
        ttk.Label(right_frame, text="Analysis Output:", font=("Arial", 9)).pack(anchor=tk.W, pady=(0, 3))
        
        self.doc_output = tk.Text(right_frame, height=8, font=("Arial", 8), wrap=tk.WORD, state=tk.DISABLED)
        self.doc_output.pack(fill=tk.BOTH, expand=True, pady=(0, 5))
        
        # Buttons for document output
        doc_button_frame = ttk.Frame(right_frame)
        doc_button_frame.pack(fill=tk.X)
        
        ttk.Button(doc_button_frame, text="Copy Output", command=self.copy_doc_output).pack(side=tk.LEFT, padx=(0, 5))
        ttk.Button(doc_button_frame, text="Clear Output", command=self.clear_doc_output).pack(side=tk.LEFT)
        
        # Direct Chat Section
        ttk.Separator(self.control_frame, orient="horizontal").pack(fill=tk.X, pady=15)
        ttk.Label(self.control_frame, text="DIRECT CHAT", font=("Arial", 11, "bold")).pack(anchor=tk.W, pady=(0, 8))
        
        # Chat input
        self.chat_input = tk.Text(self.control_frame, height=2, font=("Arial", 9), wrap=tk.WORD)
        self.chat_input.pack(fill=tk.X, pady=(0, 5))
        self.chat_input.bind('<Control-Return>', lambda e: self.send_chat())  # Ctrl+Enter to send
        
        # Send button
        ttk.Button(self.control_frame, text="Send", command=self.send_chat).pack(fill=tk.X, pady=(0, 8))
        
        # Output text box
        ttk.Label(self.control_frame, text="Response:", font=("Arial", 9)).pack(anchor=tk.W, pady=(0, 3))
        self.chat_output = tk.Text(self.control_frame, height=4, font=("Arial", 9), wrap=tk.WORD, state=tk.DISABLED)
        self.chat_output.pack(fill=tk.BOTH, expand=True, pady=(0, 5))
        
        # Clear button
        ttk.Button(self.control_frame, text="Clear Response", command=self.clear_chat_output).pack(fill=tk.X)
        
        # Bind window resize event to update resolution display
        self.root.bind("<Configure>", self.update_resolution)
        
        # Initialize with loading splash
        self.run_startup_checks()
    
    def run_startup_checks(self):
        """Run startup checks in background thread with loading splash"""
        # Show loading splash
        splash = LoadingSplash(self.root)
        
        def startup_thread():
            self.check_connection()
            self.refresh_models()
            
            # Close splash and show main window
            splash.close()
            self.root.deiconify()  # Make main window visible
        
        # Start thread
        thread = threading.Thread(target=startup_thread, daemon=True)
        thread.start()
    
    def update_resolution(self, event=None):
        """Update window resolution display"""
        width = self.root.winfo_width()
        height = self.root.winfo_height()
        if width > 1 and height > 1:  # Skip initial configure events
            self.resolution_label.config(text=f"{width}x{height}")
    
    def toggle_window_lock(self):
        """Toggle window resizing lock"""
        self.window_locked = not self.window_locked
        self.root.resizable(not self.window_locked, not self.window_locked)
        self.lock_button.config(text="🔒" if self.window_locked else "🔓")
    
    def refresh_models(self):
        """Fetch and display available models from LM Studio in listbox"""
        try:
            response = requests.get(f"{self.api_base}/api/v1/models", timeout=5)
            if response.status_code == 200:
                data = response.json()
                models = data.get("models", [])
                
                # Clear listbox
                self.models_listbox.delete(0, tk.END)
                self.model_keys = {}
                
                # Populate with model names (LLMs only)
                llm_models = [m for m in models if m.get("type") == "llm"]
                
                if llm_models:
                    for idx, model in enumerate(llm_models):
                        display_name = model.get("display_name", "Unknown")
                        key = model.get("key", "unknown")
                        quantization = model.get("quantization", {}).get("name", "")
                        
                        display_text = f"{display_name} ({quantization})"
                        
                        self.models_listbox.insert(tk.END, display_text)
                        self.model_keys[idx] = key
                else:
                    self.models_listbox.insert(tk.END, "No LLM models found")
                
                # Clear selection to prevent auto-load
                self.models_listbox.selection_clear(0, tk.END)
            else:
                self.models_listbox.delete(0, tk.END)
                self.models_listbox.insert(tk.END, "Failed to load models")
        except Exception as e:
            self.models_listbox.delete(0, tk.END)
            self.models_listbox.insert(tk.END, f"Error: {str(e)}")
    
    def on_model_select(self, event):
        """Handle model selection from listbox (double-click)"""
        if self.loading_model:  # Prevent multiple simultaneous loads
            return
        
        # Get index from mouse position
        idx = self.models_listbox.nearest(event.y)
        if idx >= 0:
            model_key = self.model_keys.get(idx)
            if model_key:
                self.load_model(model_key)
    
    def on_listbox_hover(self, event):
        """Highlight listbox item on hover"""
        idx = self.models_listbox.nearest(event.y)
        if idx >= 0:
            self.models_listbox.selection_clear(0, tk.END)
            self.models_listbox.selection_set(idx)
            self.models_listbox.see(idx)
    
    def load_model(self, model_key):
        """Load a model by its key"""
        if not model_key:
            messagebox.showerror("Error", "Could not identify selected model")
            return
        
        self.loading_model = True  # Set flag to prevent multiple loads
        
        try:
            response = requests.post(
                f"{self.api_base}/api/v1/models/load",
                json={"model": model_key},
                timeout=30
            )
            
            if response.status_code == 200:
                self.current_model = model_key
                self.check_connection()
                messagebox.showinfo("Success", f"Model loaded: {model_key}")
            else:
                messagebox.showerror("Error", f"Failed to load model.\nStatus: {response.status_code}")
        except Exception as e:
            messagebox.showerror("Error", f"Error loading model:\n{str(e)}")
        finally:
            self.loading_model = False  # Reset flag
    
    def refresh_script(self):
        """Refresh both connection and model list"""
        self.check_connection()
        self.refresh_models()
    
    def check_connection(self):
        """Check if LM Studio API is running and update model status"""
        try:
            response = requests.get(f"{self.api_base}/api/v1/models", timeout=2)
            self.status_label.config(text="✅ Connected", foreground="green")
            
            # Check for loaded model
            if response.status_code == 200:
                data = response.json()
                models = data.get("models", [])
                
                # If we have a current_model set, check if it's still loaded
                if self.current_model:
                    for model in models:
                        if model.get("key") == self.current_model:
                            display_name = model.get("display_name", "Unknown")
                            self.model_status_label.config(text="✅ Model Loaded", foreground="green")
                            self.model_name_label.config(text=display_name, foreground="blue")
                            return True
                    # Model not found in list, clear it
                    self.current_model = None
                
                # No model loaded
                self.model_status_label.config(text="❌ No Model Loaded", foreground="red")
                self.model_name_label.config(text="Waiting...", foreground="blue")
            return True
        except:
            self.status_label.config(text="❌ Disconnected", foreground="red")
            self.model_status_label.config(text="❌ No Model Loaded", foreground="red")
            self.model_name_label.config(text="Offline", foreground="blue")
            return False
    
    def browse_document(self):
        """Open file dialog to select .txt or .md files (max 2 total)"""
        # Calculate how many slots are available
        slots_available = 2 - len(self.uploaded_documents)
        
        if slots_available <= 0:
            messagebox.showwarning("File Limit", "Maximum 2 files allowed. Remove a file to add more.")
            return
        
        files = filedialog.askopenfilenames(
            title=f"Select Text Files (max {slots_available} remaining)",
            filetypes=[
                ("Text/Markdown Files", "*.txt *.md"),
                ("Text Files", "*.txt"),
                ("Markdown Files", "*.md"),
            ]
        )
        
        if files:
            # Only add up to the available slots
            files_to_add = list(files)[:slots_available]
            
            for file_path in files_to_add:
                if file_path not in self.uploaded_documents:
                    self.uploaded_documents.append(file_path)
            
            # Update listbox display
            self.update_files_display()
            
            # Show confirmation
            file_count = len(files_to_add)
            filenames = ", ".join(os.path.basename(f) for f in files_to_add)
            messagebox.showinfo("Files Added", f"Added {file_count} file(s):\n{filenames}")
    
    def update_files_display(self):
        """Update file chips display with inline X buttons for removal"""
        # Clear existing file chips
        for widget in self.files_frame.winfo_children():
            widget.destroy()
        
        if len(self.uploaded_documents) == 0:
            ttk.Label(self.files_frame, text="No files attached", font=("Arial", 9), foreground="gray").pack(anchor=tk.W)
        else:
            for i, file_path in enumerate(self.uploaded_documents):
                self.create_file_chip(i, os.path.basename(file_path))
    
    def create_file_chip(self, index, filename):
        """Create a file chip with filename and X button"""
        chip_frame = ttk.Frame(self.files_frame)
        chip_frame.pack(fill=tk.X, pady=2)
        
        # File icon and name
        ttk.Label(chip_frame, text=f"📎 {filename}", font=("Arial", 9), foreground="blue").pack(side=tk.LEFT, padx=(0, 8))
        
        # X button to remove file
        remove_btn = tk.Button(chip_frame, text="✕", font=("Arial", 9, "bold"), 
                              fg="red", relief=tk.FLAT, bd=0, padx=4, 
                              command=lambda idx=index: self.remove_file_by_index(idx))
        remove_btn.pack(side=tk.LEFT)
    
    def remove_file_by_index(self, index):
        """Remove a file by its index without showing a dialog"""
        if 0 <= index < len(self.uploaded_documents):
            self.uploaded_documents.pop(index)
            self.update_files_display()
    
    def remove_file(self):
        """Remove file - use the X button next to each file instead"""
        if not self.uploaded_documents:
            messagebox.showinfo("No Files", "Use the ✕ button next to a file to remove it.")
            return
        messagebox.showinfo("Tip", "Click the ✕ button next to a file to remove it.")
    
    def submit_document(self):
        """Submit the selected documents for analysis"""
        if not self.uploaded_documents:
            messagebox.showwarning("No Documents", "Please add documents first.")
            return
        
        if not self.current_model:
            messagebox.showwarning("No Model", "Please load a model first.")
            return
        
        try:
            # Show processing status
            self.doc_output.config(state=tk.NORMAL)
            self.doc_output.delete("1.0", tk.END)
            self.doc_output.insert(tk.END, "Processing...")
            self.doc_output.config(state=tk.DISABLED)
            self.root.update()
            
            # Read all uploaded files
            all_content = []
            for file_path in self.uploaded_documents:
                with open(file_path, 'r', encoding='utf-8') as f:
                    content = f.read()
                    all_content.append(f"=== {os.path.basename(file_path)} ===\n{content}")
            
            combined_content = "\n\n".join(all_content)
            
            # Build the prompt with default analysis
            instructions_text = "Examine thoroughly, fact check claims, verify information, and provide deep reasoning"
            
            # Build the prompt
            prompt = f"""Please analyze the following document(s). {instructions_text}.

Documents:
{combined_content}

Provide a comprehensive analysis based on the requested operations."""
            
            # Send to LM Studio API
            response = requests.post(
                f"{self.api_base}/v1/chat/completions",
                json={
                    "model": self.current_model,
                    "messages": [
                        {"role": "user", "content": prompt}
                    ],
                    "temperature": self.temperature_var.get(),
                    "max_tokens": self.max_tokens_var.get()
                },
                timeout=120
            )
            
            if response.status_code == 200:
                result = response.json()
                analysis = result['choices'][0]['message']['content']
                
                # Display the output in the text box
                self.doc_output.config(state=tk.NORMAL)
                self.doc_output.delete("1.0", tk.END)
                self.doc_output.insert(tk.END, analysis)
                self.doc_output.config(state=tk.DISABLED)
            else:
                self.doc_output.config(state=tk.NORMAL)
                self.doc_output.delete("1.0", tk.END)
                self.doc_output.insert(tk.END, f"API Error: {response.status_code}")
                self.doc_output.config(state=tk.DISABLED)
        
        except FileNotFoundError:
            self.doc_output.config(state=tk.NORMAL)
            self.doc_output.delete("1.0", tk.END)
            self.doc_output.insert(tk.END, "Error: Could not read one of the selected files.")
            self.doc_output.config(state=tk.DISABLED)
        except requests.exceptions.RequestException as e:
            self.doc_output.config(state=tk.NORMAL)
            self.doc_output.delete("1.0", tk.END)
            self.doc_output.insert(tk.END, f"Failed to connect to LM Studio:\n{str(e)}")
            self.doc_output.config(state=tk.DISABLED)
        except KeyError:
            self.doc_output.config(state=tk.NORMAL)
            self.doc_output.delete("1.0", tk.END)
            self.doc_output.insert(tk.END, "Unexpected response format from LM Studio.")
            self.doc_output.config(state=tk.DISABLED)
    
    def copy_doc_output(self):
        """Copy document output text to clipboard"""
        text = self.doc_output.get("1.0", tk.END)
        if text.strip():
            self.root.clipboard_clear()
            self.root.clipboard_append(text)
            messagebox.showinfo("Success", "Output copied to clipboard!")
        else:
            messagebox.showwarning("Empty", "No output to copy.")
    
    def clear_doc_output(self):
        """Clear document output text"""
        self.doc_output.config(state=tk.NORMAL)
        self.doc_output.delete("1.0", tk.END)
        self.doc_output.config(state=tk.DISABLED)
    
    def send_chat(self):
        """Send a chat message to the currently loaded model"""
        if not self.current_model:
            messagebox.showwarning("No Model", "Please load a model first.")
            return
        
        # Get user input
        user_message = self.chat_input.get("1.0", tk.END).strip()
        if not user_message:
            messagebox.showwarning("Empty Message", "Please type a message.")
            return
        
        try:
            # Clear input field
            self.chat_input.delete("1.0", tk.END)
            
            # Clear output box
            self.chat_output.config(state=tk.NORMAL)
            self.chat_output.delete("1.0", tk.END)
            self.chat_output.insert(tk.END, "Processing...")
            self.chat_output.config(state=tk.DISABLED)
            self.root.update()
            
            # Build prompt with uploaded documents if available
            chat_prompt = user_message
            if self.uploaded_documents:
                # Read all uploaded files
                all_content = []
                for file_path in self.uploaded_documents:
                    with open(file_path, 'r', encoding='utf-8') as f:
                        content = f.read()
                        all_content.append(f"=== {os.path.basename(file_path)} ===\n{content}")
                
                combined_content = "\n\n".join(all_content)
                chat_prompt = f"""Here are some documents:

{combined_content}

User's question: {user_message}"""
            
            # Send to LM Studio API
            response = requests.post(
                f"{self.api_base}/v1/chat/completions",
                json={
                    "model": self.current_model,
                    "messages": [
                        {"role": "user", "content": chat_prompt}
                    ],
                    "temperature": self.temperature_var.get(),
                    "max_tokens": self.max_tokens_var.get()
                },
                timeout=60
            )
            
            if response.status_code == 200:
                result = response.json()
                assistant_message = result['choices'][0]['message']['content']
                
                # Display response in output box
                self.chat_output.config(state=tk.NORMAL)
                self.chat_output.delete("1.0", tk.END)
                self.chat_output.insert(tk.END, assistant_message)
                self.chat_output.config(state=tk.DISABLED)
            else:
                self.chat_output.config(state=tk.NORMAL)
                self.chat_output.delete("1.0", tk.END)
                self.chat_output.insert(tk.END, f"API Error: {response.status_code}")
                self.chat_output.config(state=tk.DISABLED)
        
        except requests.exceptions.RequestException as e:
            self.chat_output.config(state=tk.NORMAL)
            self.chat_output.delete("1.0", tk.END)
            self.chat_output.insert(tk.END, f"Failed to connect to LM Studio:\n{str(e)}")
            self.chat_output.config(state=tk.DISABLED)
        except KeyError:
            self.chat_output.config(state=tk.NORMAL)
            self.chat_output.delete("1.0", tk.END)
            self.chat_output.insert(tk.END, "Unexpected response format from LM Studio.")
            self.chat_output.config(state=tk.DISABLED)
    
    def clear_chat_output(self):
        """Clear the chat output text box"""
        self.chat_output.config(state=tk.NORMAL)
        self.chat_output.delete("1.0", tk.END)
        self.chat_output.config(state=tk.DISABLED)


if __name__ == "__main__":
    root = tk.Tk()
    # Hide main window initially - will show after startup checks
    root.withdraw()
    app = LMStudioOrchestrator(root)
    root.mainloop()
