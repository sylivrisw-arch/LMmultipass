#!/usr/bin/env python3
"""
LMsuite Token Tuner
===================
Small GUI for changing the max_tokens limits used by the Discussion feature in
LMsuite_polished.py, without hand-editing the source.

It reads the current values straight out of the suite file, lets you change them,
makes a timestamped backup, patches ONLY those numbers, syntax-checks the result
before saving, and re-reads the file to confirm.

Limits it controls
  1. Regular turns (Researcher, Critic, Analyst, ...)   CONFIG['DISCUSSION']['turn_max_tokens']
  2. Moderator synthesis                                CONFIG['DISCUSSION']['moderator_max_tokens']
  3. Discussion Rules checks (default)                  _discussion_rule_ask(..., max_tokens=300)
  4. Rule follow-up call (Investigate rule)             _discussion_rule_ask(..., max_tokens=400)
  5. Compaction / summary call                          hardcoded in _compact_discussion_transcript

Restart LMsuite after applying - it only reads its settings at startup.

Build to .exe:  pyinstaller --onefile --noconsole lmsuite_token_tuner.py
"""

import datetime
import glob
import json
import os
import re
import shutil
import sys
import tkinter as tk
from tkinter import filedialog, messagebox, ttk

APP_TITLE = "LMsuite Token Tuner"
DEFAULT_FILENAME = "LMsuite_polished.py"
MIN_TOKENS, MAX_TOKENS = 50, 32000


def app_dir():
    if getattr(sys, "frozen", False):
        return os.path.dirname(sys.executable)
    return os.path.dirname(os.path.abspath(__file__))


SETTINGS_PATH = os.path.join(app_dir(), "lmsuite_token_tuner.json")


# --------------------------------------------------------------------------------------
# Locating the numbers inside the suite source
# --------------------------------------------------------------------------------------

def _single_span(text, pattern, flags=0, base=0):
    """Return (start, end, value) of group 2 if the pattern matches exactly once, else None."""
    matches = list(re.finditer(pattern, text, flags))
    if len(matches) != 1:
        return None
    m = matches[0]
    return (base + m.start(2), base + m.end(2), int(m.group(2)))


def find_turn(text):
    return _single_span(text, r"('turn_max_tokens'\s*:\s*)(\d+)")


def find_moderator(text):
    return _single_span(text, r"('moderator_max_tokens'\s*:\s*)(\d+)")


def find_rule_default(text):
    return _single_span(
        text,
        r"(def _discussion_rule_ask\(self,\s*prompt,\s*model_key,\s*log,\s*max_tokens\s*=\s*)(\d+)",
    )


def find_rule_followup(text):
    return _single_span(
        text,
        r"(self\._discussion_rule_ask\(\s*prompt,\s*speaker\[[\"']model_key[\"']\],\s*log,\s*max_tokens\s*=\s*)(\d+)",
    )


def find_compaction(text):
    fm = re.search(
        r"^    def _compact_discussion_transcript\b.*?(?=^    def |\Z)", text, re.S | re.M
    )
    if not fm:
        return None
    return _single_span(fm.group(0), r"([\"']max_tokens[\"']\s*:\s*)(\d+)", base=fm.start())


FIELDS = [
    {
        "key": "turn",
        "label": "Regular turns",
        "desc": "Researcher, Critic, Analyst, etc. - one reply per turn",
        "find": find_turn,
    },
    {
        "key": "moderator",
        "label": "Moderator synthesis",
        "desc": "The Moderator's closing summary of the whole discussion",
        "find": find_moderator,
    },
    {
        "key": "rule_default",
        "label": "Discussion Rules checks",
        "desc": "Default for the extra per-turn rule checks (dedup, fact-check, cross-check)",
        "find": find_rule_default,
    },
    {
        "key": "rule_followup",
        "label": "Rule follow-up call",
        "desc": "The 'investigate' rule's follow-up question call",
        "find": find_rule_followup,
    },
    {
        "key": "compaction",
        "label": "Compaction / summary",
        "desc": "Periodic call that folds older turns into the running summary",
        "find": find_compaction,
    },
]


# --------------------------------------------------------------------------------------
# File operations (no GUI code below this line until the App class)
# --------------------------------------------------------------------------------------

def read_text(path):
    # newline="" keeps the file's original line endings (CRLF vs LF) untouched
    with open(path, "r", encoding="utf-8", newline="") as f:
        return f.read()


def read_values(path):
    """Return {key: int or None} for every field."""
    text = read_text(path)
    out = {}
    for fld in FIELDS:
        span = fld["find"](text)
        out[fld["key"]] = span[2] if span else None
    return out


def list_backups(path):
    return sorted(glob.glob(path + ".bak_*"))


def apply_changes(path, new_values):
    """
    Patch the given {key: int} values into the file.
    Returns (changed_keys, backup_path). Raises ValueError with a readable message on any problem.
    """
    text = read_text(path)
    edits = []
    changed = []
    for fld in FIELDS:
        key = fld["key"]
        if key not in new_values:
            continue
        span = fld["find"](text)
        if span is None:
            raise ValueError(
                f"Couldn't find a single, unambiguous spot for '{fld['label']}' in the file. "
                "The suite's code may have changed - nothing was written."
            )
        start, end, old = span
        new = int(new_values[key])
        if new != old:
            edits.append((start, end, str(new)))
            changed.append(key)

    if not edits:
        return [], None

    new_text = text
    for start, end, repl in sorted(edits, reverse=True):
        new_text = new_text[:start] + repl + new_text[end:]

    try:
        compile(new_text, path, "exec")
    except SyntaxError as e:
        raise ValueError(f"Patched file failed the syntax check ({e}). Nothing was written.")

    stamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
    backup = f"{path}.bak_{stamp}"
    shutil.copy2(path, backup)

    with open(path, "w", encoding="utf-8", newline="") as f:
        f.write(new_text)

    # Verify by reading back
    check = read_values(path)
    for key in changed:
        if check.get(key) != int(new_values[key]):
            raise ValueError(
                "Write finished but the values didn't read back correctly. "
                f"Your original is safe in {os.path.basename(backup)}."
            )
    return changed, backup


# --------------------------------------------------------------------------------------
# GUI
# --------------------------------------------------------------------------------------

class App:
    # Shared look - these values mirror PALETTE in LMsuite_polished.py so both tools match.
    BG = "#f4f5f7"
    CARD = "#ffffff"
    TEXT = "#111827"
    MUTED = "#6b7280"
    ACCENT = "#2563eb"
    ACCENT_HOVER = "#1d4ed8"
    NEUTRAL = "#e5e7eb"
    NEUTRAL_HOVER = "#d1d5db"
    BORDER = "#e5e7eb"
    BORDER_STRONG = "#d1d5db"
    DISABLED = "#9ca3af"
    PENDING = "#b45309"
    OK = "#15803d"
    ERR = "#b91c1c"

    def __init__(self, root):
        self.root = root
        root.title(APP_TITLE)
        root.configure(bg=self.BG)
        root.minsize(760, 520)

        self.path_var = tk.StringVar(value=self._initial_path())
        self.status_var = tk.StringVar(value="")
        self.current = {f["key"]: None for f in FIELDS}   # values as last read from file
        self.vars = {f["key"]: tk.StringVar() for f in FIELDS}
        self.cur_labels = {}
        self.spinboxes = {}

        self._style()
        self._build()
        self.reload()

    # ---- setup ---------------------------------------------------------------------
    def _initial_path(self):
        try:
            with open(SETTINGS_PATH, "r", encoding="utf-8") as f:
                saved = json.load(f).get("path", "")
            if saved and os.path.isfile(saved):
                return saved
        except Exception:
            pass
        local = os.path.join(app_dir(), DEFAULT_FILENAME)
        return local if os.path.isfile(local) else ""

    def _save_path(self):
        try:
            with open(SETTINGS_PATH, "w", encoding="utf-8") as f:
                json.dump({"path": self.path_var.get()}, f)
        except Exception:
            pass

    def _style(self):
        s = ttk.Style()
        try:
            s.theme_use("clam")
        except tk.TclError:
            pass
        field = dict(fieldbackground=self.CARD, foreground=self.TEXT, bordercolor=self.BORDER_STRONG,
                     lightcolor=self.CARD, darkcolor=self.CARD, insertcolor=self.TEXT, padding=4)
        s.configure("TFrame", background=self.BG)
        s.configure("Card.TFrame", background=self.CARD)
        s.configure("Panel.TFrame", background=self.CARD, relief="solid", borderwidth=1,
                    bordercolor=self.BORDER, lightcolor=self.BORDER, darkcolor=self.BORDER)
        s.configure("TLabel", background=self.BG, foreground=self.TEXT, font=("Segoe UI", 10))
        s.configure("Card.TLabel", background=self.CARD, foreground=self.TEXT, font=("Segoe UI", 10))
        s.configure("Title.TLabel", background=self.BG, foreground=self.TEXT, font=("Segoe UI", 15, "bold"))
        s.configure("Muted.TLabel", background=self.CARD, foreground=self.MUTED, font=("Segoe UI", 9))
        s.configure("Sub.TLabel", background=self.BG, foreground=self.MUTED, font=("Segoe UI", 9))
        s.configure("TEntry", **field)
        s.configure("TSpinbox", background=self.NEUTRAL, arrowcolor=self.TEXT, **field)
        s.map("TEntry", bordercolor=[("focus", self.ACCENT)])
        s.map("TSpinbox", bordercolor=[("focus", self.ACCENT)], background=[("active", self.NEUTRAL_HOVER)])
        # Buttons: flat, same size/padding, regular weight - grey by default, blue for the main action
        s.configure("TButton", font=("Segoe UI", 10), padding=(14, 5), relief="flat", borderwidth=0,
                    background=self.NEUTRAL, foreground=self.TEXT, focuscolor=self.NEUTRAL, focusthickness=0)
        s.map("TButton", background=[("active", self.NEUTRAL_HOVER), ("pressed", self.NEUTRAL_HOVER)],
              foreground=[("disabled", self.DISABLED)])
        s.configure("Accent.TButton", font=("Segoe UI", 10), padding=(14, 5), relief="flat", borderwidth=0,
                    background=self.ACCENT, foreground="white", focuscolor=self.ACCENT, focusthickness=0)
        s.map("Accent.TButton", background=[("active", self.ACCENT_HOVER), ("pressed", self.ACCENT_HOVER),
                                            ("disabled", self.DISABLED)],
              foreground=[("disabled", "white")])

    def _build(self):
        outer = ttk.Frame(self.root, padding=18)
        outer.pack(fill=tk.BOTH, expand=True)

        ttk.Label(outer, text="Discussion token limits", style="Title.TLabel").pack(anchor=tk.W)
        ttk.Label(outer, text="Edits the max_tokens caps inside LMsuite_polished.py. "
                              "Restart the suite after applying.", style="Sub.TLabel").pack(
            anchor=tk.W, pady=(0, 12))

        # File row
        file_row = ttk.Frame(outer)
        file_row.pack(fill=tk.X, pady=(0, 12))
        ttk.Label(file_row, text="Suite file:").pack(side=tk.LEFT)
        ttk.Entry(file_row, textvariable=self.path_var, font=("Segoe UI", 10)).pack(
            side=tk.LEFT, fill=tk.X, expand=True, padx=8)
        ttk.Button(file_row, text="Browse...", command=self.browse).pack(side=tk.LEFT)
        ttk.Button(file_row, text="Reload", command=self.reload).pack(side=tk.LEFT, padx=(6, 0))

        # Fields card
        card = ttk.Frame(outer, style="Panel.TFrame", padding=16)
        card.pack(fill=tk.BOTH, expand=True)
        card.columnconfigure(0, weight=1)

        hdr_font = ("Segoe UI", 9, "bold")
        tk.Label(card, text="LIMIT", bg=self.CARD, fg=self.MUTED, font=hdr_font).grid(
            row=0, column=0, sticky=tk.W)
        tk.Label(card, text="NEW VALUE", bg=self.CARD, fg=self.MUTED, font=hdr_font).grid(
            row=0, column=1, padx=12)
        tk.Label(card, text="IN FILE NOW", bg=self.CARD, fg=self.MUTED, font=hdr_font).grid(
            row=0, column=2, sticky=tk.W)

        for i, fld in enumerate(FIELDS, start=1):
            key = fld["key"]
            text_frame = ttk.Frame(card, style="Card.TFrame")
            text_frame.grid(row=i, column=0, sticky=tk.W, pady=8)
            ttk.Label(text_frame, text=fld["label"], style="Card.TLabel",
                      font=("Segoe UI", 10, "bold")).pack(anchor=tk.W)
            ttk.Label(text_frame, text=fld["desc"], style="Muted.TLabel").pack(anchor=tk.W)

            sb = ttk.Spinbox(card, from_=MIN_TOKENS, to=MAX_TOKENS, increment=50, width=9,
                             textvariable=self.vars[key], font=("Segoe UI", 10), justify=tk.RIGHT)
            sb.grid(row=i, column=1, padx=12)
            self.spinboxes[key] = sb

            cur = tk.Label(card, text="-", bg=self.CARD, fg=self.MUTED, font=("Segoe UI", 10), width=22,
                           anchor=tk.W)
            cur.grid(row=i, column=2, sticky=tk.W)
            self.cur_labels[key] = cur

            self.vars[key].trace_add("write", lambda *_a, k=key: self._refresh_marker(k))

        ttk.Label(card, text=f"Allowed range: {MIN_TOKENS}-{MAX_TOKENS}. Keep values within your model's "
                             "context window - larger caps make each turn slower.",
                  style="Muted.TLabel").grid(row=len(FIELDS) + 1, column=0, columnspan=3,
                                             sticky=tk.W, pady=(12, 0))

        # Buttons
        btns = ttk.Frame(outer)
        btns.pack(fill=tk.X, pady=(14, 0))
        self.apply_btn = ttk.Button(btns, text="Apply changes", style="Accent.TButton", command=self.apply)
        self.apply_btn.pack(side=tk.LEFT)
        ttk.Button(btns, text="Reset to file values", command=self.reset).pack(side=tk.LEFT, padx=8)
        ttk.Button(btns, text="Restore latest backup", command=self.restore).pack(side=tk.LEFT)

        self.status_lbl = tk.Label(outer, textvariable=self.status_var, bg=self.BG, fg=self.MUTED,
                                   font=("Segoe UI", 9), anchor=tk.W, justify=tk.LEFT, wraplength=720)
        self.status_lbl.pack(fill=tk.X, pady=(12, 0))

    # ---- helpers -------------------------------------------------------------------
    def set_status(self, msg, color=None):
        self.status_var.set(msg)
        self.status_lbl.configure(fg=color or self.MUTED)

    def _parse(self, key):
        raw = self.vars[key].get().strip()
        try:
            val = int(raw)
        except ValueError:
            return None
        return val if MIN_TOKENS <= val <= MAX_TOKENS else None

    def _refresh_marker(self, key):
        cur = self.current.get(key)
        lbl = self.cur_labels[key]
        if cur is None:
            lbl.configure(text="not found in file", fg=self.ERR)
            return
        new = self._parse(key)
        if new is None:
            lbl.configure(text=f"{cur}   (invalid entry)", fg=self.ERR)
        elif new != cur:
            lbl.configure(text=f"{cur}   -> will change to {new}", fg=self.PENDING)
        else:
            lbl.configure(text=str(cur), fg=self.MUTED)

    # ---- actions -------------------------------------------------------------------
    def browse(self):
        p = filedialog.askopenfilename(
            title="Select LMsuite_polished.py",
            filetypes=[("Python files", "*.py"), ("All files", "*.*")],
            initialdir=os.path.dirname(self.path_var.get()) or app_dir(),
        )
        if p:
            self.path_var.set(p)
            self.reload()

    def reload(self):
        path = self.path_var.get().strip()
        if not path or not os.path.isfile(path):
            for key in self.current:
                self.current[key] = None
                self.vars[key].set("")
                self.spinboxes[key].configure(state="disabled")
                self._refresh_marker(key)
            self.apply_btn.state(["disabled"])
            self.set_status("Pick your LMsuite_polished.py file to begin.", self.MUTED)
            return
        try:
            values = read_values(path)
        except Exception as e:
            self.set_status(f"Couldn't read the file: {e}", self.ERR)
            return

        missing = []
        for fld in FIELDS:
            key = fld["key"]
            self.current[key] = values[key]
            if values[key] is None:
                self.vars[key].set("")
                self.spinboxes[key].configure(state="disabled")
                missing.append(fld["label"])
            else:
                self.spinboxes[key].configure(state="normal")
                self.vars[key].set(str(values[key]))
            self._refresh_marker(key)

        self.apply_btn.state(["!disabled"])
        self._save_path()
        backups = len(list_backups(path))
        if missing:
            self.set_status("Loaded, but couldn't locate: " + ", ".join(missing) +
                            ". The suite's code may differ from the version this tool expects. "
                            "Those fields are disabled.", self.PENDING)
        else:
            self.set_status(f"Loaded all {len(FIELDS)} limits. {backups} backup(s) on disk.", self.OK)

    def reset(self):
        for key, val in self.current.items():
            if val is not None:
                self.vars[key].set(str(val))
        self.set_status("Reset to the values currently in the file.", self.MUTED)

    def apply(self):
        path = self.path_var.get().strip()
        if not os.path.isfile(path):
            self.set_status("That file doesn't exist.", self.ERR)
            return

        new_values = {}
        for fld in FIELDS:
            key = fld["key"]
            if self.current[key] is None:
                continue
            val = self._parse(key)
            if val is None:
                messagebox.showerror(APP_TITLE, f"'{fld['label']}' must be a whole number between "
                                                f"{MIN_TOKENS} and {MAX_TOKENS}.")
                return
            new_values[key] = val

        try:
            changed, backup = apply_changes(path, new_values)
        except Exception as e:
            self.set_status(str(e), self.ERR)
            messagebox.showerror(APP_TITLE, str(e))
            return

        if not changed:
            self.set_status("Nothing to change - all values already match the file.", self.MUTED)
            return

        self.reload()
        names = ", ".join(f["label"] for f in FIELDS if f["key"] in changed)
        self.set_status(f"Saved: {names}.  Backup: {os.path.basename(backup)}.  "
                        "Restart LMsuite for this to take effect.", self.OK)

    def restore(self):
        path = self.path_var.get().strip()
        backups = list_backups(path) if path else []
        if not backups:
            messagebox.showinfo(APP_TITLE, "No backups found next to the suite file.")
            return
        latest = backups[-1]
        if not messagebox.askyesno(
                APP_TITLE,
                f"Replace the current file with this backup?\n\n{os.path.basename(latest)}\n\n"
                "Any edits made to the suite since that backup will be lost."):
            return
        try:
            shutil.copy2(latest, path)
        except Exception as e:
            self.set_status(f"Restore failed: {e}", self.ERR)
            return
        self.reload()
        self.set_status(f"Restored from {os.path.basename(latest)}.", self.OK)


def main():
    root = tk.Tk()
    App(root)
    root.mainloop()


if __name__ == "__main__":
    main()
