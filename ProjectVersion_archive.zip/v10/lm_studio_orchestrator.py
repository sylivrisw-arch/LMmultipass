import tkinter as tk
from tkinter import ttk, messagebox, filedialog
import requests
import os
import threading
import datetime
import sys
import subprocess

class LoadingSplash:
    """Splash screen with loading bar shown during startup checks"""
    def __init__(self, root):
        self.root = root
        self.splash = tk.Toplevel(root)
        self.splash.title("LM Studio Orchestrator")
        self.splash.geometry("400x150")
        self.splash.resizable(False, False)
        
        # Center on screen
        self.splash.update_idletasks()
        x = (self.splash.winfo_screenwidth() // 2) - 200
        y = (self.splash.winfo_screenheight() // 2) - 75
        self.splash.geometry(f"+{x}+{y}")
        
        # Remove window decorations for cleaner look
        self.splash.attributes('-topmost', True)
        
        # Content
        ttk.Label(self.splash, text="LM Studio Multi-Model Orchestrator", font=("Arial", 12, "bold")).pack(pady=15)
        ttk.Label(self.splash, text="Checking server...", font=("Arial", 9)).pack(pady=(0, 10))
        
        self.progress = ttk.Progressbar(self.splash, mode='indeterminate', length=300)
        self.progress.pack(pady=10)
        self.progress.start()
    
    def update_status(self, text):
        """Update status text on splash screen"""
        self.status_text.config(text=text)
        self.splash.update()
    
    def close(self):
        """Close splash screen"""
        self.progress.stop()
        self.splash.destroy()

class ChatWindow:
    """Separate window for direct chat interface - Facebook Messenger style"""
    def __init__(self, parent, parent_app):
        self.parent_app = parent_app
        self.window = tk.Toplevel(parent)
        self.window.title("Chat - LM Studio")
        self.window.geometry("600x700")
        self.window.resizable(True, True)
        self.window.configure(bg="#fff")
        
        # Store message labels for responsive updates
        self.message_labels = []
        
        # Header with title and resolution
        header_frame = tk.Frame(self.window, bg="#f0f2f5")
        header_frame.pack(fill=tk.X, side=tk.TOP)
        
        # Title on left
        ttk.Label(header_frame, text="LM Studio Chat", font=("Arial", 14, "bold"), background="#f0f2f5").pack(side=tk.LEFT, pady=10, padx=10, fill=tk.X, expand=True)
        
        # Resolution counter on right
        self.chat_resolution_label = ttk.Label(header_frame, text="600x700", font=("Courier", 9), background="#f0f2f5", foreground="blue")
        self.chat_resolution_label.pack(side=tk.RIGHT, pady=10, padx=10)
        
        # Bind window resize event to update resolution display
        self.window.bind("<Configure>", self.update_chat_resolution)
        
        # Messages frame with scrollbar
        messages_container = tk.Frame(self.window, bg="#fff")
        messages_container.pack(fill=tk.BOTH, expand=True, side=tk.TOP)
        
        self.canvas = tk.Canvas(messages_container, bg="#fff", highlightthickness=0)
        scrollbar = ttk.Scrollbar(messages_container, orient="vertical", command=self.canvas.yview)
        self.messages_frame = tk.Frame(self.canvas, bg="#fff")
        
        self.messages_frame.bind(
            "<Configure>",
            lambda e: self.canvas.configure(scrollregion=self.canvas.bbox("all"))
        )
        
        # Bind canvas resize to update message wraplengths
        self.canvas.bind("<Configure>", self.update_message_wraplengths)
        
        self.canvas.create_window((0, 0), window=self.messages_frame, anchor="nw")
        self.canvas.configure(yscrollcommand=scrollbar.set)
        
        self.canvas.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        
        # Bind mousewheel only to canvas (not globally)
        def _on_mousewheel(event):
            try:
                if self.canvas.winfo_exists():
                    self.canvas.yview_scroll(int(-1*(event.delta/120)), "units")
            except:
                pass  # Canvas was destroyed, ignore
        
        self.canvas.bind("<MouseWheel>", _on_mousewheel)
        self.messages_frame.bind("<MouseWheel>", _on_mousewheel)
        
        # Input frame
        input_frame = tk.Frame(self.window, bg="#f0f2f5")
        input_frame.pack(fill=tk.BOTH, side=tk.BOTTOM, padx=0, pady=0)
        
        # Input field with icon
        input_sub_frame = tk.Frame(input_frame, bg="#f0f2f5")
        input_sub_frame.pack(fill=tk.X, expand=True, padx=10, pady=10)
        
        self.chat_input = tk.Text(input_sub_frame, height=2, font=("Arial", 10), wrap=tk.WORD, 
                                   bg="white", fg="#000", relief=tk.SOLID, bd=1)
        self.chat_input.pack(side=tk.LEFT, fill=tk.BOTH, expand=True, padx=(0, 8))
        self.chat_input.bind('<Control-Return>', lambda e: self.send_chat())
        
        # Send button (blue like Messenger)
        send_btn = tk.Button(input_sub_frame, text="➤", font=("Arial", 12, "bold"), 
                            bg="#0084ff", fg="white", relief=tk.FLAT, bd=0, padx=12, pady=6,
                            command=self.send_chat, cursor="hand2")
        send_btn.pack(side=tk.LEFT)
        
        # Options frame
        options_frame = tk.Frame(input_frame, bg="#f0f2f5")
        options_frame.pack(fill=tk.X, padx=10, pady=(0, 10))
        
        ttk.Button(options_frame, text="📋 Copy", command=self.copy_chat_output).pack(side=tk.LEFT, padx=(0, 5))
        ttk.Button(options_frame, text="🗑️ Clear", command=self.clear_chat_output).pack(side=tk.LEFT)
    
    def update_chat_resolution(self, event=None):
        """Update chat window resolution display"""
        width = self.window.winfo_width()
        height = self.window.winfo_height()
        if width > 1 and height > 1:  # Skip initial configure events
            self.chat_resolution_label.config(text=f"{width}x{height}")
    
    def update_message_wraplengths(self, event=None):
        """Update wraplength for all messages based on canvas width"""
        canvas_width = self.canvas.winfo_width()
        if canvas_width > 1:
            # Calculate max bubble width (canvas width - padding)
            max_width = max(canvas_width - 100, 150)  # Min 150 to prevent too narrow text
            
            # Update all existing message labels
            for label in self.message_labels:
                label.config(wraplength=max_width)
    
    def add_message(self, text, is_user=True):
        """Add a message bubble to the chat"""
        msg_frame = tk.Frame(self.messages_frame, bg="#fff")
        msg_frame.pack(fill=tk.X, padx=10, pady=5, anchor=tk.E if is_user else tk.W)
        
        # Get current canvas width for initial wraplength
        canvas_width = self.canvas.winfo_width()
        if canvas_width < 2:
            canvas_width = 600  # Default width if not yet rendered
        max_width = max(canvas_width - 100, 150)
        
        if is_user:
            # User message (right, blue)
            bubble_frame = tk.Frame(msg_frame, bg="#0084ff", relief=tk.FLAT)
            bubble_frame.pack(side=tk.RIGHT, padx=(50, 0), fill=tk.X, expand=False)
            
            msg_label = tk.Label(bubble_frame, text=text, font=("Arial", 10), 
                                fg="white", bg="#0084ff", wraplength=max_width, justify=tk.LEFT, padx=12, pady=8)
            msg_label.pack(fill=tk.BOTH, expand=True)
        else:
            # Assistant message (left, gray)
            bubble_frame = tk.Frame(msg_frame, bg="#e4e6eb", relief=tk.FLAT)
            bubble_frame.pack(side=tk.LEFT, padx=(0, 50), fill=tk.X, expand=False)
            
            msg_label = tk.Label(bubble_frame, text=text, font=("Arial", 10), 
                                fg="#000", bg="#e4e6eb", wraplength=max_width, justify=tk.LEFT, padx=12, pady=8)
            msg_label.pack(fill=tk.BOTH, expand=True)
        
        # Store label for later updates
        self.message_labels.append(msg_label)
        
        # Auto-scroll to bottom
        self.messages_frame.update_idletasks()
        self.canvas.yview_moveto(1)
    
    def send_chat(self):
        """Send a chat message to the currently loaded model"""
        if not self.parent_app.current_model:
            messagebox.showwarning("No Model", "Please load a model first.")
            return
        
        # Get user input
        user_message = self.chat_input.get("1.0", tk.END).strip()
        if not user_message:
            messagebox.showwarning("Empty Message", "Please type a message.")
            return
        
        try:
            # Display user message
            self.add_message(user_message, is_user=True)
            
            # Clear input field
            self.chat_input.delete("1.0", tk.END)
            self.window.update()
            
            # Show typing indicator
            self.add_message("Thinking...", is_user=False)
            self.window.update()
            
            # Build prompt with uploaded documents if available
            chat_prompt = user_message
            if self.parent_app.uploaded_documents:
                # Read all uploaded files
                all_content = []
                for file_path in self.parent_app.uploaded_documents:
                    with open(file_path, 'r', encoding='utf-8') as f:
                        content = f.read()
                        all_content.append(f"=== {os.path.basename(file_path)} ===\n{content}")
                
                combined_content = "\n\n".join(all_content)
                chat_prompt = f"""Here are some documents:

{combined_content}

User's question: {user_message}"""
            
            # Send to LM Studio API
            response = requests.post(
                f"{self.parent_app.api_base}/v1/chat/completions",
                json={
                    "model": self.parent_app.current_model,
                    "messages": [
                        {"role": "user", "content": chat_prompt}
                    ],
                    "temperature": self.parent_app.temperature_var.get(),
                    "max_tokens": self.parent_app.max_tokens_var.get()
                },
                timeout=60
            )
            
            if response.status_code == 200:
                result = response.json()
                assistant_message = result['choices'][0]['message']['content']
                
                # Extract token usage and update parent app
                if 'usage' in result:
                    tokens_used = result['usage'].get('total_tokens', 0)
                    self.parent_app.reasoning_tokens = tokens_used
                    self.parent_app.session_tokens += tokens_used
                    
                    # Update token display in main window
                    self.parent_app.reasoning_tokens_label.config(text=str(self.parent_app.reasoning_tokens))
                    self.parent_app.session_tokens_label.config(text=str(self.parent_app.session_tokens))
                
                # Remove typing indicator and add real response
                self.messages_frame.winfo_children()[-1].destroy()
                self.add_message(assistant_message, is_user=False)
            else:
                self.messages_frame.winfo_children()[-1].destroy()
                self.add_message(f"API Error: {response.status_code}", is_user=False)
        
        except requests.exceptions.RequestException as e:
            if self.messages_frame.winfo_children():
                self.messages_frame.winfo_children()[-1].destroy()
            self.add_message(f"Failed to connect to LM Studio:\n{str(e)}", is_user=False)
        except KeyError:
            if self.messages_frame.winfo_children():
                self.messages_frame.winfo_children()[-1].destroy()
            self.add_message("Unexpected response format from LM Studio.", is_user=False)
    
    def copy_chat_output(self):
        """Copy last assistant message to clipboard"""
        # Find the last assistant message (gray bubble)
        for widget in reversed(self.messages_frame.winfo_children()):
            for child in widget.winfo_children():
                if isinstance(child, tk.Frame) and child.cget("bg") == "#e4e6eb":
                    # Found assistant message frame
                    for label in child.winfo_children():
                        if isinstance(label, tk.Label):
                            text = label.cget("text")
                            if text.strip():
                                self.parent_app.root.clipboard_clear()
                                self.parent_app.root.clipboard_append(text)
                                messagebox.showinfo("Success", "Message copied to clipboard!")
                                return
        messagebox.showwarning("Empty", "No message to copy.")
    
    def clear_chat_output(self):
        """Clear all chat messages"""
        for widget in self.messages_frame.winfo_children():
            widget.destroy()

class LMStudioOrchestrator:
    def __init__(self, root):
        self.root = root
        self.root.title("LM Studio Multi-Model Orchestrator")
        self.root.geometry("707x622")
        self.root.resizable(True, True)  # Allow full resizing
        
        # Window lock state
        self.window_locked = False
        
        # API Config
        self.api_base = "http://localhost:1234"
        self.model_keys = {}  # Map listbox index to model key
        self.current_model = None  # Track currently loaded model
        self.uploaded_documents = []  # Track uploaded files
        self.loading_model = False  # Prevent multiple simultaneous loads
        
        # Document settings
        self.max_tokens_var = tk.IntVar(value=2000)
        self.temperature_var = tk.DoubleVar(value=0.7)
        
        # Token tracking
        self.session_tokens = 0
        self.reasoning_tokens = 0
        
        # ===== SCROLLABLE CONTAINER =====
        # Create canvas and scrollbar for scrolling
        canvas = tk.Canvas(root, bg="white", highlightthickness=0)
        scrollbar = ttk.Scrollbar(root, orient="vertical", command=canvas.yview)
        scrollable_frame = ttk.Frame(canvas)
        
        scrollable_frame.bind(
            "<Configure>",
            lambda e: canvas.configure(scrollregion=canvas.bbox("all"))
        )
        
        canvas.create_window((0, 0), window=scrollable_frame, anchor="nw")
        canvas.configure(yscrollcommand=scrollbar.set)
        
        # Pack canvas and scrollbar
        canvas.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        
        # Bind mousewheel for scrolling (only to canvas, not globally)
        def _on_mousewheel(event):
            try:
                if canvas.winfo_exists():
                    canvas.yview_scroll(int(-1*(event.delta/120)), "units")
            except:
                pass  # Canvas was destroyed, ignore
        canvas.bind("<MouseWheel>", _on_mousewheel)
        scrollable_frame.bind("<MouseWheel>", _on_mousewheel)
        
        # ===== CONTROL PANEL =====
        self.control_frame = ttk.LabelFrame(scrollable_frame, text="Model Control", padding=10)
        self.control_frame.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)
        
        # Connection status
        ttk.Label(self.control_frame, text="LM Studio Status:", font=("Arial", 10, "bold")).pack(anchor=tk.W, pady=(0, 5))
        
        status_row = ttk.Frame(self.control_frame)
        status_row.pack(fill=tk.X, pady=(0, 5))
        
        self.status_label = ttk.Label(status_row, text="❌ Disconnected", foreground="red", font=("Arial", 9))
        self.status_label.pack(side=tk.LEFT, padx=(0, 15))
        
        ttk.Label(status_row, text="Server:", font=("Arial", 9)).pack(side=tk.LEFT, padx=(0, 5))
        self.server_label = ttk.Label(status_row, text=self.api_base, foreground="blue", font=("Courier", 9))
        self.server_label.pack(side=tk.LEFT)
        
        # Window resolution display (top right) with lock button
        resolution_frame = ttk.Frame(status_row)
        resolution_frame.pack(side=tk.RIGHT)
        
        self.resolution_label = ttk.Label(resolution_frame, text="707x622", foreground="blue", font=("Courier", 9))
        self.resolution_label.pack(side=tk.LEFT, padx=(0, 5))
        
        self.lock_button = tk.Button(resolution_frame, text="🔓", font=("Arial", 8), command=self.toggle_window_lock, relief=tk.FLAT, bd=0, padx=3, pady=0)
        self.lock_button.pack(side=tk.LEFT)
        
        # Model load status
        model_status_row = ttk.Frame(self.control_frame)
        model_status_row.pack(anchor=tk.W, pady=(0, 10))
        
        self.model_status_label = ttk.Label(model_status_row, text="❌ No Model Loaded", foreground="red", font=("Arial", 9))
        self.model_status_label.pack(side=tk.LEFT, padx=(0, 15))
        
        ttk.Label(model_status_row, text="Model:", font=("Arial", 9)).pack(side=tk.LEFT, padx=(0, 5))
        self.model_name_label = ttk.Label(model_status_row, text="Waiting...", foreground="blue", font=("Courier", 9))
        self.model_name_label.pack(side=tk.LEFT)
        
        # Token tracking labels
        token_row = ttk.Frame(self.control_frame)
        token_row.pack(anchor=tk.W, pady=(0, 10))
        
        ttk.Label(token_row, text="Tokens used this session:", font=("Arial", 9)).pack(side=tk.LEFT, padx=(0, 10))
        self.session_tokens_label = ttk.Label(token_row, text="0", foreground="green", font=("Courier", 9, "bold"))
        self.session_tokens_label.pack(side=tk.LEFT, padx=(0, 20))
        
        ttk.Label(token_row, text="Reasoning:", font=("Arial", 9)).pack(side=tk.LEFT, padx=(0, 10))
        self.reasoning_tokens_label = ttk.Label(token_row, text="0", foreground="blue", font=("Courier", 9, "bold"))
        self.reasoning_tokens_label.pack(side=tk.LEFT)
        
        ttk.Button(self.control_frame, text="Refresh Script", command=self.refresh_script).pack(fill=tk.X, pady=3)
        ttk.Button(self.control_frame, text="Restart Script", command=self.restart_script).pack(fill=tk.X, pady=3)
        
        # Model selection
        ttk.Separator(self.control_frame, orient="horizontal").pack(fill=tk.X, pady=15)
        ttk.Label(self.control_frame, text="MODEL MANAGEMENT", font=("Arial", 11, "bold")).pack(anchor=tk.W, pady=(0, 8))
        
        ttk.Label(self.control_frame, text="Available Models:", font=("Arial", 9)).pack(anchor=tk.W, pady=(0, 3))
        ttk.Label(self.control_frame, text="(click model to load)", font=("Arial", 8), foreground="gray").pack(anchor=tk.W, pady=(0, 5))
        
        # Listbox for models (vertical list)
        self.models_listbox = tk.Listbox(self.control_frame, height=4, font=("Arial", 9), selectmode=tk.SINGLE)
        self.models_listbox.pack(fill=tk.X, pady=(0, 8))
        self.models_listbox.bind('<Double-Button-1>', self.on_model_select)  # Double-click to load
        self.models_listbox.bind('<Motion>', self.on_listbox_hover)  # Hover effect
        
        self.model_keys = {}  # Map listbox index to model key
        
        # Max tokens and temperature control
        tokens_row = ttk.Frame(self.control_frame)
        tokens_row.pack(fill=tk.X, pady=(0, 15))
        
        ttk.Label(tokens_row, text="Max Tokens:", font=("Arial", 9)).pack(side=tk.LEFT, padx=(0, 5))
        ttk.Spinbox(tokens_row, from_=100, to=32000, textvariable=self.max_tokens_var, width=10).pack(side=tk.LEFT, padx=(0, 20))
        
        ttk.Label(tokens_row, text="Temperature:", font=("Arial", 9)).pack(side=tk.LEFT, padx=(0, 5))
        ttk.Spinbox(tokens_row, from_=0.0, to=2.0, increment=0.1, textvariable=self.temperature_var, width=10).pack(side=tk.LEFT, padx=(0, 20))
        
        # Chat button on the right
        ttk.Button(tokens_row, text="💬 Open Chat Window", command=self.open_chat_window).pack(side=tk.LEFT)
        
        # Document upload section
        ttk.Separator(self.control_frame, orient="horizontal").pack(fill=tk.X, pady=15)
        ttk.Label(self.control_frame, text="DOCUMENT UPLOAD", font=("Arial", 11, "bold")).pack(anchor=tk.W, pady=(0, 8))
        
        # Main document frame (left and right layout)
        doc_main_frame = ttk.Frame(self.control_frame)
        doc_main_frame.pack(fill=tk.BOTH, expand=True, pady=(0, 15))
        
        # Left side - File input
        left_frame = ttk.Frame(doc_main_frame)
        left_frame.pack(side=tk.LEFT, fill=tk.BOTH, expand=False, padx=(0, 8))
        
        ttk.Label(left_frame, text="Uploaded Files (Max 2):", font=("Arial", 9)).pack(anchor=tk.W, pady=(0, 3))
        
        # Browse and Submit buttons
        upload_button_frame = ttk.Frame(left_frame)
        upload_button_frame.pack(fill=tk.X, pady=(0, 8))
        
        ttk.Button(upload_button_frame, text="Add Files", command=self.browse_document).pack(side=tk.LEFT, padx=(0, 5))
        ttk.Button(upload_button_frame, text="Submit", command=self.submit_document).pack(side=tk.LEFT, padx=(0, 5))
        ttk.Button(upload_button_frame, text="View Output", command=self.open_last_output).pack(side=tk.LEFT)
        
        # File chips frame (will contain file entries with X buttons) - appears below buttons
        self.files_frame = ttk.Frame(left_frame)
        self.files_frame.pack(fill=tk.X)
        
        # Track last output file
        self.last_output_file = None
        
        # Initialize chat window reference
        self.chat_window = None
        
        # Bind window resize event to update resolution display
        self.root.bind("<Configure>", self.update_resolution)
        
        # Initialize with loading splash
        self.run_startup_checks()
    
    def run_startup_checks(self):
        """Run startup checks in background thread with loading splash"""
        # Show loading splash
        splash = LoadingSplash(self.root)
        
        def startup_thread():
            self.check_connection()
            self.refresh_models()
            
            # Close splash and show main window
            splash.close()
            self.root.deiconify()  # Make main window visible
        
        # Start thread
        thread = threading.Thread(target=startup_thread, daemon=True)
        thread.start()
    
    def update_resolution(self, event=None):
        """Update window resolution display"""
        width = self.root.winfo_width()
        height = self.root.winfo_height()
        if width > 1 and height > 1:  # Skip initial configure events
            self.resolution_label.config(text=f"{width}x{height}")
    
    def toggle_window_lock(self):
        """Toggle window resizing lock"""
        self.window_locked = not self.window_locked
        self.root.resizable(not self.window_locked, not self.window_locked)
        self.lock_button.config(text="🔒" if self.window_locked else "🔓")
    
    def refresh_models(self):
        """Fetch and display available models from LM Studio in listbox"""
        try:
            response = requests.get(f"{self.api_base}/api/v1/models", timeout=5)
            if response.status_code == 200:
                data = response.json()
                models = data.get("models", [])
                
                # Clear listbox
                self.models_listbox.delete(0, tk.END)
                self.model_keys = {}
                
                # Populate with model names (LLMs only)
                llm_models = [m for m in models if m.get("type") == "llm"]
                
                if llm_models:
                    for idx, model in enumerate(llm_models):
                        display_name = model.get("display_name", "Unknown")
                        key = model.get("key", "unknown")
                        quantization = model.get("quantization", {}).get("name", "")
                        
                        display_text = f"{display_name} ({quantization})"
                        
                        self.models_listbox.insert(tk.END, display_text)
                        self.model_keys[idx] = key
                else:
                    self.models_listbox.insert(tk.END, "No LLM models found")
                
                # Clear selection to prevent auto-load
                self.models_listbox.selection_clear(0, tk.END)
            else:
                self.models_listbox.delete(0, tk.END)
                self.models_listbox.insert(tk.END, "Failed to load models")
        except Exception as e:
            self.models_listbox.delete(0, tk.END)
            self.models_listbox.insert(tk.END, f"Error: {str(e)}")
    
    def on_model_select(self, event):
        """Handle model selection from listbox (double-click)"""
        if self.loading_model:  # Prevent multiple simultaneous loads
            return
        
        # Get index from mouse position
        idx = self.models_listbox.nearest(event.y)
        if idx >= 0:
            model_key = self.model_keys.get(idx)
            if model_key:
                self.load_model(model_key)
    
    def on_listbox_hover(self, event):
        """Highlight listbox item on hover"""
        idx = self.models_listbox.nearest(event.y)
        if idx >= 0:
            self.models_listbox.selection_clear(0, tk.END)
            self.models_listbox.selection_set(idx)
            self.models_listbox.see(idx)
    
    def load_model(self, model_key):
        """Load a model by its key"""
        if not model_key:
            messagebox.showerror("Error", "Could not identify selected model")
            return
        
        self.loading_model = True  # Set flag to prevent multiple loads
        
        try:
            response = requests.post(
                f"{self.api_base}/api/v1/models/load",
                json={"model": model_key},
                timeout=30
            )
            
            if response.status_code == 200:
                self.current_model = model_key
                self.check_connection()
                messagebox.showinfo("Success", f"Model loaded: {model_key}")
            else:
                messagebox.showerror("Error", f"Failed to load model.\nStatus: {response.status_code}")
        except Exception as e:
            messagebox.showerror("Error", f"Error loading model:\n{str(e)}")
        finally:
            self.loading_model = False  # Reset flag
    
    def refresh_script(self):
        """Refresh both connection and model list"""
        self.check_connection()
        self.refresh_models()
    
    def restart_script(self):
        """Restart the entire application"""
        if messagebox.askyesno("Restart", "Restart the application? Token count will reset."):
            # Close current window
            self.root.quit()
            
            # Restart the script
            subprocess.Popen([sys.executable, sys.argv[0]])
            sys.exit()
    
    def check_connection(self):
        """Check if LM Studio API is running and update model status"""
        try:
            response = requests.get(f"{self.api_base}/api/v1/models", timeout=2)
            self.status_label.config(text="✅ Connected", foreground="green")
            
            # Check for loaded model
            if response.status_code == 200:
                data = response.json()
                models = data.get("models", [])
                
                # If we have a current_model set, check if it's still loaded
                if self.current_model:
                    for model in models:
                        if model.get("key") == self.current_model:
                            display_name = model.get("display_name", "Unknown")
                            self.model_status_label.config(text="✅ Model Loaded", foreground="green")
                            self.model_name_label.config(text=display_name, foreground="blue")
                            return True
                    # Model not found in list, clear it
                    self.current_model = None
                
                # No model loaded
                self.model_status_label.config(text="❌ No Model Loaded", foreground="red")
                self.model_name_label.config(text="Waiting...", foreground="blue")
            return True
        except:
            self.status_label.config(text="❌ Disconnected", foreground="red")
            self.model_status_label.config(text="❌ No Model Loaded", foreground="red")
            self.model_name_label.config(text="Offline", foreground="blue")
            return False
    
    def browse_document(self):
        """Open file dialog to select .txt or .md files (max 2 total)"""
        # Calculate how many slots are available
        slots_available = 2 - len(self.uploaded_documents)
        
        if slots_available <= 0:
            messagebox.showwarning("File Limit", "Maximum 2 files allowed. Remove a file to add more.")
            return
        
        files = filedialog.askopenfilenames(
            title=f"Select Text Files (max {slots_available} remaining)",
            filetypes=[
                ("Text/Markdown Files", "*.txt *.md"),
                ("Text Files", "*.txt"),
                ("Markdown Files", "*.md"),
            ]
        )
        
        if files:
            # Only add up to the available slots
            files_to_add = list(files)[:slots_available]
            
            for file_path in files_to_add:
                if file_path not in self.uploaded_documents:
                    self.uploaded_documents.append(file_path)
            
            # Update listbox display
            self.update_files_display()
            
            # Show confirmation
            file_count = len(files_to_add)
            filenames = ", ".join(os.path.basename(f) for f in files_to_add)
            messagebox.showinfo("Files Added", f"Added {file_count} file(s):\n{filenames}")
    
    def update_files_display(self):
        """Update file chips display with inline X buttons for removal"""
        # Clear existing file chips
        for widget in self.files_frame.winfo_children():
            widget.destroy()
        
        if len(self.uploaded_documents) == 0:
            ttk.Label(self.files_frame, text="No files attached", font=("Arial", 9), foreground="gray").pack(anchor=tk.W)
        else:
            for i, file_path in enumerate(self.uploaded_documents):
                self.create_file_chip(i, os.path.basename(file_path))
    
    def create_file_chip(self, index, filename):
        """Create a file chip with filename and X button"""
        chip_frame = ttk.Frame(self.files_frame)
        chip_frame.pack(fill=tk.X, pady=2)
        
        # File icon and name
        ttk.Label(chip_frame, text=f"📎 {filename}", font=("Arial", 9), foreground="blue").pack(side=tk.LEFT, padx=(0, 8))
        
        # X button to remove file
        remove_btn = tk.Button(chip_frame, text="✕", font=("Arial", 9, "bold"), 
                              fg="red", relief=tk.FLAT, bd=0, padx=4, 
                              command=lambda idx=index: self.remove_file_by_index(idx))
        remove_btn.pack(side=tk.LEFT)
    
    def remove_file_by_index(self, index):
        """Remove a file by its index without showing a dialog"""
        if 0 <= index < len(self.uploaded_documents):
            self.uploaded_documents.pop(index)
            self.update_files_display()
    
    def remove_file(self):
        """Remove file - use the X button next to each file instead"""
        if not self.uploaded_documents:
            messagebox.showinfo("No Files", "Use the ✕ button next to a file to remove it.")
            return
        messagebox.showinfo("Tip", "Click the ✕ button next to a file to remove it.")
    
    def submit_document(self):
        """Submit the selected documents for analysis and save to file"""
        if not self.uploaded_documents:
            messagebox.showwarning("No Documents", "Please add documents first.")
            return
        
        if not self.current_model:
            messagebox.showwarning("No Model", "Please load a model first.")
            return
        
        try:
            # Show processing dialog
            messagebox.showinfo("Processing", "Analyzing documents... This may take a moment.")
            
            # Read all uploaded files
            all_content = []
            for file_path in self.uploaded_documents:
                with open(file_path, 'r', encoding='utf-8') as f:
                    content = f.read()
                    all_content.append(f"=== {os.path.basename(file_path)} ===\n{content}")
            
            combined_content = "\n\n".join(all_content)
            
            # Build the prompt with default analysis
            instructions_text = "Examine thoroughly, fact check claims, verify information, and provide deep reasoning"
            
            # Build the prompt
            prompt = f"""Please analyze the following document(s). {instructions_text}.

Documents:
{combined_content}

Provide a comprehensive analysis based on the requested operations."""
            
            # Send to LM Studio API
            response = requests.post(
                f"{self.api_base}/v1/chat/completions",
                json={
                    "model": self.current_model,
                    "messages": [
                        {"role": "user", "content": prompt}
                    ],
                    "temperature": self.temperature_var.get(),
                    "max_tokens": self.max_tokens_var.get()
                },
                timeout=120
            )
            
            if response.status_code == 200:
                result = response.json()
                analysis = result['choices'][0]['message']['content']
                
                # Extract token usage
                if 'usage' in result:
                    tokens_used = result['usage'].get('total_tokens', 0)
                    self.reasoning_tokens = tokens_used
                    self.session_tokens += tokens_used
                    
                    # Update token display
                    self.reasoning_tokens_label.config(text=str(self.reasoning_tokens))
                    self.session_tokens_label.config(text=str(self.session_tokens))
                
                # Save to file
                timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
                output_filename = f"analysis_{timestamp}.txt"
                output_path = os.path.join(os.path.expanduser("~"), "Downloads", output_filename)
                
                with open(output_path, 'w', encoding='utf-8') as f:
                    f.write(analysis)
                
                self.last_output_file = output_path
                messagebox.showinfo("Success", f"Analysis saved to:\n{output_filename}\n\nTokens used: {self.reasoning_tokens}\nSession total: {self.session_tokens}")
            else:
                messagebox.showerror("API Error", f"Failed to analyze documents.\nStatus: {response.status_code}")
        
        except FileNotFoundError:
            messagebox.showerror("File Error", "Could not read one of the selected files.")
        except requests.exceptions.RequestException as e:
            messagebox.showerror("Connection Error", f"Failed to connect to LM Studio:\n{str(e)}")
        except KeyError:
            messagebox.showerror("Response Error", "Unexpected response format from LM Studio.")
        except Exception as e:
            messagebox.showerror("Error", f"An error occurred:\n{str(e)}")
    
    def open_last_output(self):
        """Open the last output file"""
        if not self.last_output_file:
            messagebox.showwarning("No Output", "No analysis output generated yet.")
            return
        
        if not os.path.exists(self.last_output_file):
            messagebox.showerror("File Not Found", f"Output file not found:\n{self.last_output_file}")
            self.last_output_file = None
            return
        
        # Open file with default application
        try:
            if os.name == 'nt':  # Windows
                os.startfile(self.last_output_file)
            else:  # macOS and Linux
                os.system(f'open "{self.last_output_file}"')
        except Exception as e:
            messagebox.showerror("Error", f"Could not open file:\n{str(e)}")
    
    def open_chat_window(self):
        """Open or focus the chat window"""
        if self.chat_window is None or not self.chat_window.window.winfo_exists():
            self.chat_window = ChatWindow(self.root, self)
        else:
            # Focus existing window
            self.chat_window.window.lift()
            self.chat_window.window.focus()


if __name__ == "__main__":
    root = tk.Tk()
    # Hide main window initially - will show after startup checks
    root.withdraw()
    app = LMStudioOrchestrator(root)
    root.mainloop()
