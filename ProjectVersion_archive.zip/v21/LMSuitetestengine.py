"""
LMSuite — LM Studio Multi-Model Orchestrator
Single-file build with the Constraint Engine merged in directly
(no more cross-file imports between LMSuite and constraint_engine.py)
"""

import tkinter as tk
from tkinter import ttk, messagebox, filedialog
import requests
import os
import threading
import datetime
import sys
import subprocess
import psutil
import time
import re
import json
import difflib
import urllib.parse
from abc import ABC, abstractmethod
from typing import Any, List, Dict, Union


# ============================================================================
# CONSTRAINT ENGINE — SEPARATE CONSTRAINTS (Local, Fast, Per-Item)
# ============================================================================

class Constraint(ABC):
    """Base constraint - all constraints inherit from this"""

    def __init__(self, name: str):
        self.name = name
        self.passed = False
        self.execution_time = 0

    @abstractmethod
    def validate(self, data: Any) -> bool:
        """Does data pass this constraint?"""
        pass

    @abstractmethod
    def fix(self, data: Any) -> Any:
        """Fix data if it fails"""
        pass

    def describe(self):
        """Human-readable description"""
        return f"{self.name}"


class SeparateConstraint(Constraint):
    """Validates individual pieces in isolation"""
    pass


class NoDoubleSpaces(SeparateConstraint):
    """Remove multiple spaces"""

    def validate(self, data: str) -> bool:
        return "  " not in data

    def fix(self, data: str) -> str:
        return re.sub(r"  +", " ", data)


class CapitalizeFirst(SeparateConstraint):
    """First letter must be capitalized"""

    def validate(self, data: str) -> bool:
        if not data:
            return True
        return data[0].isupper()

    def fix(self, data: str) -> str:
        # A leading space/newline (common in local-model output) used to make this a no-op:
        # ' '.upper() is still ' ', so validate() failed again right after "fixing" it and the
        # whole round got discarded. Strip leading whitespace before capitalizing so the fix
        # actually fixes it.
        if not data:
            return data
        stripped = data.lstrip()
        if not stripped:
            return data
        return stripped[0].upper() + stripped[1:]


class ValidJSON(SeparateConstraint):
    """Must be valid JSON"""

    def __init__(self, name: str = "ValidJSON", required_fields: List[str] = None):
        super().__init__(name)
        self.required_fields = required_fields or []

    def validate(self, data: Union[str, dict]) -> bool:
        try:
            if isinstance(data, str):
                parsed = json.loads(data)
            else:
                parsed = data

            if isinstance(parsed, dict):
                for field in self.required_fields:
                    if field not in parsed:
                        return False

            return True
        except Exception:
            return False

    def fix(self, data: str) -> str:
        return data


class NoTrailingWhitespace(SeparateConstraint):
    """Remove trailing spaces"""

    def validate(self, data: str) -> bool:
        if isinstance(data, str):
            return not data.endswith((" ", "\n", "\t"))
        return True

    def fix(self, data: str) -> str:
        if isinstance(data, str):
            return data.rstrip()
        return data


class IsNonEmpty(SeparateConstraint):
    """Data must not be empty"""

    def validate(self, data: Any) -> bool:
        if isinstance(data, (str, list, dict)):
            return len(data) > 0
        return data is not None

    def fix(self, data: Any) -> Any:
        return data


class MaxLength(SeparateConstraint):
    """Enforce maximum length"""

    def __init__(self, name: str = "MaxLength", max_len: int = 1000):
        super().__init__(name)
        self.max_len = max_len

    def validate(self, data: str) -> bool:
        return len(data) <= self.max_len

    def fix(self, data: str) -> str:
        return data[:self.max_len]


class ContainsKeyword(SeparateConstraint):
    """Must contain specific keyword"""

    def __init__(self, name: str = "ContainsKeyword", keyword: str = ""):
        super().__init__(name)
        self.keyword = keyword

    def validate(self, data: str) -> bool:
        return self.keyword.lower() in data.lower()

    def fix(self, data: str) -> str:
        return data


class NoCharacters(SeparateConstraint):
    """Ban specific characters"""

    def __init__(self, name: str = "NoCharacters", banned_chars: str = ""):
        super().__init__(name)
        self.banned_chars = banned_chars

    def validate(self, data: str) -> bool:
        return not any(char in data for char in self.banned_chars)

    def fix(self, data: str) -> str:
        for char in self.banned_chars:
            data = data.replace(char, "")
        return data


class NoMarkdown(SeparateConstraint):
    """Strip markdown formatting"""

    def validate(self, data: str) -> bool:
        markdown_chars = ['#', '*', '_', '`', '[', ']', '!', '~']
        return not any(char in data for char in markdown_chars)

    def fix(self, data: str) -> str:
        markdown_chars = ['#', '*', '_', '`', '[', ']', '!', '~']
        for char in markdown_chars:
            data = data.replace(char, "")
        return data


class IsEnglish(SeparateConstraint):
    """Ensure content is primarily English"""

    def __init__(self, name: str = "IsEnglish", min_english_ratio: float = 0.85):
        super().__init__(name)
        self.min_english_ratio = min_english_ratio

    def validate(self, data: str) -> bool:
        if not data:
            return True

        english_chars = sum(1 for c in data if ord(c) < 128 and (c.isalpha() or c.isdigit() or c in " .,!?;:-'\"()"))
        ratio = english_chars / len(data)
        return ratio >= self.min_english_ratio

    def fix(self, data: str) -> str:
        return "".join(c for c in data if ord(c) < 128)


# ============================================================================
# CONSTRAINT ENGINE — COLLECTIVE CONSTRAINTS (Global, Complex, Whole-Output)
# ============================================================================

class CollectiveConstraint(Constraint):
    """Validates entire output or relationships between pieces"""
    pass


class NoContradictions(CollectiveConstraint):
    """Output must not contradict itself"""

    def validate(self, data: Union[str, dict]) -> bool:
        if isinstance(data, dict):
            data = json.dumps(data)

        contradictions = [
            ("no fever", "high fever"),
            ("not", "must"),
            ("false", "true"),
        ]

        data_lower = data.lower()
        for neg, pos in contradictions:
            if neg in data_lower and pos in data_lower:
                return False

        return True

    def fix(self, data: Any) -> Any:
        return data


class JSONFieldsPopulated(CollectiveConstraint):
    """All required JSON fields must have content"""

    def __init__(self, name: str = "JSONFieldsPopulated", required_fields: List[str] = None):
        super().__init__(name)
        self.required_fields = required_fields or []

    def validate(self, data: Union[str, dict]) -> bool:
        try:
            if isinstance(data, str):
                parsed = json.loads(data)
            else:
                parsed = data

            for field in self.required_fields:
                if field not in parsed or not parsed[field]:
                    return False

            return True
        except Exception:
            return False

    def fix(self, data: Any) -> Any:
        return data


class LogicalFlow(CollectiveConstraint):
    """Output must follow logical progression"""

    def __init__(self, name: str = "LogicalFlow", required_order: List[str] = None):
        super().__init__(name)
        self.required_order = required_order or []

    def validate(self, data: str) -> bool:
        if isinstance(data, dict):
            data = json.dumps(data)

        data_lower = data.lower()
        last_pos = -1

        for keyword in self.required_order:
            pos = data_lower.find(keyword.lower())
            if pos == -1:
                return False
            if pos <= last_pos:
                return False
            last_pos = pos

        return True

    def fix(self, data: Any) -> Any:
        return data


class NoRepetition(CollectiveConstraint):
    """Detect and penalize repetitive n-grams"""

    def __init__(self, name: str = "NoRepetition", ngram_size: int = 3):
        super().__init__(name)
        self.ngram_size = ngram_size

    def validate(self, data: str) -> bool:
        if isinstance(data, dict):
            data = json.dumps(data)

        words = data.lower().split()
        if len(words) < self.ngram_size * 2:
            return True

        ngrams = []
        for i in range(len(words) - self.ngram_size + 1):
            ngram = tuple(words[i:i + self.ngram_size])
            ngrams.append(ngram)

        return len(ngrams) == len(set(ngrams))

    def fix(self, data: str) -> str:
        return data


class FactualGrounding(CollectiveConstraint):
    """Encourage factual statements"""

    def __init__(self, name: str = "FactualGrounding", disallow_words: List[str] = None):
        super().__init__(name)
        self.disallow_words = disallow_words or []

    def validate(self, data: str) -> bool:
        if isinstance(data, dict):
            data = json.dumps(data)

        data_lower = data.lower()
        for word in self.disallow_words:
            if word.lower() in data_lower:
                return False
        return True

    def fix(self, data: str) -> str:
        result = data
        for word in self.disallow_words:
            result = re.sub(r'\b' + re.escape(word) + r'\b', '', result, flags=re.IGNORECASE)
        return result


class MinDistinctSentences(CollectiveConstraint):
    """Require at least N genuinely distinct (non-paraphrased) sentences. NoRepetition
    catches exact repeated n-grams; this catches padding via reworded restatements of the
    same sentence, using fuzzy sentence-to-sentence similarity instead of fixed n-grams."""

    def __init__(self, name: str = "MinDistinctSentences", min_sentences: int = 2,
                 similarity_threshold: float = 0.85):
        super().__init__(name)
        self.min_sentences = min_sentences
        self.similarity_threshold = similarity_threshold

    def validate(self, data: Union[str, dict]) -> bool:
        if isinstance(data, dict):
            data = json.dumps(data)

        sentences = [s.strip() for s in re.split(r'(?<=[.!?])\s+', data) if s.strip()]
        distinct = []
        for s in sentences:
            if not any(difflib.SequenceMatcher(None, s.lower(), d.lower()).ratio() >= self.similarity_threshold
                       for d in distinct):
                distinct.append(s)

        return len(distinct) >= self.min_sentences

    def fix(self, data: Any) -> Any:
        return data


class StyleConsistency(CollectiveConstraint):
    """Enforce style consistency across output"""

    def __init__(self, name: str = "StyleConsistency", enforce_style: str = "formal"):
        super().__init__(name)
        self.enforce_style = enforce_style

    def validate(self, data: str) -> bool:
        if isinstance(data, dict):
            data = json.dumps(data)

        if self.enforce_style == "formal":
            contractions = ["can't", "won't", "don't", "isn't", "aren't", "wasn't", "weren't"]
            for contraction in contractions:
                if contraction.lower() in data.lower():
                    return False

        return True

    def fix(self, data: str) -> str:
        if self.enforce_style == "formal":
            replacements = {
                "can't": "cannot", "won't": "will not", "don't": "do not",
                "doesn't": "does not", "didn't": "did not", "isn't": "is not",
                "aren't": "are not", "wasn't": "was not", "weren't": "were not",
                "haven't": "have not", "hasn't": "has not", "hadn't": "had not",
            }
            result = data
            for contraction, expansion in replacements.items():
                result = re.sub(r'\b' + re.escape(contraction) + r'\b', expansion, result, flags=re.IGNORECASE)
            return result
        return data


class MinLength(SeparateConstraint):
    """Enforce a minimum character length — catches truncated or lazy one-line outputs
    that MaxLength can't (MaxLength only guards the ceiling, not the floor)."""

    def __init__(self, name: str = "MinLength", min_len: int = 20):
        super().__init__(name)
        self.min_len = min_len

    def validate(self, data: str) -> bool:
        if not isinstance(data, str):
            return True
        return len(data) >= self.min_len

    def fix(self, data: str) -> str:
        # Missing content can't be safely fabricated — leave validate() failing so the
        # caller's normal reject/retry path handles it instead of a fake "fix".
        return data


class NoURLs(SeparateConstraint):
    """Strip or reject URLs — most useful on offline/self-knowledge runs, where a model
    citing a link it can't actually have accessed is a fabricated citation, not a source."""

    URL_PATTERN = re.compile(r'(https?://\S+|www\.\S+)', re.IGNORECASE)

    def validate(self, data: str) -> bool:
        if not isinstance(data, str):
            return True
        return not self.URL_PATTERN.search(data)

    def fix(self, data: str) -> str:
        if not isinstance(data, str):
            return data
        return self.URL_PATTERN.sub("", data).strip()


class NoPlaceholderText(SeparateConstraint):
    """Catch unresolved template placeholders/boilerplate left in by the model
    (e.g. '[insert X here]', 'TODO', 'Lorem ipsum', '<your answer>')."""

    PLACEHOLDER_PATTERNS = [
        r'\[insert[^\]]*\]', r'\[todo[^\]]*\]', r'\btodo\b', r'\btbd\b',
        r'lorem ipsum', r'<[a-zA-Z_ ]+>', r'\[your [a-zA-Z ]+\]', r'\[x+\]',
    ]

    def validate(self, data: str) -> bool:
        if not isinstance(data, str):
            return True
        data_lower = data.lower()
        return not any(re.search(p, data_lower) for p in self.PLACEHOLDER_PATTERNS)

    def fix(self, data: str) -> str:
        # No safe auto-fix — the content behind the placeholder is genuinely missing.
        return data


class EndsWithPunctuation(SeparateConstraint):
    """Output must end with proper terminal punctuation — a cheap, reliable signal that a
    generation got cut off mid-sentence (context limit, stop token misfire, etc.)."""

    def __init__(self, name: str = "EndsWithPunctuation", allowed: str = ".!?\"')"):
        super().__init__(name)
        self.allowed = allowed

    def validate(self, data: str) -> bool:
        if not isinstance(data, str) or not data.strip():
            return True
        return data.rstrip()[-1] in self.allowed

    def fix(self, data: str) -> str:
        if not isinstance(data, str):
            return data
        stripped = data.rstrip()
        if not stripped:
            return data
        if stripped[-1] not in self.allowed:
            return stripped + "."
        return stripped


class NoRefusalLanguage(SeparateConstraint):
    """Flag model refusals/deflections ('As an AI...', 'I cannot help with that') so a
    refusal doesn't get silently absorbed into a cascade or knowledge base as real content."""

    REFUSAL_PHRASES = [
        "as an ai", "as a language model", "i cannot help with", "i can't help with",
        "i cannot fulfill", "i can't fulfill", "i'm not able to help", "i am not able to help",
        "i cannot provide", "i can't provide", "i'm sorry, but i", "i'm unable to",
    ]

    def validate(self, data: str) -> bool:
        if not isinstance(data, str):
            return True
        data_lower = data.lower()
        return not any(phrase in data_lower for phrase in self.REFUSAL_PHRASES)

    def fix(self, data: str) -> str:
        # No safe auto-fix — a refusal has to be re-generated, not text-patched.
        return data


# ============================================================================
# CONSTRAINT ENGINE — ORCHESTRATOR
# ============================================================================

class ConstraintEngine:
    """Main engine that applies constraints"""

    def __init__(self, name: str = "ConstraintEngine"):
        self.name = name
        self.separate_constraints: List[SeparateConstraint] = []
        self.collective_constraints: List[CollectiveConstraint] = []
        self.execution_log: List[Dict] = []

    def add_separate(self, constraint: SeparateConstraint):
        self.separate_constraints.append(constraint)

    def add_collective(self, constraint: CollectiveConstraint):
        self.collective_constraints.append(constraint)

    def validate_separate(self, data: Any) -> Dict:
        results = []
        for constraint in self.separate_constraints:
            start = time.time()
            passed = constraint.validate(data)
            duration = (time.time() - start) * 1000
            results.append({"constraint": constraint.name, "passed": passed, "duration_ms": duration})
            if not passed:
                return {"success": False, "failed_at": constraint.name, "results": results}
        return {"success": True, "results": results}

    def validate_collective(self, data: Any) -> Dict:
        results = []
        for constraint in self.collective_constraints:
            start = time.time()
            passed = constraint.validate(data)
            duration = (time.time() - start) * 1000
            results.append({"constraint": constraint.name, "passed": passed, "duration_ms": duration})
            if not passed:
                return {"success": False, "failed_at": constraint.name, "results": results}
        return {"success": True, "results": results}

    def validate(self, data: Any, auto_fix: bool = False) -> Dict:
        """Run all constraints (separate then collective)"""
        current = data
        log = []

        for constraint in self.separate_constraints:
            start = time.time()
            passed = constraint.validate(current)
            duration = (time.time() - start) * 1000
            log.append({"phase": "separate", "constraint": constraint.name, "passed": passed, "duration_ms": duration})

            if not passed:
                if auto_fix:
                    current = constraint.fix(current)
                    fixed_passed = constraint.validate(current)
                    if fixed_passed:
                        log[-1]["fixed"] = True
                    else:
                        return {"success": False, "failed_at": constraint.name, "phase": "separate", "log": log}
                else:
                    return {"success": False, "failed_at": constraint.name, "phase": "separate", "log": log}

        if len(self.collective_constraints) > 0:
            for constraint in self.collective_constraints:
                start = time.time()
                passed = constraint.validate(current)
                duration = (time.time() - start) * 1000
                log.append({"phase": "collective", "constraint": constraint.name, "passed": passed, "duration_ms": duration})

                if not passed:
                    if auto_fix:
                        current = constraint.fix(current)
                        fixed_passed = constraint.validate(current)
                        if fixed_passed:
                            log[-1]["fixed"] = True
                        else:
                            return {"success": False, "failed_at": constraint.name, "phase": "collective", "log": log}
                    else:
                        return {"success": False, "failed_at": constraint.name, "phase": "collective", "log": log}

        self.execution_log = log
        return {"success": True, "data": current, "log": log}

    def describe(self) -> Dict:
        return {
            "separate": [c.name for c in self.separate_constraints],
            "collective": [c.name for c in self.collective_constraints]
        }


# ============================================================================
# CONSTRAINT REGISTRY - Maps type names to classes and their editable params
# ============================================================================

CONSTRAINT_REGISTRY = {
    "NoDoubleSpaces": {
        "class": NoDoubleSpaces, "category": "separate",
        "description": "Collapse multiple spaces into one", "auto_fix": True, "params": {}
    },
    "CapitalizeFirst": {
        "class": CapitalizeFirst, "category": "separate",
        "description": "First character must be uppercase", "auto_fix": True, "params": {}
    },
    "NoTrailingWhitespace": {
        "class": NoTrailingWhitespace, "category": "separate",
        "description": "Strip trailing spaces, newlines, tabs", "auto_fix": True, "params": {}
    },
    "IsNonEmpty": {
        "class": IsNonEmpty, "category": "separate",
        "description": "Reject empty or None data", "auto_fix": False, "params": {}
    },
    "MaxLength": {
        "class": MaxLength, "category": "separate",
        "description": "Enforce maximum character length", "auto_fix": True,
        "params": {"max_len": {"type": "int", "default": 10000, "label": "Max Characters", "min": 1, "max": 100000}}
    },
    "ContainsKeyword": {
        "class": ContainsKeyword, "category": "separate",
        "description": "Output must contain a specific keyword", "auto_fix": False,
        "params": {"keyword": {"type": "str", "default": "", "label": "Required Keyword"}}
    },
    "NoCharacters": {
        "class": NoCharacters, "category": "separate",
        "description": "Ban specific characters from output", "auto_fix": True,
        "params": {"banned_chars": {"type": "str", "default": "", "label": "Banned Characters"}}
    },
    "ValidJSON": {
        "class": ValidJSON, "category": "separate",
        "description": "Must be valid JSON (optional required fields)", "auto_fix": False,
        "params": {"required_fields": {"type": "list", "default": [], "label": "Required Fields (comma-separated)"}}
    },
    "NoMarkdown": {
        "class": NoMarkdown, "category": "separate",
        "description": "Strip markdown formatting characters", "auto_fix": True, "params": {}
    },
    "IsEnglish": {
        "class": IsEnglish, "category": "separate",
        "description": "Ensure content is primarily English", "auto_fix": True,
        "params": {"min_english_ratio": {"type": "float", "default": 0.85, "label": "Min English Ratio (0.0-1.0)"}}
    },
    "NoContradictions": {
        "class": NoContradictions, "category": "collective",
        "description": "Detect contradictory statements", "auto_fix": False, "params": {}
    },
    "JSONFieldsPopulated": {
        "class": JSONFieldsPopulated, "category": "collective",
        "description": "All required JSON fields must have content", "auto_fix": False,
        "params": {"required_fields": {"type": "list", "default": [], "label": "Required Fields (comma-separated)"}}
    },
    "LogicalFlow": {
        "class": LogicalFlow, "category": "collective",
        "description": "Keywords must appear in a specific order", "auto_fix": False,
        "params": {"required_order": {"type": "list", "default": [], "label": "Keywords in Order (comma-separated)"}}
    },
    "NoRepetition": {
        "class": NoRepetition, "category": "collective",
        "description": "Detect and penalize repetitive n-grams", "auto_fix": False,
        "params": {"ngram_size": {"type": "int", "default": 3, "label": "N-gram Size", "min": 2, "max": 10}}
    },
    "FactualGrounding": {
        "class": FactualGrounding, "category": "collective",
        "description": "Encourage factual statements", "auto_fix": True,
        "params": {"disallow_words": {"type": "list", "default": [], "label": "Disallow Words (comma-separated)"}}
    },
    "StyleConsistency": {
        "class": StyleConsistency, "category": "collective",
        "description": "Enforce style consistency across output", "auto_fix": True,
        "params": {"enforce_style": {"type": "str", "default": "formal", "label": "Style (formal/casual)"}}
    },
    "MinLength": {
        "class": MinLength, "category": "separate",
        "description": "Enforce a minimum character length (catches truncated/lazy outputs)", "auto_fix": False,
        "params": {"min_len": {"type": "int", "default": 20, "label": "Min Characters", "min": 1, "max": 100000}}
    },
    "NoURLs": {
        "class": NoURLs, "category": "separate",
        "description": "Ban URLs from the output (useful for offline/self-knowledge runs)", "auto_fix": True, "params": {}
    },
    "NoPlaceholderText": {
        "class": NoPlaceholderText, "category": "separate",
        "description": "Reject unresolved template placeholders (TODO, [insert X], Lorem ipsum, <..>)",
        "auto_fix": False, "params": {}
    },
    "EndsWithPunctuation": {
        "class": EndsWithPunctuation, "category": "separate",
        "description": "Output must end in proper terminal punctuation (catches mid-sentence truncation)",
        "auto_fix": True, "params": {}
    },
    "NoRefusalLanguage": {
        "class": NoRefusalLanguage, "category": "separate",
        "description": "Flag model refusals/deflections instead of treating them as real content",
        "auto_fix": False, "params": {}
    },
    "MinDistinctSentences": {
        "class": MinDistinctSentences, "category": "collective",
        "description": "Require at least N genuinely distinct (non-paraphrased) sentences", "auto_fix": False,
        "params": {
            "min_sentences": {"type": "int", "default": 2, "label": "Min Distinct Sentences", "min": 1, "max": 50},
            "similarity_threshold": {"type": "float", "default": 0.85, "label": "Similarity Threshold (0.0-1.0)"}
        }
    },
}


# ============================================================================
# SERIALIZATION - Save/load constraint configs to JSON
# ============================================================================

def engine_to_config(engine: ConstraintEngine) -> dict:
    """Serialize a ConstraintEngine to a saveable dict"""
    config = {"name": engine.name, "separate": [], "collective": []}

    for c in engine.separate_constraints:
        entry = {"type": type(c).__name__, "name": c.name}
        reg = CONSTRAINT_REGISTRY.get(type(c).__name__, {})
        for param_name in reg.get("params", {}):
            entry[param_name] = getattr(c, param_name, reg["params"][param_name]["default"])
        config["separate"].append(entry)

    for c in engine.collective_constraints:
        entry = {"type": type(c).__name__, "name": c.name}
        reg = CONSTRAINT_REGISTRY.get(type(c).__name__, {})
        for param_name in reg.get("params", {}):
            entry[param_name] = getattr(c, param_name, reg["params"][param_name]["default"])
        config["collective"].append(entry)

    return config


def config_to_engine(config: dict) -> ConstraintEngine:
    """Rebuild a ConstraintEngine from a saved config dict"""
    engine = ConstraintEngine(name=config.get("name", "ConstraintEngine"))

    for entry in config.get("separate", []):
        ctype = entry.get("type")
        if ctype in CONSTRAINT_REGISTRY:
            reg = CONSTRAINT_REGISTRY[ctype]
            kwargs = {"name": entry.get("name", ctype)}
            for param_name, param_info in reg["params"].items():
                kwargs[param_name] = entry.get(param_name, param_info["default"])
            engine.add_separate(reg["class"](**kwargs))

    for entry in config.get("collective", []):
        ctype = entry.get("type")
        if ctype in CONSTRAINT_REGISTRY:
            reg = CONSTRAINT_REGISTRY[ctype]
            kwargs = {"name": entry.get("name", ctype)}
            for param_name, param_info in reg["params"].items():
                kwargs[param_name] = entry.get(param_name, param_info["default"])
            engine.add_collective(reg["class"](**kwargs))

    return engine


# ============================================================================
# CONSTRAINT ENGINE — VISUAL EDITOR (ConstraintEngineGUI)
# ============================================================================

CE_COLORS = {
    'bg': '#1e1e2e',
    'bg_card': '#2a2a3d',
    'bg_input': '#363650',
    'bg_selected': '#3d3d5c',
    'text': '#e0e0e0',
    'text_muted': '#8888aa',
    'text_heading': '#ffffff',
    'accent': '#6c8cff',
    'accent_hover': '#8aa4ff',
    'green': '#4ec98b',
    'red': '#e05555',
    'orange': '#e0a040',
    'yellow': '#e0d060',
    'border': '#3a3a55',
    'separate_tag': '#4ec98b',
    'collective_tag': '#6c8cff',
}

CE_FONTS = {
    'heading': ('Arial', 13, 'bold'),
    'subheading': ('Arial', 11, 'bold'),
    'normal': ('Arial', 10),
    'small': ('Arial', 9),
    'mono': ('Courier', 10),
    'mono_small': ('Courier', 9),
}


class ConstraintEngineGUI:
    """Visual editor for ConstraintEngine configurations"""

    def __init__(self, root, engine: ConstraintEngine = None, on_apply=None):
        """
        root: tk.Tk or tk.Toplevel
        engine: existing ConstraintEngine to edit (or None for fresh)
        on_apply: callback(engine) called when user clicks Apply
        """
        self.root = root
        self.root.title("Constraint Engine Editor")
        self.root.geometry("820x700")
        self.root.configure(bg=CE_COLORS['bg'])
        self.root.resizable(True, True)
        self.root.minsize(700, 500)

        self.on_apply = on_apply
        self.config_path = os.path.join(os.path.expanduser("~"), "Downloads", "constraint_engine_config.json")
        self.unsaved_changes = False

        # Build working config from engine or defaults
        if engine:
            self.working_config = engine_to_config(engine)
        else:
            self.working_config = self._default_config()

        self._build_ui()
        self._refresh_list()
        self.root.protocol("WM_DELETE_WINDOW", self._on_close)

    def _default_config(self):
        return {
            "name": "StoryValidator",
            "separate": [
                {"type": "IsNonEmpty", "name": "IsNonEmpty"},
                {"type": "NoDoubleSpaces", "name": "NoDoubleSpaces"},
                {"type": "NoTrailingWhitespace", "name": "NoTrailingWhitespace"},
                {"type": "CapitalizeFirst", "name": "CapitalizeFirst"},
                {"type": "MaxLength", "name": "MaxLength", "max_len": 10000},
            ],
            "collective": [
                {"type": "NoContradictions", "name": "NoContradictions"},
            ]
        }

    # ====================================================================
    # UI BUILD
    # ====================================================================

    def _build_ui(self):
        # Title bar
        title_frame = tk.Frame(self.root, bg=CE_COLORS['bg'])
        title_frame.pack(fill=tk.X, padx=15, pady=(12, 0))

        tk.Label(title_frame, text="Constraint Engine Editor", font=CE_FONTS['heading'],
                 bg=CE_COLORS['bg'], fg=CE_COLORS['text_heading']).pack(side=tk.LEFT)

        self.status_label = tk.Label(title_frame, text="", font=CE_FONTS['small'],
                                      bg=CE_COLORS['bg'], fg=CE_COLORS['text_muted'])
        self.status_label.pack(side=tk.RIGHT)
        self._update_status()

        # Engine name row
        name_frame = tk.Frame(self.root, bg=CE_COLORS['bg'])
        name_frame.pack(fill=tk.X, padx=15, pady=(8, 0))

        tk.Label(name_frame, text="Engine Name:", font=CE_FONTS['normal'],
                 bg=CE_COLORS['bg'], fg=CE_COLORS['text_muted']).pack(side=tk.LEFT, padx=(0, 8))
        self.name_var = tk.StringVar(value=self.working_config.get("name", "ConstraintEngine"))
        name_entry = tk.Entry(name_frame, textvariable=self.name_var, font=CE_FONTS['mono'],
                              bg=CE_COLORS['bg_input'], fg=CE_COLORS['text'], insertbackground=CE_COLORS['text'],
                              relief=tk.FLAT, bd=0, width=30)
        name_entry.pack(side=tk.LEFT, padx=(0, 15), ipady=4, ipadx=6)
        self.name_var.trace_add("write", lambda *_: self._mark_changed())

        # Main split: left = constraint list, right = editor
        body = tk.Frame(self.root, bg=CE_COLORS['bg'])
        body.pack(fill=tk.BOTH, expand=True, padx=15, pady=(10, 0))
        body.columnconfigure(0, weight=1)
        body.columnconfigure(1, weight=1)
        body.rowconfigure(0, weight=1)

        # ── LEFT: Constraint List ──
        left = tk.Frame(body, bg=CE_COLORS['bg_card'], highlightthickness=1,
                        highlightbackground=CE_COLORS['border'])
        left.grid(row=0, column=0, sticky="nsew", padx=(0, 6))
        left.rowconfigure(1, weight=1)
        left.columnconfigure(0, weight=1)

        # List header
        lh = tk.Frame(left, bg=CE_COLORS['bg_card'])
        lh.grid(row=0, column=0, sticky="ew", padx=10, pady=(10, 5))
        tk.Label(lh, text="Active Constraints", font=CE_FONTS['subheading'],
                 bg=CE_COLORS['bg_card'], fg=CE_COLORS['text_heading']).pack(side=tk.LEFT)

        # Constraint listbox
        list_frame = tk.Frame(left, bg=CE_COLORS['bg_card'])
        list_frame.grid(row=1, column=0, sticky="nsew", padx=10, pady=(0, 5))
        list_frame.rowconfigure(0, weight=1)
        list_frame.columnconfigure(0, weight=1)

        self.constraint_listbox = tk.Listbox(
            list_frame, font=CE_FONTS['mono'], bg=CE_COLORS['bg_input'], fg=CE_COLORS['text'],
            selectbackground=CE_COLORS['accent'], selectforeground=CE_COLORS['text_heading'],
            relief=tk.FLAT, bd=0, highlightthickness=0, activestyle='none'
        )
        self.constraint_listbox.grid(row=0, column=0, sticky="nsew")
        self.constraint_listbox.bind("<<ListboxSelect>>", self._on_select)

        scrollbar = ttk.Scrollbar(list_frame, orient=tk.VERTICAL, command=self.constraint_listbox.yview)
        scrollbar.grid(row=0, column=1, sticky="ns")
        self.constraint_listbox.config(yscrollcommand=scrollbar.set)

        # List buttons
        lb = tk.Frame(left, bg=CE_COLORS['bg_card'])
        lb.grid(row=2, column=0, sticky="ew", padx=10, pady=(0, 10))

        btn_style = {"font": CE_FONTS['small'], "relief": tk.FLAT, "bd": 0, "padx": 10, "pady": 4, "cursor": "hand2"}

        tk.Button(lb, text="▲ Up", bg=CE_COLORS['bg_input'], fg=CE_COLORS['text'],
                  command=self._move_up, **btn_style).pack(side=tk.LEFT, padx=(0, 3))
        tk.Button(lb, text="▼ Down", bg=CE_COLORS['bg_input'], fg=CE_COLORS['text'],
                  command=self._move_down, **btn_style).pack(side=tk.LEFT, padx=(0, 3))
        tk.Button(lb, text="✕ Remove", bg=CE_COLORS['red'], fg=CE_COLORS['text_heading'],
                  command=self._remove_selected, **btn_style).pack(side=tk.RIGHT)

        # ── RIGHT: Editor Panel ──
        right = tk.Frame(body, bg=CE_COLORS['bg_card'], highlightthickness=1,
                         highlightbackground=CE_COLORS['border'])
        right.grid(row=0, column=1, sticky="nsew", padx=(6, 0))
        right.rowconfigure(1, weight=1)
        right.columnconfigure(0, weight=1)

        # Editor header
        rh = tk.Frame(right, bg=CE_COLORS['bg_card'])
        rh.grid(row=0, column=0, sticky="ew", padx=10, pady=(10, 5))
        tk.Label(rh, text="Edit Constraint", font=CE_FONTS['subheading'],
                 bg=CE_COLORS['bg_card'], fg=CE_COLORS['text_heading']).pack(side=tk.LEFT)

        # Editor content (dynamic)
        self.editor_frame = tk.Frame(right, bg=CE_COLORS['bg_card'])
        self.editor_frame.grid(row=1, column=0, sticky="nsew", padx=10, pady=(0, 10))

        self._show_no_selection()

        # ── ADD CONSTRAINT SECTION ──
        add_frame = tk.Frame(self.root, bg=CE_COLORS['bg_card'], highlightthickness=1,
                             highlightbackground=CE_COLORS['border'])
        add_frame.pack(fill=tk.X, padx=15, pady=(10, 0))

        add_inner = tk.Frame(add_frame, bg=CE_COLORS['bg_card'])
        add_inner.pack(fill=tk.X, padx=10, pady=10)

        tk.Label(add_inner, text="Add Constraint:", font=CE_FONTS['subheading'],
                 bg=CE_COLORS['bg_card'], fg=CE_COLORS['text_heading']).pack(side=tk.LEFT, padx=(0, 10))

        # Type dropdown
        self.add_type_var = tk.StringVar(value="NoDoubleSpaces")
        type_names = sorted(CONSTRAINT_REGISTRY.keys())
        self.add_dropdown = ttk.Combobox(add_inner, textvariable=self.add_type_var,
                                          values=type_names, state="readonly", width=22)
        self.add_dropdown.pack(side=tk.LEFT, padx=(0, 8))
        self.add_dropdown.bind("<<ComboboxSelected>>", self._update_add_preview)

        # Preview label
        self.add_preview = tk.Label(add_inner, text="", font=CE_FONTS['small'],
                                     bg=CE_COLORS['bg_card'], fg=CE_COLORS['text_muted'])
        self.add_preview.pack(side=tk.LEFT, padx=(0, 10), fill=tk.X, expand=True)
        self._update_add_preview()

        tk.Button(add_inner, text="+ Add", font=CE_FONTS['normal'], bg=CE_COLORS['green'],
                  fg=CE_COLORS['bg'], relief=tk.FLAT, bd=0, padx=14, pady=4,
                  cursor="hand2", command=self._add_constraint).pack(side=tk.RIGHT)

        # ── TEST SECTION ──
        test_frame = tk.Frame(self.root, bg=CE_COLORS['bg_card'], highlightthickness=1,
                              highlightbackground=CE_COLORS['border'])
        test_frame.pack(fill=tk.X, padx=15, pady=(10, 0))

        test_header = tk.Frame(test_frame, bg=CE_COLORS['bg_card'])
        test_header.pack(fill=tk.X, padx=10, pady=(10, 5))
        tk.Label(test_header, text="Test Engine", font=CE_FONTS['subheading'],
                 bg=CE_COLORS['bg_card'], fg=CE_COLORS['text_heading']).pack(side=tk.LEFT)

        tk.Button(test_header, text="▶ Run Test", font=CE_FONTS['small'], bg=CE_COLORS['accent'],
                  fg=CE_COLORS['text_heading'], relief=tk.FLAT, bd=0, padx=12, pady=3,
                  cursor="hand2", command=self._run_test).pack(side=tk.RIGHT)

        self.test_auto_fix_var = tk.BooleanVar(value=True)
        tk.Checkbutton(test_header, text="Auto-fix", variable=self.test_auto_fix_var,
                        font=CE_FONTS['small'], bg=CE_COLORS['bg_card'], fg=CE_COLORS['text'],
                        selectcolor=CE_COLORS['bg_input'], activebackground=CE_COLORS['bg_card'],
                        activeforeground=CE_COLORS['text']).pack(side=tk.RIGHT, padx=(0, 10))

        test_body = tk.Frame(test_frame, bg=CE_COLORS['bg_card'])
        test_body.pack(fill=tk.X, padx=10, pady=(0, 10))
        test_body.columnconfigure(0, weight=1)
        test_body.columnconfigure(1, weight=1)

        self.test_input = tk.Text(test_body, height=3, font=CE_FONTS['mono_small'],
                                   bg=CE_COLORS['bg_input'], fg=CE_COLORS['text'],
                                   insertbackground=CE_COLORS['text'], relief=tk.FLAT, bd=0, wrap=tk.WORD)
        self.test_input.grid(row=0, column=0, sticky="nsew", padx=(0, 4), ipady=4, ipadx=4)
        self.test_input.insert("1.0", "  hello world.  This is a  test with  double spaces.  ")

        self.test_output = tk.Text(test_body, height=3, font=CE_FONTS['mono_small'],
                                    bg=CE_COLORS['bg_input'], fg=CE_COLORS['green'],
                                    relief=tk.FLAT, bd=0, wrap=tk.WORD, state=tk.DISABLED)
        self.test_output.grid(row=0, column=1, sticky="nsew", padx=(4, 0), ipady=4, ipadx=4)

        # ── BOTTOM BUTTONS ──
        bottom = tk.Frame(self.root, bg=CE_COLORS['bg'])
        bottom.pack(fill=tk.X, padx=15, pady=(12, 15))

        tk.Button(bottom, text="💾 Save Config", font=CE_FONTS['normal'], bg=CE_COLORS['bg_input'],
                  fg=CE_COLORS['text'], relief=tk.FLAT, bd=0, padx=14, pady=6,
                  cursor="hand2", command=self._save_config).pack(side=tk.LEFT, padx=(0, 6))

        tk.Button(bottom, text="📂 Load Config", font=CE_FONTS['normal'], bg=CE_COLORS['bg_input'],
                  fg=CE_COLORS['text'], relief=tk.FLAT, bd=0, padx=14, pady=6,
                  cursor="hand2", command=self._load_config).pack(side=tk.LEFT, padx=(0, 6))

        tk.Button(bottom, text="🔄 Reset Defaults", font=CE_FONTS['normal'], bg=CE_COLORS['orange'],
                  fg=CE_COLORS['bg'], relief=tk.FLAT, bd=0, padx=14, pady=6,
                  cursor="hand2", command=self._reset_defaults).pack(side=tk.LEFT)

        self.apply_btn = tk.Button(bottom, text="✓ Apply to Engine", font=('Arial', 11, 'bold'),
                                    bg=CE_COLORS['green'], fg=CE_COLORS['bg'], relief=tk.FLAT, bd=0,
                                    padx=20, pady=6, cursor="hand2", command=self._apply)
        self.apply_btn.pack(side=tk.RIGHT)

    # ====================================================================
    # CONSTRAINT LIST MANAGEMENT
    # ====================================================================

    def _get_all_entries(self):
        """Return flat list of (category, index, entry) for display order"""
        items = []
        for i, entry in enumerate(self.working_config.get("separate", [])):
            items.append(("separate", i, entry))
        for i, entry in enumerate(self.working_config.get("collective", [])):
            items.append(("collective", i, entry))
        return items

    def _refresh_list(self):
        self.constraint_listbox.delete(0, tk.END)

        items = self._get_all_entries()
        if not items:
            self.constraint_listbox.insert(tk.END, "  (no constraints loaded)")
            return

        last_cat = None
        for cat, idx, entry in items:
            if cat != last_cat:
                header = f"── {'SEPARATE (Fast)' if cat == 'separate' else 'COLLECTIVE (Global)'} ──"
                self.constraint_listbox.insert(tk.END, header)
                self.constraint_listbox.itemconfig(tk.END, fg=CE_COLORS['text_muted'], selectbackground=CE_COLORS['bg_input'])
                last_cat = cat

            tag = "[S]" if cat == "separate" else "[C]"
            ctype = entry.get("type", "?")
            name = entry.get("name", ctype)

            # Show key param value if any
            reg = CONSTRAINT_REGISTRY.get(ctype, {})
            param_str = ""
            for pname, pinfo in reg.get("params", {}).items():
                val = entry.get(pname, pinfo["default"])
                if isinstance(val, list):
                    val = ", ".join(str(v) for v in val) if val else "(none)"
                param_str = f" = {val}"
                break  # Show first param only

            fix_icon = "🔧" if reg.get("auto_fix") else "  "
            line = f"  {tag} {fix_icon} {name}{param_str}"
            self.constraint_listbox.insert(tk.END, line)

        self._update_status()

    def _update_status(self):
        sep = len(self.working_config.get("separate", []))
        col = len(self.working_config.get("collective", []))
        changed = " ●" if self.unsaved_changes else ""
        self.status_label.config(text=f"{sep} separate, {col} collective{changed}")

    def _mark_changed(self):
        self.unsaved_changes = True
        self._update_status()

    def _resolve_selection(self):
        """Map listbox selection index to (category, config_index) or None"""
        sel = self.constraint_listbox.curselection()
        if not sel:
            return None

        lb_idx = sel[0]
        text = self.constraint_listbox.get(lb_idx)

        # Skip header rows
        if text.startswith("──") or text.startswith("  (no"):
            return None

        # Count real entries before this index
        real_idx = -1
        for i in range(lb_idx + 1):
            t = self.constraint_listbox.get(i)
            if not t.startswith("──") and not t.startswith("  (no"):
                real_idx += 1

        # Map to category + index
        sep_count = len(self.working_config.get("separate", []))
        if real_idx < sep_count:
            return ("separate", real_idx)
        else:
            return ("collective", real_idx - sep_count)

    def _on_select(self, event=None):
        resolved = self._resolve_selection()
        if resolved is None:
            self._show_no_selection()
            return

        cat, idx = resolved
        entry = self.working_config[cat][idx]
        self._show_editor(cat, idx, entry)

    def _move_up(self):
        resolved = self._resolve_selection()
        if resolved is None:
            return
        cat, idx = resolved
        if idx <= 0:
            return
        lst = self.working_config[cat]
        lst[idx], lst[idx - 1] = lst[idx - 1], lst[idx]
        self._mark_changed()
        self._refresh_list()
        # Reselect
        self._select_entry(cat, idx - 1)

    def _move_down(self):
        resolved = self._resolve_selection()
        if resolved is None:
            return
        cat, idx = resolved
        lst = self.working_config[cat]
        if idx >= len(lst) - 1:
            return
        lst[idx], lst[idx + 1] = lst[idx + 1], lst[idx]
        self._mark_changed()
        self._refresh_list()
        self._select_entry(cat, idx + 1)

    def _select_entry(self, cat, idx):
        """Select a specific entry in the listbox after refresh"""
        # Count listbox position: headers + entries
        lb_idx = 0
        # Separate header
        if self.working_config.get("separate"):
            lb_idx += 1  # header row
            if cat == "separate":
                lb_idx += idx
                self.constraint_listbox.selection_set(lb_idx)
                self.constraint_listbox.see(lb_idx)
                self._on_select()
                return
            lb_idx += len(self.working_config["separate"])

        # Collective header
        if self.working_config.get("collective"):
            lb_idx += 1  # header row
            if cat == "collective":
                lb_idx += idx
                self.constraint_listbox.selection_set(lb_idx)
                self.constraint_listbox.see(lb_idx)
                self._on_select()
                return

    def _remove_selected(self):
        resolved = self._resolve_selection()
        if resolved is None:
            return
        cat, idx = resolved
        entry = self.working_config[cat][idx]
        name = entry.get("name", entry.get("type", "?"))
        if messagebox.askyesno("Remove Constraint", f"Remove '{name}'?"):
            self.working_config[cat].pop(idx)
            self._mark_changed()
            self._refresh_list()
            self._show_no_selection()

    def _add_constraint(self):
        ctype = self.add_type_var.get()
        if ctype not in CONSTRAINT_REGISTRY:
            return

        reg = CONSTRAINT_REGISTRY[ctype]
        entry = {"type": ctype, "name": ctype}

        for pname, pinfo in reg["params"].items():
            entry[pname] = pinfo["default"]

        cat = reg["category"]
        self.working_config[cat].append(entry)
        self._mark_changed()
        self._refresh_list()

        # Select the new entry
        idx = len(self.working_config[cat]) - 1
        self._select_entry(cat, idx)

    def _update_add_preview(self, event=None):
        ctype = self.add_type_var.get()
        reg = CONSTRAINT_REGISTRY.get(ctype, {})
        cat = reg.get("category", "?")
        desc = reg.get("description", "")
        fix = "🔧 auto-fix" if reg.get("auto_fix") else "no auto-fix"
        tag = "Separate" if cat == "separate" else "Collective"
        self.add_preview.config(text=f"{tag} · {desc} · {fix}")

    # ====================================================================
    # EDITOR PANEL
    # ====================================================================

    def _show_no_selection(self):
        for w in self.editor_frame.winfo_children():
            w.destroy()

        tk.Label(self.editor_frame, text="Select a constraint\nfrom the list to edit it",
                 font=CE_FONTS['normal'], bg=CE_COLORS['bg_card'], fg=CE_COLORS['text_muted'],
                 justify=tk.CENTER).pack(expand=True)

    def _show_editor(self, cat, idx, entry):
        for w in self.editor_frame.winfo_children():
            w.destroy()

        ctype = entry.get("type", "?")
        reg = CONSTRAINT_REGISTRY.get(ctype, {})

        # Type and category
        header = tk.Frame(self.editor_frame, bg=CE_COLORS['bg_card'])
        header.pack(fill=tk.X, pady=(0, 10))

        tag_color = CE_COLORS['separate_tag'] if cat == "separate" else CE_COLORS['collective_tag']
        tag_text = "SEPARATE" if cat == "separate" else "COLLECTIVE"
        tk.Label(header, text=tag_text, font=CE_FONTS['small'], bg=tag_color,
                 fg=CE_COLORS['bg'], padx=6, pady=1).pack(side=tk.LEFT, padx=(0, 8))

        tk.Label(header, text=ctype, font=CE_FONTS['subheading'],
                 bg=CE_COLORS['bg_card'], fg=CE_COLORS['text_heading']).pack(side=tk.LEFT)

        # Description
        desc = reg.get("description", "No description")
        tk.Label(self.editor_frame, text=desc, font=CE_FONTS['small'],
                 bg=CE_COLORS['bg_card'], fg=CE_COLORS['text_muted'], anchor=tk.W).pack(fill=tk.X, pady=(0, 5))

        fix = "🔧 Can auto-fix failures" if reg.get("auto_fix") else "⚠ Cannot auto-fix (validate only)"
        tk.Label(self.editor_frame, text=fix, font=CE_FONTS['small'],
                 bg=CE_COLORS['bg_card'], fg=CE_COLORS['text_muted'], anchor=tk.W).pack(fill=tk.X, pady=(0, 12))

        # Separator
        tk.Frame(self.editor_frame, bg=CE_COLORS['border'], height=1).pack(fill=tk.X, pady=(0, 12))

        # Name field
        name_row = tk.Frame(self.editor_frame, bg=CE_COLORS['bg_card'])
        name_row.pack(fill=tk.X, pady=(0, 10))

        tk.Label(name_row, text="Display Name:", font=CE_FONTS['normal'],
                 bg=CE_COLORS['bg_card'], fg=CE_COLORS['text']).pack(anchor=tk.W)

        name_var = tk.StringVar(value=entry.get("name", ctype))
        name_entry = tk.Entry(name_row, textvariable=name_var, font=CE_FONTS['mono'],
                              bg=CE_COLORS['bg_input'], fg=CE_COLORS['text'],
                              insertbackground=CE_COLORS['text'], relief=tk.FLAT, bd=0)
        name_entry.pack(fill=tk.X, ipady=4, ipadx=6, pady=(3, 0))

        # Parameter fields
        param_vars = {}
        for pname, pinfo in reg.get("params", {}).items():
            row = tk.Frame(self.editor_frame, bg=CE_COLORS['bg_card'])
            row.pack(fill=tk.X, pady=(0, 10))

            tk.Label(row, text=f"{pinfo['label']}:", font=CE_FONTS['normal'],
                     bg=CE_COLORS['bg_card'], fg=CE_COLORS['text']).pack(anchor=tk.W)

            current_val = entry.get(pname, pinfo["default"])

            if pinfo["type"] == "int":
                var = tk.IntVar(value=current_val)
                spin = ttk.Spinbox(row, from_=pinfo.get("min", 0), to=pinfo.get("max", 999999),
                                    textvariable=var, width=12)
                spin.pack(anchor=tk.W, pady=(3, 0))
                param_vars[pname] = ("int", var)

            elif pinfo["type"] == "float":
                var = tk.DoubleVar(value=float(current_val))
                spin = ttk.Spinbox(row, from_=pinfo.get("min", 0.0), to=pinfo.get("max", 1.0),
                                    increment=0.05, textvariable=var, width=12)
                spin.pack(anchor=tk.W, pady=(3, 0))
                param_vars[pname] = ("float", var)

            elif pinfo["type"] == "str":
                var = tk.StringVar(value=current_val)
                ent = tk.Entry(row, textvariable=var, font=CE_FONTS['mono'],
                               bg=CE_COLORS['bg_input'], fg=CE_COLORS['text'],
                               insertbackground=CE_COLORS['text'], relief=tk.FLAT, bd=0)
                ent.pack(fill=tk.X, ipady=4, ipadx=6, pady=(3, 0))
                param_vars[pname] = ("str", var)

            elif pinfo["type"] == "list":
                # Show as comma-separated string
                if isinstance(current_val, list):
                    display = ", ".join(str(v) for v in current_val)
                else:
                    display = str(current_val)
                var = tk.StringVar(value=display)
                ent = tk.Entry(row, textvariable=var, font=CE_FONTS['mono'],
                               bg=CE_COLORS['bg_input'], fg=CE_COLORS['text'],
                               insertbackground=CE_COLORS['text'], relief=tk.FLAT, bd=0)
                ent.pack(fill=tk.X, ipady=4, ipadx=6, pady=(3, 0))

                tk.Label(row, text="Separate items with commas", font=CE_FONTS['small'],
                         bg=CE_COLORS['bg_card'], fg=CE_COLORS['text_muted']).pack(anchor=tk.W, pady=(2, 0))
                param_vars[pname] = ("list", var)

        if not reg.get("params"):
            tk.Label(self.editor_frame, text="This constraint has no configurable parameters.",
                     font=CE_FONTS['small'], bg=CE_COLORS['bg_card'], fg=CE_COLORS['text_muted']).pack(
                anchor=tk.W, pady=(0, 10))

        # Save button for this constraint
        tk.Frame(self.editor_frame, bg=CE_COLORS['bg_card']).pack(fill=tk.BOTH, expand=True)

        def _save_edits():
            entry["name"] = name_var.get().strip() or ctype
            for pname, (ptype, var) in param_vars.items():
                if ptype == "int":
                    try:
                        entry[pname] = var.get()
                    except (ValueError, tk.TclError):
                        entry[pname] = CONSTRAINT_REGISTRY[ctype]["params"][pname]["default"]
                elif ptype == "float":
                    try:
                        entry[pname] = var.get()
                    except (ValueError, tk.TclError):
                        entry[pname] = CONSTRAINT_REGISTRY[ctype]["params"][pname]["default"]
                elif ptype == "str":
                    entry[pname] = var.get()
                elif ptype == "list":
                    raw = var.get().strip()
                    if raw:
                        entry[pname] = [item.strip() for item in raw.split(",") if item.strip()]
                    else:
                        entry[pname] = []

            self._mark_changed()
            self._refresh_list()
            self._select_entry(cat, idx)

        btn_frame = tk.Frame(self.editor_frame, bg=CE_COLORS['bg_card'])
        btn_frame.pack(fill=tk.X, pady=(10, 0))

        tk.Button(btn_frame, text="💾 Save Changes", font=CE_FONTS['normal'], bg=CE_COLORS['accent'],
                  fg=CE_COLORS['text_heading'], relief=tk.FLAT, bd=0, padx=14, pady=5,
                  cursor="hand2", command=_save_edits).pack(side=tk.RIGHT)

    # ====================================================================
    # TEST ENGINE
    # ====================================================================

    def _run_test(self):
        test_data = self.test_input.get("1.0", tk.END).strip()
        if not test_data:
            self._set_test_output("Enter test text first", CE_COLORS['red'])
            return

        # Build engine from current config
        try:
            engine = config_to_engine(self.working_config)
        except Exception as e:
            self._set_test_output(f"Engine build error: {e}", CE_COLORS['red'])
            return

        auto_fix = self.test_auto_fix_var.get()

        start = time.time()
        result = engine.validate(test_data, auto_fix=auto_fix)
        elapsed = (time.time() - start) * 1000

        lines = []
        for entry in result.get("log", []):
            name = entry["constraint"]
            phase = "S" if entry.get("phase") == "separate" else "C"
            ms = entry.get("duration_ms", 0)

            if entry.get("fixed"):
                lines.append(f"🔧 [{phase}] {name}: FIXED ({ms:.2f}ms)")
            elif entry["passed"]:
                lines.append(f"✓ [{phase}] {name}: passed ({ms:.2f}ms)")
            else:
                lines.append(f"✗ [{phase}] {name}: FAILED ({ms:.2f}ms)")

        fixes = sum(1 for e in result.get("log", []) if e.get("fixed"))

        if result.get("success"):
            lines.append(f"\n✓ ALL PASSED ({elapsed:.2f}ms, {fixes} fixes)")
            if auto_fix and "data" in result:
                output = result["data"]
                if output != test_data:
                    lines.append(f"\nFixed output:\n{output}")
            color = CE_COLORS['green']
        else:
            failed = result.get("failed_at", "unknown")
            lines.append(f"\n✗ FAILED at: {failed} ({elapsed:.2f}ms)")
            color = CE_COLORS['red']

        self._set_test_output("\n".join(lines), color)

    def _set_test_output(self, text, color=CE_COLORS['green']):
        self.test_output.config(state=tk.NORMAL, fg=color)
        self.test_output.delete("1.0", tk.END)
        self.test_output.insert("1.0", text)
        self.test_output.config(state=tk.DISABLED)

    # ====================================================================
    # SAVE / LOAD / APPLY
    # ====================================================================

    def _save_config(self):
        self.working_config["name"] = self.name_var.get().strip() or "ConstraintEngine"

        path = filedialog.asksaveasfilename(
            title="Save Constraint Config",
            initialdir=os.path.expanduser("~/Downloads"),
            initialfile="constraint_engine_config.json",
            defaultextension=".json",
            filetypes=[("JSON files", "*.json"), ("All files", "*.*")]
        )
        if not path:
            return

        try:
            with open(path, 'w', encoding='utf-8') as f:
                json.dump(self.working_config, f, indent=2)
            self.config_path = path
            self.unsaved_changes = False
            self._update_status()
            messagebox.showinfo("Saved", f"Config saved:\n{os.path.basename(path)}")
        except Exception as e:
            messagebox.showerror("Error", f"Failed to save:\n{e}")

    def _load_config(self):
        path = filedialog.askopenfilename(
            title="Load Constraint Config",
            initialdir=os.path.expanduser("~/Downloads"),
            filetypes=[("JSON files", "*.json"), ("All files", "*.*")]
        )
        if not path:
            return

        try:
            with open(path, 'r', encoding='utf-8') as f:
                loaded = json.load(f)

            # Validate structure
            if "separate" not in loaded and "collective" not in loaded:
                messagebox.showerror("Error", "Invalid config file — missing separate/collective keys")
                return

            self.working_config = loaded
            self.name_var.set(loaded.get("name", "ConstraintEngine"))
            self.config_path = path
            self.unsaved_changes = False
            self._refresh_list()
            self._show_no_selection()
            messagebox.showinfo("Loaded", f"Config loaded:\n{os.path.basename(path)}")
        except Exception as e:
            messagebox.showerror("Error", f"Failed to load:\n{e}")

    def _reset_defaults(self):
        if messagebox.askyesno("Reset", "Reset all constraints to defaults?"):
            self.working_config = self._default_config()
            self.name_var.set(self.working_config["name"])
            self._mark_changed()
            self._refresh_list()
            self._show_no_selection()

    def _apply(self):
        """Build engine from config and fire the callback"""
        self.working_config["name"] = self.name_var.get().strip() or "ConstraintEngine"

        try:
            engine = config_to_engine(self.working_config)
        except Exception as e:
            messagebox.showerror("Error", f"Failed to build engine:\n{e}")
            return

        sep = len(engine.separate_constraints)
        col = len(engine.collective_constraints)

        if self.on_apply:
            self.on_apply(engine)
            self.unsaved_changes = False
            self._update_status()
            messagebox.showinfo("Applied", f"Engine applied: {sep} separate, {col} collective constraints")
        else:
            # Standalone mode — just confirm it builds
            self.unsaved_changes = False
            self._update_status()
            messagebox.showinfo("Validated",
                                f"Engine builds successfully:\n{sep} separate, {col} collective constraints\n\n"
                                f"(No LMSuite connected — save config to use it)")

    def _on_close(self):
        if self.unsaved_changes:
            if not messagebox.askyesno("Unsaved Changes", "You have unsaved changes. Close anyway?"):
                return
        self.root.destroy()

    def get_engine(self) -> ConstraintEngine:
        """Build and return engine from current config"""
        self.working_config["name"] = self.name_var.get().strip() or "ConstraintEngine"
        return config_to_engine(self.working_config)

# ============================================================================
# CONFIGURATION - Edit everything here to customize the app
# ============================================================================
CONFIG = {
    # ===== API SETTINGS =====
    'API': {
        'base_url': 'http://localhost:1234',
        'models_endpoint': '/api/v1/models',
        'load_model_endpoint': '/api/v1/models/load',
        'chat_endpoint': '/v1/chat/completions',
        'timeout_connect': 2,
        'timeout_models': 5,
        'timeout_load': 30,
        'timeout_chat': 300,
    },

    # ===== COLORS =====
    'COLORS': {
        'bg_primary': '#f0f2f7',           # Main background
        'bg_secondary': '#f9f9f9',         # Light gray backgrounds
        'bg_white': 'white',                # Card backgrounds
        'bg_menu': '#f0f0f0',              # Menu bar background
        'bg_input': 'white',               # Input field background

        'text_primary': '#000',             # Main text
        'text_secondary': '#333',           # Headings
        'text_muted': 'gray',              # Faded text
        'text_white': 'white',             # White text
        'text_error': '#dc2626',           # Error red
        'text_blue': '#0066cc',            # Link blue

        'button_primary': '#0084ff',       # Main button color
        'button_green': '#4CAF50',         # Save/success buttons
        'button_red': '#dc2626',           # Delete/cancel buttons
        'button_disabled': '#ccc',         # Disabled button

        'border_light': '#e8ecf4',         # Card borders
        'border_gray': '#d0d0d0',          # Separators
        'border_dark': '#e8e8e8',          # Menu borders

        'status_online': 'green',          # Connected status
        'status_offline': 'red',           # Disconnected status
        'tab_active': '#4a9eff',           # Active tab background
        'tab_inactive': '#e8e8e8',         # Inactive tab background
    },

    # ===== FONTS =====
    'FONTS': {
        'family_default': 'Arial',
        'family_mono': 'Courier',

        'size_large': 14,                  # Large titles
        'size_title': 12,                  # Window/card titles
        'size_header': 11,                 # Section headers
        'size_normal': 10,                 # Normal text
        'size_small': 9,                   # Small text
        'size_tiny': 8,                    # Tiny text
    },

    # ===== DIMENSIONS =====
    'DIMENSIONS': {
        'window_width': 900,
        'window_height': 624,
        'splash_width': 400,
        'splash_height': 150,
        'settings_width': 550,
        'settings_height': 500,

        'padding_huge': 20,                # Large padding
        'padding_large': 15,               # Card padding
        'padding_normal': 12,              # Standard padding
        'padding_small': 8,                # Small padding
        'padding_tiny': 3,                 # Tiny padding

        'margin_large': 15,                # Large margins
        'margin_normal': 12,               # Standard margins
        'margin_small': 5,                 # Small margins

        'chat_height': 200,                # Chat message container height
        'cascade_output_height': 20,       # Story output text area height
        'model_list_height': 4,            # Model listbox height
        'chat_input_height': 2,            # Chat input height
        'story_prompt_height': 3,          # Story prompt input height

        'card_relief': tk.FLAT,
        'card_border_width': 3,
        'card_border': tk.SOLID,
    },

    # ===== TEXT & LABELS =====
    'TEXT': {
        # Window titles
        'app_title': 'LMSuite — LM Studio Multi-Model Orchestrator',
        'settings_title': 'Settings (beta)',
        'error_title': 'LM Studio Error',

        # Status messages
        'status_connected': '✅ Connected',
        'status_disconnected': '❌ Disconnected',
        'status_model_loaded': '✅ Model Loaded',
        'status_no_model': '❌ No Model Loaded',
        'status_waiting': 'Waiting...',
        'status_offline': 'Offline',
        'status_thinking': 'Thinking...',
        'status_detecting': 'Detecting...',

        # Card headers
        'card_status': 'Status',
        'card_model_loader': 'Model Loader',
        'card_story_cascade': 'Story Cascade',
        'card_chat': 'Chat',

        # Labels & fields
        'label_lm_studio_status': 'LM Studio Status:',
        'label_server': 'Server:',
        'label_model': 'Model:',
        'label_model_loaded': 'Model:',
        'label_tokens_used': 'Tokens used:',
        'label_reasoning': 'Reasoning:',
        'label_max_tokens': 'Max Tokens:',
        'label_temperature': 'Temperature:',
        'label_available_models': 'Available Models:',
        'label_double_click': '(double-click to load)',
        'label_system_resources': 'System Resources:',
        'label_vram': 'VRAM:',
        'label_ram': 'RAM:',
        'label_total': 'Total:',
        'label_story_idea': 'Story Idea/Prompt:',
        'label_select_model_pass': 'Select Model for Each Pass:',
        'label_leave_blank': '(leave blank to skip pass)',
        'label_pass_function': 'Function:',
        'label_supervisor_function': 'Supervisor Function:',
        'label_pass': 'Pass',
        'label_create': 'Create',
        'label_refine': 'Refine',
        'label_polish': 'Polish',
        'label_tokens': 'Tokens:',
        'label_temp_global': 'Temperature (Global):',
        'label_temp_range': '(0.0-2.0)',
        'label_pass_polished': 'Pass 5 - Polished:',

        # Button labels
        'btn_refresh': 'Refresh Script',
        'btn_restart': 'Restart Script',
        'btn_generate': '▶ Generate',
        'btn_clear_all': '🗑️ Clear All',
        'btn_copy_output': '📋 Copy Output',
        'btn_save_story': '💾 Save Story',
        'btn_send': '➤',
        'btn_clear_chat': '🗑️ Clear',
        'btn_file': 'File',
        'btn_settings': 'Settings (beta)',
        'btn_view_log': 'View Log File',
        'btn_exit': 'Exit',
        'btn_apply_test': '✓ Apply & Test',
        'btn_close': 'Close',
        'btn_apply': '✓ Apply',
        'btn_save': 'Save',
        'btn_cancel': 'Cancel',
        'btn_pick_color': 'Pick Color',

        # Section headers in settings
        'settings_server_config': '🌐 Server Configuration',
        'settings_api_info': '📡 APIs Used',
        'settings_dev_settings': '🛠️  Developer Settings',
        'settings_color_custom': '🎨 Color Customization',
        'settings_header_custom': '📝 Section Header Customization',

        # Settings fields
        'settings_server_addr': 'LM Studio Server Address:',
        'settings_default': 'Default: http://localhost:1234',
        'settings_quick_start': 'Skip loading splash screen (Quick Start)',
        'settings_quick_start_desc': 'Bypasses the startup connection check',
        'settings_main_res': 'Main Window Resolution:',
        'settings_splash_res': 'Splash Window Resolution:',
        'settings_splash_note': 'Note: Restart app for resolution changes to take effect',
        'settings_text_color': 'Main Text Color:',
        'settings_heading_color': 'Section Header Color:',
        'settings_bg_color': 'Background Color:',
        'settings_button_color': 'Button Color:',
        'settings_font_size': 'Font Size:',
        'settings_font_weight': 'Font Weight:',

        # API info text
        'api_models_list': '• /api/v1/models - List available models',
        'api_models_load': '• /api/v1/models/load - Load a specific model',
        'api_chat': '• /v1/chat/completions - Chat endpoint for responses',

        # Messages
        'msg_no_model_selected': 'Please select a model for chat.',
        'msg_empty_message': 'Please type a message.',
        'msg_empty_prompt': 'Enter a story idea first.',
        'msg_in_progress': 'Cascade is already running.',
        'msg_no_models_cascade': 'Select at least one model for a pass.',
        'msg_empty_story': 'No story to copy',
        'msg_empty_to_save': 'No story to save',
        'msg_copied': 'Story cascade output copied to clipboard!',
        'msg_no_log': 'Log file not found:',
        'msg_restart_confirm': 'Restart? Token count will reset.',
        'msg_clear_logs': 'Clear all logs?',
        'msg_log_copied': 'Log entry copied!',
        'msg_no_selection': 'Select a log entry first.',
        'msg_no_model_identified': 'Could not identify model',
        'msg_empty_server': 'Please enter a server address first.',

        # Error messages
        'error_failed_load': 'Failed to load model.\nStatus:',
        'error_load_model': 'Error loading model:',
        'error_api_error': 'API Error:',
        'error_connection': 'Failed to connect to LM Studio:',
        'error_unexpected': 'Unexpected response format from LM Studio.',
        'error_cascade_no_models': 'Cascade error: no models selected',
        'error_cascade_empty': 'Cascade error: empty prompt',
        'error_save_file': 'Could not save:',
        'error_invalid_input': 'Invalid input',
        'error_invalid_resolution': 'Resolution values must be numbers!',

        # Popup titles
        'popup_success': 'Success',
        'popup_connected': 'Connected to server!',
        'popup_error': 'Error',
        'popup_warning': 'Warning',
        'popup_info': 'Info',

        # Research mode
        'card_research': 'Research',
        'label_research_topic': 'Research Topic / Focus:',
        'label_research_source': 'Research Source:',
        'label_research_model': 'Research Model:',
        'label_search_backend': 'Search Backend (Web Search only):',
        'label_tavily_key': 'Tavily API Key (Web Search only):',
        'label_auto_merge': 'Auto-Merge:',
        'label_research_rules': 'Research Rules (each one adds a real extra verification step):',
        'label_research_log': 'Research Log:',
        'btn_load_folder': '📂 Load Source Folder',
        'btn_load_files': '📄 Load File(s)',
        'btn_research_start': '▶ Start',
        'btn_research_pause': '⏸ Pause',
        'btn_research_resume': '▶ Resume',
        'btn_research_stop': '■ Stop',
        'btn_open_knowledge': '📄 Open Knowledge File',
        'btn_compact_now': '🔄 Compact Now',
        'text_no_folder_loaded': 'No folder loaded (only used by Local Documents mode)',
        'status_research_stopped': '■ Stopped',
        'status_research_running': '● Running',
        'status_research_paused': '⏸ Paused',
        'msg_research_running': 'Research is already running.',
        'msg_no_folder': 'Load a source folder first, or switch Research Source to a mode that doesn\'t need documents.',
        'msg_no_topic': 'Enter a research topic/focus first.',
        'msg_no_research_model': 'Select a research model first.',
        'msg_no_files_found': 'No .txt, .md, or .pdf files found in that folder.',
        'msg_no_knowledge_yet': 'No knowledge base saved yet.',
        'msg_pause_before_compact': 'Pause or stop the research run before compacting manually — '
                                     'they both write to the same knowledge base.',
        'msg_new_topic_title': 'New Topic',
        'msg_tavily_key_missing': 'Enter a Tavily API key first, or switch Search Backend to DuckDuckGo (free).',

        # Discussion mode
        'card_discussion': 'Discussion',
        'label_discussion_topic': 'Discussion Topic / Question:',
        'label_discussion_participants': 'Participants:',
        'label_discussion_role': 'Role:',
        'label_discussion_auto_merge': 'Auto-Merge:',
        'label_discussion_log': 'Discussion Log:',
        'btn_add_participant': '+ Add Participant',
        'btn_remove_participant': '✕ Remove',
        'btn_discussion_start': '▶ Start',
        'btn_discussion_pause': '⏸ Pause',
        'btn_discussion_resume': '▶ Resume',
        'btn_discussion_stop': '■ Stop',
        'btn_open_transcript': '📄 Open Transcript',
        'btn_compact_discussion_now': '🔄 Compact Now',
        'status_discussion_stopped': '■ Stopped',
        'status_discussion_running': '● Running',
        'status_discussion_paused': '⏸ Paused',
        'msg_discussion_running': 'Discussion is already running.',
        'msg_no_discussion_topic': 'Enter a discussion topic/question first.',
        'msg_discussion_too_few': 'Add at least 2 participants (with models and roles selected).',
        'msg_no_transcript_yet': 'No transcript saved yet.',
        'msg_pause_before_compact_discussion': 'Pause or stop the discussion before compacting manually — '
                                                'they both write to the same transcript.',
    },

    # ===== DEFAULT VALUES =====
    'DEFAULTS': {
        'max_tokens': 2000,
        'temperature': 0.7,
        'cascade_temperature': 0.8,
        'cascade_pass_tokens': 2000,
        'model_dropdown_width': 25,
        'model_display_width': 22,
    },

    # ===== CASCADE CATEGORIES =====
    'CASCADE_CATEGORIES': [
        'Story',
        'Coding',
        'Music',
        'Sports',
        'Movies',
        'Jokes',
        'Advice',
        'Electronics',
        'Articles',
        'Scripts',
        'Marketing',
        'Educational',
    ],

    # ===== PASS DESCRIPTIONS - EDIT THESE FOR DIFFERENT CASCADE BEHAVIORS =====
    'CASCADE_PASSES': {
        'SUPERVISOR': {
            'name': 'Supervisor',
            'role': 'Final Review',
            'rating_template': '''Rate this finished story on a scale of 1-10 for each criterion:

FINAL STORY:
{story}

Rate (1-10):
1. Narrative quality and coherence: __/10
2. Completeness and satisfying resolution: __/10
3. Writing quality and prose: __/10

Average rating: __/10

Brief assessment (1-2 sentences):

Respond ONLY with the rating and assessment, no preamble.''',
        },
        1: {
            'name': 'Pass 1',
            'role': 'Create',
            'prompt_template': 'Write a creative and engaging short story based on this idea:\n\n{story}\n\nMake it around 300-400 words with vivid descriptions and interesting characters.',
        },
        2: {
            'name': 'Pass 2',
            'role': 'Refine',
            'prompt_template': 'Improve this story by enhancing the narrative flow and adding more descriptive detail:\n\n{story}\n\nKeep it around 400-500 words.',
        },
        3: {
            'name': 'Pass 3',
            'role': 'Refine',
            'prompt_template': 'Deepen the story by developing character motivations, emotions, and dialogue. Make the interactions more realistic:\n\n{story}\n\nKeep it around 450-550 words.',
        },
        4: {
            'name': 'Pass 4',
            'role': 'Refine',
            'prompt_template': 'Refine the story for better pacing, build tension, and create a more compelling narrative arc:\n\n{story}\n\nKeep it around 450-550 words.',
        },
        5: {
            'name': 'Pass 5',
            'role': 'Polish',
            'prompt_template': 'Polish this story to publication quality. Enhance prose, ensure strong voice, perfect pacing, and create a satisfying conclusion:\n\n{story}\n\nFinal version should be 400-600 words of polished prose.',
        },
    },

    # ===== CASCADE FUNCTIONS — optional per-slot role override =====
    # Each of the 5 pass dropdowns AND the Supervisor dropdown gets a companion "Function"
    # dropdown. Left on "Default", a pass keeps its built-in Create/Refine/Polish role above and
    # the Supervisor keeps its built-in general rating — nothing here is used. Pick a named
    # function instead and it actually replaces what gets sent to that model:
    #   - assigned to one of the 5 passes, 'pass_template' replaces that pass's prompt_template
    #     (still takes {story} in, still returns text that feeds the next pass)
    #   - assigned to the Supervisor, 'rating_template' replaces the Supervisor's rating_template
    #     (must keep the "Average rating: __/10" line — that's what the rating parser looks for)
    # Add more entries here (with both keys) to add more functions to the dropdowns — nothing
    # else in the code needs to change.
    'CASCADE_FUNCTIONS': {
        'Reader': {
            'pass_template': (
                'Read the following text closely as a first-time reader would. Return the ORIGINAL '
                'text UNCHANGED, followed by a new section headed "--- READER NOTES ---" containing: '
                'a short summary of what happens/what is argued, anything confusing or unclear, and '
                'open questions a reader would still have.\n\n{story}'
            ),
            'rating_template': (
                'You are reviewing this text as a first-time Reader.\n\nTEXT:\n{story}\n\n'
                'Rate (1-10):\n1. Clarity for a first-time reader: __/10\n'
                '2. Engagement / how well it holds attention: __/10\n'
                '3. Confusion or unanswered questions: __/10 (10 = none left unanswered)\n\n'
                'Average rating: __/10\n\nBrief assessment (1-2 sentences):\n\n'
                'Respond ONLY with the rating and assessment, no preamble.'
            ),
        },
        'Verification': {
            'pass_template': (
                'Fact-check the following text. Return the ORIGINAL text UNCHANGED, followed by a '
                'new section headed "--- VERIFICATION NOTES ---" flagging any claims that are '
                'unverifiable, internally contradictory, or need a source, and noting anything you '
                'cannot confirm. Do not invent sources.\n\n{story}'
            ),
            'rating_template': (
                'You are Verifying this text for factual consistency.\n\nTEXT:\n{story}\n\n'
                'Rate (1-10):\n1. Internal consistency (no contradictions): __/10\n'
                '2. Claims are verifiable / well-supported: __/10\n'
                '3. Overall trustworthiness: __/10\n\n'
                'Average rating: __/10\n\nBrief assessment (1-2 sentences):\n\n'
                'Respond ONLY with the rating and assessment, no preamble.'
            ),
        },
        'Analyst': {
            'pass_template': (
                'Analyze the following text\'s structure, logic/argument or thematic content. Return '
                'the ORIGINAL text UNCHANGED, followed by a new section headed "--- ANALYSIS ---" '
                'with your structural/thematic breakdown and concrete suggestions for improvement.'
                '\n\n{story}'
            ),
            'rating_template': (
                'You are Analyzing this text\'s structure and content quality.\n\nTEXT:\n{story}\n\n'
                'Rate (1-10):\n1. Structural/logical coherence: __/10\n'
                '2. Depth of content: __/10\n3. Overall quality: __/10\n\n'
                'Average rating: __/10\n\nBrief assessment (1-2 sentences):\n\n'
                'Respond ONLY with the rating and assessment, no preamble.'
            ),
        },
        'Bugchecker': {
            'pass_template': (
                'Review the following as CODE for bugs, edge cases, and correctness issues. If it is '
                'not code, say so plainly. Otherwise, return the CORRECTED code (with bugs fixed), '
                'followed by a new section headed "--- BUGCHECK NOTES ---" listing every bug found and '
                'the fix applied. Do not change working behavior beyond fixing genuine bugs.\n\n{story}'
            ),
            'rating_template': (
                'You are Bugchecking this as code for correctness.\n\nCODE:\n{story}\n\n'
                'Rate (1-10):\n1. Correctness / freedom from bugs: __/10\n'
                '2. Handling of edge cases: __/10\n3. Overall code quality: __/10\n\n'
                'Average rating: __/10\n\nBrief assessment (1-2 sentences):\n\n'
                'Respond ONLY with the rating and assessment, no preamble.'
            ),
        },
        'Spellchecker': {
            'pass_template': (
                'Proofread the following text. Fix ONLY spelling, grammar, and punctuation errors — '
                'preserve the original meaning, style, word choice, and formatting exactly otherwise. '
                'Return ONLY the corrected text, with no notes or commentary.\n\n{story}'
            ),
            'rating_template': (
                'You are Spellchecking this text.\n\nTEXT:\n{story}\n\n'
                'Rate (1-10):\n1. Spelling accuracy: __/10\n2. Grammar accuracy: __/10\n'
                '3. Punctuation accuracy: __/10\n\n'
                'Average rating: __/10\n\nBrief assessment (1-2 sentences):\n\n'
                'Respond ONLY with the rating and assessment, no preamble.'
            ),
        },
    },

    # ===== RESEARCH MODE - DOCUMENT-GROUNDED RESEARCH LOOP =====
    'RESEARCH': {
        'chunk_size': 2000,
        'chunk_overlap': 200,
        'novelty_threshold': 3,          # below this score, round counts as "low novelty"
        'low_novelty_stop_streak': 3,    # this many low-novelty rounds in a row -> auto-pause
        'compact_every_n_rounds': 10,    # fallback/default only — the UI's Auto-Merge dropdown
                                          # (research_compact_interval_var) overrides this live
        'summary_context_chars': 6000,   # how much of the existing KB to show back as "already known"
                                          # (was 1500 — too small: early claims aged out of context and
                                          #  got silently re-extracted as "new" many rounds later)
        'dedup_similarity_threshold': 0.72,  # sequence-similarity cutoff for the deterministic dedup filter
        # ---- Web Search (online) mode ----
        'max_web_results': 5,
        'web_fetch_timeout': 15,
        'web_fetch_max_chars': 8000,
        'web_user_agent': ('Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 '
                            '(KHTML, like Gecko) Chrome/124.0 Safari/537.36'),
        'self_research_template': (
            "You are researching the topic: {topic}\n\n"
            "Draw only on your own trained knowledge — no source document or web page is provided "
            "for this round.\n\n"
            "KNOWLEDGE ALREADY RECORDED (do not repeat any of this, including reworded versions of it):\n"
            "{existing_summary}\n\n"
            "State 2-5 NEW factual claims about this topic that are NOT already covered above — even "
            "in different wording. Prioritize concrete specifics (numbers, dates, names, mechanisms) "
            "over general statements already captured. If you are not confident a claim is accurate, "
            "mark it 'low' confidence rather than leaving it out. For each claim, write one line in "
            "exactly this format:\n"
            "CLAIM: <the fact or finding> | CONFIDENCE: <high/medium/low>\n\n"
            "If you have nothing new and relevant to add, respond with exactly: NO NEW CLAIMS"
        ),
        'search_query_template': (
            "Topic: {topic}\n\n"
            "KNOWLEDGE ALREADY GATHERED:\n{existing_summary}\n\n"
            "Write ONE short, specific web search query (a few words, no quotes, no explanation) "
            "that would help find NEW information on this topic not already covered above. "
            "Respond with ONLY the search query text."
        ),
        'research_template': (
            "You are researching the topic: {topic}\n\n"
            "SOURCE EXCERPT (from {source}):\n{chunk}\n\n"
            "KNOWLEDGE ALREADY RECORDED (do not repeat any of this, including reworded versions of it):\n"
            "{existing_summary}\n\n"
            "Extract 2-5 NEW factual claims from the source excerpt above that are relevant to the "
            "topic and are NOT already covered — even in different wording — by the knowledge already "
            "recorded. Prioritize concrete specifics (numbers, vote counts, percentages, dates, names) "
            "over claims that just restate a general point already captured above. When the source "
            "states someone's exact title or role, preserve it verbatim rather than substituting a "
            "different one that implies something different (e.g. 'ranking member' and 'chair' are "
            "NOT interchangeable — use exactly what the source says). For each claim, write one line "
            "in exactly this format:\n"
            "CLAIM: <the fact or finding> | CONFIDENCE: <high/medium/low>\n\n"
            "If nothing new and relevant is found in this excerpt, respond with exactly: NO NEW CLAIMS"
        ),
        'novelty_template': (
            "Topic: {topic}\n\n"
            "EXISTING KNOWLEDGE BASE (summary):\n{existing_summary}\n\n"
            "NEWLY EXTRACTED CLAIMS THIS ROUND:\n{new_claims}\n\n"
            "Rate how much genuinely NEW, non-redundant information the new claims add on top of the "
            "existing knowledge base, on a scale of 0-10 (0 = pure repetition of what's already known, "
            "10 = major new information).\n"
            "Respond ONLY in this format:\nNOVELTY: <number>\nREASON: <one short sentence>"
        ),
        'compaction_template': (
            "Topic: {topic}\n\n"
            "Below is an accumulated knowledge base of claims gathered from source documents across "
            "several rounds. Some may be duplicates, near-duplicates, or could be merged/organized "
            "better.\n\n{full_knowledge}\n\n"
            "Rewrite this into a clean, de-duplicated, well-organized set of claims grouped under short "
            "subtopic headings ('## <Subtopic>'). Keep each claim's confidence level and source(s). "
            "Preserve all genuinely distinct information — only remove true duplicates and merge "
            "near-duplicates (combine their sources). Format each claim as exactly:\n"
            "CLAIM: <fact> | CONFIDENCE: <level> | SOURCES: <comma-separated source names>"
        ),
    },

    # ===== RESEARCH RULES — opt-in checkboxes on the Research card that inject real,
    # hardcoded verification steps into the research loop. Each key here becomes one
    # checkbox (see _build_ui's Research Rules section); each is read fresh every round via
    # self.research_rule_vars, so toggling one mid-run takes effect on the next round. To add
    # a new rule: add an entry here (label + whatever templates it needs), add its handling in
    # _apply_research_verification_rules / _research_loop, and the checkbox appears automatically.
    'RESEARCH_RULES': {
        'double_check': {
            'label': 'Double-Check Claims',
            'desc': 'Re-asks the model to confirm each claim it just extracted; drops any it retracts on review.',
            'default': False,
            'verify_template': (
                "Topic: {topic}\n\n"
                "You just extracted the following claims:\n{claims_list}\n\n"
                "Re-examine each one carefully and independently. For each claim, respond on its own "
                "line in EXACTLY this format (one line per claim, in order):\n"
                "<number>. CONFIRM or RETRACT\n\n"
                "Retract a claim ONLY if, on reflection, you are genuinely not confident it is accurate."
            ),
        },
        'verify_duplicates': {
            'label': 'Verify Duplicates (strict)',
            'desc': 'Applies a stricter similarity threshold when filtering new claims against the knowledge base.',
            'default': False,
            'strict_threshold': 0.55,   # lower = catches more paraphrased near-duplicates (default is 0.72)
        },
        'investigate': {
            'label': 'Investigate Deeper',
            'desc': 'Follows up on this round’s strongest new claim with one deeper investigative question.',
            'default': False,
            'followup_template': (
                "Topic: {topic}\n\n"
                "You just recorded this claim:\n\"{claim}\"\n\n"
                "Investigate it further. State 1-3 additional, MORE SPECIFIC new facts that add depth "
                "or context to this particular claim (mechanisms, numbers, causes, exceptions, related "
                "specifics) — not general restatements. Use exactly this format, one per line:\n"
                "CLAIM: <fact> | CONFIDENCE: <high/medium/low>\n\n"
                "If you have nothing more specific to add, respond with exactly: NO NEW CLAIMS"
            ),
        },
        'verify_claims': {
            'label': 'Verify Claims vs Source',
            'desc': 'Checks each new claim is actually supported by the source text (or would hold up to scrutiny offline) before recording it.',
            'default': False,
            'grounding_template': (
                "Topic: {topic}\n\n"
                "SOURCE EXCERPT:\n{source_text}\n\n"
                "CLAIMS TO CHECK:\n{claims_list}\n\n"
                "For each claim, decide whether it is directly supported by the source excerpt above "
                "(not just plausible — actually stated or clearly implied there). Respond one line per "
                "claim, in order, in EXACTLY this format:\n<number>. SUPPORTED or UNSUPPORTED"
            ),
            'grounding_template_offline': (
                "Topic: {topic}\n\n"
                "CLAIMS TO CHECK:\n{claims_list}\n\n"
                "No source document is available for this round (self-directed knowledge). For each "
                "claim, decide whether it would hold up to independent fact-checking, or is speculative/"
                "uncertain. Respond one line per claim, in order, in EXACTLY this format:\n"
                "<number>. SUPPORTED or UNSUPPORTED"
            ),
        },
        'research_offline': {
            'label': 'Research Offline (self-knowledge check)',
            'desc': 'Independently asks the model’s own trained knowledge (source hidden) to sanity-check new claims, catching source errors.',
            'default': False,
            'selfcheck_template': (
                "Topic: {topic}\n\n"
                "Using ONLY your own trained knowledge — ignore any document, web page, or prior "
                "context from this session — assess whether each of the following claims is consistent "
                "with what you actually know:\n{claims_list}\n\n"
                "Respond one line per claim, in order, in EXACTLY this format:\n"
                "<number>. CONSISTENT or QUESTIONABLE"
            ),
        },
        'cross_check': {
            'label': 'Cross-Check vs Knowledge Base',
            'desc': 'Compares new claims against everything already recorded and flags direct contradictions.',
            'default': False,
            'crosscheck_template': (
                "Topic: {topic}\n\n"
                "EXISTING KNOWLEDGE BASE:\n{existing_summary}\n\n"
                "NEW CLAIMS:\n{claims_list}\n\n"
                "Does any new claim directly CONTRADICT something already in the knowledge base above "
                "(an actual conflict — not just new information, and not a claim already covered)? "
                "Respond one line per new claim, in order, in EXACTLY this format:\n"
                "<number>. OK or CONTRADICTS"
            ),
        },
    },

    # ===== DISCUSSION MODE — multi-model roundtable with shared, compacted transcript =====
    # Mirrors the RESEARCH loop's pattern (pre-load, compact, dedup) but N participants take
    # turns responding to a running transcript instead of one model extracting claims from a
    # document. See DISCUSSION_ROLES below for what each named role actually sends.
    'DISCUSSION': {
        'summary_context_chars': 6000,        # how much compacted history to show each speaker
        'recent_turns_shown': 6,               # how many most-recent raw turns are shown in full
        'dedup_similarity_threshold': 0.75,    # difflib cutoff for "this turn just repeats an earlier one"
        'stall_threshold': 3,                  # this many near-duplicate turns in a row -> auto-pause
        'compact_every_n_rounds': 10,          # fallback/default — the UI's Auto-Merge dropdown overrides
        'moderator_every_n_rounds': 0,         # 0 = moderator only runs at the end / on demand
        'turn_max_tokens': 500,
        'moderator_max_tokens': 800,
        'compaction_template': (
            "Topic under discussion: {topic}\n\n"
            "Below is the discussion transcript so far, which may include an already-condensed "
            "summary of earlier turns followed by more recent raw turns.\n\n{full_transcript}\n\n"
            "Rewrite this into a compact running summary: preserve every distinct point, claim, "
            "objection, and open question that has been raised, attributed to who raised it (by "
            "role), but condense repeated or superseded points and drop pure pleasantries. Organize "
            "it as short bullet-free prose grouped under short subtopic headings ('## <Subtopic>'). "
            "This summary will be shown to participants in place of the raw early turns, so it must "
            "stand alone."
        ),
    },

    # ===== DISCUSSION ROLES — per-participant persona, same pattern as CASCADE_FUNCTIONS =====
    # Each participant row picks one of these. 'turn_template' takes {topic}, {transcript} (the
    # compacted history + recent raw turns) and returns what that participant says this round.
    # Add more entries here (with a 'turn_template') to add more roles to the dropdown — nothing
    # else in the code needs to change. 'Moderator' additionally needs 'synthesis_template',
    # used for the end-of-discussion (or periodic) summary instead of an ordinary turn.
    'DISCUSSION_ROLES': {
        'Researcher': {
            'turn_template': (
                "Topic under discussion: {topic}\n\n"
                "DISCUSSION SO FAR:\n{transcript}\n\n"
                "As the Researcher, contribute 1-3 concrete, well-grounded points that move the "
                "discussion forward — new information, a relevant fact, or a angle not yet raised. "
                "Do not just restate what others already said. Keep it to a short paragraph."
            ),
        },
        'Skeptic': {
            'turn_template': (
                "Topic under discussion: {topic}\n\n"
                "DISCUSSION SO FAR:\n{transcript}\n\n"
                "As the Skeptic, critically examine the most recent claims above. Point out any that "
                "are unsupported, overstated, or internally inconsistent, and say specifically why. "
                "If the recent claims hold up, say so briefly rather than manufacturing an objection. "
                "Keep it to a short paragraph."
            ),
        },
        'Fact Checker': {
            'turn_template': (
                "Topic under discussion: {topic}\n\n"
                "DISCUSSION SO FAR:\n{transcript}\n\n"
                "As the Fact Checker, verify the most recent factual claims above against what you "
                "know. Flag anything you believe is inaccurate, unverifiable, or needs a caveat, and "
                "briefly say why. Do not invent sources. If everything recent checks out, say so "
                "briefly. Keep it to a short paragraph."
            ),
        },
        'Analyst': {
            'turn_template': (
                "Topic under discussion: {topic}\n\n"
                "DISCUSSION SO FAR:\n{transcript}\n\n"
                "As the Analyst, examine the structure and logic of the discussion so far — identify "
                "where reasoning is strong, where it's weak, and any implications that haven't been "
                "drawn out yet. Keep it to a short paragraph."
            ),
        },
        'Devil\'s Advocate': {
            'turn_template': (
                "Topic under discussion: {topic}\n\n"
                "DISCUSSION SO FAR:\n{transcript}\n\n"
                "As the Devil's Advocate, argue the strongest case AGAINST the position the discussion "
                "is converging on, even if you personally find it convincing. Be specific, not "
                "contrarian for its own sake. Keep it to a short paragraph."
            ),
        },
        'Moderator': {
            'turn_template': (
                "Topic under discussion: {topic}\n\n"
                "DISCUSSION SO FAR:\n{transcript}\n\n"
                "As the Moderator, briefly steer the discussion — note what's been resolved, what's "
                "still contested, and pose one focused question the next speakers should address. "
                "Keep it to a short paragraph."
            ),
            'synthesis_template': (
                "Topic under discussion: {topic}\n\n"
                "FULL DISCUSSION:\n{transcript}\n\n"
                "As the Moderator, write a final synthesis of this discussion: what points reached "
                "consensus, what remains contested or unresolved, and your overall assessment of "
                "where the evidence/arguments land. Structure it with short headed sections. This is "
                "the closing summary, not another turn."
            ),
        },
    },
}

# ============================================================================
# END CONFIGURATION
# ============================================================================

# Research card dropdown -> internal-code lookups (kept out of CONFIG since these map
# display strings the widgets hold directly to the codes the loop logic branches on).
RESEARCH_SOURCE_MODES = {
    "Local Documents": "local",
    "Model Knowledge Only (Offline)": "offline_knowledge",
    "Web Search (Online)": "online",
}
RESEARCH_COMPACT_INTERVALS = {
    "Off": 0,
    "Every 5 rounds": 5,
    "Every 10 rounds": 10,
    "Every 15 rounds": 15,
    "Every 20 rounds": 20,
    "Every 25 rounds": 25,
    "Every 50 rounds": 50,
}
RESEARCH_SEARCH_BACKENDS = {
    "DuckDuckGo (free, no key)": "duckduckgo",
    "Tavily API (key required)": "tavily",
}

# Discussion card reuses the exact same Auto-Merge interval choices as Research.
DISCUSSION_COMPACT_INTERVALS = RESEARCH_COMPACT_INTERVALS


class LoadingSplash:
    """Splash screen with loading bar shown during startup checks"""
    def __init__(self, root):
        self.root = root
        self.splash = tk.Toplevel(root)
        self.splash.title(CONFIG['TEXT']['app_title'])
        w, h = CONFIG['DIMENSIONS']['splash_width'], CONFIG['DIMENSIONS']['splash_height']
        self.splash.geometry(f"{w}x{h}")
        self.splash.resizable(False, False)

        # Center on screen
        self.splash.update_idletasks()
        x = (self.splash.winfo_screenwidth() // 2) - (w // 2)
        y = (self.splash.winfo_screenheight() // 2) - (h // 2)
        self.splash.geometry(f"+{x}+{y}")

        # Remove window decorations for cleaner look
        self.splash.attributes('-topmost', True)

        # Content
        font = (CONFIG['FONTS']['family_default'], CONFIG['FONTS']['size_title'], 'bold')
        ttk.Label(self.splash, text=CONFIG['TEXT']['app_title'], font=font).pack(
            pady=CONFIG['DIMENSIONS']['padding_large'])
        ttk.Label(self.splash, text="Checking server...",
                 font=(CONFIG['FONTS']['family_default'], CONFIG['FONTS']['size_small'])).pack(
            pady=(0, CONFIG['DIMENSIONS']['padding_normal']))

        self.progress = ttk.Progressbar(self.splash, mode='indeterminate', length=300)
        self.progress.pack(pady=CONFIG['DIMENSIONS']['padding_normal'])
        self.progress.start()

    def close(self):
        """Close splash screen"""
        self.progress.stop()
        self.splash.destroy()


class LMStudioOrchestrator:
    def __init__(self, root):
        self.root = root
        self.root.title(CONFIG['TEXT']['app_title'])
        w, h = CONFIG['DIMENSIONS']['window_width'], CONFIG['DIMENSIONS']['window_height']
        self.root.geometry(f"{w}x{h}")
        self.root.resizable(False, False)

        # Window lock state
        self.window_locked = True

        # Connection state (set for real by check_connection(), but referenced
        # before that first runs if anything checks it during startup)
        self.is_connected = False

        # API Config
        self.api_base = CONFIG['API']['base_url']
        self.model_keys = {}
        self.current_model = None
        self.loading_model = False

        # Document settings
        self.max_tokens_var = tk.IntVar(value=CONFIG['DEFAULTS']['max_tokens'])
        self.temperature_var = tk.DoubleVar(value=CONFIG['DEFAULTS']['temperature'])
        self.cascade_category_var = tk.StringVar(value=CONFIG['CASCADE_CATEGORIES'][0])

        # Token tracking
        self.session_tokens = 0
        self.reasoning_tokens = 0

        # Logging
        self.error_log = []
        self.log_file_path = os.path.join(os.path.expanduser("~"), "Downloads", "lm_studio_logs.txt")
        self._initialize_log_file()

        # Settings storage
        self.settings = {
            'api_base': CONFIG['API']['base_url'],
            'quick_start_enabled': False,
            'main_window_width': CONFIG['DIMENSIONS']['window_width'],
            'main_window_height': CONFIG['DIMENSIONS']['window_height'],
            'splash_window_width': CONFIG['DIMENSIONS']['splash_width'],
            'splash_window_height': CONFIG['DIMENSIONS']['splash_height'],
            'research_source_mode': 'Local Documents',
            'research_search_backend': 'DuckDuckGo (free, no key)',
            'research_tavily_api_key': '',
            'research_compact_interval_label': 'Every 10 rounds',
            'discussion_compact_interval_label': 'Every 10 rounds',
            'discussion_participants': [],   # [{"model": display_name, "role": role_name}, ...]
            'research_rules': {},            # {rule_key: bool, ...} — see CONFIG['RESEARCH_RULES']
        }
        self.settings_file = os.path.join(os.path.expanduser("~"), "Downloads", "lm_studio_settings.txt")
        self.load_settings()

        # Constraint Engine
        self.engine = None
        self.engine_loaded = False
        self.engine_enabled_var = tk.BooleanVar(value=True)
        self._init_constraint_engine()

        # Supervisor state
        self.current_pass_num = 0

        # Research mode state (Variant 3 — document-grounded research loop, plus offline
        # self-directed and online web-search modes)
        self.research_running = False
        self.research_paused = False
        self.research_stop_requested = False
        self.research_folder = None
        self.research_chunks = []          # [{"source": filename, "text": chunk_text}, ...]
        self.research_chunk_idx = 0
        self.research_round = 0
        self.research_low_novelty_streak = 0
        self.research_knowledge = {"topic": "", "entries": []}
        self.research_knowledge_path = None
        self.research_last_compaction_round = 0
        self.research_compacting = False
        self.research_topic_var = tk.StringVar(value="")
        self.research_model_var = tk.StringVar(value="None Selected")
        # Research Source: Local Documents (existing chunk-cycling behaviour) / Model Knowledge
        # Only (self-directed, no documents or internet) / Web Search (live search + page fetch)
        self.research_source_var = tk.StringVar(value=self.settings.get('research_source_mode', 'Local Documents'))
        self.research_backend_var = tk.StringVar(value=self.settings.get('research_search_backend', 'DuckDuckGo (free, no key)'))
        self.research_tavily_key_var = tk.StringVar(value=self.settings.get('research_tavily_api_key', ''))
        self.research_compact_interval_var = tk.StringVar(value=self.settings.get('research_compact_interval_label', 'Every 10 rounds'))
        self.research_visited_urls = set()   # URLs already fetched this knowledge base (Web Search mode)
        self.research_search_queue = []      # pending unvisited {"title","url","content"} search hits

        # Research Rules — opt-in checkboxes (see CONFIG['RESEARCH_RULES']) that inject real
        # extra verification steps into the research loop. Created once here so state survives
        # tab switches; restored from settings, defaulting per-rule from CONFIG if never saved.
        saved_research_rules = self.settings.get('research_rules', {})
        self.research_rule_vars = {
            rule_key: tk.BooleanVar(value=saved_research_rules.get(rule_key, rule_cfg.get('default', False)))
            for rule_key, rule_cfg in CONFIG['RESEARCH_RULES'].items()
        }

        # Discussion mode state — multi-model roundtable, same pre-load/compact/dedup pattern
        # as Research but N participants take turns instead of one model per round.
        self.discussion_running = False
        self.discussion_paused = False
        self.discussion_stop_requested = False
        self.discussion_topic_var = tk.StringVar(value="")
        self.discussion_compact_interval_var = tk.StringVar(
            value=self.settings.get('discussion_compact_interval_label', 'Every 10 rounds'))
        self.discussion_participant_rows = []   # [{"frame", "model_var", "role_var", "model_dropdown"}, ...]
        self.discussion_topic = ""              # topic the current transcript/summary belongs to
        self.discussion_transcript = []         # [{"speaker": model_display, "role": role_name, "text": ..., "round": n}, ...]
        self.discussion_summary = ""            # condensed running summary of turns compaction has folded in
        self.discussion_round = 0
        self.discussion_stall_streak = 0
        self.discussion_last_compaction_round = 0
        self.discussion_compacting = False
        self.discussion_transcript_path = None

        # Build UI
        self._build_ui()

        # Bind window events
        self.root.bind("<Configure>", self.update_resolution)
        self.root.protocol("WM_DELETE_WINDOW", self.exit_app)

        # Run startup checks
        self.run_startup_checks()
        self.root.after(1000, self.update_system_resources)

    def _init_constraint_engine(self):
        """Initialize constraint engine with default story constraints"""
        try:
            self.engine = ConstraintEngine(name="StoryValidator")

            # Separate constraints (fast, per-item)
            self.engine.add_separate(IsNonEmpty("IsNonEmpty"))
            self.engine.add_separate(NoDoubleSpaces("NoDoubleSpaces"))
            self.engine.add_separate(NoTrailingWhitespace("NoTrailingWhitespace"))
            self.engine.add_separate(CapitalizeFirst("CapitalizeFirst"))
            self.engine.add_separate(MaxLength("MaxLength", max_len=10000))

            # Collective constraints (global, cross-checking)
            self.engine.add_collective(NoContradictions("NoContradictions"))

            self.engine_loaded = True
            sep_count = len(self.engine.separate_constraints)
            col_count = len(self.engine.collective_constraints)
            self.add_log(f"Constraint Engine loaded: {sep_count} separate, {col_count} collective", "INFO")
        except Exception as e:
            self.engine_loaded = False
            self.add_log(f"Constraint Engine failed to load: {str(e)}", "ERROR")

    def open_engine_editor(self):
        """Open the constraint engine GUI editor"""
        def on_apply(new_engine):
            """Callback: GUI editor sends back the updated engine"""
            self.engine = new_engine
            self.engine_loaded = True
            self._update_engine_status_display()

            sep_count = len(self.engine.separate_constraints)
            col_count = len(self.engine.collective_constraints)
            self.add_log(f"Engine updated from editor: {sep_count} separate, {col_count} collective", "INFO")

        editor_window = tk.Toplevel(self.root)
        ConstraintEngineGUI(editor_window, engine=self.engine, on_apply=on_apply)

    def toggle_engine(self):
        """Handle the Constraints Engine enable/disable checkbox"""
        self._update_engine_status_display()
        state = "enabled" if self.engine_enabled_var.get() else "disabled"
        self.add_log(f"Constraint Engine {state}", "INFO")

    def _update_engine_status_display(self):
        """Refresh the status label in the Constraints Engine card"""
        if not hasattr(self, 'engine_running_label'):
            return

        if not self.engine_loaded or not self.engine:
            self.engine_running_label.config(text="❌ Not Loaded", foreground=CONFIG['COLORS']['status_offline'])
            return

        sep_count = len(self.engine.separate_constraints)
        col_count = len(self.engine.collective_constraints)

        if self.engine_enabled_var.get():
            self.engine_running_label.config(
                text=f"✅ Engine Running ({sep_count} separate, {col_count} collective)",
                foreground=CONFIG['COLORS']['status_online']
            )
        else:
            self.engine_running_label.config(
                text=f"⏸ Loaded, Disabled ({sep_count} separate, {col_count} collective)",
                foreground=CONFIG['COLORS']['text_muted']
            )

    def open_engine_config(self):
        """Load a saved constraint engine JSON config and apply it"""
        file_path = filedialog.askopenfilename(
            title="Open Constraint Engine Config",
            initialdir=os.path.expanduser("~/Downloads"),
            filetypes=[("JSON files", "*.json"), ("All files", "*.*")]
        )

        if not file_path:
            return

        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                loaded_config = json.load(f)

            if "separate" not in loaded_config and "collective" not in loaded_config:
                messagebox.showerror("Error", "Invalid config file — missing separate/collective keys")
                return

            self.engine = config_to_engine(loaded_config)
            self.engine_loaded = True
            self._update_engine_status_display()

            sep_count = len(self.engine.separate_constraints)
            col_count = len(self.engine.collective_constraints)

            messagebox.showinfo("Loaded", f"Constraint config loaded:\n{os.path.basename(file_path)}\n\n{sep_count} separate, {col_count} collective constraints")
            self.add_log(f"Constraint config loaded from: {file_path}", "INFO")

        except Exception as e:
            messagebox.showerror("Error", f"Failed to load config:\n{str(e)}")
            self.add_log(f"Error loading constraint config: {str(e)}", "ERROR")

    def open_engine_test(self):
        """Quick 'Test Engine' dialog reachable directly from the Constraints Engine card —
        type text into the input box, run it through whichever engine is actually loaded/running
        on the app right now (self.engine — the same one Cascade/Research/Discussion use), and see
        the corrected version plus a per-constraint pass/fail breakdown in the output box. This is
        a live test of the ACTIVE engine; the separate Test section inside Edit Engine tests
        whatever draft config is currently open in the editor, which may not be applied yet."""
        if not self.engine_loaded or not self.engine:
            messagebox.showwarning(CONFIG['TEXT']['popup_warning'], "No constraint engine is loaded yet.")
            return

        font_mono = (CONFIG['FONTS']['family_mono'], CONFIG['FONTS']['size_small'])
        font_header = (CONFIG['FONTS']['family_default'], CONFIG['FONTS']['size_header'], 'bold')
        font_label = (CONFIG['FONTS']['family_default'], CONFIG['FONTS']['size_normal'], 'bold')

        win = tk.Toplevel(self.root)
        win.title("Test Constraint Engine")
        win.geometry("700x480")
        win.configure(bg=CONFIG['COLORS']['bg_white'])

        header = tk.Frame(win, bg=CONFIG['COLORS']['bg_white'])
        header.pack(fill=tk.X, padx=14, pady=(14, 8))
        tk.Label(header, text="Test Engine", font=font_header,
                bg=CONFIG['COLORS']['bg_white']).pack(side=tk.LEFT)

        sep_count = len(self.engine.separate_constraints)
        col_count = len(self.engine.collective_constraints)
        tk.Label(header, text=f"({sep_count} separate, {col_count} collective — currently active engine)",
                font=font_mono, fg=CONFIG['COLORS']['text_muted'],
                bg=CONFIG['COLORS']['bg_white']).pack(side=tk.LEFT, padx=(10, 0))

        test_auto_fix_var = tk.BooleanVar(value=True)
        tk.Checkbutton(header, text="Auto-fix", variable=test_auto_fix_var, font=font_mono,
                        bg=CONFIG['COLORS']['bg_white'], activebackground=CONFIG['COLORS']['bg_white']
                        ).pack(side=tk.RIGHT)

        body = tk.Frame(win, bg=CONFIG['COLORS']['bg_white'])
        body.pack(fill=tk.BOTH, expand=True, padx=14, pady=(0, 8))
        body.columnconfigure(0, weight=1)
        body.columnconfigure(1, weight=1)
        body.rowconfigure(1, weight=1)

        tk.Label(body, text="Input:", font=font_label,
                bg=CONFIG['COLORS']['bg_white']).grid(row=0, column=0, sticky="w", pady=(0, 2))
        tk.Label(body, text="Output (corrected version):", font=font_label,
                bg=CONFIG['COLORS']['bg_white']).grid(row=0, column=1, sticky="w", padx=(8, 0), pady=(0, 2))

        input_box = tk.Text(body, font=font_mono, wrap=tk.WORD, bg=CONFIG['COLORS']['bg_input'],
                            relief=tk.SOLID, bd=1)
        input_box.grid(row=1, column=0, sticky="nsew", padx=(0, 4))
        input_box.insert("1.0", "  hello world.  This is a  test with  double spaces.  ")

        output_box = tk.Text(body, font=font_mono, wrap=tk.WORD, bg=CONFIG['COLORS']['bg_secondary'],
                             relief=tk.SOLID, bd=1, state=tk.DISABLED)
        output_box.grid(row=1, column=1, sticky="nsew", padx=(4, 0))

        def set_output(text, color):
            output_box.config(state=tk.NORMAL, fg=color)
            output_box.delete("1.0", tk.END)
            output_box.insert("1.0", text)
            output_box.config(state=tk.DISABLED)

        def run_test():
            data = input_box.get("1.0", tk.END).strip()
            if not data:
                set_output("Enter test text first", CONFIG['COLORS']['text_error'])
                return

            auto_fix = test_auto_fix_var.get()
            start = time.time()
            result = self.engine.validate(data, auto_fix=auto_fix)
            elapsed = (time.time() - start) * 1000

            lines = []
            for entry in result.get("log", []):
                name = entry["constraint"]
                phase = "S" if entry.get("phase") == "separate" else "C"
                ms = entry.get("duration_ms", 0)
                if entry.get("fixed"):
                    lines.append(f"\U0001f527 [{phase}] {name}: FIXED ({ms:.2f}ms)")
                elif entry["passed"]:
                    lines.append(f"✓ [{phase}] {name}: passed ({ms:.2f}ms)")
                else:
                    lines.append(f"✗ [{phase}] {name}: FAILED ({ms:.2f}ms)")

            fixes = sum(1 for e in result.get("log", []) if e.get("fixed"))

            if result.get("success"):
                lines.append(f"\n✓ ALL PASSED ({elapsed:.2f}ms, {fixes} fixes)\n")
                lines.append("Corrected output:")
                lines.append(result.get("data", data))
                color = CONFIG['COLORS']['status_online']
            else:
                failed = result.get("failed_at", "unknown")
                lines.append(f"\n✗ FAILED at: {failed} ({elapsed:.2f}ms) — auto-fix couldn't "
                             f"resolve it, or Auto-fix is off\n")
                lines.append("Best available output (unfixed, since validation failed):")
                lines.append(data)
                color = CONFIG['COLORS']['text_error']

            set_output("\n".join(lines), color)

        btn_row = tk.Frame(win, bg=CONFIG['COLORS']['bg_white'])
        btn_row.pack(fill=tk.X, padx=14, pady=(0, 14))
        tk.Button(btn_row, text='▶ Run Test', command=run_test,
                 bg=CONFIG['COLORS']['button_primary'], fg=CONFIG['COLORS']['text_white'],
                 font=font_mono, relief=tk.FLAT, padx=12, pady=4).pack(side=tk.LEFT)

    def _build_ui(self):
        """Build the main UI"""
        # ===== TOP TAB MENU BAR =====
        menu_bar = tk.Frame(self.root, bg=CONFIG['COLORS']['bg_menu'], relief=tk.RIDGE, bd=1)
        menu_bar.pack(fill=tk.X, side=tk.TOP)
        menu_bar.grid_rowconfigure(0, weight=1)

        # File Menu button
        font_btn = (CONFIG['FONTS']['family_default'], CONFIG['FONTS']['size_normal'], 'bold')
        file_menu_btn = tk.Button(
            menu_bar, text=CONFIG['TEXT']['btn_file'], font=font_btn,
            bg=CONFIG['COLORS']['tab_inactive'], activebackground=CONFIG['COLORS']['border_gray'],
            relief=tk.FLAT, bd=0, pady=CONFIG['DIMENSIONS']['padding_small'],
            command=self.show_file_menu, justify=tk.CENTER
        )
        file_menu_btn.grid(row=0, column=0, sticky="nsew", padx=3, pady=5)
        menu_bar.grid_columnconfigure(0, weight=0, minsize=50)

        self.tab_buttons = {}
        self.tab_frames = {}
        self.current_tab = "model_control"

        tabs = [("model_control", CONFIG['TEXT']['card_model_loader'] + " hidden, tap to open")]
        for idx, (tab_id, tab_label) in enumerate(tabs, start=1):
            btn = tk.Button(
                menu_bar, text=tab_label, font=font_btn,
                bg=CONFIG['COLORS']['tab_inactive'], activebackground=CONFIG['COLORS']['border_gray'],
                relief=tk.FLAT, bd=0, pady=CONFIG['DIMENSIONS']['padding_small'],
                command=lambda tid=tab_id: self.switch_tab(tid), justify=tk.CENTER
            )
            btn.grid(row=0, column=idx, sticky="nsew", padx=3, pady=5)
            menu_bar.grid_columnconfigure(idx, weight=1)
            self.tab_buttons[tab_id] = btn

        self.update_tab_appearance()

        # ===== MAIN CONTAINER FRAME =====
        self.main_container = tk.Frame(self.root, bg=CONFIG['COLORS']['bg_primary'])
        self.main_container.pack(fill=tk.BOTH, expand=True)

        # ===== TAB 1: MODEL CONTROL =====
        self.model_control_frame = tk.Frame(self.main_container, bg=CONFIG['COLORS']['bg_primary'])
        self.tab_frames["model_control"] = self.model_control_frame

        # Scrollable container
        canvas = tk.Canvas(self.model_control_frame, bg=CONFIG['COLORS']['bg_primary'], highlightthickness=0)
        scrollbar = ttk.Scrollbar(self.model_control_frame, orient="vertical", command=canvas.yview)
        scrollable_frame = ttk.Frame(canvas, padding=CONFIG['DIMENSIONS']['padding_large'])
        scrollable_frame.configure(style='TFrame')

        scrollable_frame.bind(
            "<Configure>",
            lambda e: canvas.configure(scrollregion=canvas.bbox("all"))
        )

        canvas.create_window((0, 0), window=scrollable_frame, anchor="nw")
        canvas.configure(yscrollcommand=scrollbar.set, bg=CONFIG['COLORS']['bg_primary'])
        canvas.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)

        def _on_mousewheel(event):
            try:
                if canvas.winfo_exists():
                    canvas.yview_scroll(int(-1*(event.delta/120)), "units")
            except tk.TclError:
                pass
        canvas.bind("<MouseWheel>", _on_mousewheel)
        scrollable_frame.bind("<MouseWheel>", _on_mousewheel)

        # ===== CONTROL PANEL (Card 1) =====
        control_panel = tk.Frame(
            scrollable_frame, bg=CONFIG['COLORS']['bg_white'], relief=CONFIG['DIMENSIONS']['card_relief'], bd=0,
            highlightthickness=CONFIG['DIMENSIONS']['card_border_width'], highlightbackground=CONFIG['COLORS']['border_light'],
            highlightcolor=CONFIG['COLORS']['border_light']
        )
        control_panel.pack(fill=tk.BOTH, expand=False, padx=CONFIG['DIMENSIONS']['padding_normal'],
                          pady=(0, CONFIG['DIMENSIONS']['padding_large']))

        # Card header
        card_header = tk.Frame(control_panel, bg=CONFIG['COLORS']['bg_white'])
        card_header.pack(fill=tk.X, padx=CONFIG['DIMENSIONS']['padding_large'],
                        pady=(CONFIG['DIMENSIONS']['padding_large'], CONFIG['DIMENSIONS']['padding_normal']))
        font_header = (CONFIG['FONTS']['family_default'], CONFIG['FONTS']['size_header'], 'bold')
        ttk.Label(card_header, text=CONFIG['TEXT']['card_status'], font=font_header,
                 background=CONFIG['COLORS']['bg_white']).pack(anchor=tk.W)

        # Card content
        card_content = tk.Frame(control_panel, bg=CONFIG['COLORS']['bg_white'])
        card_content.pack(fill=tk.BOTH, expand=True, padx=CONFIG['DIMENSIONS']['padding_large'],
                         pady=(0, CONFIG['DIMENSIONS']['padding_large']))

        font_label = (CONFIG['FONTS']['family_default'], CONFIG['FONTS']['size_normal'], 'bold')
        font_small = (CONFIG['FONTS']['family_default'], CONFIG['FONTS']['size_small'])

        # Status row
        ttk.Label(card_content, text=CONFIG['TEXT']['label_lm_studio_status'], font=font_label,
                 background=CONFIG['COLORS']['bg_white']).pack(anchor=tk.W, pady=(0, CONFIG['DIMENSIONS']['padding_tiny']))

        status_row = tk.Frame(card_content, bg=CONFIG['COLORS']['bg_white'])
        status_row.pack(fill=tk.X, pady=(0, CONFIG['DIMENSIONS']['padding_tiny']))

        self.status_label = tk.Label(status_row, text=CONFIG['TEXT']['status_disconnected'],
                                     foreground=CONFIG['COLORS']['status_offline'], font=font_small,
                                     bg=CONFIG['COLORS']['bg_white'])
        self.status_label.pack(side=tk.LEFT, padx=(0, 15))

        tk.Label(status_row, text=CONFIG['TEXT']['label_server'], font=font_small,
                bg=CONFIG['COLORS']['bg_white']).pack(side=tk.LEFT, padx=(0, 5))
        self.server_label = tk.Label(status_row, text=self.api_base, foreground=CONFIG['COLORS']['text_blue'],
                                     font=(CONFIG['FONTS']['family_mono'], CONFIG['FONTS']['size_small']),
                                     bg=CONFIG['COLORS']['bg_white'])
        self.server_label.pack(side=tk.LEFT)

        # Resolution display with lock button
        resolution_frame = tk.Frame(status_row, bg=CONFIG['COLORS']['bg_white'])
        resolution_frame.pack(side=tk.RIGHT)

        self.resolution_label = tk.Label(resolution_frame, text="491x624",
                                         foreground=CONFIG['COLORS']['text_blue'],
                                         font=(CONFIG['FONTS']['family_mono'], CONFIG['FONTS']['size_small']),
                                         bg=CONFIG['COLORS']['bg_white'])
        self.resolution_label.pack(side=tk.LEFT, padx=(0, 5))

        self.lock_button = tk.Button(resolution_frame, text="🔒",
                                     font=(CONFIG['FONTS']['family_default'], CONFIG['FONTS']['size_tiny']),
                                     command=self.toggle_window_lock, relief=tk.FLAT, bd=0, padx=3, pady=0,
                                     bg=CONFIG['COLORS']['bg_white'])
        self.lock_button.pack(side=tk.LEFT)

        # LMs available row
        lms_row = tk.Frame(card_content, bg=CONFIG['COLORS']['bg_white'])
        lms_row.pack(anchor=tk.W, pady=(0, CONFIG['DIMENSIONS']['padding_normal']))

        tk.Label(lms_row, text=CONFIG['TEXT']['label_available_models'], font=font_small,
                bg=CONFIG['COLORS']['bg_white']).pack(side=tk.LEFT, padx=(0, 5))
        self.lms_count_label = tk.Label(lms_row, text="0", foreground=CONFIG['COLORS']['text_blue'],
                                        font=(CONFIG['FONTS']['family_mono'], CONFIG['FONTS']['size_small'], 'bold'),
                                        bg=CONFIG['COLORS']['bg_white'])
        self.lms_count_label.pack(side=tk.LEFT)

        # Token tracking
        token_row = tk.Frame(card_content, bg=CONFIG['COLORS']['bg_white'])
        token_row.pack(anchor=tk.W, pady=(0, CONFIG['DIMENSIONS']['padding_normal']))

        tk.Label(token_row, text=CONFIG['TEXT']['label_tokens_used'], font=font_small,
                bg=CONFIG['COLORS']['bg_white']).pack(side=tk.LEFT, padx=(0, 10))
        self.session_tokens_label = tk.Label(token_row, text="0", foreground=CONFIG['COLORS']['status_online'],
                                             font=(CONFIG['FONTS']['family_mono'], CONFIG['FONTS']['size_small'], 'bold'),
                                             bg=CONFIG['COLORS']['bg_white'])
        self.session_tokens_label.pack(side=tk.LEFT, padx=(0, 20))

        tk.Label(token_row, text=CONFIG['TEXT']['label_reasoning'], font=font_small,
                bg=CONFIG['COLORS']['bg_white']).pack(side=tk.LEFT, padx=(0, 10))
        self.reasoning_tokens_label = tk.Label(token_row, text="0", foreground=CONFIG['COLORS']['text_blue'],
                                               font=(CONFIG['FONTS']['family_mono'], CONFIG['FONTS']['size_small'], 'bold'),
                                               bg=CONFIG['COLORS']['bg_white'])
        self.reasoning_tokens_label.pack(side=tk.LEFT)

        font_btn_small = (CONFIG['FONTS']['family_default'], CONFIG['FONTS']['size_small'])
        tk.Button(card_content, text=CONFIG['TEXT']['btn_refresh'], command=self.refresh_script,
                 bg=CONFIG['COLORS']['button_red'], fg=CONFIG['COLORS']['text_white'],
                 font=font_btn_small).pack(fill=tk.X, pady=CONFIG['DIMENSIONS']['padding_tiny'])
        tk.Button(card_content, text=CONFIG['TEXT']['btn_restart'], command=self.restart_script,
                 bg=CONFIG['COLORS']['button_red'], fg=CONFIG['COLORS']['text_white'],
                 font=font_btn_small).pack(fill=tk.X, pady=CONFIG['DIMENSIONS']['padding_tiny'])

        # ===== CONSTRAINTS ENGINE (Card 1.5) =====
        engine_card = tk.Frame(
            scrollable_frame, bg=CONFIG['COLORS']['bg_white'], relief=CONFIG['DIMENSIONS']['card_relief'], bd=0,
            highlightthickness=CONFIG['DIMENSIONS']['card_border_width'], highlightbackground=CONFIG['COLORS']['border_light'],
            highlightcolor=CONFIG['COLORS']['border_light']
        )
        engine_card.pack(fill=tk.BOTH, expand=False, padx=CONFIG['DIMENSIONS']['padding_normal'],
                        pady=(0, CONFIG['DIMENSIONS']['padding_large']))

        # Card header: title + running status, right-aligned (same pattern as Supervisor card)
        engine_card_header = tk.Frame(engine_card, bg=CONFIG['COLORS']['bg_white'])
        engine_card_header.pack(fill=tk.X, padx=CONFIG['DIMENSIONS']['padding_large'],
                                pady=(CONFIG['DIMENSIONS']['padding_large'], CONFIG['DIMENSIONS']['padding_normal']))

        tk.Label(engine_card_header, text="Constraints Engine", font=font_header,
                background=CONFIG['COLORS']['bg_white']).pack(anchor=tk.W, side=tk.LEFT)

        self.engine_running_label = tk.Label(
            engine_card_header, text="❌ Not Loaded",
            font=(CONFIG['FONTS']['family_mono'], CONFIG['FONTS']['size_small'], 'bold'),
            background=CONFIG['COLORS']['bg_white'], foreground=CONFIG['COLORS']['status_offline']
        )
        self.engine_running_label.pack(anchor=tk.E, side=tk.RIGHT)

        # Card content
        engine_card_content = tk.Frame(engine_card, bg=CONFIG['COLORS']['bg_white'])
        engine_card_content.pack(fill=tk.BOTH, expand=True, padx=CONFIG['DIMENSIONS']['padding_large'],
                                 pady=(0, CONFIG['DIMENSIONS']['padding_large']))

        engine_controls_row = tk.Frame(engine_card_content, bg=CONFIG['COLORS']['bg_white'])
        engine_controls_row.pack(fill=tk.X)

        tk.Checkbutton(engine_controls_row, text="Enabled", variable=self.engine_enabled_var,
                        command=self.toggle_engine, font=font_small, bg=CONFIG['COLORS']['bg_white'],
                        fg=CONFIG['COLORS']['text_primary'], selectcolor=CONFIG['COLORS']['bg_input'],
                        activebackground=CONFIG['COLORS']['bg_white']).pack(side=tk.LEFT, padx=(0, 15))

        tk.Button(engine_controls_row, text='📂 Open Config', command=self.open_engine_config,
                 bg=CONFIG['COLORS']['button_primary'], fg=CONFIG['COLORS']['text_white'],
                 font=(CONFIG['FONTS']['family_default'], CONFIG['FONTS']['size_small']),
                 relief=tk.FLAT, padx=10, pady=3).pack(side=tk.LEFT, padx=(0, 6))

        tk.Button(engine_controls_row, text='⚙️ Edit Engine', command=self.open_engine_editor,
                 bg=CONFIG['COLORS']['button_primary'], fg=CONFIG['COLORS']['text_white'],
                 font=(CONFIG['FONTS']['family_default'], CONFIG['FONTS']['size_small']),
                 relief=tk.FLAT, padx=10, pady=3).pack(side=tk.LEFT, padx=(6, 0))

        tk.Button(engine_controls_row, text='🧪 Test Engine', command=self.open_engine_test,
                 bg=CONFIG['COLORS']['button_primary'], fg=CONFIG['COLORS']['text_white'],
                 font=(CONFIG['FONTS']['family_default'], CONFIG['FONTS']['size_small']),
                 relief=tk.FLAT, padx=10, pady=3).pack(side=tk.LEFT, padx=(6, 0))

        self._update_engine_status_display()

        # ===== STORY CASCADE (Card 2) =====
        cascade_card = tk.Frame(
            scrollable_frame, bg=CONFIG['COLORS']['bg_white'], relief=CONFIG['DIMENSIONS']['card_relief'], bd=0,
            highlightthickness=CONFIG['DIMENSIONS']['card_border_width'], highlightbackground=CONFIG['COLORS']['border_light'],
            highlightcolor=CONFIG['COLORS']['border_light']
        )
        cascade_card.pack(fill=tk.BOTH, expand=False, padx=CONFIG['DIMENSIONS']['padding_normal'],
                         pady=(0, CONFIG['DIMENSIONS']['padding_large']))

        # Category selector header
        cascade_card_header = tk.Frame(cascade_card, bg=CONFIG['COLORS']['bg_white'])
        cascade_card_header.pack(fill=tk.X, padx=CONFIG['DIMENSIONS']['padding_large'],
                                pady=(CONFIG['DIMENSIONS']['padding_large'], CONFIG['DIMENSIONS']['padding_normal']))

        tk.Label(cascade_card_header, text='Category:', font=font_label,
                bg=CONFIG['COLORS']['bg_white']).pack(side=tk.LEFT, padx=(0, 10))

        category_dropdown = ttk.Combobox(cascade_card_header, textvariable=self.cascade_category_var,
                                        values=CONFIG['CASCADE_CATEGORIES'], state="readonly",
                                        width=15)
        category_dropdown.pack(side=tk.LEFT, padx=(0, 10))

        tk.Button(cascade_card_header, text='⚙️ Edit Passes', command=self.edit_cascade_config,
                 bg=CONFIG['COLORS']['button_primary'], fg=CONFIG['COLORS']['text_white'],
                 font=(CONFIG['FONTS']['family_default'], CONFIG['FONTS']['size_small']),
                 relief=tk.FLAT, padx=10, pady=3).pack(side=tk.LEFT)

        cascade_card_content = tk.Frame(cascade_card, bg=CONFIG['COLORS']['bg_white'])
        cascade_card_content.pack(fill=tk.BOTH, expand=True, padx=CONFIG['DIMENSIONS']['padding_large'],
                                 pady=(0, CONFIG['DIMENSIONS']['padding_large']))

        # Story prompt input
        tk.Label(cascade_card_content, text=CONFIG['TEXT']['label_story_idea'], font=font_label,
                bg=CONFIG['COLORS']['bg_white']).pack(anchor=tk.W, pady=(0, CONFIG['DIMENSIONS']['padding_tiny']))

        self.cascade_input = tk.Text(cascade_card_content, height=CONFIG['DIMENSIONS']['story_prompt_height'],
                                     font=font_small, wrap=tk.WORD, bg=CONFIG['COLORS']['bg_input'],
                                     fg=CONFIG['COLORS']['text_primary'], relief=tk.SOLID, bd=1)
        self.cascade_input.pack(fill=tk.X, pady=(0, CONFIG['DIMENSIONS']['padding_large']))
        self.cascade_input.insert("1.0", "A mysterious figure arrives in a small town...")

        # Model selection
        tk.Label(cascade_card_content, text=CONFIG['TEXT']['label_select_model_pass'], font=font_label,
                bg=CONFIG['COLORS']['bg_white']).pack(anchor=tk.W, pady=(0, CONFIG['DIMENSIONS']['padding_small']))
        tk.Label(cascade_card_content, text=CONFIG['TEXT']['label_leave_blank'], font=font_small,
                foreground=CONFIG['COLORS']['text_muted'], bg=CONFIG['COLORS']['bg_white']).pack(
            anchor=tk.W, pady=(0, CONFIG['DIMENSIONS']['padding_normal']))

        # Store cascade selections
        self.cascade_pass_vars = {}
        self.cascade_pass_dropdowns = {}
        self.cascade_pass_function_vars = {}
        self.cascade_pass_max_tokens = {}
        self.model_display_names = {}

        # Function choices available under every model slot (5 passes + Supervisor below).
        # "Default" means: pass keeps its built-in Create/Refine/Polish role, Supervisor keeps
        # its built-in general rating — see CONFIG['CASCADE_FUNCTIONS'] for what each one does.
        cascade_function_choices = ["Default"] + list(CONFIG['CASCADE_FUNCTIONS'].keys())

        # Create 5 pass dropdowns
        for pass_num in range(1, 6):
            pass_frame = tk.Frame(cascade_card_content, bg=CONFIG['COLORS']['bg_white'])
            pass_frame.pack(fill=tk.X, pady=(0, CONFIG['DIMENSIONS']['padding_normal']))

            pass_config = CONFIG['CASCADE_PASSES'][pass_num]
            pass_label_text = f"{pass_config['name']} ({pass_config['role']})"

            tk.Label(pass_frame, text=pass_label_text, font=font_small,
                    bg=CONFIG['COLORS']['bg_white']).pack(anchor=tk.W, pady=(0, 3))

            var = tk.StringVar(value="None Selected")
            self.cascade_pass_vars[pass_num] = var

            dropdown = ttk.Combobox(pass_frame, textvariable=var, state="readonly",
                                   width=CONFIG['DEFAULTS']['model_display_width'])
            dropdown.pack(fill=tk.X, pady=(0, 5))
            self.cascade_pass_dropdowns[pass_num] = dropdown

            # Function row — overrides this pass's role when not "Default"
            function_row = tk.Frame(pass_frame, bg=CONFIG['COLORS']['bg_white'])
            function_row.pack(fill=tk.X, pady=(0, 3))
            tk.Label(function_row, text=CONFIG['TEXT']['label_pass_function'], font=font_small,
                    bg=CONFIG['COLORS']['bg_white']).pack(side=tk.LEFT, padx=(0, 5))
            function_var = tk.StringVar(value="Default")
            self.cascade_pass_function_vars[pass_num] = function_var
            ttk.Combobox(function_row, textvariable=function_var, state="readonly",
                        values=cascade_function_choices, width=16).pack(side=tk.LEFT)

            # Per-pass tokens row
            tokens_row = tk.Frame(pass_frame, bg=CONFIG['COLORS']['bg_white'])
            tokens_row.pack(fill=tk.X, pady=(0, 3))

            tk.Label(tokens_row, text=CONFIG['TEXT']['label_tokens'], font=font_small,
                    bg=CONFIG['COLORS']['bg_white']).pack(side=tk.LEFT, padx=(0, 5))

            # Pass 5 (Polish) gets higher tokens by default
            if pass_num == 5:
                tokens_var = tk.IntVar(value=8000)
                ttk.Spinbox(tokens_row, from_=100, to=32000, textvariable=tokens_var, width=5).pack(side=tk.LEFT, padx=(0, 5))
                tk.Label(tokens_row, text='(higher limits)', font=font_small,
                        foreground=CONFIG['COLORS']['status_online'], bg=CONFIG['COLORS']['bg_white']).pack(side=tk.LEFT)
            else:
                tokens_var = tk.IntVar(value=CONFIG['DEFAULTS']['cascade_pass_tokens'])
                ttk.Spinbox(tokens_row, from_=100, to=4000, textvariable=tokens_var, width=5).pack(side=tk.LEFT)

            self.cascade_pass_max_tokens[pass_num] = tokens_var

        # Temperature and buttons
        limiter_frame = tk.Frame(cascade_card_content, bg=CONFIG['COLORS']['bg_white'], relief=tk.FLAT, bd=0)
        limiter_frame.pack(fill=tk.X, pady=(CONFIG['DIMENSIONS']['padding_large'], CONFIG['DIMENSIONS']['padding_normal']))

        # Timeout row (above)
        timeout_row = tk.Frame(limiter_frame, bg=CONFIG['COLORS']['bg_white'])
        timeout_row.pack(fill=tk.X, pady=(0, CONFIG['DIMENSIONS']['padding_small']))

        tk.Label(timeout_row, text='Server Timeout (Global):', font=font_small,
                bg=CONFIG['COLORS']['bg_white']).pack(side=tk.LEFT, padx=(0, 5))
        self.timeout_var = tk.IntVar(value=CONFIG['API']['timeout_chat'])
        ttk.Spinbox(timeout_row, from_=30, to=600, increment=30, textvariable=self.timeout_var, width=8).pack(side=tk.LEFT, padx=(0, 5))
        tk.Label(timeout_row, text='(30-600 seconds)', font=font_small,
                foreground=CONFIG['COLORS']['text_muted'], bg=CONFIG['COLORS']['bg_white']).pack(side=tk.LEFT)

        # Temperature row (below)
        settings_row = tk.Frame(limiter_frame, bg=CONFIG['COLORS']['bg_white'])
        settings_row.pack(fill=tk.X, pady=(CONFIG['DIMENSIONS']['padding_small'], CONFIG['DIMENSIONS']['padding_small']))

        left_frame = tk.Frame(settings_row, bg=CONFIG['COLORS']['bg_white'])
        left_frame.pack(side=tk.LEFT, fill=tk.X, expand=True)

        tk.Label(left_frame, text=CONFIG['TEXT']['label_temp_global'], font=font_small,
                bg=CONFIG['COLORS']['bg_white']).pack(side=tk.LEFT, padx=(0, 5))
        self.cascade_temp_var = tk.DoubleVar(value=CONFIG['DEFAULTS']['cascade_temperature'])
        ttk.Spinbox(left_frame, from_=0.0, to=2.0, increment=0.1, textvariable=self.cascade_temp_var, width=8).pack(
            side=tk.LEFT, padx=(0, 15))
        tk.Label(left_frame, text=CONFIG['TEXT']['label_temp_range'], font=font_small,
                foreground=CONFIG['COLORS']['text_muted'], bg=CONFIG['COLORS']['bg_white']).pack(side=tk.LEFT)

        right_frame = tk.Frame(settings_row, bg=CONFIG['COLORS']['bg_white'])
        right_frame.pack(side=tk.RIGHT, fill=tk.X)

        tk.Button(right_frame, text=CONFIG['TEXT']['btn_generate'], command=self.start_cascade,
                 bg=CONFIG['COLORS']['status_online'], fg=CONFIG['COLORS']['text_white'],
                 font=font_btn_small).pack(side=tk.LEFT, padx=(0, 5))
        tk.Button(right_frame, text=CONFIG['TEXT']['btn_clear_all'], command=self.clear_cascade,
                 bg=CONFIG['COLORS']['button_red'], fg=CONFIG['COLORS']['text_white'],
                 font=font_btn_small).pack(side=tk.LEFT)

        # Output section
        tk.Label(cascade_card_content, text=CONFIG['TEXT']['label_pass_polished'], font=font_label,
                bg=CONFIG['COLORS']['bg_white']).pack(anchor=tk.W, pady=(0, CONFIG['DIMENSIONS']['padding_small']))

        cascade_output_frame = tk.Frame(cascade_card_content, bg=CONFIG['COLORS']['bg_white'], relief=tk.SOLID, bd=1)
        cascade_output_frame.pack(fill=tk.BOTH, expand=False, pady=(0, CONFIG['DIMENSIONS']['padding_normal']))

        self.cascade_output = tk.Text(cascade_output_frame, height=CONFIG['DIMENSIONS']['cascade_output_height'],
                                      font=(CONFIG['FONTS']['family_mono'], CONFIG['FONTS']['size_small']),
                                      wrap=tk.WORD, bg=CONFIG['COLORS']['bg_secondary'],
                                      fg=CONFIG['COLORS']['text_primary'], relief=tk.SOLID, bd=0, state=tk.DISABLED)
        self.cascade_output.pack(fill=tk.BOTH, expand=True)

        cascade_btn_frame = tk.Frame(cascade_card_content, bg=CONFIG['COLORS']['bg_white'])
        cascade_btn_frame.pack(fill=tk.X)
        tk.Button(cascade_btn_frame, text=CONFIG['TEXT']['btn_copy_output'], command=self.copy_cascade_output,
                 bg=CONFIG['COLORS']['button_primary'], fg=CONFIG['COLORS']['text_white'],
                 font=font_btn_small).pack(side=tk.LEFT, padx=(0, 3))
        tk.Button(cascade_btn_frame, text=CONFIG['TEXT']['btn_save_story'], command=self.save_cascade_story,
                 bg=CONFIG['COLORS']['button_primary'], fg=CONFIG['COLORS']['text_white'],
                 font=font_btn_small).pack(side=tk.LEFT)

        self.cascade_running = False
        self.logs_listbox = None
        self.model_display_names = {}

        # ===== SUPERVISOR OVERSIGHT PANEL (Card 3) =====
        supervisor_card = tk.Frame(
            scrollable_frame, bg=CONFIG['COLORS']['bg_white'], relief=CONFIG['DIMENSIONS']['card_relief'], bd=0,
            highlightthickness=CONFIG['DIMENSIONS']['card_border_width'], highlightbackground=CONFIG['COLORS']['border_light'],
            highlightcolor=CONFIG['COLORS']['border_light']
        )
        supervisor_card.pack(fill=tk.BOTH, expand=False, padx=CONFIG['DIMENSIONS']['padding_normal'],
                             pady=(0, CONFIG['DIMENSIONS']['padding_large']))

        # Card header
        supervisor_header = tk.Frame(supervisor_card, bg=CONFIG['COLORS']['bg_white'])
        supervisor_header.pack(fill=tk.X, padx=CONFIG['DIMENSIONS']['padding_large'],
                               pady=(CONFIG['DIMENSIONS']['padding_large'], CONFIG['DIMENSIONS']['padding_normal']))

        tk.Label(supervisor_header, text="Supervisor Analysis", font=font_header,
                background=CONFIG['COLORS']['bg_white']).pack(anchor=tk.W, side=tk.LEFT)

        self.supervisor_rating_label = tk.Label(supervisor_header, text="Rating: —",
                                                font=(CONFIG['FONTS']['family_mono'], CONFIG['FONTS']['size_small'], 'bold'),
                                                background=CONFIG['COLORS']['bg_white'],
                                                foreground=CONFIG['COLORS']['text_muted'])
        self.supervisor_rating_label.pack(anchor=tk.E, side=tk.RIGHT, padx=(10, 0))

        # Card content
        supervisor_content = tk.Frame(supervisor_card, bg=CONFIG['COLORS']['bg_white'])
        supervisor_content.pack(fill=tk.BOTH, expand=True, padx=CONFIG['DIMENSIONS']['padding_large'],
                               pady=(0, CONFIG['DIMENSIONS']['padding_large']))

        # Supervisor model selector
        tk.Label(supervisor_content, text="Select Supervisor Model:", font=font_label,
                bg=CONFIG['COLORS']['bg_white']).pack(anchor=tk.W, pady=(0, CONFIG['DIMENSIONS']['padding_small']))

        self.supervisor_pass_var = tk.StringVar(value="None Selected")
        self.supervisor_dropdown = ttk.Combobox(supervisor_content, textvariable=self.supervisor_pass_var,
                                               state="readonly", width=CONFIG['DEFAULTS']['model_display_width'])
        self.supervisor_dropdown.pack(fill=tk.X, pady=(0, CONFIG['DIMENSIONS']['padding_small']))

        # Supervisor Function row — overrides the built-in rating rubric when not "Default"
        supervisor_function_row = tk.Frame(supervisor_content, bg=CONFIG['COLORS']['bg_white'])
        supervisor_function_row.pack(fill=tk.X, pady=(0, CONFIG['DIMENSIONS']['padding_normal']))
        tk.Label(supervisor_function_row, text=CONFIG['TEXT']['label_supervisor_function'], font=font_small,
                bg=CONFIG['COLORS']['bg_white']).pack(side=tk.LEFT, padx=(0, 5))
        self.supervisor_function_var = tk.StringVar(value="Default")
        ttk.Combobox(supervisor_function_row, textvariable=self.supervisor_function_var, state="readonly",
                    values=(["Default"] + list(CONFIG['CASCADE_FUNCTIONS'].keys())), width=16).pack(side=tk.LEFT)

        # Supervisor output box
        tk.Label(supervisor_content, text="Analysis & Recommendation:", font=font_label,
                bg=CONFIG['COLORS']['bg_white']).pack(anchor=tk.W, pady=(0, CONFIG['DIMENSIONS']['padding_small']))

        supervisor_output_frame = tk.Frame(supervisor_content, bg=CONFIG['COLORS']['bg_white'], relief=tk.SOLID, bd=1)
        supervisor_output_frame.pack(fill=tk.BOTH, expand=True, pady=(0, CONFIG['DIMENSIONS']['padding_normal']))

        self.supervisor_output = tk.Text(supervisor_output_frame, height=6,
                                         font=(CONFIG['FONTS']['family_mono'], CONFIG['FONTS']['size_small']),
                                         wrap=tk.WORD, bg=CONFIG['COLORS']['bg_secondary'],
                                         fg=CONFIG['COLORS']['text_primary'], relief=tk.SOLID, bd=0, state=tk.DISABLED)
        self.supervisor_output.pack(fill=tk.BOTH, expand=True)

        # ===== RESEARCH MODE (Card 4) — document-grounded research loop =====
        research_card = tk.Frame(
            scrollable_frame, bg=CONFIG['COLORS']['bg_white'], relief=CONFIG['DIMENSIONS']['card_relief'], bd=0,
            highlightthickness=CONFIG['DIMENSIONS']['card_border_width'], highlightbackground=CONFIG['COLORS']['border_light'],
            highlightcolor=CONFIG['COLORS']['border_light']
        )
        research_card.pack(fill=tk.BOTH, expand=False, padx=CONFIG['DIMENSIONS']['padding_normal'],
                           pady=(0, CONFIG['DIMENSIONS']['padding_large']))

        # Card header: title + live status, right-aligned (same pattern as other cards)
        research_header = tk.Frame(research_card, bg=CONFIG['COLORS']['bg_white'])
        research_header.pack(fill=tk.X, padx=CONFIG['DIMENSIONS']['padding_large'],
                             pady=(CONFIG['DIMENSIONS']['padding_large'], CONFIG['DIMENSIONS']['padding_normal']))

        tk.Label(research_header, text=CONFIG['TEXT']['card_research'], font=font_header,
                background=CONFIG['COLORS']['bg_white']).pack(anchor=tk.W, side=tk.LEFT)

        self.research_status_label = tk.Label(
            research_header, text=f"{CONFIG['TEXT']['status_research_stopped']} — Round 0 · 0 claims",
            font=(CONFIG['FONTS']['family_mono'], CONFIG['FONTS']['size_small'], 'bold'),
            background=CONFIG['COLORS']['bg_white'], foreground=CONFIG['COLORS']['status_offline']
        )
        self.research_status_label.pack(anchor=tk.E, side=tk.RIGHT)

        # Card content
        research_content = tk.Frame(research_card, bg=CONFIG['COLORS']['bg_white'])
        research_content.pack(fill=tk.BOTH, expand=True, padx=CONFIG['DIMENSIONS']['padding_large'],
                              pady=(0, CONFIG['DIMENSIONS']['padding_large']))

        # Research Source selector — Local Documents (needs Load below) / Model Knowledge Only
        # (offline, no documents or internet) / Web Search (online, live search + page fetch)
        tk.Label(research_content, text=CONFIG['TEXT']['label_research_source'], font=font_label,
                bg=CONFIG['COLORS']['bg_white']).pack(anchor=tk.W, pady=(0, CONFIG['DIMENSIONS']['padding_tiny']))

        self.research_source_dropdown = ttk.Combobox(research_content, textvariable=self.research_source_var,
                                                      state="readonly", values=list(RESEARCH_SOURCE_MODES.keys()))
        self.research_source_dropdown.pack(fill=tk.X, pady=(0, CONFIG['DIMENSIONS']['padding_normal']))

        # Source folder row (only relevant when Research Source = Local Documents)
        folder_row = tk.Frame(research_content, bg=CONFIG['COLORS']['bg_white'])
        folder_row.pack(fill=tk.X, pady=(0, CONFIG['DIMENSIONS']['padding_normal']))

        tk.Button(folder_row, text=CONFIG['TEXT']['btn_load_folder'], command=self.load_research_folder,
                 bg=CONFIG['COLORS']['button_primary'], fg=CONFIG['COLORS']['text_white'],
                 font=font_btn_small, relief=tk.FLAT, padx=10, pady=3).pack(side=tk.LEFT, padx=(0, 6))

        tk.Button(folder_row, text=CONFIG['TEXT']['btn_load_files'], command=self.load_research_files,
                 bg=CONFIG['COLORS']['button_primary'], fg=CONFIG['COLORS']['text_white'],
                 font=font_btn_small, relief=tk.FLAT, padx=10, pady=3).pack(side=tk.LEFT, padx=(0, 10))

        self.research_folder_label = tk.Label(folder_row, text=CONFIG['TEXT']['text_no_folder_loaded'],
                                              font=font_small, foreground=CONFIG['COLORS']['text_muted'],
                                              bg=CONFIG['COLORS']['bg_white'])
        self.research_folder_label.pack(side=tk.LEFT)

        # Topic input
        tk.Label(research_content, text=CONFIG['TEXT']['label_research_topic'], font=font_label,
                bg=CONFIG['COLORS']['bg_white']).pack(anchor=tk.W, pady=(0, CONFIG['DIMENSIONS']['padding_tiny']))

        topic_entry = tk.Entry(research_content, textvariable=self.research_topic_var, font=font_small,
                               bg=CONFIG['COLORS']['bg_input'], relief=tk.SOLID, bd=1)
        topic_entry.pack(fill=tk.X, pady=(0, CONFIG['DIMENSIONS']['padding_normal']), ipady=4)

        # Model selector — this one model both researches each round and does the merge/compaction.
        # It gets pre-loaded in LM Studio at Start so the first round doesn't lazily wait on it.
        tk.Label(research_content, text=CONFIG['TEXT']['label_research_model'], font=font_label,
                bg=CONFIG['COLORS']['bg_white']).pack(anchor=tk.W, pady=(0, CONFIG['DIMENSIONS']['padding_tiny']))

        self.research_dropdown = ttk.Combobox(research_content, textvariable=self.research_model_var,
                                              state="readonly", width=CONFIG['DEFAULTS']['model_display_width'])
        self.research_dropdown.pack(fill=tk.X, pady=(0, CONFIG['DIMENSIONS']['padding_normal']))

        # Web Search backend + key (only used when Research Source = Web Search)
        backend_row = tk.Frame(research_content, bg=CONFIG['COLORS']['bg_white'])
        backend_row.pack(fill=tk.X, pady=(0, CONFIG['DIMENSIONS']['padding_normal']))

        backend_col = tk.Frame(backend_row, bg=CONFIG['COLORS']['bg_white'])
        backend_col.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=(0, 8))
        tk.Label(backend_col, text=CONFIG['TEXT']['label_search_backend'], font=font_label,
                bg=CONFIG['COLORS']['bg_white']).pack(anchor=tk.W, pady=(0, CONFIG['DIMENSIONS']['padding_tiny']))
        self.research_backend_dropdown = ttk.Combobox(backend_col, textvariable=self.research_backend_var,
                                                       state="readonly", values=list(RESEARCH_SEARCH_BACKENDS.keys()))
        self.research_backend_dropdown.pack(fill=tk.X)

        key_col = tk.Frame(backend_row, bg=CONFIG['COLORS']['bg_white'])
        key_col.pack(side=tk.LEFT, fill=tk.X, expand=True)
        tk.Label(key_col, text=CONFIG['TEXT']['label_tavily_key'], font=font_label,
                bg=CONFIG['COLORS']['bg_white']).pack(anchor=tk.W, pady=(0, CONFIG['DIMENSIONS']['padding_tiny']))
        tk.Entry(key_col, textvariable=self.research_tavily_key_var, font=font_small, show="*",
                bg=CONFIG['COLORS']['bg_input'], relief=tk.SOLID, bd=1).pack(fill=tk.X, ipady=4)

        # Auto-Merge interval
        merge_row = tk.Frame(research_content, bg=CONFIG['COLORS']['bg_white'])
        merge_row.pack(fill=tk.X, pady=(0, CONFIG['DIMENSIONS']['padding_normal']))
        tk.Label(merge_row, text=CONFIG['TEXT']['label_auto_merge'], font=font_label,
                bg=CONFIG['COLORS']['bg_white']).pack(side=tk.LEFT, padx=(0, 8))
        self.research_compact_dropdown = ttk.Combobox(merge_row, textvariable=self.research_compact_interval_var,
                                                       state="readonly", width=16,
                                                       values=list(RESEARCH_COMPACT_INTERVALS.keys()))
        self.research_compact_dropdown.pack(side=tk.LEFT)

        # Research Rules — functional checkboxes, each wired to a real extra step in
        # _research_loop / _apply_research_verification_rules (see CONFIG['RESEARCH_RULES']).
        # Not placeholders: toggling one changes what actually happens on the next round.
        tk.Label(research_content, text=CONFIG['TEXT']['label_research_rules'], font=font_label,
                bg=CONFIG['COLORS']['bg_white']).pack(anchor=tk.W, pady=(4, CONFIG['DIMENSIONS']['padding_tiny']))

        rules_frame = tk.Frame(research_content, bg=CONFIG['COLORS']['bg_white'])
        rules_frame.pack(fill=tk.X, pady=(0, CONFIG['DIMENSIONS']['padding_normal']))
        rules_frame.grid_columnconfigure(0, weight=1, uniform="rule_col")
        rules_frame.grid_columnconfigure(1, weight=1, uniform="rule_col")

        font_rule_desc = (CONFIG['FONTS']['family_default'], CONFIG['FONTS']['size_small'] - 1) \
            if CONFIG['FONTS']['size_small'] > 7 else (CONFIG['FONTS']['family_default'], CONFIG['FONTS']['size_small'])

        for i, (rule_key, rule_cfg) in enumerate(CONFIG['RESEARCH_RULES'].items()):
            cell = tk.Frame(rules_frame, bg=CONFIG['COLORS']['bg_white'])
            cell.grid(row=i // 2, column=i % 2, sticky="w", padx=(0, 12), pady=(0, 4))

            tk.Checkbutton(
                cell, text=rule_cfg['label'], variable=self.research_rule_vars[rule_key],
                bg=CONFIG['COLORS']['bg_white'], font=font_label, anchor=tk.W,
                command=self.save_settings
            ).pack(anchor=tk.W)

            tk.Label(cell, text=rule_cfg.get('desc', ''), font=font_rule_desc, wraplength=260,
                    justify=tk.LEFT, fg=CONFIG['COLORS']['text_muted'],
                    bg=CONFIG['COLORS']['bg_white']).pack(anchor=tk.W, padx=(20, 0))

        # Control buttons
        research_btn_row = tk.Frame(research_content, bg=CONFIG['COLORS']['bg_white'])
        research_btn_row.pack(fill=tk.X, pady=(0, CONFIG['DIMENSIONS']['padding_normal']))

        tk.Button(research_btn_row, text=CONFIG['TEXT']['btn_research_start'], command=self.start_research,
                 bg=CONFIG['COLORS']['status_online'], fg=CONFIG['COLORS']['text_white'],
                 font=font_btn_small).pack(side=tk.LEFT, padx=(0, 5))

        self.pause_research_btn = tk.Button(research_btn_row, text=CONFIG['TEXT']['btn_research_pause'],
                                            command=self.pause_research, bg=CONFIG['COLORS']['button_primary'],
                                            fg=CONFIG['COLORS']['text_white'], font=font_btn_small)
        self.pause_research_btn.pack(side=tk.LEFT, padx=(0, 5))

        tk.Button(research_btn_row, text=CONFIG['TEXT']['btn_research_stop'], command=self.stop_research,
                 bg=CONFIG['COLORS']['button_red'], fg=CONFIG['COLORS']['text_white'],
                 font=font_btn_small).pack(side=tk.LEFT, padx=(0, 5))

        tk.Button(research_btn_row, text=CONFIG['TEXT']['btn_compact_now'], command=self.compact_research_now,
                 bg=CONFIG['COLORS']['button_primary'], fg=CONFIG['COLORS']['text_white'],
                 font=font_btn_small).pack(side=tk.LEFT, padx=(0, 5))

        tk.Button(research_btn_row, text=CONFIG['TEXT']['btn_open_knowledge'], command=self.open_knowledge_file,
                 bg=CONFIG['COLORS']['button_primary'], fg=CONFIG['COLORS']['text_white'],
                 font=font_btn_small).pack(side=tk.LEFT)

        # Live research log
        tk.Label(research_content, text=CONFIG['TEXT']['label_research_log'], font=font_label,
                bg=CONFIG['COLORS']['bg_white']).pack(anchor=tk.W, pady=(0, CONFIG['DIMENSIONS']['padding_small']))

        research_output_frame = tk.Frame(research_content, bg=CONFIG['COLORS']['bg_white'], relief=tk.SOLID, bd=1)
        research_output_frame.pack(fill=tk.BOTH, expand=False)

        self.research_output = tk.Text(research_output_frame, height=12,
                                       font=(CONFIG['FONTS']['family_mono'], CONFIG['FONTS']['size_small']),
                                       wrap=tk.WORD, bg=CONFIG['COLORS']['bg_secondary'],
                                       fg=CONFIG['COLORS']['text_primary'], relief=tk.SOLID, bd=0, state=tk.DISABLED)
        self.research_output.pack(fill=tk.BOTH, expand=True)

        # ===== DISCUSSION MODE (Card 5) — multi-model roundtable =====
        discussion_card = tk.Frame(
            scrollable_frame, bg=CONFIG['COLORS']['bg_white'], relief=CONFIG['DIMENSIONS']['card_relief'], bd=0,
            highlightthickness=CONFIG['DIMENSIONS']['card_border_width'], highlightbackground=CONFIG['COLORS']['border_light'],
            highlightcolor=CONFIG['COLORS']['border_light']
        )
        discussion_card.pack(fill=tk.BOTH, expand=False, padx=CONFIG['DIMENSIONS']['padding_normal'],
                             pady=(0, CONFIG['DIMENSIONS']['padding_large']))

        # Card header: title + live status, right-aligned (same pattern as Research/Supervisor)
        discussion_header = tk.Frame(discussion_card, bg=CONFIG['COLORS']['bg_white'])
        discussion_header.pack(fill=tk.X, padx=CONFIG['DIMENSIONS']['padding_large'],
                               pady=(CONFIG['DIMENSIONS']['padding_large'], CONFIG['DIMENSIONS']['padding_normal']))

        tk.Label(discussion_header, text=CONFIG['TEXT']['card_discussion'], font=font_header,
                background=CONFIG['COLORS']['bg_white']).pack(anchor=tk.W, side=tk.LEFT)

        self.discussion_status_label = tk.Label(
            discussion_header, text=f"{CONFIG['TEXT']['status_discussion_stopped']} — Round 0 · 0 turns",
            font=(CONFIG['FONTS']['family_mono'], CONFIG['FONTS']['size_small'], 'bold'),
            background=CONFIG['COLORS']['bg_white'], foreground=CONFIG['COLORS']['status_offline']
        )
        self.discussion_status_label.pack(anchor=tk.E, side=tk.RIGHT)

        # Card content
        discussion_content = tk.Frame(discussion_card, bg=CONFIG['COLORS']['bg_white'])
        discussion_content.pack(fill=tk.BOTH, expand=True, padx=CONFIG['DIMENSIONS']['padding_large'],
                                pady=(0, CONFIG['DIMENSIONS']['padding_large']))

        # Topic input
        tk.Label(discussion_content, text=CONFIG['TEXT']['label_discussion_topic'], font=font_label,
                bg=CONFIG['COLORS']['bg_white']).pack(anchor=tk.W, pady=(0, CONFIG['DIMENSIONS']['padding_tiny']))

        discussion_topic_entry = tk.Entry(discussion_content, textvariable=self.discussion_topic_var, font=font_small,
                                          bg=CONFIG['COLORS']['bg_input'], relief=tk.SOLID, bd=1)
        discussion_topic_entry.pack(fill=tk.X, pady=(0, CONFIG['DIMENSIONS']['padding_normal']), ipady=4)

        # Participants label + dynamic row container
        tk.Label(discussion_content, text=CONFIG['TEXT']['label_discussion_participants'], font=font_label,
                bg=CONFIG['COLORS']['bg_white']).pack(anchor=tk.W, pady=(0, CONFIG['DIMENSIONS']['padding_small']))

        self.discussion_participants_frame = tk.Frame(discussion_content, bg=CONFIG['COLORS']['bg_white'])
        self.discussion_participants_frame.pack(fill=tk.X, pady=(0, CONFIG['DIMENSIONS']['padding_small']))

        tk.Button(discussion_content, text=CONFIG['TEXT']['btn_add_participant'],
                 command=self.add_discussion_participant_row,
                 bg=CONFIG['COLORS']['button_primary'], fg=CONFIG['COLORS']['text_white'],
                 font=font_btn_small, relief=tk.FLAT, padx=10, pady=3).pack(
            anchor=tk.W, pady=(0, CONFIG['DIMENSIONS']['padding_normal']))

        # Auto-Merge interval (same choices/pattern as Research)
        d_merge_row = tk.Frame(discussion_content, bg=CONFIG['COLORS']['bg_white'])
        d_merge_row.pack(fill=tk.X, pady=(0, CONFIG['DIMENSIONS']['padding_normal']))
        tk.Label(d_merge_row, text=CONFIG['TEXT']['label_discussion_auto_merge'], font=font_label,
                bg=CONFIG['COLORS']['bg_white']).pack(side=tk.LEFT, padx=(0, 8))
        self.discussion_compact_dropdown = ttk.Combobox(d_merge_row, textvariable=self.discussion_compact_interval_var,
                                                         state="readonly", width=16,
                                                         values=list(DISCUSSION_COMPACT_INTERVALS.keys()))
        self.discussion_compact_dropdown.pack(side=tk.LEFT)

        # Control buttons
        discussion_btn_row = tk.Frame(discussion_content, bg=CONFIG['COLORS']['bg_white'])
        discussion_btn_row.pack(fill=tk.X, pady=(0, CONFIG['DIMENSIONS']['padding_normal']))

        tk.Button(discussion_btn_row, text=CONFIG['TEXT']['btn_discussion_start'], command=self.start_discussion,
                 bg=CONFIG['COLORS']['status_online'], fg=CONFIG['COLORS']['text_white'],
                 font=font_btn_small).pack(side=tk.LEFT, padx=(0, 5))

        self.pause_discussion_btn = tk.Button(discussion_btn_row, text=CONFIG['TEXT']['btn_discussion_pause'],
                                              command=self.pause_discussion, bg=CONFIG['COLORS']['button_primary'],
                                              fg=CONFIG['COLORS']['text_white'], font=font_btn_small)
        self.pause_discussion_btn.pack(side=tk.LEFT, padx=(0, 5))

        tk.Button(discussion_btn_row, text=CONFIG['TEXT']['btn_discussion_stop'], command=self.stop_discussion,
                 bg=CONFIG['COLORS']['button_red'], fg=CONFIG['COLORS']['text_white'],
                 font=font_btn_small).pack(side=tk.LEFT, padx=(0, 5))

        tk.Button(discussion_btn_row, text=CONFIG['TEXT']['btn_compact_discussion_now'],
                 command=self.compact_discussion_now,
                 bg=CONFIG['COLORS']['button_primary'], fg=CONFIG['COLORS']['text_white'],
                 font=font_btn_small).pack(side=tk.LEFT, padx=(0, 5))

        tk.Button(discussion_btn_row, text=CONFIG['TEXT']['btn_open_transcript'], command=self.open_discussion_transcript,
                 bg=CONFIG['COLORS']['button_primary'], fg=CONFIG['COLORS']['text_white'],
                 font=font_btn_small).pack(side=tk.LEFT)

        # Live discussion log
        tk.Label(discussion_content, text=CONFIG['TEXT']['label_discussion_log'], font=font_label,
                bg=CONFIG['COLORS']['bg_white']).pack(anchor=tk.W, pady=(0, CONFIG['DIMENSIONS']['padding_small']))

        discussion_output_frame = tk.Frame(discussion_content, bg=CONFIG['COLORS']['bg_white'], relief=tk.SOLID, bd=1)
        discussion_output_frame.pack(fill=tk.BOTH, expand=False)

        self.discussion_output = tk.Text(discussion_output_frame, height=14,
                                         font=(CONFIG['FONTS']['family_mono'], CONFIG['FONTS']['size_small']),
                                         wrap=tk.WORD, bg=CONFIG['COLORS']['bg_secondary'],
                                         fg=CONFIG['COLORS']['text_primary'], relief=tk.SOLID, bd=0, state=tk.DISABLED)
        self.discussion_output.pack(fill=tk.BOTH, expand=True)

        # Seed with two participant rows (or the saved set, if any were persisted) so there's
        # something usable on first open without making the user click "+ Add Participant" twice.
        saved_participants = self.settings.get('discussion_participants') or []
        if saved_participants:
            for p in saved_participants:
                self.add_discussion_participant_row(model_display=p.get('model'), role=p.get('role'))
        else:
            self.add_discussion_participant_row()
            self.add_discussion_participant_row()

    def switch_tab(self, tab_id):
        """Switch to a different tab"""
        for frame in self.tab_frames.values():
            frame.pack_forget()

        if tab_id in self.tab_frames:
            self.tab_frames[tab_id].pack(fill=tk.BOTH, expand=True)
            self.current_tab = tab_id
            self.update_tab_appearance()

    def update_tab_appearance(self):
        """Update tab button styling"""
        for tab_id, btn in self.tab_buttons.items():
            if tab_id == self.current_tab:
                btn.config(bg=CONFIG['COLORS']['tab_active'], fg=CONFIG['COLORS']['text_white'])
            else:
                btn.config(bg=CONFIG['COLORS']['tab_inactive'], fg=CONFIG['COLORS']['text_primary'])

    def _initialize_log_file(self):
        """Create or append to log file"""
        try:
            with open(self.log_file_path, 'a', encoding='utf-8') as f:
                f.write(f"\n{'='*60}\nSession started: {datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n{'='*60}\n")
        except OSError:
            pass

    def show_file_menu(self):
        """Show File menu"""
        menu = tk.Menu(self.root, tearoff=0)
        menu.add_command(label=CONFIG['TEXT']['btn_settings'], command=self.open_settings)
        menu.add_separator()
        menu.add_command(label=CONFIG['TEXT']['btn_view_log'], command=self.open_log_file)
        menu.add_separator()
        menu.add_command(label=CONFIG['TEXT']['btn_exit'], command=self.exit_app)

        try:
            menu.post(self.root.winfo_x(), self.root.winfo_y() + 50)
        except tk.TclError:
            pass

    def exit_app(self):
        """Clean exit"""
        self.add_log("Application closing", "SYSTEM")
        self.save_settings()
        self.root.quit()

    def edit_cascade_config(self):
        """Open the cascade config in text editor"""
        try:
            script_path = os.path.abspath(__file__)
            if os.name == 'nt':
                # Windows - open with Notepad
                os.system(f'notepad "{script_path}"')
            elif os.uname().sysname == 'Darwin':
                # macOS - open with TextEdit
                os.system(f'open -a TextEdit "{script_path}"')
            else:
                # Linux - open with gedit or nano
                os.system(f'gedit "{script_path}" &')
            self.add_log("Opened config file for editing", "INFO")
        except Exception as e:
            messagebox.showerror(CONFIG['TEXT']['popup_error'],
                                f"Could not open config file:\n{str(e)}")
            self.add_log(f"Error opening config: {str(e)}", "ERROR")

    def load_settings(self):
        """Load settings from file"""
        try:
            if os.path.exists(self.settings_file):
                import json
                with open(self.settings_file, 'r', encoding='utf-8') as f:
                    saved_settings = json.load(f)
                    self.settings.update(saved_settings)
                self.api_base = self.settings['api_base']
        except (OSError, json.JSONDecodeError, KeyError) as e:
            self.add_log(f"Could not load settings, using defaults: {str(e)}", "WARNING")

    def save_settings(self):
        """Save settings to file"""
        try:
            import json
            if hasattr(self, 'discussion_participant_rows'):
                self.settings['discussion_participants'] = self._collect_discussion_participants()
            if hasattr(self, 'research_rule_vars'):
                self.settings['research_rules'] = {k: v.get() for k, v in self.research_rule_vars.items()}
            with open(self.settings_file, 'w', encoding='utf-8') as f:
                json.dump(self.settings, f, indent=2)
            self.add_log("Settings saved", "INFO")
        except Exception as e:
            self.add_log(f"Error saving settings: {str(e)}", "ERROR")

    def open_settings(self):
        """Open settings window"""
        settings_win = tk.Toplevel(self.root)
        settings_win.title(CONFIG['TEXT']['settings_title'])
        w, h = CONFIG['DIMENSIONS']['settings_width'], CONFIG['DIMENSIONS']['settings_height']
        settings_win.geometry(f"{w}x{h}")
        settings_win.resizable(False, False)
        settings_win.grab_set()

        # Center on parent
        self.root.update_idletasks()
        x = self.root.winfo_x() + (self.root.winfo_width() // 2) - (w // 2)
        y = self.root.winfo_y() + (self.root.winfo_height() // 2) - (h // 2)
        settings_win.geometry(f"+{x}+{y}")

        # Note: Settings UI simplified for space - full version has all color picker fields
        # The key improvement is that all TEXT and COLORS/DIMENSIONS reference CONFIG

        messagebox.showinfo(CONFIG['TEXT']['popup_info'],
                           "Settings panel customizable via CONFIG dictionary at top of code.\n"
                           "Edit colors, text, dimensions, and API endpoints there.")
        settings_win.destroy()

    def open_log_file(self):
        """Open log file"""
        if not os.path.exists(self.log_file_path):
            messagebox.showwarning(CONFIG['TEXT']['popup_warning'],
                                  f"{CONFIG['TEXT']['msg_no_log']}\n{self.log_file_path}")
            return

        try:
            if os.name == 'nt':
                os.startfile(self.log_file_path)
            else:
                os.system(f'open "{self.log_file_path}"')
            self.add_log("Opened log file", "INFO")
        except Exception as e:
            messagebox.showerror(CONFIG['TEXT']['popup_error'], f"Could not open log:\n{str(e)}")
            self.add_log(f"Error opening log: {str(e)}", "ERROR")

    def add_log(self, message, log_type="INFO"):
        """Add log message"""
        timestamp = datetime.datetime.now().strftime("%H:%M:%S")
        log_entry = f"[{timestamp}] {log_type}: {message}"
        self.error_log.append(log_entry)

        try:
            with open(self.log_file_path, 'a', encoding='utf-8') as f:
                f.write(log_entry + "\n")
        except OSError:
            pass

        if len(self.error_log) > 1000:
            self.error_log.pop(0)

    def run_startup_checks(self):
        """Run startup checks"""
        splash = LoadingSplash(self.root)
        self.add_log("Starting application...", "SYSTEM")

        def startup_thread():
            self.is_connected = self.check_connection()
            self.refresh_models()
            # splash.close() and deiconify() touch Tkinter widgets — this
            # function runs on a background thread, so marshal them onto
            # the main thread instead of calling them directly.
            def finish_startup():
                splash.close()
                self.root.deiconify()
            self.root.after(0, finish_startup)

        def launch_startup_thread():
            # Do NOT start this thread directly from __init__ (i.e. before
            # root.mainloop() has actually begun running). check_connection()
            # and refresh_models() call self.root.after() from this background
            # thread, and if that fires before Tk's event loop is dispatching
            # — which it can easily be on a slower machine, or if LM Studio is
            # unreachable and the connection attempt returns fast — Tkinter
            # raises "RuntimeError: main thread is not in main loop". That
            # exception is unhandled here, so it kills this thread before it
            # ever reaches finish_startup(): the splash screen never closes
            # and the main window never appears, with only a background
            # thread traceback (no popup, no console error) as any hint why.
            # Scheduling the thread's start via root.after() from the MAIN
            # thread guarantees this callback can't fire until mainloop() is
            # already running and pumping events, so the race can't happen.
            thread = threading.Thread(target=startup_thread, daemon=True)
            thread.start()

        self.root.after(50, launch_startup_thread)

    def update_resolution(self, event=None):
        """Update resolution display"""
        width = self.root.winfo_width()
        height = self.root.winfo_height()
        if width > 1 and height > 1:
            self.resolution_label.config(text=f"{width}x{height}")

    def toggle_window_lock(self):
        """Toggle window lock"""
        self.window_locked = not self.window_locked
        self.root.resizable(not self.window_locked, not self.window_locked)
        self.lock_button.config(text="🔒" if self.window_locked else "🔓")

    def refresh_models(self):
        """Fetch available models. Safe to call from any thread — this method
        itself may run on a background thread (e.g. startup), so all widget
        updates are marshalled onto the main thread via root.after()."""
        try:
            response = requests.get(f"{self.api_base}{CONFIG['API']['models_endpoint']}",
                                   timeout=CONFIG['API']['timeout_models'])
            if response.status_code == 200:
                data = response.json()
                models = data.get("models", [])

                self.model_keys = {}

                llm_models = [m for m in models if m.get("type") == "llm"]

                if llm_models:
                    for idx, model in enumerate(llm_models):
                        key = model.get("key", "unknown")
                        self.model_keys[idx] = key
                    self.root.after(0, lambda: self.lms_count_label.config(text=str(len(llm_models))))
                    self.add_log(f"Loaded {len(llm_models)} models", "INFO")
                else:
                    self.root.after(0, lambda: self.lms_count_label.config(text="0"))
                    self.add_log("No LLM models found", "WARNING")

                self.update_cascade_models()
            else:
                self.root.after(0, lambda: self.lms_count_label.config(text="0"))
                self.add_log(f"Failed to load models: {response.status_code}", "ERROR")
        except Exception as e:
            self.root.after(0, lambda: self.lms_count_label.config(text="0"))
            self.add_log(f"Error fetching models: {str(e)}", "ERROR")

    def on_model_select(self, event):
        """Handle model selection"""
        if self.loading_model:
            return

        idx = self.models_listbox.nearest(event.y)
        if idx >= 0:
            model_key = self.model_keys.get(idx)
            if model_key:
                self.load_model(model_key)

    def load_model(self, model_key):
        """Load a model"""
        if not model_key:
            messagebox.showerror(CONFIG['TEXT']['popup_error'], CONFIG['TEXT']['msg_no_model_identified'])
            self.add_log("Failed to identify model", "ERROR")
            return

        self.loading_model = True

        try:
            response = requests.post(
                f"{self.api_base}{CONFIG['API']['load_model_endpoint']}",
                json={"model": model_key},
                timeout=CONFIG['API']['timeout_load']
            )

            if response.status_code == 200:
                self.current_model = model_key
                self.check_connection()
                messagebox.showinfo(CONFIG['TEXT']['popup_success'], f"Model loaded: {model_key}")
                self.add_log(f"Model loaded: {model_key}", "INFO")
            else:
                messagebox.showerror(CONFIG['TEXT']['popup_error'],
                                    f"{CONFIG['TEXT']['error_failed_load']}{response.status_code}")
                self.add_log(f"Failed to load model: {response.status_code}", "ERROR")
        except Exception as e:
            messagebox.showerror(CONFIG['TEXT']['popup_error'], f"{CONFIG['TEXT']['error_load_model']}\n{str(e)}")
            self.add_log(f"Error loading model: {str(e)}", "ERROR")
        finally:
            self.loading_model = False

    def refresh_script(self):
        """Refresh connection"""
        self.check_connection()
        self.refresh_models()
        self.add_log("Script refreshed", "INFO")

    def restart_script(self):
        """Restart application"""
        if messagebox.askyesno(CONFIG['TEXT']['popup_info'], CONFIG['TEXT']['msg_restart_confirm']):
            self.root.quit()
            subprocess.Popen([sys.executable, sys.argv[0]])
            sys.exit()

    def check_connection(self):
        """Check LM Studio connection. Safe to call from any thread — this
        method itself may run on a background thread (e.g. startup), so all
        widget updates are marshalled onto the main thread via root.after()."""
        try:
            response = requests.get(f"{self.api_base}{CONFIG['API']['models_endpoint']}",
                                   timeout=CONFIG['API']['timeout_connect'])
            self.root.after(0, lambda: self.status_label.config(
                text=CONFIG['TEXT']['status_connected'], foreground=CONFIG['COLORS']['status_online']))
            self.add_log("Connected to LM Studio", "INFO")

            if response.status_code == 200:
                data = response.json()
                models = data.get("models", [])
                llm_models = [m for m in models if m.get("type") == "llm"]
                self.root.after(0, lambda: self.lms_count_label.config(text=str(len(llm_models))))
            return True
        except Exception as e:
            self.root.after(0, lambda: self.status_label.config(
                text=CONFIG['TEXT']['status_disconnected'], foreground=CONFIG['COLORS']['status_offline']))
            self.root.after(0, lambda: self.lms_count_label.config(text="0"))
            self.add_log(f"Lost connection to LM Studio: {str(e)}", "ERROR")
            return False

    def update_system_resources(self):
        """Periodically update system resources"""
        def resource_thread():
            try:
                ram_info = psutil.virtual_memory()
                ram_used = ram_info.used / (1024**3)
                ram_total = ram_info.total / (1024**3)
                ram_percent = ram_info.percent

                vram_used = None
                vram_total = None
                try:
                    import subprocess
                    result = subprocess.run(
                        ['nvidia-smi', '--query-gpu=memory.used,memory.total', '--format=csv,nounits,noheader'],
                        capture_output=True, text=True, timeout=2
                    )
                    if result.returncode == 0:
                        parts = result.stdout.strip().split(',')
                        if len(parts) == 2:
                            vram_used = float(parts[0].strip()) / 1024
                            vram_total = float(parts[1].strip()) / 1024
                except Exception:
                    pass  # nvidia-smi not available — GPU memory stats just won't be shown

                self.root.after(0, self._update_resource_ui, ram_used, ram_total, ram_percent, vram_used, vram_total)
            except Exception as e:
                self.add_log(f"Error getting system resources: {str(e)}", "ERROR")

        thread = threading.Thread(target=resource_thread, daemon=True)
        thread.start()
        self.root.after(2000, self.update_system_resources)

    def _update_resource_ui(self, ram_used, ram_total, ram_percent, vram_used, vram_total):
        """Update resource display"""
        try:
            if ram_used is not None:
                ram_text = f"{ram_used:.1f} GB / {ram_total:.1f} GB ({ram_percent:.0f}%)"
                self.ram_label.config(text=ram_text)

            if vram_used is not None and vram_total is not None:
                vram_percent = (vram_used / vram_total) * 100
                vram_text = f"{vram_used:.1f} GB / {vram_total:.1f} GB ({vram_percent:.0f}%)"
                self.vram_label.config(text=vram_text)

                total_used = vram_used + ram_used
                total_available = vram_total + ram_total
                total_percent = (total_used / total_available) * 100
                total_text = f"{total_used:.1f} GB / {total_available:.1f} GB ({total_percent:.0f}%)"
                self.total_label.config(text=total_text)
            else:
                self.vram_label.config(text="N/A (nvidia-smi not found)")
                if ram_used is not None:
                    total_text = f"{ram_used:.1f} GB / {ram_total:.1f} GB ({ram_percent:.0f}%)"
                    self.total_label.config(text=total_text)
        except Exception as e:
            self.add_log(f"Error updating resource display: {str(e)}", "ERROR")


    def update_cascade_models(self):
        """Update cascade model dropdowns. Safe to call from any thread —
        this method itself may run on a background thread (e.g. startup), so
        all widget updates are marshalled onto the main thread via
        root.after()."""
        try:
            response = requests.get(f"{self.api_base}{CONFIG['API']['models_endpoint']}",
                                   timeout=CONFIG['API']['timeout_models'])
            if response.status_code == 200:
                data = response.json()
                models = data.get("models", [])
                llm_models = [m for m in models if m.get("type") == "llm"]

                model_options = ["None Selected"]
                self.model_display_names = {}

                for model in llm_models:
                    display_name = model.get("display_name", "Unknown")
                    key = model.get("key", "unknown")
                    quantization = model.get("quantization", {}).get("name", "")
                    display_text = f"{display_name} ({quantization})" if quantization else display_name

                    model_options.append(display_text)
                    self.model_display_names[display_text] = key

                def update_dropdowns():
                    for pass_num in range(1, 6):
                        if pass_num in self.cascade_pass_dropdowns:
                            self.cascade_pass_dropdowns[pass_num]['values'] = model_options

                    # Update supervisor dropdown
                    if hasattr(self, 'supervisor_dropdown'):
                        self.supervisor_dropdown['values'] = model_options

                    # Update research dropdown
                    if hasattr(self, 'research_dropdown'):
                        self.research_dropdown['values'] = model_options

                    # Update discussion participant dropdowns
                    if hasattr(self, 'discussion_participant_rows'):
                        for row in self.discussion_participant_rows:
                            row['model_dropdown']['values'] = model_options
                self.root.after(0, update_dropdowns)
        except Exception as e:
            self.add_log(f"Error updating cascade models: {str(e)}", "ERROR")

    def _get_supervisor_rating(self, current_story, pass_num):
        """Get supervisor analysis and rating"""
        supervisor_model = self.supervisor_pass_var.get()
        if supervisor_model == "None Selected":
            return None

        supervisor_model_key = self.model_display_names.get(supervisor_model)
        if not supervisor_model_key:
            self.add_log(f"Supervisor model '{supervisor_model}' not found in available models", "ERROR")
            return None

        supervisor_function = self.supervisor_function_var.get() if hasattr(self, 'supervisor_function_var') else "Default"
        if supervisor_function != "Default" and supervisor_function in CONFIG['CASCADE_FUNCTIONS']:
            rating_template = CONFIG['CASCADE_FUNCTIONS'][supervisor_function]['rating_template']
        else:
            rating_template = CONFIG['CASCADE_PASSES']['SUPERVISOR']['rating_template']

        rating_prompt = rating_template.format(
            story=current_story[:1500]  # Limit context for rating
        )

        try:
            response = requests.post(
                f"{self.api_base}{CONFIG['API']['chat_endpoint']}",
                json={
                    "model": supervisor_model_key,
                    "messages": [{"role": "user", "content": rating_prompt}],
                    "temperature": 0.5,  # Low temp for consistent ratings
                    "max_tokens": 300
                },
                timeout=self.timeout_var.get()
            )

            if response.status_code == 200:
                result = response.json()
                analysis = result['choices'][0]['message']['content']

                # Extract numeric rating from response
                lines = analysis.split('\n')
                rating = None
                for line in lines:
                    if 'Average rating:' in line or 'rating:' in line.lower():
                        # Try to extract the number
                        match = re.search(r'(\d+\.?\d*)\s*/?10', line)
                        if match:
                            rating = float(match.group(1))
                            break

                if rating is None:
                    self.add_log("Could not extract rating from supervisor response", "WARNING")
                    rating = 0

                return {
                    'analysis': analysis,
                    'rating': rating,
                    'model': supervisor_model
                }
        except Exception as e:
            self.add_log(f"Supervisor error: {str(e)}", "ERROR")

        return None

    def _display_supervisor_analysis(self, analysis_data, pass_num=None, pass_role=None):
        """Display the Supervisor's analysis of a pass (or, if pass_num is omitted, the
        finished story) in the Supervisor card's output box."""
        if not analysis_data:
            return

        analysis_text = analysis_data['analysis']
        rating = analysis_data['rating']
        model = analysis_data['model']

        # Update output box
        self.supervisor_output.config(state=tk.NORMAL)
        self.supervisor_output.delete("1.0", tk.END)

        pass_label = f"Pass {pass_num} ({pass_role})" if pass_num is not None else "Final story"
        header = f"{pass_label} — Rated by {model}\n{'─' * 50}\n\n"
        self.supervisor_output.insert(tk.END, header)
        self.supervisor_output.insert(tk.END, analysis_text)
        self.supervisor_output.config(state=tk.DISABLED)

        # Update rating display with color coding
        if rating >= 8.0:
            color = CONFIG['COLORS']['status_online']  # Green
            status = "EXCELLENT"
        elif rating >= 6.0:
            color = CONFIG['COLORS']['button_green']  # Yellow-ish
            status = "GOOD"
        else:
            color = CONFIG['COLORS']['text_error']  # Red
            status = "FLAG"

        self.supervisor_rating_label.config(
            text=f"{pass_label} Rating: {rating:.1f}/10 [{status}]",
            foreground=color
        )

        self.add_log(f"{pass_label} supervisor rating: {rating:.1f}/10", "INFO")

    def _ask_continue_or_retry(self, pass_num, pass_role, analysis_data):
        """Blocks the CASCADE background thread (not the UI) until the user picks Continue or
        Retry in a modal shown on the main thread. A threading.Event hands control back once
        a button is clicked; closing the dialog without choosing defaults to Continue."""
        event = threading.Event()
        choice = {"value": "continue"}

        def show_dialog():
            dlg = tk.Toplevel(self.root)
            dlg.title(f"Pass {pass_num} ({pass_role}) — Continue or Retry?")
            dlg.geometry("520x420")
            dlg.transient(self.root)
            dlg.grab_set()
            dlg.configure(bg=CONFIG['COLORS']['bg_white'])

            self.root.update_idletasks()
            x = self.root.winfo_x() + (self.root.winfo_width() // 2) - 260
            y = self.root.winfo_y() + (self.root.winfo_height() // 2) - 210
            dlg.geometry(f"+{max(x, 0)}+{max(y, 0)}")

            rating = analysis_data['rating']
            model = analysis_data['model']
            if rating >= 8.0:
                color = CONFIG['COLORS']['status_online']
            elif rating >= 6.0:
                color = CONFIG['COLORS']['button_green']
            else:
                color = CONFIG['COLORS']['text_error']

            tk.Label(dlg, text=f"Pass {pass_num} ({pass_role}) — rated by {model}",
                     font=(CONFIG['FONTS']['family_default'], CONFIG['FONTS']['size_normal'], 'bold'),
                     bg=CONFIG['COLORS']['bg_white']).pack(anchor=tk.W, padx=14, pady=(14, 2))
            tk.Label(dlg, text=f"Rating: {rating:.1f}/10",
                     font=(CONFIG['FONTS']['family_default'], CONFIG['FONTS']['size_large'], 'bold'),
                     foreground=color, bg=CONFIG['COLORS']['bg_white']).pack(anchor=tk.W, padx=14, pady=(0, 8))

            text_frame = tk.Frame(dlg, relief=tk.SOLID, bd=1)
            text_frame.pack(fill=tk.BOTH, expand=True, padx=14, pady=(0, 10))
            txt = tk.Text(text_frame, wrap=tk.WORD,
                           font=(CONFIG['FONTS']['family_mono'], CONFIG['FONTS']['size_small']))
            txt.insert("1.0", analysis_data['analysis'])
            txt.config(state=tk.DISABLED)
            txt.pack(fill=tk.BOTH, expand=True)

            btn_row = tk.Frame(dlg, bg=CONFIG['COLORS']['bg_white'])
            btn_row.pack(fill=tk.X, padx=14, pady=(0, 14))

            def pick(value):
                choice["value"] = value
                dlg.destroy()
                event.set()

            tk.Button(btn_row, text="↻ Retry This Pass", command=lambda: pick("retry"),
                      bg=CONFIG['COLORS']['button_red'], fg=CONFIG['COLORS']['text_white'],
                      relief=tk.FLAT, padx=10, pady=6).pack(side=tk.LEFT, padx=(0, 8))
            tk.Button(btn_row, text="▶ Continue", command=lambda: pick("continue"),
                      bg=CONFIG['COLORS']['status_online'], fg=CONFIG['COLORS']['text_white'],
                      relief=tk.FLAT, padx=10, pady=6).pack(side=tk.LEFT)

            dlg.protocol("WM_DELETE_WINDOW", lambda: pick("continue"))

        self.root.after(0, show_dialog)
        event.wait()
        return choice["value"]

    def start_cascade(self):
        """Start cascade refinement"""
        if self.cascade_running:
            messagebox.showwarning(CONFIG['TEXT']['popup_warning'], CONFIG['TEXT']['msg_in_progress'])
            return

        selected_passes = []
        for pass_num in range(1, 6):
            model_display = self.cascade_pass_vars[pass_num].get()
            if model_display != "None Selected":
                model_key = self.model_display_names.get(model_display)
                if model_key:
                    selected_passes.append((pass_num, model_display, model_key))
                else:
                    self.add_log(f"Pass {pass_num} model '{model_display}' not found in available models — skipping", "ERROR")

        if not selected_passes:
            messagebox.showwarning(CONFIG['TEXT']['popup_warning'], CONFIG['TEXT']['msg_no_models_cascade'])
            self.add_log(CONFIG['TEXT']['error_cascade_no_models'], "WARNING")
            return

        story_prompt = self.cascade_input.get("1.0", tk.END).strip()
        if not story_prompt:
            messagebox.showwarning(CONFIG['TEXT']['popup_warning'], CONFIG['TEXT']['msg_empty_prompt'])
            self.add_log(CONFIG['TEXT']['error_cascade_empty'], "WARNING")
            return

        self.cascade_output.config(state=tk.NORMAL)
        self.cascade_output.delete("1.0", tk.END)
        self.cascade_output.config(state=tk.DISABLED)

        self.cascade_running = True
        self.add_log(f"Starting 5-pass cascade with {len(selected_passes)} models", "INFO")

        def _append_output(text):
            """Thread-safe append to cascade output — called from the cascade
            background thread, so the actual widget mutation is marshalled
            onto the main thread via root.after()."""
            def update_widget():
                self.cascade_output.config(state=tk.NORMAL)
                self.cascade_output.insert(tk.END, text)
                self.cascade_output.see(tk.END)
                self.cascade_output.config(state=tk.DISABLED)
            self.root.after(0, update_widget)

        def _set_output(text):
            """Thread-safe replace cascade output — see _append_output."""
            def update_widget():
                self.cascade_output.config(state=tk.NORMAL)
                self.cascade_output.delete("1.0", tk.END)
                self.cascade_output.insert(tk.END, text)
                self.cascade_output.see("1.0")
                self.cascade_output.config(state=tk.DISABLED)
            self.root.after(0, update_widget)

        def _format_validation_report(pass_num, pass_role, validation_result):
            """Format constraint validation results as readable report"""
            lines = []
            lines.append(f"{'─' * 50}")
            lines.append(f"  Constraint Engine — Pass {pass_num} ({pass_role}) Validation")
            lines.append(f"{'─' * 50}")

            total_time = 0
            fixes_applied = 0

            for entry in validation_result.get('log', []):
                name = entry['constraint']
                passed = entry['passed']
                ms = entry.get('duration_ms', 0)
                fixed = entry.get('fixed', False)
                phase = entry.get('phase', 'unknown')
                total_time += ms

                if fixed:
                    fixes_applied += 1
                    icon = "🔧"
                    status = "FIXED"
                elif passed:
                    icon = "✓"
                    status = "passed"
                else:
                    icon = "✗"
                    status = "FAILED"

                phase_tag = "S" if phase == "separate" else "C"
                lines.append(f"  {icon} [{phase_tag}] {name}: {status} ({ms:.2f}ms)")

            # Summary line
            success = validation_result.get('success', False)
            total_constraints = len(validation_result.get('log', []))
            summary_icon = "✓" if success else "✗"
            lines.append(f"{'─' * 50}")
            lines.append(f"  {summary_icon} {total_constraints} constraints checked in {total_time:.2f}ms | {fixes_applied} fixes applied")

            if not success:
                failed_at = validation_result.get('failed_at', 'unknown')
                lines.append(f"  ⚠ HALTED at: {failed_at}")

            lines.append(f"{'─' * 50}\n")
            return "\n".join(lines)

        def cascade_thread():
            try:
                current_story = story_prompt
                total_tokens = 0

                supervisor_enabled = self.supervisor_pass_var.get() != "None Selected"
                supervisor_model_key = None
                if supervisor_enabled:
                    supervisor_model_key = self.model_display_names.get(self.supervisor_pass_var.get())

                # Pre-load every distinct model this run touches — each selected pass's model,
                # plus the Supervisor's — up front. Otherwise, once the Supervisor starts rating
                # after each pass, LM Studio ends up swapping the loaded model back and forth
                # between "whichever pass is next" and "the Supervisor" every single round.
                distinct_keys = []
                for _, _, k in selected_passes:
                    if k not in distinct_keys:
                        distinct_keys.append(k)
                if supervisor_model_key and supervisor_model_key not in distinct_keys:
                    distinct_keys.append(supervisor_model_key)
                if len(distinct_keys) > 1:
                    _append_output(f"⏳ Pre-loading {len(distinct_keys)} model(s) in LM Studio...\n")
                    for k in distinct_keys:
                        self._load_model_silent(k, _append_output)
                    _append_output("\n")

                # Show engine status at start
                if self.engine_loaded and self.engine_enabled_var.get():
                    desc = self.engine.describe()
                    _append_output(f"Constraint Engine: {len(desc['separate'])} separate, {len(desc['collective'])} collective constraints active\n\n")
                elif self.engine_loaded and not self.engine_enabled_var.get():
                    _append_output("⏸ Constraint Engine loaded but disabled — running without validation\n\n")
                else:
                    _append_output("⚠ Constraint Engine not loaded — running without validation\n\n")

                if supervisor_enabled:
                    _append_output(f"👁 Supervisor ({self.supervisor_pass_var.get()}) will review each pass "
                                    f"and ask you to continue or retry it.\n\n")

                idx = 0
                while idx < len(selected_passes):
                    pass_num, model_name, model_key = selected_passes[idx]
                    pass_config = CONFIG['CASCADE_PASSES'].get(pass_num)
                    if not pass_config:
                        error_msg = f"Invalid pass number: {pass_num}"
                        _append_output(f"❌ {error_msg}\n")
                        self.add_log(error_msg, "ERROR")
                        idx += 1
                        continue
                    is_last_pass = (idx == len(selected_passes) - 1)

                    self.current_pass_num = pass_num
                    pre_pass_story = current_story  # snapshot to retry from if you send this pass back

                    # Function override — when a named function is picked for this pass slot
                    # instead of "Default", it replaces both the role label and the prompt template
                    # actually sent, while everything downstream (validation, supervisor, retry) is
                    # unaffected since it just keeps using effective_role/effective_template.
                    pass_function = "Default"
                    if hasattr(self, 'cascade_pass_function_vars') and pass_num in self.cascade_pass_function_vars:
                        pass_function = self.cascade_pass_function_vars[pass_num].get()
                    if pass_function != "Default" and pass_function in CONFIG['CASCADE_FUNCTIONS']:
                        effective_role = pass_function
                        effective_template = CONFIG['CASCADE_FUNCTIONS'][pass_function]['pass_template']
                    else:
                        effective_role = pass_config['role']
                        effective_template = pass_config['prompt_template']

                    # Show pass header
                    _append_output(f"▶ Pass {pass_num} ({effective_role}): {model_name}\n")
                    _append_output(f"  Sending to LM Studio...\n")
                    self.add_log(f"Pass {pass_num}/{len(selected_passes)}: {model_name}", "INFO")

                    refine_prompt = effective_template.format(story=pre_pass_story)

                    response = requests.post(
                        f"{self.api_base}{CONFIG['API']['chat_endpoint']}",
                        json={
                            "model": model_key,
                            "messages": [{"role": "user", "content": refine_prompt}],
                            "temperature": self.cascade_temp_var.get(),
                            "max_tokens": self.cascade_pass_max_tokens[pass_num].get()
                        },
                        timeout=self.timeout_var.get()
                    )

                    if response.status_code != 200:
                        error_msg = f"API Error ({response.status_code}) from {model_name} (Pass {pass_num})"
                        _append_output(f"\n❌ {error_msg}\n")
                        self.add_log(error_msg, "ERROR")
                        break

                    result = response.json()
                    current_story = result['choices'][0]['message']['content']

                    if 'usage' in result:
                        tokens_used = result['usage'].get('total_tokens', 0)
                        total_tokens += tokens_used
                        self.reasoning_tokens = tokens_used
                        self.session_tokens += tokens_used

                    _append_output(f"  ✓ Response received ({len(current_story)} chars)\n")

                    # === CONSTRAINT VALIDATION ===
                    if self.engine_loaded and self.engine and self.engine_enabled_var.get():
                        _append_output(f"  Running constraint validation...\n")

                        validation_result = self.engine.validate(current_story, auto_fix=True)
                        report = _format_validation_report(pass_num, effective_role, validation_result)
                        _append_output(report)

                        # Use the (potentially fixed) data
                        if validation_result.get('success') and 'data' in validation_result:
                            current_story = validation_result['data']

                        # Log validation outcome
                        if validation_result.get('success'):
                            fixes = sum(1 for e in validation_result.get('log', []) if e.get('fixed'))
                            self.add_log(f"Pass {pass_num} validation: PASSED ({fixes} fixes)", "INFO")
                        else:
                            failed = validation_result.get('failed_at', 'unknown')
                            self.add_log(f"Pass {pass_num} validation: FAILED at {failed}", "WARNING")

                    # === SUPERVISOR CHECK — rates THIS pass's output, then you decide ===
                    decision = "continue"
                    if supervisor_enabled and current_story:
                        _append_output(f"\n  ▶ Supervisor check ({self.supervisor_pass_var.get()})...\n")
                        analysis = self._get_supervisor_rating(current_story, pass_num)
                        if analysis:
                            self.root.after(0, self._display_supervisor_analysis, analysis, pass_num, effective_role)
                            _append_output(f"  Supervisor rating: {analysis['rating']:.1f}/10 — awaiting your decision...\n")
                            decision = self._ask_continue_or_retry(pass_num, effective_role, analysis)
                        else:
                            _append_output(f"  ⚠ Supervisor analysis unavailable — continuing automatically\n")
                            self.add_log(f"Pass {pass_num} supervisor analysis unavailable", "WARNING")

                    if decision == "retry":
                        _append_output(f"  ↻ Retrying Pass {pass_num} per your choice...\n\n")
                        self.add_log(f"Pass {pass_num} retried by user after supervisor review", "INFO")
                        current_story = pre_pass_story
                        continue  # re-run this same pass — idx does not advance

                    # Confirmed — show the transition/final-output banner now
                    if not is_last_pass:
                        _append_output(f"  ➜ Feeding validated output to next pass...\n\n")
                    else:
                        _append_output(f"\n{'═' * 50}\n")
                        _append_output(f"  FINAL OUTPUT (Pass {pass_num} — {effective_role})\n")
                        _append_output(f"{'═' * 50}\n\n")
                        _append_output(current_story)

                    idx += 1

                self.root.after(0, lambda: self.reasoning_tokens_label.config(text=str(total_tokens)))
                self.root.after(0, lambda: self.session_tokens_label.config(text=str(self.session_tokens)))
                self.add_log(f"Cascade complete: {total_tokens} total tokens", "INFO")

            except requests.exceptions.RequestException as e:
                error_msg = f"Connection error: {str(e)}"
                _set_output(f"❌ {error_msg}\n")
                self.add_log(error_msg, "ERROR")
            except Exception as e:
                error_msg = f"Error: {str(e)}"
                _set_output(f"❌ {error_msg}\n")
                self.add_log(error_msg, "ERROR")
            finally:
                self.cascade_running = False

        thread = threading.Thread(target=cascade_thread, daemon=True)
        thread.start()

    def clear_cascade(self):
        """Clear cascade"""
        self.cascade_input.delete("1.0", tk.END)
        self.cascade_output.config(state=tk.NORMAL)
        self.cascade_output.delete("1.0", tk.END)
        self.cascade_output.config(state=tk.DISABLED)
        for pass_num in range(1, 6):
            self.cascade_pass_max_tokens[pass_num].set(CONFIG['DEFAULTS']['cascade_pass_tokens'])
        self.add_log("Cascade cleared", "INFO")

    def copy_cascade_output(self):
        """Copy cascade output"""
        text = self.cascade_output.get("1.0", tk.END).strip()
        if not text:
            messagebox.showwarning(CONFIG['TEXT']['popup_warning'], CONFIG['TEXT']['msg_empty_story'])
            return

        self.root.clipboard_clear()
        self.root.clipboard_append(text)
        messagebox.showinfo(CONFIG['TEXT']['popup_info'], CONFIG['TEXT']['msg_copied'])
        self.add_log("Copied cascade output", "INFO")

    def save_cascade_story(self):
        """Save cascade story"""
        text = self.cascade_output.get("1.0", tk.END).strip()
        if not text:
            messagebox.showwarning(CONFIG['TEXT']['popup_warning'], CONFIG['TEXT']['msg_empty_to_save'])
            return

        timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
        filename = f"story_cascade_{timestamp}.txt"
        filepath = os.path.join(os.path.expanduser("~"), "Downloads", filename)

        try:
            with open(filepath, 'w', encoding='utf-8') as f:
                f.write(text)

            messagebox.showinfo(CONFIG['TEXT']['popup_info'], f"Story saved:\n{filename}")
            self.add_log(f"Saved cascade story: {filename}", "INFO")
        except Exception as e:
            messagebox.showerror(CONFIG['TEXT']['popup_error'], f"{CONFIG['TEXT']['error_save_file']}\n{str(e)}")
            self.add_log(f"Error saving story: {str(e)}", "ERROR")

    # ====================================================================
    # RESEARCH MODE — Variant 3: document-grounded infinite research loop
    # ====================================================================

    def _extract_text_from_file(self, filepath):
        """Read a source document. .txt/.md need no dependency; .pdf uses PyPDF2 if available."""
        ext = os.path.splitext(filepath)[1].lower()
        try:
            if ext in ('.txt', '.md'):
                with open(filepath, 'r', encoding='utf-8', errors='ignore') as f:
                    return f.read()
            elif ext == '.pdf':
                try:
                    import PyPDF2
                except ImportError:
                    self.add_log(f"PyPDF2 not installed — skipping PDF: {os.path.basename(filepath)}", "WARNING")
                    return None
                text_parts = []
                with open(filepath, 'rb') as f:
                    reader = PyPDF2.PdfReader(f)
                    for page in reader.pages:
                        text_parts.append(page.extract_text() or "")
                return "\n".join(text_parts)
            return None
        except Exception as e:
            self.add_log(f"Error reading {filepath}: {str(e)}", "ERROR")
            return None

    def _chunk_text(self, text, filename):
        """Split a document into overlapping chunks for round-by-round processing."""
        chunk_size = CONFIG['RESEARCH']['chunk_size']
        overlap = CONFIG['RESEARCH']['chunk_overlap']
        chunks = []
        start = 0
        n = len(text)
        while start < n:
            end = min(start + chunk_size, n)
            piece = text[start:end].strip()
            if piece:
                chunks.append({"source": filename, "text": piece})
            if end == n:
                break
            start = end - overlap
        return chunks

    def _load_document_paths(self, filepaths):
        """Shared loader: extract + chunk a list of file paths, appending to research_chunks"""
        loaded_count = 0
        for fpath in filepaths:
            text = self._extract_text_from_file(fpath)
            if text and text.strip():
                self.research_chunks.extend(self._chunk_text(text, os.path.basename(fpath)))
                loaded_count += 1
        return loaded_count

    def _update_research_folder_label(self):
        """Refresh the 'what's loaded' label next to the Load buttons"""
        total_chunks = len(self.research_chunks)
        if not total_chunks:
            self.research_folder_label.config(text=CONFIG['TEXT']['text_no_folder_loaded'])
        elif self.research_folder:
            self.research_folder_label.config(
                text=f"{os.path.basename(self.research_folder)} ({total_chunks} chunks)"
            )
        else:
            self.research_folder_label.config(text=f"{total_chunks} chunk(s) loaded from individual file(s)")

    def load_research_folder(self):
        """Load and chunk every .txt/.md/.pdf file in a folder as the research source material.
        Replaces whatever was previously loaded (folder or loose files)."""
        folder = filedialog.askdirectory(title="Select Research Source Folder")
        if not folder:
            return

        supported_ext = ('.txt', '.md', '.pdf')
        try:
            files = [os.path.join(folder, f) for f in os.listdir(folder) if f.lower().endswith(supported_ext)]
        except Exception as e:
            messagebox.showerror(CONFIG['TEXT']['popup_error'], f"Could not read folder:\n{str(e)}")
            return

        if not files:
            messagebox.showwarning(CONFIG['TEXT']['popup_warning'], CONFIG['TEXT']['msg_no_files_found'])
            return

        self.research_folder = folder
        self.research_chunks = []
        loaded_count = self._load_document_paths(files)

        self.research_chunk_idx = 0
        self._update_research_folder_label()
        self.add_log(f"Research: loaded {loaded_count} documents, {len(self.research_chunks)} chunks from {folder}", "INFO")

    def load_research_files(self):
        """Load one or more individual .txt/.md/.pdf files — for when there's no folder to point at.
        Adds to whatever's already loaded rather than replacing it."""
        filepaths = filedialog.askopenfilenames(
            title="Select Research Source File(s)",
            filetypes=[
                ("Supported files", "*.txt *.md *.pdf"),
                ("Text files", "*.txt"),
                ("Markdown files", "*.md"),
                ("PDF files", "*.pdf"),
                ("All files", "*.*"),
            ]
        )
        if not filepaths:
            return

        loaded_count = self._load_document_paths(list(filepaths))
        if loaded_count == 0:
            messagebox.showwarning(CONFIG['TEXT']['popup_warning'],
                                   "Could not extract text from the selected file(s).")
            return

        self._update_research_folder_label()
        self.add_log(f"Research: loaded {loaded_count} individual file(s), "
                     f"{len(self.research_chunks)} total chunks", "INFO")

    def start_research(self):
        """Start (or resume into) the research loop on a background thread"""
        if self.research_running:
            messagebox.showwarning(CONFIG['TEXT']['popup_warning'], CONFIG['TEXT']['msg_research_running'])
            return

        source_mode = self._get_research_source_mode()

        if source_mode == 'local' and not self.research_chunks:
            messagebox.showwarning(CONFIG['TEXT']['popup_warning'], CONFIG['TEXT']['msg_no_folder'])
            return

        topic = self.research_topic_var.get().strip()
        if not topic:
            messagebox.showwarning(CONFIG['TEXT']['popup_warning'], CONFIG['TEXT']['msg_no_topic'])
            return

        model_display = self.research_model_var.get()
        if model_display == "None Selected":
            messagebox.showwarning(CONFIG['TEXT']['popup_warning'], CONFIG['TEXT']['msg_no_research_model'])
            return

        model_key = self.model_display_names.get(model_display)
        if not model_key:
            self.add_log(f"Research model '{model_display}' not found in available models", "ERROR")
            messagebox.showwarning(CONFIG['TEXT']['popup_warning'], CONFIG['TEXT']['msg_no_research_model'])
            return

        if source_mode == 'online' and self._get_search_backend() == 'tavily' and not self.research_tavily_key_var.get().strip():
            messagebox.showwarning(CONFIG['TEXT']['popup_warning'], CONFIG['TEXT']['msg_tavily_key_missing'])
            return

        # Persist the current Research card choices right away (also saved again on exit) so a
        # crash mid-run doesn't lose which source/backend/interval was in use.
        self.settings['research_source_mode'] = self.research_source_var.get()
        self.settings['research_search_backend'] = self.research_backend_var.get()
        self.settings['research_tavily_api_key'] = self.research_tavily_key_var.get()
        self.settings['research_compact_interval_label'] = self.research_compact_interval_var.get()

        existing_topic = self.research_knowledge.get("topic", "")
        if existing_topic and existing_topic != topic and self.research_knowledge.get("entries"):
            if not messagebox.askyesno(
                CONFIG['TEXT']['msg_new_topic_title'],
                f"Current knowledge base is for '{existing_topic}'. Starting '{topic}' will replace it "
                f"in memory (already-saved files on disk are unaffected). Continue?"
            ):
                return
            self.research_knowledge = {"topic": topic, "entries": []}
            self.research_round = 0
            self.research_low_novelty_streak = 0
            self.research_chunk_idx = 0
            self.research_knowledge_path = None
            self.research_last_compaction_round = 0
            self.research_visited_urls = set()
            self.research_search_queue = []
        elif not existing_topic:
            self.research_knowledge = {"topic": topic, "entries": []}

        self.research_running = True
        self.research_paused = False
        self.research_stop_requested = False
        self.pause_research_btn.config(text=CONFIG['TEXT']['btn_research_pause'])
        self._update_research_status_display()
        self.add_log(f"Research started: topic='{topic}', source={source_mode}, model={model_display}", "INFO")

        thread = threading.Thread(target=self._research_loop, args=(topic, model_key, source_mode), daemon=True)
        thread.start()

    def _get_research_source_mode(self):
        """Internal code for the current Research Source dropdown selection."""
        return RESEARCH_SOURCE_MODES.get(self.research_source_var.get(), 'local')

    def _get_search_backend(self):
        """Internal code ('duckduckgo'/'tavily') for the current Search Backend dropdown selection."""
        return RESEARCH_SEARCH_BACKENDS.get(self.research_backend_var.get(), 'duckduckgo')

    def _get_compact_interval(self):
        """Rounds between periodic auto-merges, or 0 if Auto-Merge is set to Off. Read fresh each
        time so changing the dropdown mid-run takes effect on the next check without restarting."""
        return RESEARCH_COMPACT_INTERVALS.get(self.research_compact_interval_var.get(), 10)

    def _load_model_silent(self, model_key, log=None):
        """Explicitly ask LM Studio to load a model, without the popup dialogs load_model() shows —
        used to pre-load model(s) up front so LM Studio doesn't lazily load/swap them mid-run."""
        try:
            response = requests.post(
                f"{self.api_base}{CONFIG['API']['load_model_endpoint']}",
                json={"model": model_key},
                timeout=CONFIG['API']['timeout_load']
            )
            if response.status_code == 200:
                self.add_log(f"Model pre-loaded: {model_key}", "INFO")
                if log:
                    log(f"  ✓ Loaded: {model_key}\n")
                return True
            self.add_log(f"Failed to pre-load model {model_key}: {response.status_code}", "WARNING")
            if log:
                log(f"  ⚠ Could not pre-load {model_key} (HTTP {response.status_code}) — "
                    f"it will still load on first use\n")
            return False
        except Exception as e:
            self.add_log(f"Error pre-loading model {model_key}: {str(e)}", "WARNING")
            if log:
                log(f"  ⚠ Could not pre-load {model_key}: {str(e)} — it will still load on first use\n")
            return False

    def pause_research(self):
        """Toggle pause/resume — the loop thread checks this flag between rounds"""
        if not self.research_running:
            return
        self.research_paused = not self.research_paused
        self.pause_research_btn.config(
            text=CONFIG['TEXT']['btn_research_resume'] if self.research_paused else CONFIG['TEXT']['btn_research_pause']
        )
        self.add_log(f"Research {'paused' if self.research_paused else 'resumed'}", "INFO")
        self._update_research_status_display()

    def stop_research(self):
        """Request a clean stop — loop thread exits at the next round boundary"""
        if not self.research_running:
            return
        self.research_stop_requested = True
        self.research_paused = False
        self.add_log("Research stop requested", "INFO")

    def _append_research_output(self, text):
        """Thread-safe append to the research log box — safe to call from
        any thread; the widget mutation always runs on the main thread."""
        def update_widget():
            self.research_output.config(state=tk.NORMAL)
            self.research_output.insert(tk.END, text)
            self.research_output.see(tk.END)
            self.research_output.config(state=tk.DISABLED)
        self.root.after(0, update_widget)

    def _update_research_status_display(self):
        """Refresh the status label in the Research card header"""
        if not hasattr(self, 'research_status_label'):
            return

        entries_count = len(self.research_knowledge.get("entries", []))

        if self.research_running and self.research_paused:
            state_text = CONFIG['TEXT']['status_research_paused']
            color = CONFIG['COLORS']['text_muted']
        elif self.research_running:
            state_text = CONFIG['TEXT']['status_research_running']
            color = CONFIG['COLORS']['status_online']
        else:
            state_text = CONFIG['TEXT']['status_research_stopped']
            color = CONFIG['COLORS']['status_offline']

        self.research_status_label.config(
            text=f"{state_text} — Round {self.research_round} · {entries_count} claims · "
                 f"streak {self.research_low_novelty_streak}",
            foreground=color
        )

    def _parse_claims(self, raw_text, source, round_num):
        """Parse 'CLAIM: ... | CONFIDENCE: ...' lines out of a model response"""
        entries = []
        for line in raw_text.split('\n'):
            line = line.strip()
            if not line.upper().startswith('CLAIM:'):
                continue
            body = line[len('CLAIM:'):].strip()
            if '|' in body:
                claim_part, conf_part = body.split('|', 1)
                claim = claim_part.strip()
                conf_match = re.search(r'(high|medium|low)', conf_part, re.IGNORECASE)
                confidence = conf_match.group(1).lower() if conf_match else "medium"
            else:
                claim = body
                confidence = "medium"
            if claim:
                entries.append({"claim": claim, "confidence": confidence, "source": source, "round": round_num})
        return entries

    def _is_near_duplicate(self, claim_text, existing_entries, threshold=None):
        """Deterministic dedup check — sequence similarity against every existing claim, no API call.
        Catches reworded repeats (e.g. two phrasings of the same senator-vote fact) that a context-window
        summary can miss once older entries have aged out of what the model is shown."""
        if threshold is None:
            threshold = CONFIG['RESEARCH']['dedup_similarity_threshold']
        a = claim_text.lower().strip()
        for e in existing_entries:
            b = e['claim'].lower().strip()
            if difflib.SequenceMatcher(None, a, b).ratio() >= threshold:
                return True
        return False

    # ====================================================================
    # RESEARCH RULES — real verification steps behind the Research card's checkboxes.
    # Each rule is read fresh every round from self.research_rule_vars, so toggling one
    # mid-run changes behavior on the very next round without needing a restart.
    # ====================================================================

    def _research_rule_enabled(self, rule_key):
        var = self.research_rule_vars.get(rule_key)
        return bool(var.get()) if var is not None else False

    def _parse_verdict_list(self, text, negative_word, count):
        """Parse a numbered list of per-claim verdicts like '1. RETRACT' / '2. CONFIRM'.
        Returns a list of `count` booleans (True = keep the claim at that index). Any line
        that can't be parsed, or a response that never arrives, defaults to True — a parsing
        failure or a dropped API call should never silently destroy already-extracted data."""
        keep = [True] * count
        if not text:
            return keep
        for line in text.strip().split('\n'):
            m = re.match(r'\s*(\d+)[\.\):]\s*(.+)', line)
            if not m:
                continue
            idx = int(m.group(1)) - 1
            if 0 <= idx < count and negative_word.upper() in m.group(2).strip().upper():
                keep[idx] = False
        return keep

    def _apply_research_verification_rules(self, new_entries, topic, chunk, model_key, log):
        """Runs whichever Research Rules checkboxes are currently enabled against this round's
        freshly-extracted (and already lexically-deduped) claims, filtering out anything a rule
        rejects. Each rule is its own extra API call with its own prompt/verdict format — this
        is deliberately sequential (not parallel) so later rules see the smaller, already-
        filtered list rather than double-flagging claims an earlier rule already dropped."""
        if not new_entries:
            return new_entries

        is_offline = chunk.get('text') is None
        timeout = self.timeout_var.get()

        def numbered(entries):
            return "\n".join(f"{i + 1}. {e['claim']}" for i, e in enumerate(entries))

        def ask(prompt, max_tokens=300):
            try:
                resp = requests.post(
                    f"{self.api_base}{CONFIG['API']['chat_endpoint']}",
                    json={"model": model_key, "messages": [{"role": "user", "content": prompt}],
                          "temperature": 0.2, "max_tokens": max_tokens},
                    timeout=timeout
                )
                if resp.status_code == 200:
                    result = resp.json()
                    if 'usage' in result:
                        self.session_tokens += result['usage'].get('total_tokens', 0)
                        self.root.after(0, lambda: self.session_tokens_label.config(text=str(self.session_tokens)))
                    return result['choices'][0]['message']['content']
            except requests.exceptions.RequestException as e:
                log(f"  ⚠ Verification call failed ({str(e)}) — skipping this check for this round\n")
            return None

        # --- Double-Check Claims: the model re-confirms each claim it just extracted ---
        if new_entries and self._research_rule_enabled('double_check'):
            rcfg = CONFIG['RESEARCH_RULES']['double_check']
            text = ask(rcfg['verify_template'].format(topic=topic, claims_list=numbered(new_entries)))
            keep = self._parse_verdict_list(text, "RETRACT", len(new_entries))
            kept = [e for e, k in zip(new_entries, keep) if k]
            dropped = len(new_entries) - len(kept)
            if dropped:
                log(f"  ⊘ Double-check: {dropped} claim(s) retracted by the model on review\n")
            new_entries = kept

        # --- Verify Claims vs Source: is each claim actually grounded in the source excerpt? ---
        if new_entries and self._research_rule_enabled('verify_claims'):
            rcfg = CONFIG['RESEARCH_RULES']['verify_claims']
            if is_offline:
                prompt = rcfg['grounding_template_offline'].format(topic=topic, claims_list=numbered(new_entries))
            else:
                source_text = (chunk.get('text') or '')[:3000]
                prompt = rcfg['grounding_template'].format(topic=topic, source_text=source_text,
                                                            claims_list=numbered(new_entries))
            text = ask(prompt)
            keep = self._parse_verdict_list(text, "UNSUPPORTED", len(new_entries))
            kept = [e for e, k in zip(new_entries, keep) if k]
            dropped = len(new_entries) - len(kept)
            if dropped:
                log(f"  ⊘ Verify Claims: {dropped} claim(s) not directly supported by the source — dropped\n")
            new_entries = kept

        # --- Research Offline (self-knowledge check): independent sanity-check against the
        # model's own trained knowledge, without showing it the source at all. Only meaningful
        # when a source actually exists this round — in offline_knowledge mode it's redundant
        # with the round itself, so it's skipped there. ---
        if new_entries and self._research_rule_enabled('research_offline') and not is_offline:
            rcfg = CONFIG['RESEARCH_RULES']['research_offline']
            text = ask(rcfg['selfcheck_template'].format(topic=topic, claims_list=numbered(new_entries)))
            keep = self._parse_verdict_list(text, "QUESTIONABLE", len(new_entries))
            kept = [e for e, k in zip(new_entries, keep) if k]
            dropped = len(new_entries) - len(kept)
            if dropped:
                log(f"  ⊘ Research Offline: {dropped} claim(s) flagged questionable against the "
                    f"model's own knowledge — dropped\n")
            new_entries = kept

        # --- Cross-Check vs Knowledge Base: do any new claims contradict what's already recorded? ---
        if new_entries and self._research_rule_enabled('cross_check'):
            all_entries = self.research_knowledge.get("entries", [])
            if all_entries:
                rcfg = CONFIG['RESEARCH_RULES']['cross_check']
                existing_summary = self._summarize_knowledge_base()
                text = ask(rcfg['crosscheck_template'].format(
                    topic=topic, existing_summary=existing_summary, claims_list=numbered(new_entries)))
                keep = self._parse_verdict_list(text, "CONTRADICTS", len(new_entries))
                kept = [e for e, k in zip(new_entries, keep) if k]
                dropped = len(new_entries) - len(kept)
                if dropped:
                    log(f"  ⊘ Cross-Check: {dropped} claim(s) contradicted the existing knowledge "
                        f"base — dropped\n")
                new_entries = kept

        return new_entries

    def _run_investigate_followup(self, claim_entry, topic, chunk, model_key, log):
        """'Investigate Deeper' rule: asks one follow-up question about the strongest claim
        just recorded this round, extracts any resulting sub-claims the same way a normal
        round does, dedups them against the full knowledge base, and records them directly
        (no separate novelty gate — the model was explicitly asked to go deeper on something
        already judged novel enough to record, so a second novelty check would be redundant)."""
        rcfg = CONFIG['RESEARCH_RULES']['investigate']
        prompt = rcfg['followup_template'].format(topic=topic, claim=claim_entry['claim'])
        try:
            resp = requests.post(
                f"{self.api_base}{CONFIG['API']['chat_endpoint']}",
                json={"model": model_key, "messages": [{"role": "user", "content": prompt}],
                      "temperature": 0.4, "max_tokens": 400},
                timeout=self.timeout_var.get()
            )
        except requests.exceptions.RequestException as e:
            log(f"  ⚠ Investigate: follow-up call failed ({str(e)})\n")
            return

        if resp.status_code != 200:
            return
        result = resp.json()
        if 'usage' in result:
            self.session_tokens += result['usage'].get('total_tokens', 0)
            self.root.after(0, lambda: self.session_tokens_label.config(text=str(self.session_tokens)))

        raw = result['choices'][0]['message']['content'].strip()
        if raw.upper().startswith("NO NEW CLAIMS"):
            return

        source_label = f"{chunk.get('source', 'unknown')} (investigate follow-up)"
        followups = self._parse_claims(raw, source_label, self.research_round)
        if not followups:
            return

        all_entries = self.research_knowledge.get("entries", [])
        before = len(followups)
        followups = [e for e in followups if not self._is_near_duplicate(e['claim'], all_entries)]
        if not followups:
            return

        self.research_knowledge["entries"].extend(followups)
        self._save_knowledge_base()
        log(f"  \U0001f50d Investigate: +{len(followups)} deeper claim(s) on \"{claim_entry['claim'][:60]}"
            f"{'...' if len(claim_entry['claim']) > 60 else ''}\"\n")
        for e in followups:
            log(f"    • {e['claim']} ({e['confidence']})\n")

    def _summarize_knowledge_base(self, max_chars=None):
        """Compact text view of what's already known, fed back to the model to avoid repetition"""
        if max_chars is None:
            max_chars = CONFIG['RESEARCH']['summary_context_chars']
        entries = self.research_knowledge.get("entries", [])
        if not entries:
            return ""
        text = "\n".join(f"- {e['claim']}" for e in entries)
        if len(text) > max_chars:
            text = text[-max_chars:]  # keep the most recently added knowledge in context
        return text

    def _save_knowledge_base(self):
        """Write the structured knowledge base to a JSON file in Downloads"""
        if not self.research_knowledge_path:
            topic_slug = re.sub(r'[^a-zA-Z0-9_-]+', '_', self.research_knowledge.get("topic", "research")).strip('_')[:50]
            timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
            filename = f"research_{topic_slug or 'topic'}_{timestamp}.json"
            self.research_knowledge_path = os.path.join(os.path.expanduser("~"), "Downloads", filename)

        try:
            payload = {
                "topic": self.research_knowledge.get("topic", ""),
                "round": self.research_round,
                "generated": datetime.datetime.now().isoformat(),
                "source_mode": self._get_research_source_mode(),
                "visited_urls": sorted(self.research_visited_urls),
                "entries": self.research_knowledge.get("entries", [])
            }
            with open(self.research_knowledge_path, 'w', encoding='utf-8') as f:
                json.dump(payload, f, indent=2)
        except Exception as e:
            self.add_log(f"Error saving knowledge base: {str(e)}", "ERROR")

    def open_knowledge_file(self):
        """Open the saved knowledge base JSON in the default viewer"""
        if not self.research_knowledge_path or not os.path.exists(self.research_knowledge_path):
            messagebox.showwarning(CONFIG['TEXT']['popup_warning'], CONFIG['TEXT']['msg_no_knowledge_yet'])
            return
        try:
            if os.name == 'nt':
                os.startfile(self.research_knowledge_path)
            else:
                os.system(f'open "{self.research_knowledge_path}"')
            self.add_log("Opened knowledge base file", "INFO")
        except Exception as e:
            messagebox.showerror(CONFIG['TEXT']['popup_error'], f"Could not open file:\n{str(e)}")

    def compact_research_now(self):
        """Manually trigger a compaction pass on demand, outside the automatic schedule.
        Requires the loop to not be actively running (or to be paused) since compaction replaces
        the entries list wholesale — running it concurrently with an active round risks one of the
        two overwriting the other's write to research_knowledge."""
        if not self.research_knowledge.get("entries"):
            messagebox.showwarning(CONFIG['TEXT']['popup_warning'], CONFIG['TEXT']['msg_no_knowledge_yet'])
            return

        if self.research_running and not self.research_paused:
            messagebox.showwarning(CONFIG['TEXT']['popup_warning'], CONFIG['TEXT']['msg_pause_before_compact'])
            return

        if self.research_compacting:
            return  # a manual compaction is already in flight

        model_display = self.research_model_var.get()
        model_key = self.model_display_names.get(model_display)
        if model_display == "None Selected" or not model_key:
            if model_display != "None Selected":
                self.add_log(f"Research model '{model_display}' not found in available models", "ERROR")
            messagebox.showwarning(CONFIG['TEXT']['popup_warning'], CONFIG['TEXT']['msg_no_research_model'])
            return

        topic = self.research_knowledge.get("topic") or self.research_topic_var.get().strip()
        if not topic:
            messagebox.showwarning(CONFIG['TEXT']['popup_warning'], CONFIG['TEXT']['msg_no_topic'])
            return

        entry_count = len(self.research_knowledge.get("entries", []))
        self.research_compacting = True
        self._append_research_output(f"\n🔄 Manual compaction requested ({entry_count} entries)...\n")
        self.add_log(f"Manual compaction requested: {entry_count} entries", "INFO")

        def _run():
            try:
                self._compact_knowledge_base(topic, model_key)
                self.research_last_compaction_round = self.research_round
                new_count = len(self.research_knowledge.get("entries", []))
                self.root.after(0, self._append_research_output,
                                f"  ✓ Manual compaction complete ({new_count} entries after merge)\n")
                self.root.after(0, self._update_research_status_display)
            finally:
                self.research_compacting = False

        thread = threading.Thread(target=_run, daemon=True)
        thread.start()

    def _maybe_compact(self, topic, model_key, log):
        """Run a compaction pass if there's enough to merge and this round hasn't already been
        compacted (the periodic check, the auto-pause point, and the loop-exit point can all land
        on the same round, so this guard stops it running twice for one round's worth of entries)."""
        if len(self.research_knowledge.get("entries", [])) <= 5:
            return
        if self.research_round == self.research_last_compaction_round:
            return

        log(f"\n🔄 Compacting knowledge base ({len(self.research_knowledge['entries'])} entries)...\n")
        self._compact_knowledge_base(topic, model_key)
        log(f"  ✓ Compaction complete ({len(self.research_knowledge['entries'])} entries after merge)\n")
        self.research_last_compaction_round = self.research_round
        self.root.after(0, self._update_research_status_display)

    def _compact_knowledge_base(self, topic, model_key):
        """Periodic cleanup pass: de-duplicate and re-group the accumulated claims"""
        entries = self.research_knowledge.get("entries", [])
        full_text = "\n".join(
            f"CLAIM: {e['claim']} | CONFIDENCE: {e['confidence']} | SOURCE: {e['source']}"
            for e in entries
        )

        prompt = CONFIG['RESEARCH']['compaction_template'].format(topic=topic, full_knowledge=full_text[:6000])

        try:
            response = requests.post(
                f"{self.api_base}{CONFIG['API']['chat_endpoint']}",
                json={
                    "model": model_key,
                    "messages": [{"role": "user", "content": prompt}],
                    "temperature": 0.3,
                    "max_tokens": 2000
                },
                timeout=self.timeout_var.get()
            )
            if response.status_code != 200:
                self.add_log(f"Compaction API error: {response.status_code}", "WARNING")
                return

            compacted_text = response.json()['choices'][0]['message']['content']
            new_entries = []
            for line in compacted_text.split('\n'):
                line = line.strip()
                if not line.upper().startswith('CLAIM:'):
                    continue
                body = line[len('CLAIM:'):].strip()
                parts = body.split('|')
                claim = parts[0].strip()
                confidence, sources = "medium", "unknown"
                for p in parts[1:]:
                    p = p.strip()
                    if p.upper().startswith('CONFIDENCE:'):
                        confidence = p.split(':', 1)[1].strip().lower()
                    elif p.upper().startswith('SOURCES:'):
                        sources = p.split(':', 1)[1].strip()
                if claim:
                    new_entries.append({"claim": claim, "confidence": confidence, "source": sources,
                                        "round": self.research_round})

            if new_entries:
                self.research_knowledge["entries"] = new_entries
                self._save_knowledge_base()
        except Exception as e:
            self.add_log(f"Compaction error: {str(e)}", "ERROR")

    # ---- Web Search (online) mode: search backends + page fetch ----

    def _search_duckduckgo(self, query):
        """Free, no-key search via DuckDuckGo's plain-HTML results page. There's no official API
        for this — it scrapes their lite HTML endpoint, which can break if DuckDuckGo changes its
        markup or rate-limits automated requests. If that happens, switch Search Backend to Tavily
        (or point this function at another provider — it just needs to return a list of
        {"title", "url", "content"} dicts, with "content" left None here since this backend only
        gives a snippet; _fetch_page_text() pulls the real page separately)."""
        try:
            from bs4 import BeautifulSoup
        except ImportError:
            raise RuntimeError("beautifulsoup4 is not installed — run: pip install beautifulsoup4")
        resp = requests.get(
            "https://html.duckduckgo.com/html/",
            params={"q": query},
            headers={"User-Agent": CONFIG['RESEARCH']['web_user_agent']},
            timeout=CONFIG['RESEARCH']['web_fetch_timeout']
        )
        resp.raise_for_status()
        soup = BeautifulSoup(resp.text, "html.parser")
        results = []
        for a in soup.select("a.result__a")[:CONFIG['RESEARCH']['max_web_results']]:
            href = a.get('href', '')
            real_url = href
            # DuckDuckGo's HTML endpoint wraps result links in a redirect: .../l/?uddg=<real-url>
            if 'uddg=' in href:
                parsed = urllib.parse.urlparse(href)
                qs = urllib.parse.parse_qs(parsed.query)
                if 'uddg' in qs:
                    real_url = urllib.parse.unquote(qs['uddg'][0])
            title = a.get_text(strip=True)
            if real_url.startswith('http'):
                results.append({"title": title, "url": real_url, "content": None})
        return results

    def _search_tavily(self, query):
        """Tavily is a search API purpose-built for AI/agent use — one JSON call, and (with
        include_raw_content) it returns already-extracted page text per result, so it's both
        simpler and more reliable than scraping when a key is available."""
        api_key = self.research_tavily_key_var.get().strip()
        if not api_key:
            raise RuntimeError("No Tavily API key set (Research card)")
        resp = requests.post(
            "https://api.tavily.com/search",
            json={
                "api_key": api_key,
                "query": query,
                "max_results": CONFIG['RESEARCH']['max_web_results'],
                "include_raw_content": True,
            },
            timeout=CONFIG['RESEARCH']['web_fetch_timeout']
        )
        resp.raise_for_status()
        data = resp.json()
        results = []
        for r in data.get('results', []):
            results.append({
                "title": r.get('title', ''),
                "url": r.get('url', ''),
                "content": r.get('raw_content') or r.get('content') or None,
            })
        return results

    def _fetch_page_text(self, url, log):
        """Download a page and strip it to visible body text. Only needed for DuckDuckGo-mode
        results — Tavily supplies extracted content itself and skips this."""
        try:
            from bs4 import BeautifulSoup
        except ImportError:
            log("  ❌ beautifulsoup4 is not installed — run: pip install beautifulsoup4\n")
            self.add_log("Web fetch failed: beautifulsoup4 not installed", "ERROR")
            return None
        try:
            resp = requests.get(url, headers={"User-Agent": CONFIG['RESEARCH']['web_user_agent']},
                                 timeout=CONFIG['RESEARCH']['web_fetch_timeout'])
            resp.raise_for_status()
            soup = BeautifulSoup(resp.text, "html.parser")
            for tag in soup(["script", "style", "nav", "footer", "header", "aside", "form", "noscript"]):
                tag.decompose()
            text = soup.get_text(separator="\n")
            lines = [ln.strip() for ln in text.split("\n") if ln.strip()]
            text = "\n".join(lines)
            if len(text) < 200:
                log(f"  — Page had little extractable text, skipping: {url}\n")
                return None
            return text
        except Exception as e:
            log(f"  ❌ Fetch failed for {url}: {str(e)}\n")
            self.add_log(f"Web fetch failed for {url}: {str(e)}", "WARNING")
            return None

    def _build_search_query(self, topic, model_key):
        """First query is just the topic; later queries ask the model for a fresh angle so
        Web Search mode doesn't keep re-fetching the same top results once they're all visited."""
        if not self.research_visited_urls:
            return topic
        existing_summary = self._summarize_knowledge_base(max_chars=2000)
        prompt = CONFIG['RESEARCH']['search_query_template'].format(
            topic=topic, existing_summary=existing_summary if existing_summary else "(none yet)"
        )
        try:
            response = requests.post(
                f"{self.api_base}{CONFIG['API']['chat_endpoint']}",
                json={"model": model_key, "messages": [{"role": "user", "content": prompt}],
                      "temperature": 0.6, "max_tokens": 40},
                timeout=self.timeout_var.get()
            )
            if response.status_code == 200:
                q = response.json()['choices'][0]['message']['content'].strip().strip('"')
                if q:
                    return q[:200]
        except Exception:
            pass
        return topic

    def _get_next_web_chunk(self, topic, model_key, log):
        """Web Search mode: pop the next unvisited search result, get its page text, and return
        it as a chunk dict compatible with the document-grounded pipeline. Returns None when the
        caller should just sleep briefly and retry (search failed, no results, or a fetch failed)."""
        backend = self._get_search_backend()

        if not self.research_search_queue:
            query = self._build_search_query(topic, model_key)
            log(f"  🔎 Searching ({'Tavily' if backend == 'tavily' else 'DuckDuckGo'}): {query}\n")
            try:
                results = self._search_tavily(query) if backend == 'tavily' else self._search_duckduckgo(query)
            except Exception as e:
                log(f"  ❌ Search failed: {str(e)}\n")
                self.add_log(f"Web search failed: {str(e)}", "ERROR")
                return None
            fresh = [r for r in results if r['url'] not in self.research_visited_urls]
            if not fresh:
                log("  — No new (unvisited) results for that query; will try a fresh query next round\n")
                return None
            self.research_search_queue = fresh

        result = self.research_search_queue.pop(0)
        self.research_visited_urls.add(result['url'])

        if backend == 'tavily' and result.get('content'):
            text = result['content']
        else:
            text = self._fetch_page_text(result['url'], log)
            if not text:
                return None

        text = text[:CONFIG['RESEARCH']['web_fetch_max_chars']]
        log(f"  🌐 {result.get('title') or result['url']}\n     {result['url']}\n")
        return {"source": result['url'], "text": text}

    def _research_loop(self, topic, model_key, source_mode):
        """Background thread: research -> validate -> score novelty -> record, round after round.
        source_mode is 'local' (cycle loaded document chunks), 'offline_knowledge' (self-directed —
        the model's own trained knowledge, no documents or internet), or 'online' (live web search
        + page fetch each round)."""
        rcfg = CONFIG['RESEARCH']
        novelty_threshold = rcfg['novelty_threshold']
        low_novelty_stop = rcfg['low_novelty_stop_streak']

        def log(text):
            self.root.after(0, self._append_research_output, text)

        try:
            log(f"\n⏳ Pre-loading research model in LM Studio...\n")
            self._load_model_silent(model_key, log)

            while not self.research_stop_requested:
                while self.research_paused and not self.research_stop_requested:
                    time.sleep(0.5)
                if self.research_stop_requested:
                    break

                if source_mode == 'local':
                    if self.research_chunk_idx >= len(self.research_chunks):
                        self.research_chunk_idx = 0  # loop back through the source material
                        if self.research_round > 0:
                            log(f"\n↻ Completed a full pass over the loaded source material — "
                                f"starting again from the top\n")
                    chunk = self.research_chunks[self.research_chunk_idx]
                elif source_mode == 'offline_knowledge':
                    chunk = {"source": "model's own knowledge", "text": None}
                else:  # online
                    chunk = self._get_next_web_chunk(topic, model_key, log)
                    if chunk is None:
                        if self.research_stop_requested:
                            break
                        time.sleep(2)
                        continue

                self.research_round += 1

                if source_mode == 'local':
                    log(f"\n▶ Round {self.research_round} — source: {chunk['source']} "
                        f"(chunk {self.research_chunk_idx + 1}/{len(self.research_chunks)})\n")
                else:
                    log(f"\n▶ Round {self.research_round} — source: {chunk['source']}\n")

                existing_summary = self._summarize_knowledge_base()

                if chunk['text'] is None:
                    research_prompt = rcfg['self_research_template'].format(
                        topic=topic,
                        existing_summary=existing_summary if existing_summary else "(none yet)"
                    )
                else:
                    research_prompt = rcfg['research_template'].format(
                        topic=topic, source=chunk['source'], chunk=chunk['text'],
                        existing_summary=existing_summary if existing_summary else "(none yet)"
                    )

                response = requests.post(
                    f"{self.api_base}{CONFIG['API']['chat_endpoint']}",
                    json={
                        "model": model_key,
                        "messages": [{"role": "user", "content": research_prompt}],
                        "temperature": 0.4,
                        "max_tokens": 600
                    },
                    timeout=self.timeout_var.get()
                )

                if response.status_code != 200:
                    log(f"  ❌ API error {response.status_code} — skipping\n")
                    self.add_log(f"Research API error: {response.status_code}", "ERROR")
                    if source_mode == 'local':
                        self.research_chunk_idx += 1
                    time.sleep(1)
                    continue

                result = response.json()
                raw_claims = result['choices'][0]['message']['content'].strip()

                if 'usage' in result:
                    tokens_used = result['usage'].get('total_tokens', 0)
                    self.session_tokens += tokens_used
                    self.root.after(0, lambda: self.session_tokens_label.config(text=str(self.session_tokens)))

                novelty_score = 0
                new_entries = []

                if raw_claims.upper().startswith("NO NEW CLAIMS"):
                    log("  — No new claims found in this excerpt\n")
                else:
                    new_entries = self._parse_claims(raw_claims, chunk['source'], self.research_round)

                    # Run the same Constraint Engine used by the cascade over the raw claim text
                    if new_entries and self.engine_loaded and self.engine and self.engine_enabled_var.get():
                        validation_result = self.engine.validate(raw_claims, auto_fix=True)
                        if not validation_result.get('success'):
                            log(f"  ⚠ Constraint validation failed at {validation_result.get('failed_at')} "
                                f"— discarding round\n")
                            new_entries = []

                    # Deterministic dedup filter — catches reworded repeats of existing claims before
                    # spending an API call on novelty scoring. This runs against the FULL entry list,
                    # not the truncated "existing_summary" text, so it can't miss claims that aged out
                    # of what the model was shown.
                    if new_entries:
                        all_entries = self.research_knowledge.get("entries", [])
                        before_count = len(new_entries)
                        # "Verify Duplicates" rule tightens this same lexical filter rather than
                        # adding a separate pass — a stricter threshold catches more paraphrased
                        # near-duplicates at zero extra API cost.
                        dedup_threshold = (CONFIG['RESEARCH_RULES']['verify_duplicates']['strict_threshold']
                                          if self._research_rule_enabled('verify_duplicates') else None)
                        new_entries = [e for e in new_entries
                                      if not self._is_near_duplicate(e['claim'], all_entries, threshold=dedup_threshold)]
                        skipped = before_count - len(new_entries)
                        if skipped:
                            log(f"  ⊘ {skipped} claim(s) filtered as near-duplicates of existing knowledge\n")

                    # Research Rules — opt-in checkboxes on the card, each a real extra
                    # verification step (double-check, verify-vs-source, self-knowledge check,
                    # cross-check vs knowledge base). No-ops for any rule left unchecked.
                    if new_entries:
                        new_entries = self._apply_research_verification_rules(new_entries, topic, chunk, model_key, log)

                    if new_entries:
                        log(f"  + {len(new_entries)} new claim(s) extracted\n")
                        for e in new_entries:
                            log(f"    • {e['claim']} ({e['confidence']})\n")

                        claims_text = "\n".join(f"- {e['claim']}" for e in new_entries)
                        novelty_prompt = rcfg['novelty_template'].format(
                            topic=topic,
                            existing_summary=existing_summary if existing_summary else "(none yet)",
                            new_claims=claims_text
                        )
                        nov_response = requests.post(
                            f"{self.api_base}{CONFIG['API']['chat_endpoint']}",
                            json={
                                "model": model_key,
                                "messages": [{"role": "user", "content": novelty_prompt}],
                                "temperature": 0.3,
                                "max_tokens": 150
                            },
                            timeout=self.timeout_var.get()
                        )
                        novelty_score = 5  # default if the score can't be parsed out
                        if nov_response.status_code == 200:
                            nov_text = nov_response.json()['choices'][0]['message']['content']
                            match = re.search(r'NOVELTY:\s*(\d+)', nov_text, re.IGNORECASE)
                            if match:
                                novelty_score = int(match.group(1))

                        log(f"  Novelty score: {novelty_score}/10\n")

                        if novelty_score >= novelty_threshold:
                            self.research_knowledge["entries"].extend(new_entries)
                            self._save_knowledge_base()

                            # "Investigate Deeper" rule: one extra follow-up question on this
                            # round's strongest claim, digging for more specific sub-claims.
                            if self._research_rule_enabled('investigate'):
                                confidence_rank = {'high': 2, 'medium': 1, 'low': 0}
                                strongest = max(new_entries, key=lambda e: confidence_rank.get(e['confidence'], 0))
                                self._run_investigate_followup(strongest, topic, chunk, model_key, log)
                        else:
                            log("  (below novelty threshold — not recorded)\n")

                if novelty_score < novelty_threshold:
                    self.research_low_novelty_streak += 1
                else:
                    self.research_low_novelty_streak = 0

                self.root.after(0, self._update_research_status_display)

                if self.research_low_novelty_streak >= low_novelty_stop:
                    log(f"\n⏸ {low_novelty_stop} consecutive low-novelty rounds — auto-pausing "
                        f"(topic may be exhausted for this source material)\n")
                    self.add_log("Research auto-paused: topic likely exhausted", "INFO")
                    self.research_paused = True
                    self.research_low_novelty_streak = 0
                    self.root.after(0, lambda: self.pause_research_btn.config(
                        text=CONFIG['TEXT']['btn_research_resume']))
                    self.root.after(0, self._update_research_status_display)
                    # A short run (e.g. one small document) may never reach the periodic compaction
                    # interval below before pausing — make sure at least one cleanup pass happens here
                    # too, since paraphrase-level duplicates need the model's full-context judgment,
                    # not the lexical dedup filter, to catch.
                    self._maybe_compact(topic, model_key, log)

                # Re-read the Auto-Merge dropdown each round so changing it mid-run takes effect
                # immediately rather than needing a restart.
                compact_every = self._get_compact_interval()
                if compact_every > 0 and self.research_round % compact_every == 0 and len(self.research_knowledge["entries"]) > 5:
                    self._maybe_compact(topic, model_key, log)

                self.add_log(f"Research round {self.research_round} complete: novelty={novelty_score}", "INFO")
                if source_mode == 'local':
                    self.research_chunk_idx += 1
                time.sleep(0.3)  # brief pacing between rounds

            # Same reasoning as the auto-pause case: a run that's stopped manually before ever hitting
            # the periodic interval or the low-novelty streak still deserves one cleanup pass.
            self._maybe_compact(topic, model_key, log)

            log(f"\n■ Research stopped at round {self.research_round} "
                f"({len(self.research_knowledge.get('entries', []))} total claims saved)\n")
            self.add_log(f"Research stopped: {len(self.research_knowledge.get('entries', []))} total entries", "INFO")

        except requests.exceptions.RequestException as e:
            log(f"\n❌ Connection error: {str(e)}\n")
            self.add_log(f"Research connection error: {str(e)}", "ERROR")
        except Exception as e:
            log(f"\n❌ Error: {str(e)}\n")
            self.add_log(f"Research error: {str(e)}", "ERROR")
        finally:
            self.research_running = False
            self.root.after(0, self._update_research_status_display)

    # ====================================================================
    # DISCUSSION MODE — multi-model roundtable with shared, compacted transcript
    # ====================================================================

    def add_discussion_participant_row(self, model_display=None, role=None):
        """Add one participant row (model dropdown + role dropdown + remove button) to the
        Discussion card. Called for the two seed rows on first build, once per saved participant
        when restoring from settings, and on every '+ Add Participant' click."""
        model_options = ["None Selected"] + list(self.model_display_names.keys())
        role_options = list(CONFIG['DISCUSSION_ROLES'].keys())

        row_frame = tk.Frame(self.discussion_participants_frame, bg=CONFIG['COLORS']['bg_white'])
        row_frame.pack(fill=tk.X, pady=(0, 6))

        model_var = tk.StringVar(value=model_display if model_display in model_options else "None Selected")
        model_dropdown = ttk.Combobox(row_frame, textvariable=model_var, state="readonly",
                                       values=model_options, width=CONFIG['DEFAULTS']['model_display_width'])
        model_dropdown.pack(side=tk.LEFT, padx=(0, 6))

        role_var = tk.StringVar(value=role if role in role_options else (role_options[0] if role_options else ""))
        ttk.Combobox(row_frame, textvariable=role_var, state="readonly",
                    values=role_options, width=16).pack(side=tk.LEFT, padx=(0, 6))

        row = {"frame": row_frame, "model_var": model_var, "role_var": role_var, "model_dropdown": model_dropdown}

        remove_btn = tk.Button(
            row_frame, text=CONFIG['TEXT']['btn_remove_participant'],
            command=lambda: self.remove_discussion_participant_row(row),
            bg=CONFIG['COLORS']['button_red'], fg=CONFIG['COLORS']['text_white'],
            font=(CONFIG['FONTS']['family_default'], CONFIG['FONTS']['size_small']),
            relief=tk.FLAT, padx=8, pady=2
        )
        remove_btn.pack(side=tk.LEFT)

        self.discussion_participant_rows.append(row)
        return row

    def remove_discussion_participant_row(self, row):
        """Remove one participant row. Refuses to drop below 1 row left in the UI — start_discussion
        separately enforces at least 2 with valid models/roles before a run can begin."""
        if row not in self.discussion_participant_rows:
            return
        if len(self.discussion_participant_rows) <= 1:
            return
        row["frame"].destroy()
        self.discussion_participant_rows.remove(row)

    def _collect_discussion_participants(self):
        """Current participant rows as plain dicts — used both for settings persistence and to
        resolve who's actually speaking when a run starts."""
        return [{"model": row["model_var"].get(), "role": row["role_var"].get()}
                for row in self.discussion_participant_rows]

    def _get_discussion_compact_interval(self):
        """Rounds between periodic auto-merges, or 0 if Auto-Merge is set to Off. Read fresh each
        time so changing the dropdown mid-run takes effect on the next check without restarting."""
        return DISCUSSION_COMPACT_INTERVALS.get(self.discussion_compact_interval_var.get(), 10)

    def start_discussion(self):
        """Start (or resume into) the discussion loop on a background thread"""
        if self.discussion_running:
            messagebox.showwarning(CONFIG['TEXT']['popup_warning'], CONFIG['TEXT']['msg_discussion_running'])
            return

        topic = self.discussion_topic_var.get().strip()
        if not topic:
            messagebox.showwarning(CONFIG['TEXT']['popup_warning'], CONFIG['TEXT']['msg_no_discussion_topic'])
            return

        participants = []
        for entry in self._collect_discussion_participants():
            model_display = entry["model"]
            role = entry["role"]
            if model_display == "None Selected" or not role:
                continue
            model_key = self.model_display_names.get(model_display)
            if not model_key:
                self.add_log(f"Discussion participant model '{model_display}' not found in available models — skipping", "ERROR")
                continue
            participants.append({"model_display": model_display, "model_key": model_key, "role": role})

        if len(participants) < 2:
            messagebox.showwarning(CONFIG['TEXT']['popup_warning'], CONFIG['TEXT']['msg_discussion_too_few'])
            return

        # Persist the current Discussion card choices right away (also saved again on exit).
        self.settings['discussion_compact_interval_label'] = self.discussion_compact_interval_var.get()
        self.settings['discussion_participants'] = self._collect_discussion_participants()

        if self.discussion_topic and self.discussion_topic != topic and self.discussion_transcript:
            if not messagebox.askyesno(
                CONFIG['TEXT']['msg_new_topic_title'],
                f"Current transcript is for '{self.discussion_topic}'. Starting '{topic}' will replace it "
                f"in memory (already-saved files on disk are unaffected). Continue?"
            ):
                return
            self.discussion_transcript = []
            self.discussion_summary = ""
            self.discussion_round = 0
            self.discussion_stall_streak = 0
            self.discussion_last_compaction_round = 0
            self.discussion_transcript_path = None

        self.discussion_topic = topic
        self.discussion_running = True
        self.discussion_paused = False
        self.discussion_stop_requested = False
        self.pause_discussion_btn.config(text=CONFIG['TEXT']['btn_discussion_pause'])
        self._update_discussion_status_display()
        self.add_log(f"Discussion started: topic='{topic}', {len(participants)} participants", "INFO")

        thread = threading.Thread(target=self._discussion_loop, args=(topic, participants), daemon=True)
        thread.start()

    def pause_discussion(self):
        """Toggle pause/resume — the loop thread checks this flag between turns"""
        if not self.discussion_running:
            return
        self.discussion_paused = not self.discussion_paused
        self.pause_discussion_btn.config(
            text=CONFIG['TEXT']['btn_discussion_resume'] if self.discussion_paused else CONFIG['TEXT']['btn_discussion_pause']
        )
        self.add_log(f"Discussion {'paused' if self.discussion_paused else 'resumed'}", "INFO")
        self._update_discussion_status_display()

    def stop_discussion(self):
        """Request a clean stop — loop thread exits at the next turn boundary"""
        if not self.discussion_running:
            return
        self.discussion_stop_requested = True
        self.discussion_paused = False
        self.add_log("Discussion stop requested", "INFO")

    def _append_discussion_output(self, text):
        """Thread-safe append to the discussion log box — safe to call from
        any thread; the widget mutation always runs on the main thread."""
        def update_widget():
            self.discussion_output.config(state=tk.NORMAL)
            self.discussion_output.insert(tk.END, text)
            self.discussion_output.see(tk.END)
            self.discussion_output.config(state=tk.DISABLED)
        self.root.after(0, update_widget)

    def _update_discussion_status_display(self):
        """Refresh the status label in the Discussion card header"""
        if not hasattr(self, 'discussion_status_label'):
            return

        turns_count = len(self.discussion_transcript)

        if self.discussion_running and self.discussion_paused:
            state_text = CONFIG['TEXT']['status_discussion_paused']
            color = CONFIG['COLORS']['text_muted']
        elif self.discussion_running:
            state_text = CONFIG['TEXT']['status_discussion_running']
            color = CONFIG['COLORS']['status_online']
        else:
            state_text = CONFIG['TEXT']['status_discussion_stopped']
            color = CONFIG['COLORS']['status_offline']

        self.discussion_status_label.config(
            text=f"{state_text} — Round {self.discussion_round} · {turns_count} turns · "
                 f"streak {self.discussion_stall_streak}",
            foreground=color
        )

    def _text_is_near_duplicate(self, text, existing_texts, threshold=None):
        """Same deterministic dedup approach as Research's _is_near_duplicate, generalized to a
        plain list of strings (a participant's turn text) instead of {'claim': ...} dicts — used
        here as the stall detector: repeated near-identical turns mean the discussion has nothing
        left to say."""
        if threshold is None:
            threshold = CONFIG['DISCUSSION']['dedup_similarity_threshold']
        a = text.lower().strip()
        for b_raw in existing_texts:
            b = b_raw.lower().strip()
            if difflib.SequenceMatcher(None, a, b).ratio() >= threshold:
                return True
        return False

    def _recent_turns_text(self, n=None):
        """Plain-text rendering of the last n raw turns, each attributed to its speaker/role."""
        if n is None:
            n = CONFIG['DISCUSSION']['recent_turns_shown']
        recent = self.discussion_transcript[-n:] if n > 0 else []
        return "\n\n".join(f"[{t['role']} — {t['speaker']}]: {t['text']}" for t in recent)

    def _summarize_discussion(self, max_chars=None):
        """Compact context view fed to each speaker: the condensed summary of everything
        compaction has folded in, followed by the most recent raw turns in full."""
        if max_chars is None:
            max_chars = CONFIG['DISCUSSION']['summary_context_chars']
        parts = []
        if self.discussion_summary:
            summary = self.discussion_summary
            if len(summary) > max_chars:
                summary = summary[-max_chars:]
            parts.append(f"[Summary of earlier discussion]\n{summary}")
        recent = self._recent_turns_text()
        if recent:
            parts.append(recent)
        return "\n\n".join(parts) if parts else "(nothing said yet — you are opening the discussion)"

    def _save_discussion_transcript(self):
        """Write the full raw transcript (plus the condensed summary) to a JSON file in Downloads"""
        if not self.discussion_transcript_path:
            topic_slug = re.sub(r'[^a-zA-Z0-9_-]+', '_', self.discussion_topic or "discussion").strip('_')[:50]
            timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
            filename = f"discussion_{topic_slug or 'topic'}_{timestamp}.json"
            self.discussion_transcript_path = os.path.join(os.path.expanduser("~"), "Downloads", filename)

        try:
            payload = {
                "topic": self.discussion_topic,
                "round": self.discussion_round,
                "generated": datetime.datetime.now().isoformat(),
                "summary": self.discussion_summary,
                "transcript": self.discussion_transcript,
            }
            with open(self.discussion_transcript_path, 'w', encoding='utf-8') as f:
                json.dump(payload, f, indent=2)
        except Exception as e:
            self.add_log(f"Error saving discussion transcript: {str(e)}", "ERROR")

    def open_discussion_transcript(self):
        """Open the saved transcript JSON in the default viewer"""
        if not self.discussion_transcript_path or not os.path.exists(self.discussion_transcript_path):
            messagebox.showwarning(CONFIG['TEXT']['popup_warning'], CONFIG['TEXT']['msg_no_transcript_yet'])
            return
        try:
            if os.name == 'nt':
                os.startfile(self.discussion_transcript_path)
            else:
                os.system(f'open "{self.discussion_transcript_path}"')
            self.add_log("Opened discussion transcript file", "INFO")
        except Exception as e:
            messagebox.showerror(CONFIG['TEXT']['popup_error'], f"Could not open file:\n{str(e)}")

    def compact_discussion_now(self):
        """Manually trigger a compaction pass on demand, outside the automatic schedule. Requires
        the loop to not be actively running (or to be paused), same reasoning as Research's manual
        compaction — it replaces discussion_summary wholesale."""
        if not self.discussion_transcript:
            messagebox.showwarning(CONFIG['TEXT']['popup_warning'], CONFIG['TEXT']['msg_no_transcript_yet'])
            return

        if self.discussion_running and not self.discussion_paused:
            messagebox.showwarning(CONFIG['TEXT']['popup_warning'], CONFIG['TEXT']['msg_pause_before_compact_discussion'])
            return

        if self.discussion_compacting:
            return  # a manual compaction is already in flight

        # Use whichever participant model is first configured as a stand-in compactor model —
        # compaction doesn't need a dedicated role, just any capable model already in play.
        participants = [p for p in self._collect_discussion_participants() if p["model"] != "None Selected"]
        if not participants:
            messagebox.showwarning(CONFIG['TEXT']['popup_warning'], CONFIG['TEXT']['msg_discussion_too_few'])
            return
        model_key = self.model_display_names.get(participants[0]["model"])
        if not model_key:
            self.add_log(f"Discussion compaction model '{participants[0]['model']}' not found", "ERROR")
            return

        topic = self.discussion_topic or self.discussion_topic_var.get().strip()
        if not topic:
            messagebox.showwarning(CONFIG['TEXT']['popup_warning'], CONFIG['TEXT']['msg_no_discussion_topic'])
            return

        turn_count = len(self.discussion_transcript)
        self.discussion_compacting = True
        self._append_discussion_output(f"\n🔄 Manual compaction requested ({turn_count} turns)...\n")
        self.add_log(f"Manual discussion compaction requested: {turn_count} turns", "INFO")

        def _run():
            try:
                self._compact_discussion_transcript(topic, model_key)
                self.discussion_last_compaction_round = self.discussion_round
                self.root.after(0, self._append_discussion_output, "  ✓ Manual compaction complete\n")
                self.root.after(0, self._update_discussion_status_display)
            finally:
                self.discussion_compacting = False

        thread = threading.Thread(target=_run, daemon=True)
        thread.start()

    def _maybe_compact_discussion(self, topic, model_key, log):
        """Run a compaction pass if there's enough to condense and this round hasn't already been
        compacted (same double-compaction guard as Research's _maybe_compact)."""
        if len(self.discussion_transcript) <= CONFIG['DISCUSSION']['recent_turns_shown']:
            return  # nothing sits outside the raw recent-turns window yet — nothing to fold in
        if self.discussion_round == self.discussion_last_compaction_round:
            return

        log(f"\n🔄 Compacting discussion transcript ({len(self.discussion_transcript)} turns)...\n")
        self._compact_discussion_transcript(topic, model_key)
        log("  ✓ Compaction complete\n")
        self.discussion_last_compaction_round = self.discussion_round
        self.root.after(0, self._update_discussion_status_display)

    def _compact_discussion_transcript(self, topic, model_key):
        """Periodic cleanup pass: fold everything except the most recent raw turns into
        discussion_summary, so later speakers get a bounded-size context no matter how long the
        discussion runs."""
        older_turns = self.discussion_transcript[:-CONFIG['DISCUSSION']['recent_turns_shown']] \
            if CONFIG['DISCUSSION']['recent_turns_shown'] > 0 else self.discussion_transcript
        if not older_turns and not self.discussion_summary:
            return

        older_text = "\n\n".join(f"[{t['role']} — {t['speaker']}]: {t['text']}" for t in older_turns)
        full_text = (f"[Summary of earlier discussion]\n{self.discussion_summary}\n\n{older_text}"
                     if self.discussion_summary else older_text)

        prompt = CONFIG['DISCUSSION']['compaction_template'].format(topic=topic, full_transcript=full_text[:8000])

        try:
            response = requests.post(
                f"{self.api_base}{CONFIG['API']['chat_endpoint']}",
                json={
                    "model": model_key,
                    "messages": [{"role": "user", "content": prompt}],
                    "temperature": 0.3,
                    "max_tokens": 1500
                },
                timeout=self.timeout_var.get()
            )
            if response.status_code != 200:
                self.add_log(f"Discussion compaction API error: {response.status_code}", "WARNING")
                return

            self.discussion_summary = response.json()['choices'][0]['message']['content'].strip()
            self._save_discussion_transcript()
        except Exception as e:
            self.add_log(f"Discussion compaction error: {str(e)}", "ERROR")

    def _get_moderator_synthesis(self, topic, model_key, log):
        """Ask a model to produce the Moderator's closing synthesis over the full discussion.
        Uses DISCUSSION_ROLES['Moderator']['synthesis_template'] — falls back quietly if that
        role's template is ever removed from CONFIG."""
        moderator_cfg = CONFIG['DISCUSSION_ROLES'].get('Moderator', {})
        synthesis_template = moderator_cfg.get('synthesis_template')
        if not synthesis_template:
            return None

        full_transcript = self._summarize_discussion(max_chars=CONFIG['DISCUSSION']['summary_context_chars'] * 2)
        prompt = synthesis_template.format(topic=topic, transcript=full_transcript)

        try:
            response = requests.post(
                f"{self.api_base}{CONFIG['API']['chat_endpoint']}",
                json={
                    "model": model_key,
                    "messages": [{"role": "user", "content": prompt}],
                    "temperature": 0.4,
                    "max_tokens": CONFIG['DISCUSSION']['moderator_max_tokens']
                },
                timeout=self.timeout_var.get()
            )
            if response.status_code != 200:
                log(f"  ❌ Moderator synthesis API error: {response.status_code}\n")
                self.add_log(f"Moderator synthesis API error: {response.status_code}", "ERROR")
                return None
            return response.json()['choices'][0]['message']['content'].strip()
        except Exception as e:
            log(f"  ❌ Moderator synthesis error: {str(e)}\n")
            self.add_log(f"Moderator synthesis error: {str(e)}", "ERROR")
            return None

    def _discussion_loop(self, topic, participants):
        """Background thread: participants take turns round-robin, each responding to the
        compacted-context + recent-raw-turns view of the discussion so far. Mirrors Research's
        pre-load / dedup / compact / auto-pause pattern, but N speakers instead of one model."""
        dcfg = CONFIG['DISCUSSION']
        stall_threshold = dcfg['stall_threshold']

        def log(text):
            self.root.after(0, self._append_discussion_output, text)

        try:
            distinct_keys = []
            for p in participants:
                if p["model_key"] not in distinct_keys:
                    distinct_keys.append(p["model_key"])
            log(f"\n⏳ Pre-loading {len(distinct_keys)} model(s) in LM Studio...\n")
            for k in distinct_keys:
                self._load_model_silent(k, log)
            participant_desc = ", ".join(f"{p['role']} ({p['model_display']})" for p in participants)
            log(f"\n▶ Discussion started — {len(participants)} participants: {participant_desc}\n")

            speaker_idx = 0
            while not self.discussion_stop_requested:
                while self.discussion_paused and not self.discussion_stop_requested:
                    time.sleep(0.5)
                if self.discussion_stop_requested:
                    break

                speaker = participants[speaker_idx % len(participants)]
                speaker_idx += 1
                self.discussion_round += 1

                role_cfg = CONFIG['DISCUSSION_ROLES'].get(speaker["role"])
                if not role_cfg or 'turn_template' not in role_cfg:
                    log(f"  ⚠ Role '{speaker['role']}' has no turn_template — skipping this speaker's turn\n")
                    self.add_log(f"Discussion role '{speaker['role']}' missing turn_template", "WARNING")
                    continue

                log(f"\n▶ Round {self.discussion_round} — {speaker['role']} ({speaker['model_display']})\n")
                self.add_log(f"Discussion round {self.discussion_round}: {speaker['role']} "
                             f"({speaker['model_display']})", "INFO")

                transcript_context = self._summarize_discussion()
                turn_prompt = role_cfg['turn_template'].format(topic=topic, transcript=transcript_context)

                response = requests.post(
                    f"{self.api_base}{CONFIG['API']['chat_endpoint']}",
                    json={
                        "model": speaker["model_key"],
                        "messages": [{"role": "user", "content": turn_prompt}],
                        "temperature": 0.7,
                        "max_tokens": dcfg['turn_max_tokens']
                    },
                    timeout=self.timeout_var.get()
                )

                if response.status_code != 200:
                    log(f"  ❌ API error {response.status_code} — skipping this turn\n")
                    self.add_log(f"Discussion API error: {response.status_code}", "ERROR")
                    time.sleep(1)
                    continue

                result = response.json()
                turn_text = result['choices'][0]['message']['content'].strip()

                if 'usage' in result:
                    tokens_used = result['usage'].get('total_tokens', 0)
                    self.session_tokens += tokens_used
                    self.root.after(0, lambda: self.session_tokens_label.config(text=str(self.session_tokens)))

                if not turn_text:
                    log("  — Empty response, skipping\n")
                    continue

                # Run the same Constraint Engine the cascade/research use, so a turn with e.g.
                # double spaces or a missing capital gets the same auto-fix treatment.
                if self.engine_loaded and self.engine and self.engine_enabled_var.get():
                    validation_result = self.engine.validate(turn_text, auto_fix=True)
                    if validation_result.get('success') and 'data' in validation_result:
                        turn_text = validation_result['data']
                    elif not validation_result.get('success'):
                        log(f"  ⚠ Constraint validation failed at {validation_result.get('failed_at')} "
                            f"— keeping turn unvalidated\n")

                # Stall detection — near-duplicate of a recent turn means this speaker (or the
                # discussion generally) has nothing new left to say.
                recent_texts = [t['text'] for t in self.discussion_transcript[-6:]]
                is_stalled_turn = self._text_is_near_duplicate(turn_text, recent_texts)

                log(f"  {turn_text}\n")

                self.discussion_transcript.append({
                    "speaker": speaker["model_display"], "role": speaker["role"],
                    "text": turn_text, "round": self.discussion_round
                })
                self._save_discussion_transcript()

                if is_stalled_turn:
                    self.discussion_stall_streak += 1
                    log(f"  (near-duplicate of a recent turn — stall streak {self.discussion_stall_streak})\n")
                else:
                    self.discussion_stall_streak = 0

                self.root.after(0, self._update_discussion_status_display)

                if self.discussion_stall_streak >= stall_threshold:
                    log(f"\n⏸ {stall_threshold} consecutive near-duplicate turns — auto-pausing "
                        f"(discussion may have run its course)\n")
                    self.add_log("Discussion auto-paused: appears to have stalled", "INFO")
                    self.discussion_paused = True
                    self.discussion_stall_streak = 0
                    self.root.after(0, lambda: self.pause_discussion_btn.config(
                        text=CONFIG['TEXT']['btn_discussion_resume']))
                    self.root.after(0, self._update_discussion_status_display)
                    self._maybe_compact_discussion(topic, speaker["model_key"], log)
                    moderator = next((p for p in participants if p["role"] == "Moderator"), None)
                    if moderator:
                        log("\n▶ Moderator synthesis...\n")
                        synthesis = self._get_moderator_synthesis(topic, moderator["model_key"], log)
                        if synthesis:
                            log(f"\n{'═' * 50}\n  MODERATOR SYNTHESIS\n{'═' * 50}\n\n{synthesis}\n")
                            self.discussion_transcript.append({
                                "speaker": moderator["model_display"], "role": "Moderator (synthesis)",
                                "text": synthesis, "round": self.discussion_round
                            })
                            self._save_discussion_transcript()

                compact_every = self._get_discussion_compact_interval()
                if compact_every > 0 and self.discussion_round % compact_every == 0:
                    self._maybe_compact_discussion(topic, speaker["model_key"], log)

                time.sleep(0.3)  # brief pacing between turns

            # Manual/clean stop — one last compaction pass, same reasoning as Research.
            self._maybe_compact_discussion(topic, participants[0]["model_key"], log)

            log(f"\n■ Discussion stopped at round {self.discussion_round} "
                f"({len(self.discussion_transcript)} total turns saved)\n")
            self.add_log(f"Discussion stopped: {len(self.discussion_transcript)} total turns", "INFO")

        except requests.exceptions.RequestException as e:
            log(f"\n❌ Connection error: {str(e)}\n")
            self.add_log(f"Discussion connection error: {str(e)}", "ERROR")
        except Exception as e:
            log(f"\n❌ Error: {str(e)}\n")
            self.add_log(f"Discussion error: {str(e)}", "ERROR")
        finally:
            self.discussion_running = False
            self.root.after(0, self._update_discussion_status_display)


if __name__ == "__main__":
    root = tk.Tk()
    root.withdraw()
    app = LMStudioOrchestrator(root)
    root.mainloop()
