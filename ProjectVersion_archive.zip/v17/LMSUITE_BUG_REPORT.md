# LMSuite.py - Comprehensive Bug Report

## CRITICAL BUGS

### 1. **Tkinter Thread Safety Violations** ⚠️ CRITICAL
**Location**: Lines 2999-3015, 3419-3425
**Problem**: Tkinter widgets are being modified directly from daemon threads.

```python
# CURRENT CODE (WRONG):
def _append_output(text):
    """Thread-safe append to cascade output"""
    self.cascade_output.config(state=tk.NORMAL)  # ← CALLED FROM DAEMON THREAD!
    self.cascade_output.insert(tk.END, text)
    self.cascade_output.see(tk.END)
    self.cascade_output.config(state=tk.DISABLED)
    self.root.update()  # ← DANGEROUS! This blocks the main thread
```

**Impact**: Race conditions, crashes, unpredictable behavior. Tkinter is NOT thread-safe.

**Fix**: Use `self.root.after()` for thread-safe widget updates:
```python
def _append_output(text):
    """Thread-safe append to cascade output"""
    def update_widget():
        self.cascade_output.config(state=tk.NORMAL)
        self.cascade_output.insert(tk.END, text)
        self.cascade_output.see(tk.END)
        self.cascade_output.config(state=tk.DISABLED)
    self.root.after(0, update_widget)
```

**Affected Functions**:
- `_append_output()` @ line 3002
- `_set_output()` @ line 3009
- `_append_research_output()` @ line 3419
- All thread target functions that call these

---

### 2. **Bare `except:` Statements** ⚠️ HIGH PRIORITY
**Location**: Lines 100, 262, 1177, 1182, 2050, 2532, 2546, 2583, 2645, 2779, 2808, 2841

**Problem**: Bare `except:` catches ALL exceptions, including:
- `KeyboardInterrupt` (Ctrl+C) - User can't stop the program
- `SystemExit` - Can't shut down gracefully
- `GeneratorExit` - Breaks generator protocols
- Memory/resource exceptions

**Example**:
```python
# BAD:
except:
    return False

# GOOD:
except Exception as e:
    self.add_log(f"Validation failed: {str(e)}", "ERROR")
    return False
```

**Fix**: Replace all bare `except:` with `except Exception as e:` or specific exceptions.

**Lines to Fix**:
- 100: ValidJSON.validate()
- 262: ValidJSON.validate()
- 1177-1182: MaxLength spinbox handling
- 2050: startup_thread resource error
- 2532: show_file_menu()
- 2546: show_file_menu()
- 2583: show_settings()
- 2645: _build_ui()
- 2779: check_connection()
- 2808: resource_thread()
- 2841: load_settings()

---

### 3. **Uninitialized Attribute: `self.is_connected`** ⚠️ MEDIUM
**Location**: Line 2657 assignment, no initialization in `__init__`

**Problem**:
```python
def __init__(self):
    # ... other init code ...
    # self.is_connected NOT initialized!

def run_startup_checks(self):
    def startup_thread():
        self.is_connected = self.check_connection()  # ← First assignment
```

If `run_startup_checks()` never completes, or if code references `self.is_connected` before startup_thread runs, it will crash with `AttributeError`.

**Fix**: Initialize in `__init__`:
```python
def __init__(self):
    self.is_connected = False  # Add this line
```

---

## MAJOR BUGS

### 4. **Research Loop Thread Safety** ⚠️ HIGH
**Location**: Lines 3651-3812 (`_research_loop` method)

**Problem**: The nested `log()` function uses `self.root.after()` to schedule GUI updates, BUT the `_append_research_output` function directly modifies Tkinter widgets without scheduling:

```python
def _append_research_output(self, text):
    """Thread-safe append to the research log box"""
    self.research_output.config(state=tk.NORMAL)  # ← NOT scheduled via after()
    self.research_output.insert(tk.END, text)     # ← Direct widget modification
    self.research_output.see(tk.END)
    self.research_output.config(state=tk.DISABLED)
```

**Fix**: Use `self.root.after()` inside `_append_research_output`:
```python
def _append_research_output(self, text):
    """Thread-safe append to the research log box"""
    def update():
        self.research_output.config(state=tk.NORMAL)
        self.research_output.insert(tk.END, text)
        self.research_output.see(tk.END)
        self.research_output.config(state=tk.DISABLED)
    self.root.after(0, update)
```

---

### 5. **Potential KeyError in Config Access**
**Location**: Line 2079 (`pass_config['role']`)

**Problem**: The code assumes `CONFIG['CASCADE_PASSES'][pass_num]` exists but doesn't validate:

```python
# In cascade_thread():
for pass_idx, (pass_num, model_name, model_key) in enumerate(selected_passes):
    pass_config = CONFIG['CASCADE_PASSES'][pass_num]  # ← What if pass_num is invalid?
    # ...
    _append_output(f"▶ Pass {pass_num} ({pass_config['role']}): {model_name}\n")
```

If `pass_num` is corrupted or invalid, this crashes with `KeyError`.

**Fix**:
```python
pass_config = CONFIG['CASCADE_PASSES'].get(pass_num)
if not pass_config:
    error_msg = f"Invalid pass number: {pass_num}"
    _append_output(f"❌ {error_msg}\n")
    self.add_log(error_msg, "ERROR")
    continue
```

---

### 6. **Rating Extraction Regex Could Fail Silently**
**Location**: Lines 2908-2916

**Problem**: If the supervisor response doesn't contain "Average rating:" or "rating:", the rating stays `None` but the code doesn't warn the user:

```python
rating = None
for line in lines:
    if 'Average rating:' in line or 'rating:' in line.lower():
        match = re.search(r'(\d+\.?\d*)\s*/?10', line)
        if match:
            rating = float(match.group(1))
            break

return {
    'analysis': analysis,
    'rating': rating if rating else 0,  # ← Silently defaults to 0
    'model': supervisor_model
}
```

**Fix**: Log when extraction fails:
```python
if rating is None:
    self.add_log("Warning: Could not extract rating from supervisor response", "WARNING")
    rating = 0
```

---

## MINOR BUGS & ISSUES

### 7. **Missing Error Handling for File Operations**
**Location**: Line 1269-1277 (save_config), Line 1290-1315 (load_config)

**Problem**: File I/O errors might not be properly displayed. The try/except is present but could be more specific.

**Recommendation**: Keep as-is but add more granular error messages:
```python
except IOError as e:
    messagebox.showerror("Error", f"File I/O error:\n{e}")
except json.JSONDecodeError as e:
    messagebox.showerror("Error", f"Invalid JSON format:\n{e}")
```

---

### 8. **Daemon Thread Cleanup Issue**
**Location**: Lines 2662, 2815, 3183, 3397, 3571

**Problem**: Daemon threads are set with `daemon=True`, which means they're forcefully terminated when the main thread exits. This can lead to:
- Incomplete file writes
- Incomplete API requests
- Resource leaks

**Example**:
```python
thread = threading.Thread(target=cascade_thread, daemon=True)  # ← If main exits, thread dies instantly
```

**Fix** (if data integrity is important): Use `daemon=False` and manually join/wait, OR ensure threads check `self.research_stop_requested` frequently.

**Note**: For UI responsiveness, daemon threads are often appropriate. Just be aware of potential data loss on exit.

---

### 9. **Potential IndexError in Constraint Listbox**
**Location**: Lines 934-952 (`_resolve_selection`)

**Problem**: If listbox has no entries, `curselection()` returns `()` (empty tuple), so `sel[0]` should crash. But you have a guard `if not sel: return None`, so this is actually SAFE. ✓

---

### 10. **Missing Validation for Model Keys**
**Location**: Line 2978, 2887, 3368, 3545

**Problem**: `.get()` is used without verifying the model exists:

```python
model_key = self.model_display_names.get(model_display)
if not model_key:
    return None  # ← Good, but doesn't log why it failed
```

**Recommendation**: Add logging:
```python
model_key = self.model_display_names.get(model_display)
if not model_key:
    self.add_log(f"Model '{model_display}' not found in available models", "ERROR")
    return None
```

---

## SUMMARY TABLE

| Severity | Issue | Lines | Type | Fix Difficulty |
|----------|-------|-------|------|-----------------|
| CRITICAL | Tkinter thread safety violations | 2999-3015, 3419-3425 | Thread/GUI | Medium |
| HIGH | Bare except statements | 100, 262, 1177, 1182, 2050, 2532, 2546, 2583, 2645, 2779, 2808, 2841 | Error Handling | Low |
| MEDIUM | Missing `self.is_connected` init | 2657 | Initialization | Low |
| HIGH | Research loop thread safety | 3651-3812 | Thread/GUI | Medium |
| HIGH | Potential KeyError in config access | 2079 | Dictionary Access | Low |
| MEDIUM | Silent rating extraction failure | 2908-2916 | Error Handling | Low |
| LOW | File I/O error messages | 1269-1315 | Error Messages | Low |
| LOW | Daemon thread cleanup risk | Various | Thread Management | High |
| LOW | Missing model validation logs | 2978, 2887, 3368, 3545 | Logging | Low |

---

## RECOMMENDED FIX PRIORITY

1. **FIRST**: Fix all bare `except:` statements (HIGH impact, LOW effort)
2. **SECOND**: Fix Tkinter thread safety (CRITICAL, but requires refactoring)
3. **THIRD**: Initialize `self.is_connected` (MEDIUM, LOW effort)
4. **FOURTH**: Add validation and logging to remaining issues

---

## TESTING RECOMMENDATIONS

- Test cascade generation while rapidly closing the window
- Test rapid start/stop of research mode
- Test with network interruptions during long-running operations
- Monitor for race conditions using thread debugging tools
- Verify all file saves complete even during forceful shutdown
